<?php
/**
 * config.php — Configuración central de APIs de IA
 * ══════════════════════════════════════════════════════════════════
 * ⚠️  NUNCA incluir este archivo en rutas públicas.
 *     Colocarlo FUERA del public_html, o protegerlo con .htaccess.
 *
 * Uso:  require_once __DIR__ . '/config.php';
 * ══════════════════════════════════════════════════════════════════
 */

// ── Claves de API ─────────────────────────────────────────────────
// Reemplaza cada valor con tu clave real.
// Mejor aún: cárgalas desde variables de entorno:
//   putenv("ANTHROPIC_KEY=sk-ant-...") en el panel de hosting
//   y usa: getenv("ANTHROPIC_KEY")

define('ANTHROPIC_API_KEY', getenv('ANTHROPIC_API_KEY') ?: 'sk-ant-TU_CLAVE_AQUI');
define('GEMINI_API_KEY',    getenv('GEMINI_API_KEY')    ?: 'AIzaSyCbWIjSquWdGEs0QqsS652JBWpjwc3iRDg');
define('OPENAI_API_KEY',    getenv('OPENAI_API_KEY')    ?: 'sk-TU_CLAVE_OPENAI_AQUI');

// ── Modelos por defecto ───────────────────────────────────────────
define('CLAUDE_MODEL',  'claude-sonnet-4-20250514');
define('GEMINI_MODEL',  'gemini-1.5-flash');
define('OPENAI_MODEL',  'gpt-4o-mini');

// ── Límites ───────────────────────────────────────────────────────
define('MAX_TOKENS',        1500);
define('MAX_HISTORY_MSGS',  20);    // mensajes de contexto enviados a la API
define('MAX_SAVED_CONVS',   50);    // conversaciones guardadas por usuario

// ── Proveedor por defecto para cada agente ────────────────────────
// 'claude' | 'gemini' | 'openai'
define('AGENT_PROVIDERS', [
    'asistente'   => 'claude',
    'ciberseg'    => 'claude',
    'codigo'      => 'claude',
    'aprendizaje' => 'claude',
    'analisis'    => 'gemini',   // Gemini es bueno con datos estructurados
    'proyectos'   => 'claude',
    'redaccion'   => 'openai',   // GPT es fluido en redacción
    'redes'       => 'claude',
    'ia_explica'  => 'gemini',
    'optimizador' => 'claude',
]);
