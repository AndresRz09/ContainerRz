<?php
include 'conexion.php';
session_start();

$uid      = (int)($_SESSION['user_id'] ?? 0);
$rol      = $_SESSION['rol'] ?? 'invitado';
$nombre   = htmlspecialchars($_SESSION['user_name'] ?? 'Visitante');
$avatar   = htmlspecialchars($_SESSION['avatar']    ?? 'assets/avatar-default.png');
$es_staff = in_array($rol, ['empleado','admin','superadmin']);
$es_admin = in_array($rol, ['admin','superadmin']);

// ── Helpers ─────────────────────────────────────────────────────
function qall($db,$sql,$t='',...$p):array{
    if(!$db)return[];
    $s=$db->prepare($sql);if(!$s)return[];
    if($t)$s->bind_param($t,...$p);
    $s->execute();$rows=$s->get_result()->fetch_all(MYSQLI_ASSOC);$s->close();return $rows;
}
function qrow($db,$sql,$t='',...$p):?array{
    if(!$db)return null;
    $s=$db->prepare($sql);if(!$s)return null;
    if($t)$s->bind_param($t,...$p);
    $s->execute();$r=$s->get_result()->fetch_assoc();$s->close();return $r;
}
function qval($db,$sql,$t='',...$p):mixed{
    $r=qrow($db,$sql,$t,...$p);return $r?reset($r):0;
}

// ── Ver proyecto individual ──────────────────────────────────────
$view_id = (int)($_GET['id'] ?? 0);

// ── AJAX: acciones POST ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['accion'])) {
    header('Content-Type: application/json');
    if (!$es_staff) { echo json_encode(['ok'=>false,'error'=>'Sin permisos']); exit(); }
    $a = $_POST['accion'];

    if ($a==='agregar_avance') {
        $pid   = (int)($_POST['proyecto_id']??0);
        $titulo= htmlspecialchars(trim($_POST['titulo']??''),ENT_QUOTES);
        $desc  = htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $comp  = (int)($_POST['completado']??0);
        if ($pid && $titulo) {
            $q=$conexion->prepare("INSERT INTO proyecto_avances(proyecto_id,titulo,descripcion,completado,fecha,autor_id) VALUES(?,?,?,?,CURDATE(),?)");
            if($q){$q->bind_param("issii",$pid,$titulo,$desc,$comp,$uid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos incompletos']);
        exit();
    }

    if ($a==='update_progreso' && $es_admin) {
        $pid  = (int)($_POST['proyecto_id']??0);
        $prog = min(100,max(0,(int)($_POST['progreso']??0)));
        $est  = in_array($_POST['estado']??'',['planeado','activo','pausado','completado','cancelado'])?$_POST['estado']:'activo';
        $q=$conexion->prepare("UPDATE proyectos SET progreso=?,estado=?,fecha_update=NOW() WHERE id=?");
        if($q){$q->bind_param("isi",$prog,$est,$pid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
        else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        exit();
    }

    if ($a==='add_doc' && $es_admin) {
        $pid   = (int)($_POST['proyecto_id']??0);
        $nom   = htmlspecialchars(trim($_POST['nombre']??''),ENT_QUOTES);
        $arch  = htmlspecialchars(trim($_POST['archivo']??''),ENT_QUOTES);
        $desc  = htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $tipo  = in_array($_POST['tipo']??'',['pdf','imagen','video','enlace','otro'])?$_POST['tipo']:'otro';
        if ($pid && $nom && $arch) {
            $q=$conexion->prepare("INSERT INTO proyecto_documentos(proyecto_id,nombre,archivo,descripcion,tipo,subido_por) VALUES(?,?,?,?,?,?)");
            if($q){$q->bind_param("issssi",$pid,$nom,$arch,$desc,$tipo,$uid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos incompletos']);
        exit();
    }

    if ($a==='add_kpi' && $es_admin) {
        $pid  = (int)($_POST['proyecto_id']??0);
        $nom  = htmlspecialchars(trim($_POST['nombre']??''),ENT_QUOTES);
        $val  = htmlspecialchars(trim($_POST['valor']??''),ENT_QUOTES);
        $ico  = htmlspecialchars(trim($_POST['icono']??'📊'),ENT_QUOTES);
        $meta = htmlspecialchars(trim($_POST['meta']??''),ENT_QUOTES);
        if ($pid && $nom) {
            $q=$conexion->prepare("INSERT INTO proyecto_kpis(proyecto_id,nombre,valor,icono,meta) VALUES(?,?,?,?,?)");
            if($q){$q->bind_param("issss",$pid,$nom,$val,$ico,$meta);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos incompletos']);
        exit();
    }

    if ($a==='add_imagen' && $es_admin) {
        $pid  = (int)($_POST['proyecto_id']??0);
        $url  = htmlspecialchars(trim($_POST['imagen']??''),ENT_QUOTES);
        $tit  = htmlspecialchars(trim($_POST['titulo']??''),ENT_QUOTES);
        if ($pid && $url) {
            $ord=(int)qval($conexion,"SELECT COALESCE(MAX(orden),0)+1 FROM proyecto_imagenes WHERE proyecto_id=?","i",$pid);
            $q=$conexion->prepare("INSERT INTO proyecto_imagenes(proyecto_id,imagen,titulo,orden) VALUES(?,?,?,?)");
            if($q){$q->bind_param("issi",$pid,$url,$tit,$ord);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos incompletos']);
        exit();
    }

    if ($a==='delete_avance' && $es_admin) {
        $id=(int)($_POST['id']??0);
        $q=$conexion->prepare("DELETE FROM proyecto_avances WHERE id=?");
        if($q){$q->bind_param("i",$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
        else echo json_encode(['ok'=>false]);
        exit();
    }

    echo json_encode(['ok'=>false,'error'=>'Acción no reconocida']);
    exit();
}

// ═══════════════════════════════════════════════════════════════════
//  CARGAR DATOS
// ═══════════════════════════════════════════════════════════════════
$proyectos_propios = qall($conexion,"SELECT * FROM proyectos WHERE tipo='propio' ORDER BY estado='activo' DESC, fecha_inicio DESC");
$filtro_cat  = $_GET['cat']  ?? '';
$filtro_tipo = $_GET['tipo'] ?? '';
$where = "WHERE tipo != 'propio'";
if ($filtro_cat)  $where .= " AND categoria='" . $conexion->real_escape_string($filtro_cat)  . "'";
if ($filtro_tipo) $where .= " AND subtipo='"   . $conexion->real_escape_string($filtro_tipo) . "'";
$proyectos_otros = qall($conexion,"SELECT * FROM proyectos $where ORDER BY fecha_inicio DESC");
$categorias      = qall($conexion,"SELECT DISTINCT categoria FROM proyectos WHERE tipo!='propio' AND categoria IS NOT NULL");
$categorias      = array_column($categorias,'categoria');
$total_todos     = count($proyectos_propios) + count($proyectos_otros);

// Si se solicita un proyecto específico
$proyecto_actual = null;
$proy_avances    = [];
$proy_docs       = [];
$proy_kpis       = [];
$proy_imagenes   = [];
$proy_team       = [];
$proy_stats      = [];

if ($view_id) {
    $proyecto_actual = qrow($conexion,"SELECT p.*,u.nombre AS creador_nombre,u.apellido AS creador_apellido FROM proyectos p LEFT JOIN usuarios u ON u.id=p.creado_por WHERE p.id=?","i",$view_id);
    if ($proyecto_actual && ($es_staff || !$proyecto_actual['privado'])) {
        $proy_avances  = qall($conexion,"SELECT pa.*,u.nombre AS autor_nombre FROM proyecto_avances pa LEFT JOIN usuarios u ON u.id=pa.autor_id WHERE pa.proyecto_id=? ORDER BY pa.fecha DESC","i",$view_id);
        $proy_docs     = qall($conexion,"SELECT pd.*,u.nombre AS subido_nombre FROM proyecto_documentos pd LEFT JOIN usuarios u ON u.id=pd.subido_por WHERE pd.proyecto_id=? ORDER BY pd.fecha DESC","i",$view_id);
        $proy_kpis     = qall($conexion,"SELECT * FROM proyecto_kpis WHERE proyecto_id=? ORDER BY fecha DESC","i",$view_id);
        $proy_imagenes = qall($conexion,"SELECT * FROM proyecto_imagenes WHERE proyecto_id=? ORDER BY orden ASC","i",$view_id);
        $proy_team     = qall($conexion,"SELECT pu.*,u.nombre,u.apellido,u.avatar,u.area_tecnologica,u.cargo_equipo FROM proyecto_usuarios pu JOIN usuarios u ON u.id=pu.usuario_id WHERE pu.proyecto_id=?","i",$view_id);
        $proy_stats = [
            'avances'    => count($proy_avances),
            'docs'       => count($proy_docs),
            'miembros'   => count($proy_team),
            'completados'=> count(array_filter($proy_avances,fn($a)=>$a['completado'])),
        ];
    } else {
        $proyecto_actual = null;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Proyectos — Team VIROX</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="style.css">
<style>
/* ═══════════════════════════════════════════════
   VARIABLES LOCALES
═══════════════════════════════════════════════ */
:root{
  --hh:68px;--idx-w:270px;
  --n950:#010610;--n900:#020817;--n800:#0c1526;
  --n700:#111827;--n600:#182035;--n500:#1e2d47;
  --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.13);
  --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.13);
  --blue:#3b82f6;--blue-lt:#93c5fd;--blue-dim:rgba(59,130,246,.13);
  --purple:#8b5cf6;--purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
  --red:#ef4444;--red-lt:#fca5a5;--red-dim:rgba(239,68,68,.12);
  --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
  --sh-sm:0 4px 18px rgba(0,0,0,.4);
  --sh-md:0 10px 36px rgba(0,0,0,.5);
  --sh-lg:0 24px 64px rgba(0,0,0,.65);
  --r-sm:8px;--r-md:14px;--r-lg:20px;--r-xl:28px;
  --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
}

/* ═══ LAYOUT ═══ */
.proy-layout{
  display:grid;grid-template-columns:var(--idx-w) 1fr;
  max-width:1480px;margin:0 auto;
  padding:32px 28px;gap:28px;align-items:start;
}

/* ═══ SIDEBAR ÍNDICE ═══ */
.proy-index{
  position:sticky;top:calc(var(--hh) + 18px);
  background:var(--n800);border:1px solid rgba(40,166,128,.18);
  border-radius:var(--r-xl);padding:22px 16px;
  box-shadow:var(--sh-md);
  max-height:calc(100vh - var(--hh) - 56px);overflow-y:auto;
}
.proy-index::-webkit-scrollbar{width:3px;}
.idx-brand{display:flex;align-items:center;gap:8px;margin-bottom:18px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.06);}
.idx-brand-ico{font-size:1.2rem;color:var(--green);}
.idx-brand-txt{font-family:var(--font-d);font-size:.78rem;font-weight:700;color:var(--gold);letter-spacing:2px;}
.idx-search{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:var(--r-md);padding:7px 11px;margin-bottom:14px;}
.idx-search i{color:var(--muted);font-size:.8rem;flex-shrink:0;}
.idx-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.8rem;width:100%;}
.idx-search input::placeholder{color:var(--dim);}
.idx-slbl{font-size:.6rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:0 5px;margin:12px 0 5px;}
.idx-item{display:flex;align-items:center;gap:9px;padding:8px 9px;border-radius:var(--r-md);color:var(--muted);font-size:.8rem;font-weight:500;cursor:pointer;transition:all .2s;border-left:2px solid transparent;margin-bottom:2px;}
.idx-item:hover,.idx-item.on{background:var(--green-dim);color:var(--green-lt);border-left-color:var(--green);}
.idx-item i{width:15px;text-align:center;font-size:.78rem;flex-shrink:0;}
.idx-item-badge{margin-left:auto;padding:1px 6px;background:rgba(255,255,255,.07);border-radius:99px;font-size:.6rem;color:var(--dim);}
.idx-item.on .idx-item-badge{background:rgba(40,166,128,.2);color:var(--green-lt);}
.idx-stats{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:18px;padding-top:14px;border-top:1px solid rgba(255,255,255,.06);}
.idx-stat{background:rgba(255,255,255,.04);border-radius:var(--r-md);padding:9px 7px;text-align:center;}
.idx-stat-n{font-family:var(--font-d);font-size:1.2rem;font-weight:900;color:var(--gold);}
.idx-stat-l{font-size:.58rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

/* Staff panel en sidebar */
.idx-staff-panel{background:rgba(40,166,128,.06);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-lg);padding:12px;margin-top:16px;}
.idx-staff-ttl{font-size:.62rem;font-weight:800;color:var(--green-lt);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px;}
.staff-btn{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:var(--r-md);font-size:.78rem;font-weight:600;color:var(--txt);cursor:pointer;transition:all .2s;margin-bottom:4px;border:none;font-family:var(--font-b);background:none;width:100%;text-align:left;}
.staff-btn:hover{background:rgba(40,166,128,.15);}
.staff-btn i{color:var(--green-lt);width:16px;text-align:center;}

/* ═══ MAIN ═══ */
.proy-main{min-width:0;}

/* ═══ HERO PROYECTO INDIVIDUAL ═══ */
.proj-hero{
  position:relative;overflow:hidden;
  border-radius:var(--r-xl);margin-bottom:24px;
  border:1px solid rgba(40,166,128,.2);
}
.proj-hero-banner{
  height:180px;position:relative;overflow:hidden;
  display:flex;align-items:flex-end;padding:24px 28px;
}
.phb-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.05) 1px,transparent 1px);background-size:32px 32px;}
.phb-orb1{position:absolute;width:320px;height:320px;border-radius:50%;filter:blur(80px);background:radial-gradient(circle,rgba(40,166,128,.22),transparent 70%);right:-80px;top:-100px;animation:orb1 8s ease-in-out infinite;}
.phb-orb2{position:absolute;width:220px;height:220px;border-radius:50%;filter:blur(80px);background:radial-gradient(circle,rgba(218,165,32,.14),transparent 70%);left:-40px;bottom:-60px;animation:orb1 11s ease-in-out infinite reverse;}
@keyframes orb1{0%,100%{transform:translate(0,0)}50%{transform:translate(14px,-14px)}}
.phb-content{position:relative;z-index:1;flex:1;}
.phb-status{display:inline-flex;align-items:center;gap:5px;padding:3px 11px;border-radius:99px;font-size:.68rem;font-weight:700;letter-spacing:.5px;margin-bottom:7px;}
.st-active{background:rgba(40,166,128,.2);border:1px solid var(--green);color:var(--green-lt);}
.st-pause{background:rgba(218,165,32,.15);border:1px solid var(--gold);color:var(--gold-lt);}
.st-done{background:rgba(59,130,246,.15);border:1px solid #3b82f6;color:#93c5fd;}
.st-planned{background:rgba(139,92,246,.15);border:1px solid #8b5cf6;color:#c4b5fd;}
.st-cancelled{background:rgba(239,68,68,.15);border:1px solid var(--red);color:var(--red-lt);}
.phb-title{font-family:var(--font-d);font-size:clamp(1.2rem,2.5vw,1.7rem);font-weight:900;color:var(--txt);letter-spacing:1px;}
.phb-actions{position:relative;z-index:1;display:flex;gap:7px;align-self:flex-start;margin-top:6px;}
.phb-act{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.8rem;cursor:pointer;transition:all .2s;text-decoration:none;}
.phb-act:hover{background:rgba(40,166,128,.2);color:var(--green-lt);border-color:var(--green);}

/* Meta row */
.proj-meta-row{display:flex;align-items:center;gap:10px;padding:16px 24px;background:var(--n800);flex-wrap:wrap;border-top:1px solid rgba(255,255,255,.06);}
.proj-meta-chip{display:flex;align-items:center;gap:6px;font-size:.75rem;color:var(--muted);}
.proj-meta-chip i{color:var(--green-lt);font-size:.72rem;}
.proj-meta-div{width:1px;height:14px;background:rgba(255,255,255,.1);}

/* ═══ TABS DEL PROYECTO ═══ */
.proj-tabs{display:flex;gap:2px;background:rgba(255,255,255,.04);padding:3px;border-radius:var(--r-md);margin-bottom:22px;overflow-x:auto;}
.proj-tab{padding:8px 16px;border-radius:10px;font-size:.78rem;font-weight:600;color:var(--muted);cursor:pointer;transition:all .2s;border:none;background:none;font-family:var(--font-b);white-space:nowrap;}
.proj-tab:hover{color:var(--txt);}
.proj-tab.on{background:var(--green);color:#fff;box-shadow:0 2px 12px rgba(40,166,128,.35);}
.proj-tab-content{display:none;animation:tabIn .3s ease both;}
.proj-tab-content.on{display:block;}
@keyframes tabIn{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}

/* ═══ INFO CARDS ═══ */
.info-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px;margin-bottom:18px;}
.info-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:12px 14px;}
.info-lbl{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
.info-val{font-size:.86rem;color:var(--txt);font-weight:600;}

/* ═══ PROGRESO GRANDE ═══ */
.prog-section{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px 20px;margin-bottom:18px;}
.prog-hd{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;}
.prog-lbl{font-size:.78rem;color:var(--muted);font-weight:600;}
.prog-pct{font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);}
.prog-bar{height:8px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
.prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1.2s ease;}
.prog-steps{display:flex;gap:6px;margin-top:12px;flex-wrap:wrap;}
.prog-step{padding:3px 10px;border-radius:99px;font-size:.65rem;font-weight:600;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);color:var(--dim);}
.prog-step.done{background:var(--green-dim);border-color:rgba(40,166,128,.3);color:var(--green-lt);}

/* ═══ KPIs ═══ */
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:10px;margin-bottom:18px;}
.kpi-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:14px 12px;text-align:center;transition:border-color .2s,transform .25s;cursor:pointer;}
.kpi-card:hover{border-color:rgba(218,165,32,.35);transform:translateY(-3px);}
.kpi-ico{font-size:1.5rem;margin-bottom:5px;}
.kpi-val{font-family:var(--font-d);font-size:1.15rem;font-weight:700;color:var(--gold);}
.kpi-lbl{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}
.kpi-meta{font-size:.62rem;color:var(--green-lt);margin-top:2px;}

/* ═══ TAGS ═══ */
.tag-row{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px;}
.tag{padding:3px 11px;border-radius:99px;font-size:.7rem;font-weight:600;}
.tag-tech{background:rgba(218,165,32,.1);border:1px solid rgba(218,165,32,.25);color:var(--gold-lt);}
.tag-area{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.25);color:var(--green-lt);}

/* ═══ TIMELINE AVANCES ═══ */
.timeline{display:flex;flex-direction:column;}
.tl-item{display:flex;gap:14px;padding-bottom:18px;position:relative;}
.tl-item:not(:last-child)::before{content:'';position:absolute;left:12px;top:26px;width:2px;height:calc(100% - 18px);background:rgba(255,255,255,.07);}
.tl-dot{width:26px;height:26px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.7rem;z-index:1;}
.tl-done{background:var(--green-dim);border:2px solid var(--green);color:var(--green);}
.tl-pend{background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.15);color:var(--dim);}
.tl-body{flex:1;}
.tl-title{font-size:.86rem;font-weight:700;color:var(--txt);margin-bottom:3px;}
.tl-desc{font-size:.76rem;color:var(--muted);line-height:1.55;}
.tl-meta{display:flex;gap:10px;margin-top:5px;flex-wrap:wrap;}
.tl-meta-chip{font-size:.62rem;color:var(--dim);display:flex;align-items:center;gap:3px;}
.tl-del{opacity:0;transition:opacity .2s;padding:3px 7px;background:var(--red-dim);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-sm);color:var(--red-lt);font-size:.65rem;cursor:pointer;}
.tl-item:hover .tl-del{opacity:1;}

/* ═══ DOCUMENTOS ═══ */
.doc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;}
.doc-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;gap:8px;cursor:pointer;transition:all .25s;text-decoration:none;}
.doc-card:hover{border-color:rgba(40,166,128,.35);transform:translateY(-4px);box-shadow:var(--sh-sm);}
.doc-ico{font-size:2rem;}
.doc-name{font-size:.84rem;font-weight:700;color:var(--txt);}
.doc-desc{font-size:.72rem;color:var(--muted);line-height:1.45;}
.doc-meta{font-size:.62rem;color:var(--dim);display:flex;align-items:center;gap:5px;}
.doc-badge{padding:2px 8px;border-radius:99px;font-size:.6rem;font-weight:700;}
.db-pdf{background:rgba(239,68,68,.15);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
.db-video{background:rgba(139,92,246,.15);color:var(--purple-lt);border:1px solid rgba(139,92,246,.3);}
.db-imagen{background:rgba(40,166,128,.15);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.db-enlace{background:rgba(59,130,246,.15);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
.db-otro{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.1);}

/* ═══ GALERÍA ═══ */
.gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;}
.gallery-img{aspect-ratio:16/9;border-radius:var(--r-lg);overflow:hidden;cursor:pointer;position:relative;}
.gallery-img img{width:100%;height:100%;object-fit:cover;transition:transform .4s;}
.gallery-img:hover img{transform:scale(1.07);}
.gallery-img-ov{position:absolute;inset:0;background:rgba(0,0,0,.4);display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .3s;}
.gallery-img:hover .gallery-img-ov{opacity:1;}
.gallery-img-ov i{color:#fff;font-size:1.5rem;}

/* ═══ DEMO ═══ */
.demo-panel{background:linear-gradient(135deg,#050d1a,#0a1a0d);border:1px solid rgba(40,166,128,.25);border-radius:var(--r-xl);overflow:hidden;}
.demo-header{padding:22px 24px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;}
.demo-embed{width:100%;aspect-ratio:16/9;background:#000;border:none;}
.demo-links{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;padding:20px 24px;}
.demo-link{display:flex;align-items:center;gap:12px;padding:14px 16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-lg);cursor:pointer;transition:all .2s;text-decoration:none;}
.demo-link:hover{background:var(--green-dim);border-color:rgba(40,166,128,.3);}
.demo-link-ico{width:36px;height:36px;border-radius:var(--r-md);background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0;}
.demo-link-name{font-size:.82rem;font-weight:700;color:var(--txt);}
.demo-link-desc{font-size:.68rem;color:var(--muted);}

/* ═══ TEAM ═══ */
.team-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;}
.team-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:16px;text-align:center;transition:all .25s;cursor:pointer;}
.team-card:hover{border-color:rgba(40,166,128,.3);transform:translateY(-3px);}
.team-av{width:52px;height:52px;border-radius:50%;object-fit:cover;border:2px solid var(--green);margin:0 auto 9px;box-shadow:0 0 14px rgba(40,166,128,.25);}
.team-av-ph{width:52px;height:52px;border-radius:50%;background:var(--green-dim);border:2px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:1.1rem;margin:0 auto 9px;}
.team-name{font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:3px;}
.team-rol{font-size:.68rem;color:var(--green-lt);margin-bottom:3px;}
.team-area{font-size:.62rem;color:var(--dim);}

/* ═══ TARJETA PROYECTO (vista lista) ═══ */
.proy-card{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);margin-bottom:18px;overflow:hidden;transition:border-color .3s,box-shadow .3s;}
.proy-card:hover{border-color:rgba(40,166,128,.35);box-shadow:var(--sh-md);}
.pc-banner{height:140px;background:linear-gradient(135deg,#0b1f40,#162640,#0e2a1f);position:relative;overflow:hidden;display:flex;align-items:flex-end;padding:18px 24px;}
.pc-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:32px 32px;}
.pc-orb{position:absolute;width:260px;height:260px;border-radius:50%;filter:blur(70px);background:radial-gradient(circle,rgba(40,166,128,.18),transparent 70%);right:-60px;top:-80px;}
.pc-content{position:relative;z-index:1;flex:1;}
.pc-name{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--txt);letter-spacing:.5px;}
.pc-acts{position:relative;z-index:1;display:flex;gap:7px;align-self:flex-start;margin-top:4px;}
.pc-act{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.75rem;cursor:pointer;transition:all .2s;text-decoration:none;}
.pc-act:hover{background:rgba(40,166,128,.2);color:var(--green-lt);border-color:var(--green);}
.pc-body{padding:20px 24px;}

/* Tabs tarjeta */
.pc-tabs{display:flex;gap:2px;margin-bottom:18px;background:rgba(255,255,255,.04);padding:3px;border-radius:var(--r-md);width:fit-content;overflow-x:auto;}
.pc-tab{padding:7px 14px;border-radius:9px;font-size:.76rem;font-weight:600;color:var(--muted);cursor:pointer;transition:all .2s;border:none;background:none;font-family:var(--font-b);white-space:nowrap;}
.pc-tab:hover{color:var(--txt);}
.pc-tab.on{background:var(--green);color:#fff;box-shadow:0 2px 10px rgba(40,166,128,.3);}
.pc-tc{display:none;}
.pc-tc.on{display:block;animation:tabIn .3s ease both;}
.pc-desc{font-size:.86rem;color:var(--muted);line-height:1.75;margin-bottom:14px;}
.pc-prog-bar{height:5px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;margin:10px 0;}
.pc-prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}

/* ═══ OTROS PROYECTOS GRID ═══ */
.otros-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;}
.otro-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);overflow:hidden;cursor:pointer;transition:all .25s;}
.otro-card:hover{transform:translateY(-5px);border-color:rgba(40,166,128,.3);box-shadow:var(--sh-md);}
.oc-band{height:4px;}
.oc-body{padding:16px 18px;}
.oc-top{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
.oc-ico{width:40px;height:40px;border-radius:var(--r-md);background:var(--n600);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.oc-title{font-size:.9rem;font-weight:800;color:var(--txt);}
.oc-sub{font-size:.68rem;color:var(--muted);}
.oc-desc{font-size:.76rem;color:var(--muted);line-height:1.55;margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.oc-footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.06);}
.oc-prog{font-family:var(--font-d);font-size:.78rem;color:var(--gold);}
.oc-prog-bar{height:3px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden;margin-top:4px;}
.oc-prog-fill{height:100%;background:var(--green);border-radius:99px;}

/* ═══ STAFF TOOLS PANEL ═══ */
.staff-panel{background:rgba(40,166,128,.04);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-xl);padding:18px 20px;margin-bottom:22px;}
.sp-hd{display:flex;align-items:center;gap:8px;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.06);}
.sp-hd-ttl{font-family:var(--font-d);font-size:.8rem;font-weight:700;color:var(--green-lt);letter-spacing:1px;}
.sp-hd-badge{padding:2px 8px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;font-size:.6rem;font-weight:800;color:var(--green-lt);letter-spacing:1px;text-transform:uppercase;}
.sp-actions{display:flex;gap:8px;flex-wrap:wrap;}
.sp-btn{display:inline-flex;align-items:center;gap:6px;padding:7px 15px;border-radius:99px;font-size:.76rem;font-weight:700;transition:all .2s;cursor:pointer;border:none;font-family:var(--font-b);}
.spb-green{background:var(--green);color:#fff;}
.spb-green:hover{background:var(--green-lt);}
.spb-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
.spb-gold:hover{background:var(--gold);color:#000;}
.spb-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.spb-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt);}
.spb-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.spb-red:hover{background:var(--red);color:#fff;}

/* ═══ MODAL ═══ */
.p-modal{position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;overflow-y:auto;}
.p-modal.on{display:flex;}
.pm-box{background:var(--n800);border:1px solid rgba(40,166,128,.22);border-radius:var(--r-xl);width:100%;max-width:560px;box-shadow:var(--sh-lg);animation:mIn .3s ease both;margin:auto;}
.pm-box.wide{max-width:900px;}
.pm-box.fs{max-width:98vw;height:90vh;display:flex;flex-direction:column;}
@keyframes mIn{from{opacity:0;transform:scale(.95)translateY(14px)}to{opacity:1;transform:none}}
.pm-hd{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.07);}
.pm-ttl{font-family:var(--font-d);font-size:.84rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.pm-cls{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
.pm-cls:hover{background:var(--red-dim);color:#f87171;}
.pm-body{padding:18px 20px;}
.pm-box.fs .pm-body{flex:1;overflow:auto;padding:0;}
.pm-foot{padding:13px 20px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:8px;justify-content:flex-end;}
.fg{margin-bottom:12px;}
.fl{display:block;font-size:.66rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:5px;}
.fi{width:100%;padding:9px 13px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.86rem;transition:all .2s;outline:none;}
.fi:focus{border-color:var(--green);background:rgba(40,166,128,.05);}
textarea.fi{resize:vertical;min-height:72px;line-height:1.6;}
select.fi option{background:var(--n700);}
.fg-2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.em-btn{padding:9px 20px;border-radius:var(--r-md);font-weight:700;font-size:.82rem;transition:all .2s;cursor:pointer;border:none;font-family:var(--font-b);}
.em-btn-green{background:var(--green);color:#fff;}
.em-btn-green:hover{background:var(--green-lt);}
.em-btn-cancel{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.em-btn-cancel:hover{background:rgba(255,255,255,.1);color:var(--txt);}

/* ═══ TOAST ═══ */
.toast-w{position:fixed;bottom:22px;right:22px;z-index:10000;display:flex;flex-direction:column;gap:7px;}
.tst{display:flex;align-items:center;gap:9px;padding:10px 16px;border-radius:var(--r-md);font-size:.8rem;font-weight:600;animation:tstIn .3s ease both;max-width:310px;box-shadow:var(--sh-md);}
@keyframes tstIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:none}}
.t-ok{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
.t-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.t-info{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}

/* ═══ EMPTY ═══ */
.empty{text-align:center;padding:36px 18px;color:var(--dim);}
.empty-ico{font-size:2.8rem;opacity:.25;margin-bottom:10px;}
.empty-txt{font-size:.86rem;}

/* Módulo separador */
.proy-module{margin-bottom:60px;}
.mod-hd{display:flex;align-items:center;gap:14px;margin-bottom:22px;flex-wrap:wrap;}
.mod-num{font-family:var(--font-d);font-size:.62rem;font-weight:900;color:var(--green);letter-spacing:2px;opacity:.6;}
.mod-title{font-family:var(--font-d);font-size:1.3rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.mod-line{flex:1;height:1px;background:linear-gradient(to right,rgba(40,166,128,.35),transparent);}
.mod-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 18px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.82rem;transition:all .2s;flex-shrink:0;border:none;cursor:pointer;font-family:var(--font-b);}
.mod-btn:hover{background:var(--green-lt);transform:translateY(-2px);}
.mod-btn-ghost{background:transparent;border:1.5px solid rgba(40,166,128,.4);color:var(--green-lt);}
.mod-btn-ghost:hover{background:var(--green-dim);border-color:var(--green);}

/* FAB */
.fab{position:fixed;bottom:28px;right:28px;width:52px;height:52px;border-radius:50%;background:var(--green);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.2rem;box-shadow:0 8px 28px rgba(40,166,128,.45);cursor:pointer;transition:all .3s;z-index:100;border:none;}
.fab:hover{transform:scale(1.1) rotate(90deg);box-shadow:0 10px 32px rgba(40,166,128,.6);}

/* Iframe doc */
.iframe-doc{width:100%;height:80vh;border:none;border-radius:var(--r-lg);}

/* ═══ RESPONSIVE ═══ */
@media(max-width:1024px){.proy-layout{grid-template-columns:230px 1fr;gap:20px;padding:20px 16px;}}
@media(max-width:820px){.proy-layout{grid-template-columns:1fr;}.proy-index{position:static;max-height:none;}.otros-grid{grid-template-columns:1fr;}.proj-tabs{width:100%;}}
@media(max-width:560px){.info-grid{grid-template-columns:1fr 1fr;}.kpi-grid{grid-template-columns:1fr 1fr;}.fg-2{grid-template-columns:1fr;}}
</style>
</head>
<body>

<!-- ═══════════════════════════════════════
     HEADER
═══════════════════════════════════════ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link active">Proyectos</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php"        class="nav-link">Aprendizaje</a>
      <a href="IA.php"        class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>
      <?php if(!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span style="width:26px;height:26px;background:var(--n500);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span>
          </button>
          <div class="user-drop">
            <?php if($es_staff): ?>
            <a href="<?= $rol==='superadmin'?'superadmin.php':($rol==='admin'?'admin/index.php':'empleado/index.php') ?>"><i class="fa fa-gauge-high"></i> Mi Panel</a>
            <?php endif; ?>
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi Perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Salir</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ═══════════════════════════════════════
     HERO
═══════════════════════════════════════ -->
<div style="background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,var(--n950) 70%);padding:48px 28px 36px;text-align:center;position:relative;overflow:hidden;border-bottom:1px solid rgba(40,166,128,.15);">
  <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:48px 48px;"></div>
  <div style="position:relative;z-index:1;max-width:700px;margin:auto;">
    <span style="display:inline-block;padding:4px 14px;background:rgba(40,166,128,.12);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.73rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:14px;">⬡ Proyectos — Team VIROX</span>
    <h1 style="font-family:var(--font-d);font-size:clamp(1.8rem,3vw,2.8rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:10px;">Nuestros <span style="color:var(--gold);text-shadow:0 0 28px rgba(218,165,32,.4);">Proyectos</span></h1>
    <p style="font-size:.93rem;color:var(--muted);line-height:1.7;">Exploración, desarrollo y colaboración. Desde videojuegos educativos hasta plataformas empresariales.</p>
    <?php if($es_staff): ?>
    <div style="display:inline-flex;gap:8px;margin-top:14px;padding:8px 16px;background:rgba(40,166,128,.08);border:1px solid rgba(40,166,128,.2);border-radius:99px;align-items:center;">
      <span style="font-size:.72rem;color:var(--green-lt);font-weight:700;"><i class="fa fa-shield-halved"></i> Acceso de <?= ucfirst($rol) ?> habilitado</span>
    </div>
    <?php endif; ?>
  </div>
</div>


<!-- ═══════════════════════════════════════
     LAYOUT PRINCIPAL
═══════════════════════════════════════ -->
<div class="proy-layout">

  <!-- ─── SIDEBAR ─────────────────────────── -->
  <aside class="proy-index" id="proyIndex">
    <div class="idx-brand">
      <span class="idx-brand-ico">🚀</span>
      <span class="idx-brand-txt">Índice</span>
    </div>

    <div class="idx-search">
      <i class="fa fa-search"></i>
      <input type="text" id="idxSearch" placeholder="Buscar proyecto...">
    </div>

    <div class="idx-slbl">Proyectos Propios</div>
    <?php if(empty($proyectos_propios)): ?>
    <div class="idx-item"><i class="fa fa-folder-open"></i><span>Sin proyectos aún</span><span class="idx-item-badge">0</span></div>
    <?php else: foreach($proyectos_propios as $p):
      $ico_est=match($p['estado']??'activo'){'completado'=>'fa-check-circle','pausado'=>'fa-pause-circle','planeado'=>'fa-clock',default=>'fa-circle-dot'};
    ?>
    <div class="idx-item" id="idx-pp-<?= $p['id'] ?>" onclick="verProyecto(<?= $p['id'] ?>)" data-name="<?= htmlspecialchars(strtolower($p['titulo']??'')) ?>">
      <i class="fa <?= $ico_est ?>"></i>
      <span><?= htmlspecialchars($p['titulo']??'Sin título') ?></span>
      <span class="idx-item-badge"><?= $p['progreso']??0 ?>%</span>
    </div>
    <?php endforeach; endif; ?>

    <div class="idx-slbl" style="margin-top:14px;">Categorías</div>
    <div class="idx-item" onclick="filterCat('',this)"><i class="fa fa-border-all"></i><span>Todos</span><span class="idx-item-badge"><?= count($proyectos_otros) ?></span></div>
    <?php foreach($categorias as $cat): ?>
    <div class="idx-item" onclick="filterCat('<?= htmlspecialchars($cat,ENT_QUOTES) ?>',this)" data-name="<?= htmlspecialchars(strtolower($cat)) ?>">
      <i class="fa fa-layer-group"></i><span><?= htmlspecialchars($cat) ?></span>
    </div>
    <?php endforeach; ?>

    <?php if($es_staff): ?>
    <div class="idx-staff-panel">
      <div class="idx-staff-ttl">🔑 Herramientas del equipo</div>
      <button class="staff-btn" onclick="abrirModal('mNuevoAvance')"><i class="fa fa-plus-circle"></i> Nuevo avance</button>
      <?php if($es_admin): ?>
      <button class="staff-btn" onclick="abrirModal('mNuevoDoc')"><i class="fa fa-file-arrow-up"></i> Subir documento</button>
      <button class="staff-btn" onclick="abrirModal('mNuevoKpi')"><i class="fa fa-chart-bar"></i> Agregar KPI</button>
      <button class="staff-btn" onclick="abrirModal('mNuevaImagen')"><i class="fa fa-image"></i> Agregar captura</button>
      <button class="staff-btn" onclick="abrirModal('mProgreso')"><i class="fa fa-sliders"></i> Actualizar progreso</button>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="idx-stats">
      <div class="idx-stat"><div class="idx-stat-n"><?= count($proyectos_propios) ?></div><div class="idx-stat-l">Propios</div></div>
      <div class="idx-stat"><div class="idx-stat-n"><?= count($proyectos_otros) ?></div><div class="idx-stat-l">Comunidad</div></div>
      <div class="idx-stat"><div class="idx-stat-n"><?= $total_todos ?></div><div class="idx-stat-l">Total</div></div>
      <div class="idx-stat">
        <?php $compl=count(array_filter($proyectos_propios,fn($p)=>($p['estado']??'')=='completado')); ?>
        <div class="idx-stat-n"><?= $compl ?></div><div class="idx-stat-l">Listos</div>
      </div>
    </div>
  </aside>


  <!-- ─── CONTENIDO ──────────────────────────── -->
  <main class="proy-main">

    <!-- ══ VISTA INDIVIDUAL DE PROYECTO ══ -->
    <?php if ($proyecto_actual): ?>
    <?php
      $p   = $proyecto_actual;
      $pid = $p['id'];
      $est = $p['estado']??'activo';
      $prog= (int)($p['progreso']??0);
      $tags_tec  = array_filter(explode(',', $p['tecnologias']??''));
      $tags_area = array_filter(explode(',', $p['areas']??''));
      $stClass   = match($est){'completado'=>'st-done','pausado'=>'st-pause','planeado'=>'st-planned','cancelado'=>'st-cancelled',default=>'st-active'};
      $stLabel   = match($est){'completado'=>'Completado','pausado'=>'En pausa','planeado'=>'Planeado','cancelado'=>'Cancelado',default=>'Activo'};
    ?>
    <div style="margin-bottom:20px;">
      <button onclick="window.history.back()" style="display:inline-flex;align-items:center;gap:7px;padding:7px 14px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;color:var(--muted);font-size:.78rem;font-weight:600;cursor:pointer;transition:all .2s;font-family:var(--font-b);" onmouseover="this.style.color='var(--txt)'" onmouseout="this.style.color='var(--muted)'">
        <i class="fa fa-arrow-left"></i> Volver a proyectos
      </button>
    </div>

    <?php if($es_staff): ?>
    <div class="staff-panel">
      <div class="sp-hd">
        <span class="sp-hd-ttl"><i class="fa fa-shield-halved"></i> Panel del Equipo</span>
        <span class="sp-hd-badge"><?= ucfirst($rol) ?></span>
      </div>
      <div class="sp-actions">
        <button class="sp-btn spb-green" onclick="document.getElementById('pa_proyecto').value=<?= $pid ?>;abrirModal('mNuevoAvance')">
          <i class="fa fa-plus"></i> Registrar avance
        </button>
        <?php if($es_admin): ?>
        <button class="sp-btn spb-gold" onclick="document.getElementById('pd_proyecto').value=<?= $pid ?>;abrirModal('mNuevoDoc')">
          <i class="fa fa-file-arrow-up"></i> Subir documento
        </button>
        <button class="sp-btn spb-ghost" onclick="document.getElementById('pk_proyecto').value=<?= $pid ?>;abrirModal('mNuevoKpi')">
          <i class="fa fa-chart-bar"></i> Agregar KPI
        </button>
        <button class="sp-btn spb-ghost" onclick="document.getElementById('pi_proyecto').value=<?= $pid ?>;abrirModal('mNuevaImagen')">
          <i class="fa fa-image"></i> Captura de pantalla
        </button>
        <button class="sp-btn spb-ghost" onclick="document.getElementById('pp_proyecto').value=<?= $pid ?>;document.getElementById('pp_prog').value=<?= $prog ?>;document.getElementById('pp_progVal').textContent='<?= $prog ?>%';document.getElementById('pp_estado').value='<?= $est ?>';abrirModal('mProgreso')">
          <i class="fa fa-sliders"></i> Progreso/Estado
        </button>
        <?php endif; ?>
        <?php if(!empty($p['url_demo'])): ?>
        <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" class="sp-btn spb-green">
          <i class="fa fa-play"></i> Jugar Demo
        </a>
        <?php endif; ?>
        <?php if(!empty($p['repositorio'])): ?>
        <a href="<?= htmlspecialchars($p['repositorio']) ?>" target="_blank" class="sp-btn spb-ghost">
          <i class="fa fa-code-branch"></i> Repositorio
        </a>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Hero del proyecto -->
    <div class="proj-hero">
      <div class="proj-hero-banner" style="background:linear-gradient(135deg,<?= $est==='activo'?'#0a1f30,#0e2a1a':'#1a0a0a,#0a0a1a' ?>);">
        <div class="phb-bg"></div>
        <div class="phb-orb1"></div>
        <div class="phb-orb2"></div>
        <div class="phb-content">
          <div class="phb-status <?= $stClass ?>"><?= $stLabel ?></div>
          <div class="phb-title"><?= htmlspecialchars($p['icono']??'🚀') ?> <?= htmlspecialchars($p['titulo']) ?></div>
        </div>
        <div class="phb-actions">
          <?php if(!empty($p['url_demo'])): ?>
          <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" class="phb-act" title="Demo"><i class="fa fa-play"></i></a>
          <?php endif; ?>
          <?php if(!empty($p['repositorio'])): ?>
          <a href="<?= htmlspecialchars($p['repositorio']) ?>" target="_blank" class="phb-act" title="Repositorio"><i class="fa fa-code-branch"></i></a>
          <?php endif; ?>
          <button class="phb-act" title="Compartir" onclick="navigator.clipboard.writeText(location.href);toast('🔗 Link copiado','info')"><i class="fa fa-share-nodes"></i></button>
        </div>
      </div>
      <div class="proj-meta-row">
        <?php if(!empty($p['tipo'])): ?>
        <div class="proj-meta-chip"><i class="fa fa-tag"></i> <?= ucfirst($p['tipo']) ?></div>
        <div class="proj-meta-div"></div>
        <?php endif; ?>
        <?php if(!empty($p['fecha_inicio'])): ?>
        <div class="proj-meta-chip"><i class="fa fa-calendar-plus"></i> <?= date('d M Y',strtotime($p['fecha_inicio'])) ?></div>
        <div class="proj-meta-div"></div>
        <?php endif; ?>
        <div class="proj-meta-chip"><i class="fa fa-users"></i> <?= $proy_stats['miembros'] ?> miembros</div>
        <div class="proj-meta-div"></div>
        <div class="proj-meta-chip"><i class="fa fa-list-check"></i> <?= $proy_stats['avances'] ?> avances</div>
        <div class="proj-meta-div"></div>
        <div class="proj-meta-chip"><i class="fa fa-file"></i> <?= $proy_stats['docs'] ?> documentos</div>
        <?php if($p['creado_por']??null): ?>
        <div class="proj-meta-div"></div>
        <div class="proj-meta-chip"><i class="fa fa-user-pen"></i> <?= htmlspecialchars($p['creador_nombre']??'') ?></div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Tabs del proyecto -->
    <div class="proj-tabs" id="projTabs">
      <button class="proj-tab on" onclick="projTab('general',this)">📋 Información</button>
      <button class="proj-tab" onclick="projTab('demo',this)">🎮 Demo & Acceso</button>
      <button class="proj-tab" onclick="projTab('docs',this)">📄 Documentación (<?= $proy_stats['docs'] ?>)</button>
      <button class="proj-tab" onclick="projTab('avances',this)">📋 Avances (<?= $proy_stats['avances'] ?>)</button>
      <button class="proj-tab" onclick="projTab('galeria',this)">🖼 Galería (<?= count($proy_imagenes) ?>)</button>
      <button class="proj-tab" onclick="projTab('kpis',this)">📊 KPIs (<?= count($proy_kpis) ?>)</button>
      <button class="proj-tab" onclick="projTab('equipo',this)">👥 Equipo (<?= $proy_stats['miembros'] ?>)</button>
    </div>

    <!-- Tab: Información General -->
    <div class="proj-tab-content on" id="ptc-general">
      <div class="info-grid">
        <div class="info-card"><div class="info-lbl">Estado</div><div class="info-val" style="color:var(--green-lt);"><?= $stLabel ?></div></div>
        <div class="info-card"><div class="info-lbl">Progreso</div><div class="info-val" style="color:var(--gold);font-family:var(--font-d);"><?= $prog ?>%</div></div>
        <div class="info-card"><div class="info-lbl">Tipo</div><div class="info-val"><?= ucfirst($p['tipo']??'—') ?></div></div>
        <div class="info-card"><div class="info-lbl">Inicio</div><div class="info-val"><?= !empty($p['fecha_inicio'])?date('d M Y',strtotime($p['fecha_inicio'])):'—' ?></div></div>
        <div class="info-card"><div class="info-lbl">Fin</div><div class="info-val"><?= !empty($p['fecha_fin'])?date('d M Y',strtotime($p['fecha_fin'])):'En curso' ?></div></div>
        <?php if($es_staff && !empty($p['presupuesto'])): ?>
        <div class="info-card"><div class="info-lbl">Presupuesto</div><div class="info-val" style="color:var(--gold);">$<?= number_format($p['presupuesto'],0,',','.') ?></div></div>
        <?php endif; ?>
      </div>

      <div class="prog-section">
        <div class="prog-hd"><span class="prog-lbl">Progreso del proyecto</span><span class="prog-pct"><?= $prog ?>%</span></div>
        <div class="prog-bar"><div class="prog-fill" style="width:<?= $prog ?>%;"></div></div>
        <div class="prog-steps">
          <?php $fases=['Diseño','Desarrollo','Pruebas','Deploy','Lanzamiento']; $por_fase=100/count($fases); foreach($fases as $i=>$f): ?>
          <span class="prog-step <?= $prog>($i+1)*$por_fase?'done':'' ?>"><?= $f ?></span>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if(!empty($p['descripcion'])): ?>
      <h3 style="font-size:.78rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:10px;">📋 Descripción</h3>
      <p style="font-size:.88rem;color:var(--muted);line-height:1.8;margin-bottom:18px;"><?= nl2br(htmlspecialchars($p['descripcion'])) ?></p>
      <?php endif; ?>

      <?php if(!empty(array_filter($tags_tec))): ?>
      <h3 style="font-size:.75rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:8px;">⚙️ Stack tecnológico</h3>
      <div class="tag-row">
        <?php foreach($tags_tec as $t): if(!trim($t))continue; ?>
        <span class="tag tag-tech"><?= htmlspecialchars(trim($t)) ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <?php if(!empty(array_filter($tags_area))): ?>
      <h3 style="font-size:.75rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:8px;margin-top:10px;">🎯 Áreas</h3>
      <div class="tag-row">
        <?php foreach($tags_area as $t): if(!trim($t))continue; ?>
        <span class="tag tag-area"><?= htmlspecialchars(trim($t)) ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Demo -->
    <div class="proj-tab-content" id="ptc-demo">
      <div class="demo-panel">
        <div class="demo-header">
          <div>
            <h3 style="font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:4px;">🎮 Demo & Acceso al Proyecto</h3>
            <p style="font-size:.78rem;color:var(--muted);">Explora el proyecto de forma interactiva o accede a sus recursos.</p>
          </div>
          <?php if(!empty($p['url_demo'])): ?>
          <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:10px 22px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.86rem;transition:all .2s;" onmouseover="this.style.background='var(--green-lt)'" onmouseout="this.style.background='var(--green)'">
            <i class="fa fa-play"></i> Abrir demo completa
          </a>
          <?php endif; ?>
        </div>

        <?php if(!empty($p['url_demo']) && (strpos($p['url_demo'],'itch.io')!==false || strpos($p['url_demo'],'iframe')!==false)): ?>
        <div style="padding:0 24px 20px;">
          <iframe src="<?= htmlspecialchars($p['url_demo']) ?>" class="demo-embed" allowfullscreen title="Demo <?= htmlspecialchars($p['titulo']) ?>"></iframe>
        </div>
        <?php elseif(!empty($p['url_demo'])): ?>
        <div style="padding:20px 24px;">
          <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:28px;text-align:center;">
            <div style="font-size:3rem;margin-bottom:14px;">🎮</div>
            <p style="font-size:.88rem;color:var(--muted);margin-bottom:16px;">La demo del proyecto está disponible en una plataforma externa.</p>
            <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:11px 24px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.86rem;">
              <i class="fa fa-external-link-alt"></i> Abrir demo
            </a>
          </div>
        </div>
        <?php else: ?>
        <div style="padding:30px 24px;text-align:center;">
          <div class="empty"><div class="empty-ico">🎮</div><p class="empty-txt">Demo no disponible aún.</p></div>
        </div>
        <?php endif; ?>

        <!-- Links de acceso -->
        <div class="demo-links">
          <?php if(!empty($p['url_demo'])): ?>
          <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" class="demo-link">
            <div class="demo-link-ico"><i class="fa fa-play" style="color:var(--green-lt);"></i></div>
            <div><div class="demo-link-name">Demo en vivo</div><div class="demo-link-desc">Versión jugable del proyecto</div></div>
          </a>
          <?php endif; ?>
          <?php if(!empty($p['repositorio'])): ?>
          <a href="<?= htmlspecialchars($p['repositorio']) ?>" target="_blank" class="demo-link">
            <div class="demo-link-ico"><i class="fa fa-code-branch" style="color:var(--gold-lt);"></i></div>
            <div><div class="demo-link-name">Repositorio</div><div class="demo-link-desc">Código fuente del proyecto</div></div>
          </a>
          <?php endif; ?>
          <?php foreach($proy_docs as $doc): if($doc['tipo']!=='enlace')continue; ?>
          <a href="<?= htmlspecialchars($doc['archivo']) ?>" target="_blank" class="demo-link">
            <div class="demo-link-ico"><i class="fa fa-link" style="color:var(--blue-lt);"></i></div>
            <div><div class="demo-link-name"><?= htmlspecialchars($doc['nombre']) ?></div><div class="demo-link-desc"><?= htmlspecialchars($doc['descripcion']??'') ?></div></div>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Tab: Documentación -->
    <div class="proj-tab-content" id="ptc-docs">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <p style="font-size:.82rem;color:var(--muted);">Documentos, manuales y recursos del proyecto.</p>
        <?php if($es_admin): ?>
        <button class="mod-btn" style="padding:7px 15px;font-size:.78rem;" onclick="document.getElementById('pd_proyecto').value=<?= $pid ?>;abrirModal('mNuevoDoc')"><i class="fa fa-plus"></i> Agregar documento</button>
        <?php endif; ?>
      </div>
      <?php if(empty($proy_docs)): ?>
      <div class="empty"><div class="empty-ico">📄</div><p class="empty-txt">Sin documentos aún.</p></div>
      <?php else: ?>
      <div class="doc-grid">
        <?php
        $doc_icos=['pdf'=>'📕','imagen'=>'🖼','video'=>'🎬','enlace'=>'🔗','otro'=>'📁'];
        foreach($proy_docs as $doc):
          $dic=$doc_icos[$doc['tipo']]??'📁';
          $dbc='db-'.$doc['tipo'];
          $es_ext=in_array($doc['tipo'],['enlace']);
        ?>
        <a href="<?= htmlspecialchars($doc['archivo']) ?>" <?= $es_ext?'target="_blank"':'' ?> class="doc-card" onclick="<?= !$es_ext?'event.preventDefault();abrirDoc(\''.addslashes($doc['archivo']).'\',\''.addslashes($doc['nombre']).'\')':'' ?>">
          <div class="doc-ico"><?= $dic ?></div>
          <div style="display:flex;align-items:center;gap:8px;justify-content:space-between;">
            <span class="doc-badge <?= $dbc ?>"><?= strtoupper($doc['tipo']) ?></span>
            <?php if(!empty($doc['tamanio_kb'])): ?>
            <span style="font-size:.6rem;color:var(--dim);"><?= $doc['tamanio_kb'] ?>KB</span>
            <?php endif; ?>
          </div>
          <div class="doc-name"><?= htmlspecialchars($doc['nombre']) ?></div>
          <?php if(!empty($doc['descripcion'])): ?>
          <div class="doc-desc"><?= htmlspecialchars($doc['descripcion']) ?></div>
          <?php endif; ?>
          <div class="doc-meta"><i class="fa fa-user fa-xs"></i> <?= htmlspecialchars($doc['subido_nombre']??'Admin') ?> · <?= date('d M Y',strtotime($doc['fecha'])) ?></div>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Avances -->
    <div class="proj-tab-content" id="ptc-avances">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <p style="font-size:.82rem;color:var(--muted);"><?= $proy_stats['completados'] ?> de <?= $proy_stats['avances'] ?> avances completados.</p>
        <?php if($es_staff): ?>
        <button class="mod-btn" style="padding:7px 15px;font-size:.78rem;" onclick="document.getElementById('pa_proyecto').value=<?= $pid ?>;abrirModal('mNuevoAvance')"><i class="fa fa-plus"></i> Registrar avance</button>
        <?php endif; ?>
      </div>
      <?php if(empty($proy_avances)): ?>
      <div class="empty"><div class="empty-ico">📋</div><p class="empty-txt">Sin avances registrados.</p></div>
      <?php else: ?>
      <div class="timeline">
        <?php foreach($proy_avances as $av): ?>
        <div class="tl-item">
          <div class="tl-dot <?= $av['completado']?'tl-done':'tl-pend' ?>"><i class="fa <?= $av['completado']?'fa-check':'fa-clock' ?> fa-xs"></i></div>
          <div class="tl-body">
            <div class="tl-title"><?= htmlspecialchars($av['titulo']) ?></div>
            <?php if(!empty($av['descripcion'])): ?>
            <div class="tl-desc"><?= htmlspecialchars($av['descripcion']) ?></div>
            <?php endif; ?>
            <div class="tl-meta">
              <span class="tl-meta-chip"><i class="fa fa-calendar fa-xs"></i> <?= date('d M Y',strtotime($av['fecha'])) ?></span>
              <?php if(!empty($av['autor_nombre'])): ?>
              <span class="tl-meta-chip"><i class="fa fa-user fa-xs"></i> <?= htmlspecialchars($av['autor_nombre']) ?></span>
              <?php endif; ?>
              <?php if($av['completado']): ?><span class="tl-meta-chip" style="color:var(--green-lt);"><i class="fa fa-check-circle fa-xs"></i> Completado</span><?php endif; ?>
            </div>
          </div>
          <?php if($es_admin): ?>
          <button class="tl-del" onclick="eliminarAvance(<?= $av['id'] ?>)"><i class="fa fa-trash fa-xs"></i></button>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Galería -->
    <div class="proj-tab-content" id="ptc-galeria">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <p style="font-size:.82rem;color:var(--muted);">Capturas de pantalla y material visual del proyecto.</p>
        <?php if($es_admin): ?>
        <button class="mod-btn" style="padding:7px 15px;font-size:.78rem;" onclick="document.getElementById('pi_proyecto').value=<?= $pid ?>;abrirModal('mNuevaImagen')"><i class="fa fa-plus"></i> Agregar imagen</button>
        <?php endif; ?>
      </div>
      <?php if(empty($proy_imagenes)): ?>
      <div class="empty"><div class="empty-ico">🖼</div><p class="empty-txt">Sin imágenes de galería aún.</p></div>
      <?php else: ?>
      <div class="gallery-grid">
        <?php foreach($proy_imagenes as $img): ?>
        <div class="gallery-img" onclick="abrirImagen('<?= htmlspecialchars($img['imagen'],ENT_QUOTES) ?>','<?= htmlspecialchars($img['titulo']??'',ENT_QUOTES) ?>')">
          <img src="<?= htmlspecialchars($img['imagen']) ?>" alt="<?= htmlspecialchars($img['titulo']??'') ?>" loading="lazy">
          <div class="gallery-img-ov"><i class="fa fa-magnifying-glass-plus"></i></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: KPIs -->
    <div class="proj-tab-content" id="ptc-kpis">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <p style="font-size:.82rem;color:var(--muted);">Indicadores clave de rendimiento del proyecto.</p>
        <?php if($es_admin): ?>
        <button class="mod-btn" style="padding:7px 15px;font-size:.78rem;" onclick="document.getElementById('pk_proyecto').value=<?= $pid ?>;abrirModal('mNuevoKpi')"><i class="fa fa-plus"></i> Agregar KPI</button>
        <?php endif; ?>
      </div>
      <?php if(empty($proy_kpis)): ?>
      <div class="empty"><div class="empty-ico">📊</div><p class="empty-txt">Sin KPIs registrados.</p></div>
      <?php else: ?>
      <div class="kpi-grid">
        <?php foreach($proy_kpis as $k): ?>
        <div class="kpi-card">
          <div class="kpi-ico"><?= htmlspecialchars($k['icono']??'📊') ?></div>
          <div class="kpi-val"><?= htmlspecialchars($k['valor']??'—') ?></div>
          <div class="kpi-lbl"><?= htmlspecialchars($k['nombre']) ?></div>
          <?php if(!empty($k['meta'])): ?>
          <div class="kpi-meta">Meta: <?= htmlspecialchars($k['meta']) ?></div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Equipo -->
    <div class="proj-tab-content" id="ptc-equipo">
      <?php if(empty($proy_team)): ?>
      <div class="empty"><div class="empty-ico">👥</div><p class="empty-txt">Sin miembros asignados.</p></div>
      <?php else: ?>
      <div class="team-grid">
        <?php foreach($proy_team as $m):
          $mav=!empty($m['avatar'])?htmlspecialchars($m['avatar']):'';
          $mini=mb_substr($m['nombre']??'U',0,1);
        ?>
        <div class="team-card">
          <?php if($mav):?><img src="<?= $mav ?>" class="team-av" alt="" onerror="this.style.display='none'"><?php else:?><div class="team-av-ph"><?= $mini ?></div><?php endif;?>
          <div class="team-name"><?= htmlspecialchars($m['nombre'].' '.($m['apellido']??'')) ?></div>
          <div class="team-rol"><?= htmlspecialchars($m['rol_proyecto']??'Colaborador') ?></div>
          <div class="team-area"><?= htmlspecialchars($m['area_tecnologica']??$m['cargo_equipo']??'') ?></div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <?php else: /* ══ VISTA LISTA ══ */ ?>

    <!-- ══ MÓDULO 1: PROYECTOS PROPIOS ══ -->
    <div class="proy-module" id="mod-propios">
      <div class="mod-hd">
        <span class="mod-num">01</span>
        <h2 class="mod-title">Proyectos Propios</h2>
        <div class="mod-line"></div>
        <?php if($es_admin): ?>
        <button class="mod-btn" onclick="abrirModal('mNuevoProyecto')"><i class="fa fa-plus"></i> Nuevo</button>
        <?php endif; ?>
      </div>

      <?php if(empty($proyectos_propios)): ?>
      <div class="empty"><div class="empty-ico">🚀</div><p class="empty-txt">Sin proyectos propios aún.</p></div>
      <?php else: foreach($proyectos_propios as $p):
        $est = $p['estado']??'activo';
        $prog= (int)($p['progreso']??0);
        $stClass=match($est){'completado'=>'st-done','pausado'=>'st-pause','planeado'=>'st-planned','cancelado'=>'st-cancelled',default=>'st-active'};
        $stLabel=match($est){'completado'=>'Completado','pausado'=>'En pausa','planeado'=>'Planeado','cancelado'=>'Cancelado',default=>'Activo'};
        $tags_tec=array_filter(explode(',',$p['tecnologias']??''));
        $avances_cnt=(int)qval($conexion,"SELECT COUNT(*) FROM proyecto_avances WHERE proyecto_id=?","i",$p['id']);
        $docs_cnt   =(int)qval($conexion,"SELECT COUNT(*) FROM proyecto_documentos WHERE proyecto_id=?","i",$p['id']);
      ?>
      <div class="proy-card" id="pp-<?= $p['id'] ?>">
        <div class="pc-banner">
          <div class="pc-bg"></div><div class="pc-orb"></div>
          <div class="pc-content">
            <div class="phb-status <?= $stClass ?>" style="font-size:.65rem;padding:2px 10px;"><?= $stLabel ?></div>
            <div class="pc-name"><?= htmlspecialchars($p['icono']??'🚀') ?> <?= htmlspecialchars($p['titulo']) ?></div>
          </div>
          <div class="pc-acts">
            <button class="pc-act" onclick="verProyecto(<?= $p['id'] ?>)" title="Ver detalle completo"><i class="fa fa-expand"></i></button>
            <?php if(!empty($p['url_demo'])): ?>
            <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" class="pc-act" title="Demo"><i class="fa fa-play"></i></a>
            <?php endif; ?>
            <?php if(!empty($p['repositorio'])): ?>
            <a href="<?= htmlspecialchars($p['repositorio']) ?>" target="_blank" class="pc-act" title="Repo"><i class="fa fa-code-branch"></i></a>
            <?php endif; ?>
          </div>
        </div>
        <div class="pc-body">
          <!-- Tabs -->
          <div class="pc-tabs">
            <button class="pc-tab on" onclick="pcTab('<?= $p['id'] ?>','info',this)">📋 Info</button>
            <button class="pc-tab" onclick="pcTab('<?= $p['id'] ?>','demo',this)">🎮 Demo</button>
            <button class="pc-tab" onclick="pcTab('<?= $p['id'] ?>','avances',this)">📊 Avances</button>
            <button class="pc-tab" onclick="pcTab('<?= $p['id'] ?>','tech',this)">⚙️ Tech</button>
          </div>

          <!-- Tab Info -->
          <div class="pc-tc on" id="pct-<?= $p['id'] ?>-info">
            <?php if(!empty($p['descripcion'])): ?>
            <p class="pc-desc"><?= htmlspecialchars(mb_substr($p['descripcion'],0,300)) ?><?= strlen($p['descripcion'])>300?'…':'' ?></p>
            <?php endif; ?>
            <div class="prog-hd" style="margin-bottom:4px;"><span class="prog-lbl">Progreso</span><span class="prog-pct"><?= $prog ?>%</span></div>
            <div class="pc-prog-bar"><div class="pc-prog-fill" style="width:<?= $prog ?>%;"></div></div>
            <div style="display:flex;gap:14px;margin-top:12px;flex-wrap:wrap;">
              <span style="font-size:.72rem;color:var(--muted);"><i class="fa fa-calendar fa-xs" style="color:var(--green-lt);"></i> <?= !empty($p['fecha_inicio'])?date('d M Y',strtotime($p['fecha_inicio'])):'—' ?></span>
              <span style="font-size:.72rem;color:var(--muted);"><i class="fa fa-list-check fa-xs" style="color:var(--green-lt);"></i> <?= $avances_cnt ?> avances</span>
              <span style="font-size:.72rem;color:var(--muted);"><i class="fa fa-file fa-xs" style="color:var(--green-lt);"></i> <?= $docs_cnt ?> documentos</span>
            </div>
            <button onclick="verProyecto(<?= $p['id'] ?>)" style="margin-top:14px;display:inline-flex;align-items:center;gap:7px;padding:8px 18px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);color:var(--green-lt);font-size:.8rem;font-weight:700;cursor:pointer;transition:all .2s;font-family:var(--font-b);" onmouseover="this.style.background='var(--green)';this.style.color='#fff'" onmouseout="this.style.background='var(--green-dim)';this.style.color='var(--green-lt)'">
              <i class="fa fa-expand"></i> Ver panel completo
            </button>
          </div>

          <!-- Tab Demo -->
          <div class="pc-tc" id="pct-<?= $p['id'] ?>-demo">
            <?php if(!empty($p['url_demo'])): ?>
            <div style="text-align:center;padding:20px 0;">
              <div style="font-size:2.5rem;margin-bottom:12px;">🎮</div>
              <p style="font-size:.86rem;color:var(--muted);margin-bottom:16px;">Demo disponible del proyecto.</p>
              <a href="<?= htmlspecialchars($p['url_demo']) ?>" target="_blank" style="display:inline-flex;align-items:center;gap:8px;padding:11px 22px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.86rem;">
                <i class="fa fa-play"></i> Abrir demo
              </a>
            </div>
            <?php else: ?>
            <div class="empty" style="padding:24px;"><div class="empty-ico" style="font-size:2rem;">🎮</div><p class="empty-txt">Demo no disponible aún.</p></div>
            <?php endif; ?>
          </div>

          <!-- Tab Avances -->
          <div class="pc-tc" id="pct-<?= $p['id'] ?>-avances">
            <?php
            $avs_mini=qall($conexion,"SELECT * FROM proyecto_avances WHERE proyecto_id=? ORDER BY fecha DESC LIMIT 4","i",$p['id']);
            if(empty($avs_mini)):
            ?><div class="empty" style="padding:18px;"><div class="empty-ico" style="font-size:1.8rem;">📋</div><p class="empty-txt">Sin avances registrados.</p></div>
            <?php else: foreach($avs_mini as $av): ?>
            <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);">
              <span style="font-size:.8rem;"><?= $av['completado']?'✅':'⏳' ?></span>
              <div style="flex:1;">
                <p style="font-size:.8rem;font-weight:600;color:var(--txt);"><?= htmlspecialchars($av['titulo']) ?></p>
                <p style="font-size:.62rem;color:var(--dim);"><?= date('d M Y',strtotime($av['fecha'])) ?></p>
              </div>
            </div>
            <?php endforeach; endif; ?>
            <?php if($es_staff): ?>
            <button onclick="document.getElementById('pa_proyecto').value=<?= $p['id'] ?>;abrirModal('mNuevoAvance')" style="margin-top:10px;display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.25);border-radius:99px;color:var(--green-lt);font-size:.72rem;font-weight:700;cursor:pointer;font-family:var(--font-b);">
              <i class="fa fa-plus"></i> Registrar avance
            </button>
            <?php endif; ?>
          </div>

          <!-- Tab Tech -->
          <div class="pc-tc" id="pct-<?= $p['id'] ?>-tech">
            <?php if(!empty(array_filter($tags_tec))): ?>
            <div class="tag-row">
              <?php foreach($tags_tec as $t): if(!trim($t))continue; ?><span class="tag tag-tech"><?= htmlspecialchars(trim($t)) ?></span><?php endforeach; ?>
            </div>
            <?php else: ?><div class="empty" style="padding:18px;"><p class="empty-txt">Sin tecnologías definidas.</p></div><?php endif; ?>
            <?php
            $kpis_mini=qall($conexion,"SELECT * FROM proyecto_kpis WHERE proyecto_id=? LIMIT 4","i",$p['id']);
            if(!empty($kpis_mini)):
            ?><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px;">
              <?php foreach($kpis_mini as $k): ?>
              <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:10px;text-align:center;">
                <div style="font-size:1.2rem;"><?= htmlspecialchars($k['icono']??'📊') ?></div>
                <div style="font-family:var(--font-d);font-size:.9rem;color:var(--gold);font-weight:700;"><?= htmlspecialchars($k['valor']??'—') ?></div>
                <div style="font-size:.6rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;"><?= htmlspecialchars($k['nombre']) ?></div>
              </div>
              <?php endforeach; ?>
            </div><?php endif; ?>
          </div>
        </div>
      </div>
      <?php endforeach; endif; ?>
    </div>


    <!-- ══ MÓDULO 2: OTROS PROYECTOS ══ -->
    <div class="proy-module" id="mod-otros">
      <div class="mod-hd">
        <span class="mod-num">02</span>
        <h2 class="mod-title">Otros Proyectos</h2>
        <div class="mod-line"></div>
        <!-- Filtros rápidos -->
        <div style="display:flex;gap:5px;flex-wrap:wrap;">
          <button class="mod-btn mod-btn-ghost" style="padding:6px 13px;font-size:.72rem;" onclick="filterCat('',null)">Todos</button>
          <?php foreach(array_slice($categorias,0,4) as $cat): ?>
          <button class="mod-btn mod-btn-ghost" style="padding:6px 13px;font-size:.72rem;" onclick="filterCat('<?= htmlspecialchars($cat,ENT_QUOTES) ?>',null)"><?= htmlspecialchars($cat) ?></button>
          <?php endforeach; ?>
        </div>
      </div>

      <?php if(empty($proyectos_otros)): ?>
      <div class="empty"><div class="empty-ico">🌐</div><p class="empty-txt">Sin proyectos de comunidad aún.</p></div>
      <?php else: ?>
      <div class="otros-grid" id="otrosGrid">
        <?php
        $band_colors=['activo'=>'linear-gradient(to right,#28A680,transparent)','planeado'=>'linear-gradient(to right,#3b82f6,transparent)','pausado'=>'linear-gradient(to right,#DAA520,transparent)','completado'=>'linear-gradient(to right,#14b8a6,transparent)','cancelado'=>'linear-gradient(to right,#ef4444,transparent)'];
        foreach($proyectos_otros as $p):
          $est=$p['estado']??'planeado';
          $prog=(int)($p['progreso']??0);
          $band=$band_colors[$est]??$band_colors['planeado'];
          $stl=match($est){'completado'=>'Completado','pausado'=>'En pausa','cancelado'=>'Cancelado','activo'=>'Activo',default=>'Planeado'};
          $techs=array_filter(explode(',',$p['tecnologias']??''));
        ?>
        <div class="otro-card" data-cat="<?= htmlspecialchars($p['categoria']??'') ?>" onclick="verProyecto(<?= $p['id'] ?>)">
          <div class="oc-band" style="background:<?= $band ?>"></div>
          <div class="oc-body">
            <div class="oc-top">
              <div class="oc-ico"><?= htmlspecialchars($p['icono']??'🚀') ?></div>
              <div>
                <div class="oc-title"><?= htmlspecialchars($p['titulo']) ?></div>
                <div class="oc-sub"><?= htmlspecialchars($p['categoria']??'') ?> · <?= $stl ?></div>
              </div>
            </div>
            <?php if(!empty($p['descripcion'])): ?>
            <div class="oc-desc"><?= htmlspecialchars($p['descripcion']) ?></div>
            <?php endif; ?>
            <?php if(!empty(array_filter($techs))): ?>
            <div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px;">
              <?php foreach(array_slice($techs,0,3) as $t): if(!trim($t))continue; ?><span class="tag tag-tech" style="font-size:.6rem;padding:2px 7px;"><?= htmlspecialchars(trim($t)) ?></span><?php endforeach; ?>
            </div>
            <?php endif; ?>
            <div class="oc-footer">
              <div style="flex:1;"><div class="oc-prog"><?= $prog ?>%</div><div class="oc-prog-bar"><div class="oc-prog-fill" style="width:<?= $prog ?>%;"></div></div></div>
              <button style="font-size:.7rem;padding:5px 12px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;color:var(--green-lt);font-weight:700;cursor:pointer;font-family:var(--font-b);transition:all .2s;" onmouseover="this.style.background='var(--green)';this.style.color='#fff'" onmouseout="this.style.background='var(--green-dim)';this.style.color='var(--green-lt)'">
                Ver más <i class="fa fa-arrow-right fa-xs"></i>
              </button>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <?php endif; /* fin vista individual vs lista */ ?>
  </main>
</div>

<!-- FAB (solo staff en vista lista) -->
<?php if($es_staff && !$view_id): ?>
<button class="fab" onclick="abrirModal('mNuevoAvance')" title="Registrar avance"><i class="fa fa-plus"></i></button>
<?php endif; ?>


<!-- ═══════════════════════════════════════
     MODALES
═══════════════════════════════════════ -->

<!-- Modal: Nuevo avance -->
<div class="p-modal" id="mNuevoAvance">
  <div class="pm-box">
    <div class="pm-hd"><span class="pm-ttl">📋 Registrar Avance</span><button class="pm-cls" onclick="cerrarModal('mNuevoAvance')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body">
      <div class="fg"><label class="fl">Proyecto</label>
        <select class="fi" id="pa_proyecto">
          <option value="">Seleccionar proyecto...</option>
          <?php foreach($proyectos_propios as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['icono']??'🚀') ?> <?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
          <?php foreach($proyectos_otros as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg"><label class="fl">Título del avance *</label><input type="text" class="fi" id="pa_titulo" placeholder="Ej: Implementación de sistema de físicas completada"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="pa_desc" rows="3" placeholder="Detalla qué se logró en este avance..."></textarea></div>
      <div style="display:flex;align-items:center;gap:10px;padding:8px 0;">
        <input type="checkbox" id="pa_completado" style="accent-color:var(--green);width:16px;height:16px;">
        <label for="pa_completado" style="font-size:.82rem;color:var(--txt);cursor:pointer;">Marcar como completado</label>
      </div>
    </div>
    <div class="pm-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mNuevoAvance')">Cancelar</button>
      <button class="em-btn em-btn-green" onclick="guardarAvance()"><i class="fa fa-save"></i> Guardar avance</button>
    </div>
  </div>
</div>

<!-- Modal: Nuevo documento (admin) -->
<?php if($es_admin): ?>
<div class="p-modal" id="mNuevoDoc">
  <div class="pm-box">
    <div class="pm-hd"><span class="pm-ttl">📄 Agregar Documento</span><button class="pm-cls" onclick="cerrarModal('mNuevoDoc')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body">
      <div class="fg"><label class="fl">Proyecto</label>
        <select class="fi" id="pd_proyecto">
          <?php foreach(array_merge($proyectos_propios,$proyectos_otros) as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Nombre *</label><input type="text" class="fi" id="pd_nombre" placeholder="Ej: Manual de Usuario v1.2"></div>
        <div class="fg"><label class="fl">Tipo</label>
          <select class="fi" id="pd_tipo">
            <option value="pdf">📕 PDF</option><option value="imagen">🖼 Imagen</option>
            <option value="video">🎬 Video</option><option value="enlace">🔗 Enlace</option><option value="otro">📁 Otro</option>
          </select>
        </div>
      </div>
      <div class="fg"><label class="fl">URL / Ruta del archivo *</label><input type="text" class="fi" id="pd_archivo" placeholder="https://... o /uploads/docs/archivo.pdf"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="pd_desc" rows="2"></textarea></div>
    </div>
    <div class="pm-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mNuevoDoc')">Cancelar</button>
      <button class="em-btn em-btn-green" onclick="guardarDoc()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>

<!-- Modal: Nuevo KPI -->
<div class="p-modal" id="mNuevoKpi">
  <div class="pm-box">
    <div class="pm-hd"><span class="pm-ttl">📊 Agregar KPI</span><button class="pm-cls" onclick="cerrarModal('mNuevoKpi')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body">
      <div class="fg"><label class="fl">Proyecto</label>
        <select class="fi" id="pk_proyecto">
          <?php foreach(array_merge($proyectos_propios,$proyectos_otros) as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Nombre del indicador *</label><input type="text" class="fi" id="pk_nombre" placeholder="Ej: Usuarios activos"></div>
        <div class="fg"><label class="fl">Icono (emoji)</label><input type="text" class="fi" id="pk_icono" value="📊" maxlength="4"></div>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Valor actual</label><input type="text" class="fi" id="pk_valor" placeholder="Ej: 1.250"></div>
        <div class="fg"><label class="fl">Meta</label><input type="text" class="fi" id="pk_meta" placeholder="Ej: 5.000"></div>
      </div>
    </div>
    <div class="pm-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mNuevoKpi')">Cancelar</button>
      <button class="em-btn em-btn-green" onclick="guardarKpi()"><i class="fa fa-save"></i> Guardar KPI</button>
    </div>
  </div>
</div>

<!-- Modal: Nueva imagen galería -->
<div class="p-modal" id="mNuevaImagen">
  <div class="pm-box">
    <div class="pm-hd"><span class="pm-ttl">🖼 Agregar Captura / Imagen</span><button class="pm-cls" onclick="cerrarModal('mNuevaImagen')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body">
      <div class="fg"><label class="fl">Proyecto</label>
        <select class="fi" id="pi_proyecto">
          <?php foreach(array_merge($proyectos_propios,$proyectos_otros) as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg"><label class="fl">URL de la imagen *</label><input type="text" class="fi" id="pi_imagen" placeholder="https://...imagen.jpg o /uploads/..."></div>
      <div class="fg"><label class="fl">Título de la imagen</label><input type="text" class="fi" id="pi_titulo" placeholder="Ej: Pantalla principal del juego"></div>
    </div>
    <div class="pm-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mNuevaImagen')">Cancelar</button>
      <button class="em-btn em-btn-green" onclick="guardarImagen()"><i class="fa fa-save"></i> Agregar</button>
    </div>
  </div>
</div>

<!-- Modal: Actualizar progreso -->
<div class="p-modal" id="mProgreso">
  <div class="pm-box">
    <div class="pm-hd"><span class="pm-ttl">📈 Actualizar Progreso</span><button class="pm-cls" onclick="cerrarModal('mProgreso')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body">
      <div class="fg"><label class="fl">Proyecto</label>
        <select class="fi" id="pp_proyecto">
          <?php foreach(array_merge($proyectos_propios,$proyectos_otros) as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="fg"><label class="fl">Estado</label>
        <select class="fi" id="pp_estado">
          <option value="planeado">◌ Planeado</option><option value="activo">● Activo</option>
          <option value="pausado">⏸ Pausado</option><option value="completado">✓ Completado</option><option value="cancelado">✕ Cancelado</option>
        </select>
      </div>
      <div class="fg">
        <label class="fl">Progreso: <span id="pp_progVal">0%</span></label>
        <input type="range" id="pp_prog" min="0" max="100" value="0" style="width:100%;accent-color:var(--green);margin-top:8px;" oninput="document.getElementById('pp_progVal').textContent=this.value+'%'">
      </div>
    </div>
    <div class="pm-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mProgreso')">Cancelar</button>
      <button class="em-btn em-btn-green" onclick="guardarProgreso()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>
<?php endif; /* es_admin */ ?>

<!-- Modal: Ver imagen fullscreen -->
<div class="p-modal" id="mImagen">
  <div class="pm-box wide" style="background:rgba(0,0,0,.95);">
    <div class="pm-hd" style="background:rgba(0,0,0,.5);">
      <span class="pm-ttl" id="mImgTtl">🖼 Imagen</span>
      <button class="pm-cls" onclick="cerrarModal('mImagen')"><i class="fa fa-times"></i></button>
    </div>
    <div class="pm-body" style="padding:0;">
      <img id="mImgSrc" src="" alt="" style="width:100%;max-height:80vh;object-fit:contain;display:block;">
    </div>
  </div>
</div>

<!-- Modal: Ver documento PDF/iframe -->
<div class="p-modal" id="mDoc">
  <div class="pm-box fs wide">
    <div class="pm-hd"><span class="pm-ttl" id="mDocTtl">📄 Documento</span><button class="pm-cls" onclick="cerrarModal('mDoc')"><i class="fa fa-times"></i></button></div>
    <div class="pm-body" style="overflow:hidden;">
      <iframe id="mDocSrc" src="" class="iframe-doc" title="Documento"></iframe>
    </div>
  </div>
</div>

<!-- Toasts -->
<div class="toast-w" id="toastW"></div>


<!-- ═══════════════════════════════════════
     FOOTER
═══════════════════════════════════════ -->
<footer style="background:#050d1a;border-top:1px solid rgba(40,166,128,.12);padding:28px;margin-top:60px;">
  <div style="max-width:1480px;margin:auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <div style="display:flex;align-items:center;gap:10px;"><span style="font-size:1.3rem;color:var(--green);">⬡</span><span style="font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);letter-spacing:3px;">VIROX</span></div>
    <p style="font-size:.78rem;color:var(--dim);">© 2025 Team VIROX — Todos los derechos reservados</p>
    <nav style="display:flex;gap:16px;"><a href="index.php" style="font-size:.78rem;color:var(--dim);">Inicio</a><a href="equipo.php" style="font-size:.78rem;color:var(--dim);">Equipo</a><a href="contacto.php" style="font-size:.78rem;color:var(--dim);">Contacto</a></nav>
  </div>
</footer>


<!-- ═══════════════════════════════════════
     JAVASCRIPT
═══════════════════════════════════════ -->
<script>
/* ══ HEADER SCROLL ══ */
window.addEventListener('scroll',()=>document.getElementById('siteHeader').classList.toggle('hdr-on',scrollY>40));
document.getElementById('burger')?.addEventListener('click',function(){this.classList.toggle('burger-x');document.getElementById('mainNav').classList.toggle('nav-open');});

/* ══ VER PROYECTO INDIVIDUAL ══ */
function verProyecto(id){
  window.location.href='proyecto.php?id='+id;
}

/* ══ TABS PROYECTO INDIVIDUAL ══ */
function projTab(id,btn){
  document.querySelectorAll('.proj-tab-content').forEach(c=>c.classList.remove('on'));
  document.querySelectorAll('.proj-tab').forEach(t=>t.classList.remove('on'));
  document.getElementById('ptc-'+id)?.classList.add('on');
  btn.classList.add('on');
}

/* ══ TABS TARJETA MINI ══ */
function pcTab(pid,tab,btn){
  const wrap=btn.closest('.pc-body');
  wrap.querySelectorAll('.pc-tc').forEach(c=>c.classList.remove('on'));
  wrap.querySelectorAll('.pc-tab').forEach(t=>t.classList.remove('on'));
  wrap.querySelector('#pct-'+pid+'-'+tab)?.classList.add('on');
  btn.classList.add('on');
}

/* ══ FILTER CAT ══ */
function filterCat(cat,btn){
  document.querySelectorAll('#otrosGrid .otro-card').forEach(c=>{
    c.style.display=(!cat||c.dataset.cat===cat)?'':'none';
  });
  document.querySelectorAll('.idx-item').forEach(i=>i.classList.remove('on'));
  if(btn)btn.classList.add('on');
}

/* ══ BUSCADOR ÍNDICE ══ */
document.getElementById('idxSearch').addEventListener('input',function(){
  const q=this.value.toLowerCase();
  document.querySelectorAll('.idx-item[data-name]').forEach(el=>{
    el.style.display=(!q||el.dataset.name.includes(q))?'':'none';
  });
  document.querySelectorAll('.proy-card,.otro-card').forEach(c=>{
    const txt=(c.querySelector('.pc-name')?.textContent||c.querySelector('.oc-title')?.textContent||'').toLowerCase();
    c.style.display=(!q||txt.includes(q))?'':'none';
  });
});

/* ══ MODALES ══ */
function abrirModal(id){document.getElementById(id).classList.add('on');document.body.style.overflow='hidden';}
function cerrarModal(id){document.getElementById(id).classList.remove('on');document.body.style.overflow='';}
document.querySelectorAll('.p-modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m){m.classList.remove('on');document.body.style.overflow=''}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.p-modal.on').forEach(m=>m.classList.remove('on'));document.body.style.overflow=''}});

/* ══ TOAST ══ */
function toast(msg,tipo='ok',dur=3500){
  const w=document.getElementById('toastW'),t=document.createElement('div');
  const icons={ok:'fa-circle-check',err:'fa-triangle-exclamation',info:'fa-circle-info'};
  t.className=`tst t-${tipo}`;
  t.innerHTML=`<i class="fa ${icons[tipo]}"></i>${msg}`;
  w.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(14px)';t.style.transition='all .3s';setTimeout(()=>t.remove(),300);},dur);
}

/* ══ FETCH ══ */
async function postAction(data){
  const fd=new FormData();Object.entries(data).forEach(([k,v])=>fd.append(k,v));
  try{const r=await fetch('',{method:'POST',body:fd});return await r.json();}
  catch(e){return{ok:false,error:'Error de conexión'};}
}

/* ══ GUARDAR AVANCE ══ */
async function guardarAvance(){
  const pid=document.getElementById('pa_proyecto').value;
  const titulo=document.getElementById('pa_titulo').value.trim();
  if(!pid){toast('Selecciona un proyecto','err');return;}
  if(!titulo){toast('El título es obligatorio','err');return;}
  const r=await postAction({
    accion:'agregar_avance',proyecto_id:pid,titulo,
    descripcion:document.getElementById('pa_desc').value,
    completado:document.getElementById('pa_completado').checked?1:0,
  });
  if(r.ok){toast('✅ Avance registrado','ok');cerrarModal('mNuevoAvance');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ GUARDAR DOCUMENTO ══ */
async function guardarDoc(){
  const pid=document.getElementById('pd_proyecto').value;
  const nom=document.getElementById('pd_nombre').value.trim();
  const arch=document.getElementById('pd_archivo').value.trim();
  if(!nom||!arch){toast('Nombre y URL son obligatorios','err');return;}
  const r=await postAction({
    accion:'add_doc',proyecto_id:pid,nombre:nom,archivo:arch,
    descripcion:document.getElementById('pd_desc').value,
    tipo:document.getElementById('pd_tipo').value,
  });
  if(r.ok){toast('📄 Documento agregado','ok');cerrarModal('mNuevoDoc');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ GUARDAR KPI ══ */
async function guardarKpi(){
  const pid=document.getElementById('pk_proyecto').value;
  const nom=document.getElementById('pk_nombre').value.trim();
  if(!nom){toast('El nombre es obligatorio','err');return;}
  const r=await postAction({
    accion:'add_kpi',proyecto_id:pid,nombre:nom,
    valor:document.getElementById('pk_valor').value,
    icono:document.getElementById('pk_icono').value||'📊',
    meta:document.getElementById('pk_meta').value,
  });
  if(r.ok){toast('📊 KPI agregado','ok');cerrarModal('mNuevoKpi');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ GUARDAR IMAGEN ══ */
async function guardarImagen(){
  const pid=document.getElementById('pi_proyecto').value;
  const img=document.getElementById('pi_imagen').value.trim();
  if(!img){toast('La URL de la imagen es obligatoria','err');return;}
  const r=await postAction({
    accion:'add_imagen',proyecto_id:pid,imagen:img,
    titulo:document.getElementById('pi_titulo').value,
  });
  if(r.ok){toast('🖼 Imagen agregada','ok');cerrarModal('mNuevaImagen');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ GUARDAR PROGRESO ══ */
async function guardarProgreso(){
  const pid=document.getElementById('pp_proyecto').value;
  const prog=document.getElementById('pp_prog').value;
  const est=document.getElementById('pp_estado').value;
  const r=await postAction({accion:'update_progreso',proyecto_id:pid,progreso:prog,estado:est});
  if(r.ok){toast('📈 Progreso actualizado','ok');cerrarModal('mProgreso');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ ELIMINAR AVANCE ══ */
async function eliminarAvance(id){
  if(!confirm('¿Eliminar este avance?'))return;
  const r=await postAction({accion:'delete_avance',id});
  if(r.ok){toast('🗑 Avance eliminado','info');setTimeout(()=>location.reload(),900);}
  else toast('Error: '+r.error,'err');
}

/* ══ VER IMAGEN ══ */
function abrirImagen(src,titulo){
  document.getElementById('mImgSrc').src=src;
  document.getElementById('mImgTtl').textContent='🖼 '+titulo;
  abrirModal('mImagen');
}

/* ══ VER DOCUMENTO ══ */
function abrirDoc(src,nombre){
  document.getElementById('mDocSrc').src=src;
  document.getElementById('mDocTtl').textContent='📄 '+nombre;
  abrirModal('mDoc');
}

/* ══ SCROLL ANIMADO ══ */
function scrollToProject(id){
  document.getElementById(id)?.scrollIntoView({behavior:'smooth',block:'start'});
}

/* ══ REVEAL ANIMATIONS ══ */
const ro=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';}}),{threshold:.04});
document.querySelectorAll('.proy-card,.otro-card,.kpi-card,.doc-card,.team-card,.tl-item').forEach((el,i)=>{
  el.style.opacity='0';el.style.transform='translateY(14px)';
  el.style.transition=`opacity .4s ease ${i*.04}s,transform .4s ease ${i*.04}s`;
  ro.observe(el);
});

/* ══ PROGRESS BARS ANIMATE ON SCROLL ══ */
const progObs=new IntersectionObserver(entries=>entries.forEach(e=>{
  if(e.isIntersecting){
    const fill=e.target.querySelector('.prog-fill,.pc-prog-fill,.oc-prog-fill');
    if(fill&&!fill.dataset.animated){fill.dataset.animated='1';fill.style.transition='width 1.2s ease';}
  }
}),{threshold:.1});
document.querySelectorAll('.prog-section,.proy-card,.otro-card').forEach(el=>progObs.observe(el));
</script>
</body>
</html>