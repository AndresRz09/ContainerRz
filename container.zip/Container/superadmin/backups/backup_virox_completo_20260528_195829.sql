-- =============================================
-- VIROX Backup: completo
-- Fecha: 2026-05-28 19:58:29
-- Generado por: SuperAdmin #1
-- =============================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;
USE `container`;

-- Tabla: usuarios
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `username` varchar(60) NOT NULL,
  `tipo_documento` enum('CC','TI','CE','NIT','PASAPORTE','DNI') NOT NULL DEFAULT 'CC',
  `identificacion` varchar(30) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `fecha_expedicion` date NOT NULL,
  `genero` enum('M','F','NB','O','') DEFAULT NULL,
  `pais` varchar(80) DEFAULT 'Colombia',
  `ciudad` varchar(80) DEFAULT NULL,
  `telefono` varchar(25) DEFAULT NULL,
  `avatar` varchar(500) DEFAULT 'assets/avatar-default.png',
  `bio` text DEFAULT NULL,
  `ocupacion` varchar(120) DEFAULT NULL,
  `institucion` varchar(150) DEFAULT NULL,
  `nivel_educativo` enum('primaria','bachillerato','tecnico','universitario','pregrado','especializacion','maestria','doctorado') DEFAULT NULL,
  `experiencia_cyber` enum('ninguna','basica','intermedia','avanzada') DEFAULT 'ninguna',
  `certificaciones` text DEFAULT NULL,
  `intereses` varchar(500) DEFAULT NULL,
  `area_tecnologica` varchar(80) DEFAULT NULL COMMENT 'Área: Backend, Ciberseguridad, Datos…',
  `habilidades` text DEFAULT NULL COMMENT 'CSV de habilidades técnicas',
  `cargo_equipo` varchar(100) DEFAULT NULL COMMENT 'Cargo dentro del equipo',
  `disponible` tinyint(1) DEFAULT 1 COMMENT '1=disponible para proyectos',
  `calificacion` decimal(3,2) DEFAULT 0.00 COMMENT 'Promedio de calificaciones 0-5',
  `num_proyectos` int(10) unsigned DEFAULT 0 COMMENT 'Cache conteo de proyectos',
  `descripcion_equipo` text DEFAULT NULL COMMENT 'Descripción pública para sección equipo',
  `tipo_equipo` varchar(80) DEFAULT NULL COMMENT 'Desarrollo, Seguridad, I+D…',
  `tipo_usuario` enum('cliente','empresa','creador','consultor') NOT NULL DEFAULT 'cliente',
  `rol` enum('superadmin','admin','empleado','creador','consultor','cliente') NOT NULL DEFAULT 'cliente',
  `linkedin` varchar(255) DEFAULT NULL,
  `github` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `discord` varchar(100) DEFAULT NULL,
  `telegram` varchar(100) DEFAULT NULL,
  `zona_horaria` varchar(60) DEFAULT 'America/Bogota',
  `idioma_preferido` varchar(5) DEFAULT 'es',
  `notif_email` tinyint(1) DEFAULT 1,
  `notif_curso` tinyint(1) DEFAULT 1,
  `notif_sistema` tinyint(1) DEFAULT 1,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `verificado` tinyint(1) NOT NULL DEFAULT 0,
  `google_id` varchar(128) DEFAULT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `fecha_registro` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_actualizacion` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `oauth_provider` varchar(30) DEFAULT NULL COMMENT 'google, github, etc.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_username` (`username`),
  UNIQUE KEY `uq_identificacion` (`identificacion`),
  KEY `idx_rol` (`rol`),
  KEY `idx_tipo_usuario` (`tipo_usuario`),
  KEY `idx_activo` (`activo`),
  KEY `idx_pais` (`pais`),
  KEY `idx_fecha_registro` (`fecha_registro`),
  KEY `idx_google_id` (`google_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos: usuarios
INSERT INTO `usuarios` (`id`,`nombre`,`apellido`,`username`,`tipo_documento`,`identificacion`,`fecha_nacimiento`,`fecha_expedicion`,`genero`,`pais`,`ciudad`,`telefono`,`avatar`,`bio`,`ocupacion`,`institucion`,`nivel_educativo`,`experiencia_cyber`,`certificaciones`,`intereses`,`area_tecnologica`,`habilidades`,`cargo_equipo`,`disponible`,`calificacion`,`num_proyectos`,`descripcion_equipo`,`tipo_equipo`,`tipo_usuario`,`rol`,`linkedin`,`github`,`twitter`,`website`,`discord`,`telegram`,`zona_horaria`,`idioma_preferido`,`notif_email`,`notif_curso`,`notif_sistema`,`activo`,`verificado`,`google_id`,`ultimo_acceso`,`fecha_registro`,`fecha_actualizacion`,`oauth_provider`) VALUES ('1','Andres Felipe','Rozo Garzon','AndresRz09','CC','1072642850','2005-03-09','2023-03-22','M','Colombia','Chia','3212771090','assets/Tesla.png','Visualiza con la mente.... Y Crea con las manos.','Ingeniero de Sistemas','Uniminuto','pregrado','avanzada','Coursera','hacking,redes,criptografia,ia_security,forense,malware,cloud,web_security,programacion',NULL,NULL,'Propietario','1','0.00','0',NULL,NULL,'cliente','superadmin','','','','',NULL,NULL,'America/Bogota','es','1','1','1','1','1',NULL,'2026-05-28 12:56:37','2026-05-13 15:39:18','2026-05-28 12:56:37',NULL);
INSERT INTO `usuarios` (`id`,`nombre`,`apellido`,`username`,`tipo_documento`,`identificacion`,`fecha_nacimiento`,`fecha_expedicion`,`genero`,`pais`,`ciudad`,`telefono`,`avatar`,`bio`,`ocupacion`,`institucion`,`nivel_educativo`,`experiencia_cyber`,`certificaciones`,`intereses`,`area_tecnologica`,`habilidades`,`cargo_equipo`,`disponible`,`calificacion`,`num_proyectos`,`descripcion_equipo`,`tipo_equipo`,`tipo_usuario`,`rol`,`linkedin`,`github`,`twitter`,`website`,`discord`,`telegram`,`zona_horaria`,`idioma_preferido`,`notif_email`,`notif_curso`,`notif_sistema`,`activo`,`verificado`,`google_id`,`ultimo_acceso`,`fecha_registro`,`fecha_actualizacion`,`oauth_provider`) VALUES ('2','Víctor Emmanuel','Pedroza de la Torre','TheEmmanuel13','CC','26022004','0000-00-00','0000-00-00','M','Mexico','Ciudad de Mexico','+52 1 395 106 2966','uploads/avatars/avatar_2_1778909352.png','xd','Ingeniero de Videojuegos','Uniminuto','pregrado','avanzada','Nan','programacion','0',NULL,'','1','0.00','0',NULL,'Ingenieria de Videojuegos','cliente','empleado','','','','',NULL,NULL,'America/Bogota','es','1','1','1','1','1',NULL,'2026-05-23 19:15:01','2026-05-15 23:52:10','2026-05-23 19:15:01',NULL);
INSERT INTO `usuarios` (`id`,`nombre`,`apellido`,`username`,`tipo_documento`,`identificacion`,`fecha_nacimiento`,`fecha_expedicion`,`genero`,`pais`,`ciudad`,`telefono`,`avatar`,`bio`,`ocupacion`,`institucion`,`nivel_educativo`,`experiencia_cyber`,`certificaciones`,`intereses`,`area_tecnologica`,`habilidades`,`cargo_equipo`,`disponible`,`calificacion`,`num_proyectos`,`descripcion_equipo`,`tipo_equipo`,`tipo_usuario`,`rol`,`linkedin`,`github`,`twitter`,`website`,`discord`,`telegram`,`zona_horaria`,`idioma_preferido`,`notif_email`,`notif_curso`,`notif_sistema`,`activo`,`verificado`,`google_id`,`ultimo_acceso`,`fecha_registro`,`fecha_actualizacion`,`oauth_provider`) VALUES ('4','Leonardo Josué','Pilay Salinas','takyi_','CC','2450170788','0000-00-00','0000-00-00','M','Ecuador','Guayaquil','+593 96 260 2629','uploads/avatars/avatar_4_1778991515.png','xd','Ingeniero Electrico','','pregrado','avanzada','','redes,web_security,programacion',NULL,NULL,NULL,'1','0.00','0',NULL,NULL,'','admin','','','','',NULL,NULL,'America/Bogota','es','1','1','1','1','1',NULL,'2026-05-23 19:18:52','2026-05-16 23:13:43','2026-05-23 19:18:52',NULL);
INSERT INTO `usuarios` (`id`,`nombre`,`apellido`,`username`,`tipo_documento`,`identificacion`,`fecha_nacimiento`,`fecha_expedicion`,`genero`,`pais`,`ciudad`,`telefono`,`avatar`,`bio`,`ocupacion`,`institucion`,`nivel_educativo`,`experiencia_cyber`,`certificaciones`,`intereses`,`area_tecnologica`,`habilidades`,`cargo_equipo`,`disponible`,`calificacion`,`num_proyectos`,`descripcion_equipo`,`tipo_equipo`,`tipo_usuario`,`rol`,`linkedin`,`github`,`twitter`,`website`,`discord`,`telegram`,`zona_horaria`,`idioma_preferido`,`notif_email`,`notif_curso`,`notif_sistema`,`activo`,`verificado`,`google_id`,`ultimo_acceso`,`fecha_registro`,`fecha_actualizacion`,`oauth_provider`) VALUES ('5','Gerrald Joshua','Díaz Valdez','Ennuit','CE','v32201856','2007-08-20','2025-08-25','M','Venezuela','Arjona','+58 416-3730297','uploads/avatars/avatar_1779485775_350.jpg','xd','Educación Mencion Idiomas extranjeros','Universidad de los Andes.','universitario','intermedia','','redes,forense,web_security,programacion',NULL,NULL,NULL,'1','0.00','0',NULL,NULL,'creador','creador','','','','',NULL,NULL,'America/Bogota','es','1','1','1','1','1',NULL,'2026-05-22 16:40:03','2026-05-22 16:36:16','2026-05-23 19:19:03',NULL);

-- Tabla: usuarios_seguridad
DROP TABLE IF EXISTS `usuarios_seguridad`;
CREATE TABLE `usuarios_seguridad` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `correo` varchar(180) NOT NULL,
  `identificacion` varchar(30) NOT NULL COMMENT 'Copia cifrada para login alternativo',
  `telefono` varchar(25) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL COMMENT 'bcrypt cost=12 NUNCA MD5/SHA1',
  `salt_extra` varchar(64) DEFAULT NULL COMMENT 'Salt adicional para rotación',
  `intentos_fallidos` tinyint(3) unsigned DEFAULT 0,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `token_reset` varchar(128) DEFAULT NULL,
  `token_reset_expiry` datetime DEFAULT NULL,
  `token_verificacion` varchar(128) DEFAULT NULL,
  `2fa_secreto` varchar(64) DEFAULT NULL COMMENT 'TOTP secreto para autenticación 2 factores',
  `2fa_activo` tinyint(1) DEFAULT 0,
  `ultimo_ip` varchar(45) DEFAULT NULL COMMENT 'IPv4 o IPv6',
  `fecha_cambio_pass` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_correo` (`correo`),
  UNIQUE KEY `uq_usuario_id` (`usuario_id`),
  KEY `idx_token_reset` (`token_reset`),
  KEY `idx_bloqueado` (`bloqueado_hasta`),
  CONSTRAINT `fk_seg_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Datos: usuarios_seguridad
INSERT INTO `usuarios_seguridad` (`id`,`usuario_id`,`correo`,`identificacion`,`telefono`,`password_hash`,`salt_extra`,`intentos_fallidos`,`bloqueado_hasta`,`token_reset`,`token_reset_expiry`,`token_verificacion`,`2fa_secreto`,`2fa_activo`,`ultimo_ip`,`fecha_cambio_pass`,`created_at`,`updated_at`) VALUES ('1','1','andres.rozogx@gmail.com','1072642850','3212771090','$2y$12$r2Yz.Y8fq0UDw6byfN.cHeYuD4pOp2/LLhXALNq9s8SVIHjma0E2K',NULL,'2',NULL,'de754077d2d214ea41f8f12563ed7097a34f856e254dcc88bc1f10d5a655b22b','2026-05-26 02:40:09',NULL,NULL,'0',NULL,NULL,'2026-05-13 15:42:38','2026-05-25 18:40:09');
INSERT INTO `usuarios_seguridad` (`id`,`usuario_id`,`correo`,`identificacion`,`telefono`,`password_hash`,`salt_extra`,`intentos_fallidos`,`bloqueado_hasta`,`token_reset`,`token_reset_expiry`,`token_verificacion`,`2fa_secreto`,`2fa_activo`,`ultimo_ip`,`fecha_cambio_pass`,`created_at`,`updated_at`) VALUES ('2','2','theemmanuel131211@gmail.com','','+52 1 395 106 2966','$2y$12$0iTN1KwJ8pqVl3MBzpG2beHS4LIzSndVztRd9CyOrPlh9r8hFdXJW',NULL,'3',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2026-05-15 23:53:38','2026-05-16 00:24:38');
INSERT INTO `usuarios_seguridad` (`id`,`usuario_id`,`correo`,`identificacion`,`telefono`,`password_hash`,`salt_extra`,`intentos_fallidos`,`bloqueado_hasta`,`token_reset`,`token_reset_expiry`,`token_verificacion`,`2fa_secreto`,`2fa_activo`,`ultimo_ip`,`fecha_cambio_pass`,`created_at`,`updated_at`) VALUES ('3','4','josuepilay34@gmail.com','2450170788','+593 96 260 2629','$2y$12$tBU08TmYfeyC2nPVlNrXu..YXJtQjGYvfdhSqyDKnIPPpY4OWxDPa',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2026-05-16 23:15:44','2026-05-16 23:15:56');
INSERT INTO `usuarios_seguridad` (`id`,`usuario_id`,`correo`,`identificacion`,`telefono`,`password_hash`,`salt_extra`,`intentos_fallidos`,`bloqueado_hasta`,`token_reset`,`token_reset_expiry`,`token_verificacion`,`2fa_secreto`,`2fa_activo`,`ultimo_ip`,`fecha_cambio_pass`,`created_at`,`updated_at`) VALUES ('5','5','gerraldvaldez200807@gmail.com','v32201856','+58 416-3730297','$2y$12$OJzUTMYjQRctQeLRm.qkCu7CXccw30zHPswu6ZwH0wz93t3AwPPa6',NULL,'0',NULL,NULL,NULL,NULL,NULL,'0',NULL,NULL,'2026-05-22 16:36:16',NULL);

-- Tabla: servicios
DROP TABLE IF EXISTS `servicios`;
CREATE TABLE `servicios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(80) NOT NULL COMMENT 'identificador URL-friendly',
  `icono` varchar(20) DEFAULT '?',
  `categoria` varchar(80) DEFAULT NULL,
  `titulo` varchar(150) NOT NULL,
  `subtitulo` varchar(200) DEFAULT NULL,
  `color` varchar(30) DEFAULT 'green',
  `nivel` varchar(80) DEFAULT NULL,
  `duracion` varchar(50) DEFAULT NULL,
  `precio_base` decimal(12,2) DEFAULT 0.00,
  `definicion` text DEFAULT NULL,
  `importancia` text DEFAULT NULL,
  `foto_url` varchar(400) DEFAULT NULL,
  `video_url` varchar(400) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `destacado` tinyint(1) DEFAULT 0,
  `orden` smallint(5) unsigned DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_activo` (`activo`),
  KEY `idx_destacado` (`destacado`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos: servicios
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('6','programacion','💻','Desarrollo','Programación','Fundamentos y desarrollo de software','green','Básico → Avanzado','20 – 120 h','150000.00','La programación es el proceso de diseñar, codificar, depurar y mantener el código fuente de programas computacionales para resolver problemas o realizar tareas. Actúa como puente de comunicación entre el ser humano y la máquina, utilizando lenguajes específicos para crear software, aplicaciones móviles, sitios web y sistemas de Inteligencia Artificial.','En un mundo completamente digitalizado, la programación es el motor que impulsa la economía, la medicina, la ingeniería y la educación. Dominarla abre puertas a decenas de perfiles profesionales con alta demanda y excelente remuneración.','https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80','https://www.youtube.com/embed/nLRL_NcnK-4','1','1','1','2026-05-13 14:48:52');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('8','prog-web','🌐','Desarrollo','Programación Web','Frontend, Backend y Full-Stack','blue','Básico → Full-Stack','30 – 150 h','180000.00','La programación web es la disciplina que permite crear sitios, aplicaciones y plataformas accesibles desde navegadores o dispositivos conectados a internet. Abarca el desarrollo del lado del cliente (Frontend), del lado del servidor (Backend) y la integración de ambos (Full-Stack), empleando tecnologías como HTML, CSS, JavaScript, PHP, Node.js, React, entre otras.','Más del 60% de las empresas del mundo dependen de presencia digital activa. Un desarrollador web competente puede construir desde portafolios personales hasta plataformas e-commerce de millones de usuarios.','https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&q=80','https://www.youtube.com/embed/ysEN5RaKOlA','1','1','2','2026-05-13 14:51:27');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('9','poo','🧩','Desarrollo','POO','Programación Orientada a Objetos','purple','Intermedio → Avanzado','25 – 80 h','140000.00','La Programación Orientada a Objetos (POO) es un paradigma de programación que organiza el software en torno a objetos, que son instancias de clases con atributos (datos) y métodos (comportamientos). Sus cuatro pilares —Encapsulamiento, Herencia, Polimorfismo y Abstracción— permiten construir software modular, reutilizable y fácilmente mantenible.','POO es el paradigma dominante en la industria. Frameworks y sistemas empresariales como Django, Spring, Laravel y .NET están construidos sobre sus principios. Dominarlo es esencial para cualquier desarrollador profesional.','https://images.unsplash.com/photo-1618477388954-7852f32655ec?w=800&q=80','https://www.youtube.com/embed/I848HdWjLMo','1','0','3','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('10','bases-datos','🗄','Datos','Bases de Datos','SQL, NoSQL y diseño de datos','gold','Básico → DBA','20 – 100 h','160000.00','Una base de datos es un sistema organizado para almacenar, gestionar y recuperar información de forma eficiente, segura y estructurada. Existen bases de datos relacionales (SQL: MySQL, PostgreSQL, SQL Server, Oracle) y no relacionales (NoSQL: MongoDB, Redis, Cassandra, Firebase) cada una óptima para diferentes escenarios.','Toda aplicación del mundo real requiere almacenamiento persistente de datos. Sin bases de datos bien diseñadas no hay banca digital, redes sociales, e-commerce ni sistemas empresariales.','https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&q=80','https://www.youtube.com/embed/HXV3zeQKqGY','1','1','4','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('11','ciberseguridad','🛡','Seguridad','Ciberseguridad','Ethical Hacking y protección digital','red','Básico → OSCP','40 – 200 h','220000.00','La ciberseguridad es el conjunto de tecnologías, procesos y prácticas diseñadas para proteger redes, sistemas, programas y datos de ataques, daños o accesos no autorizados. Abarca desde la seguridad perimetral hasta el hacking ético, la respuesta a incidentes y el análisis forense digital.','El cibercrimen genera pérdidas superiores a $8 billones de dólares anuales globalmente. Los profesionales en ciberseguridad son los más demandados del sector TI con salarios hasta un 40% superiores al promedio tecnológico.','https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&q=80','https://www.youtube.com/embed/GHpL7WYEhI4','1','1','5','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('12','redes','📡','Infraestructura','Redes y Conectividad','Infraestructura de comunicaciones','teal','Básico → CCNA/CompTIA','30 – 120 h','175000.00','Las redes de computadoras son sistemas de comunicación que permiten el intercambio de datos entre dispositivos. Incluyen desde redes locales (LAN) hasta redes globales (WAN/Internet), empleando protocolos como TCP/IP, modelos OSI y dispositivos como routers, switches y firewalls.','Toda organización moderna depende de su red para operar. Un ingeniero de redes diseña, implementa y asegura la infraestructura que conecta empleados, servidores, la nube y el mundo exterior.','https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80','https://www.youtube.com/embed/qiQR5rTSshw','1','0','6','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('13','iot','📡','Innovación','IoT','Internet de las Cosas','orange','Básico → Avanzado','30 – 100 h','195000.00','El Internet de las Cosas (IoT) es la interconexión de objetos físicos (sensores, actuadores, electrodomésticos, vehículos) a internet para recopilar, intercambiar y procesar datos en tiempo real, creando sistemas inteligentes que automatizan entornos domésticos, industriales y urbanos.','Para 2030 habrá más de 75 mil millones de dispositivos IoT conectados. Sectores como salud, manufactura, agricultura y ciudades inteligentes dependerán de profesionales capaces de diseñar ecosistemas IoT completos.','https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80','https://www.youtube.com/embed/LlhmzVL5bm8','1','0','7','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('14','ia-automatizacion','🤖','IA & Datos','Automatización e IA','Machine Learning y procesos inteligentes','indigo','Intermedio → Experto','40 – 180 h','280000.00','La Inteligencia Artificial y la Automatización permiten que los sistemas aprendan de los datos, tomen decisiones y ejecuten tareas sin intervención humana constante. Incluye Machine Learning, Deep Learning, procesamiento de lenguaje natural (NLP), visión por computadora y automatización de procesos robóticos (RPA).','La IA reemplazará el 30% de las tareas rutinarias para 2030, pero creará el doble de empleos especializados. Los ingenieros de IA son los profesionales con mayor crecimiento salarial del siglo XXI.','https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80','https://www.youtube.com/embed/aircAruvnKk','1','1','8','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('15','ciencia-datos','📊','IA & Datos','Ciencia de Datos','Analytics, BI y estadística aplicada','cyan','Básico → Científico de Datos','35 – 150 h','210000.00','La Ciencia de Datos es la disciplina interdisciplinaria que combina estadística, programación, visualización y conocimiento del dominio para extraer insights valiosos de grandes volúmenes de datos. Emplea el ciclo completo: recopilación, limpieza, análisis exploratorio, modelado predictivo y comunicación de resultados.','Las empresas que adoptan decisiones basadas en datos tienen un 23% más de rentabilidad. El científico de datos es uno de los empleos más demandados y mejor pagados de la última década.','https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80','https://www.youtube.com/embed/X3paOmcrTjQ','1','1','9','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('16','cloud','☁️','Infraestructura','Cloud Computing','AWS, Azure, GCP y arquitecturas cloud','sky','Básico → Architect','30 – 130 h','235000.00','La computación en la nube es el modelo de entrega de recursos de TI (cómputo, almacenamiento, red, bases de datos, IA) a través de internet bajo demanda. Los tres grandes proveedores —AWS, Microsoft Azure y Google Cloud Platform— ofrecen más de 200 servicios cada uno para escalar aplicaciones globalmente.','El 94% de las empresas globales usa algún servicio cloud. La migración a la nube reduce costos de infraestructura hasta un 40% y permite escalar de 10 a 10 millones de usuarios sin cambiar el código.','https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80','https://www.youtube.com/embed/M988_fsOSWo','1','1','10','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('17','estructuras-datos','🌲','CS Fundamentals','Estructuras de Datos','Algoritmos y eficiencia computacional','emerald','Intermedio → Avanzado','25 – 90 h','155000.00','Las estructuras de datos son formas organizadas de almacenar y gestionar datos en memoria para facilitar operaciones eficientes. Su correcta elección determina el rendimiento de cualquier sistema, siendo la base para entrevistas técnicas en FAANG y el desarrollo de sistemas de alto rendimiento.','Google, Amazon y Meta basan sus entrevistas técnicas completamente en estructuras de datos y algoritmos. Un ingeniero que las domina resuelve problemas 10x más eficientemente.','https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&q=80','https://www.youtube.com/embed/bum_19loj9A','1','0','11','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('18','sistemas-operativos','⚙️','CS Fundamentals','Sistemas Operativos','Gestión de procesos, memoria y concurrencia','slate','Intermedio → Avanzado','25 – 80 h','145000.00','Un sistema operativo (SO) es el software fundamental que gestiona los recursos de hardware de un computador (CPU, memoria, disco, red) y proporciona servicios a las aplicaciones. Estudiar SO implica comprender cómo funcionan procesos, hilos, scheduling, memoria virtual, sistemas de archivos y sincronización.','Comprender los SO permite escribir aplicaciones más eficientes, diagnosticar problemas de rendimiento, administrar servidores y desarrollar software de bajo nivel. Es esencial para DevOps, programadores de sistemas y arquitectos.','https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80','https://www.youtube.com/embed/26QPDBe-NB8','1','0','12','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('19','linux','🐧','Infraestructura','Linux','Administración de sistemas Unix/Linux','amber','Básico → SysAdmin','20 – 100 h','165000.00','Linux es el sistema operativo más usado del mundo en servidores, supercomputadoras, dispositivos IoT y la nube. Aprender Linux significa dominar la línea de comandos, administrar servidores, automatizar tareas con Bash y gestionar la infraestructura que soporta el 90% de internet.','El 96.4% de los servidores web del mundo corren Linux. Cualquier carrera en DevOps, Cloud, Seguridad o Desarrollo Backend requiere un dominio profundo de este sistema.','https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80','https://www.youtube.com/embed/sWbUDq4S6Y8','1','0','13','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('20','ing-software','🏗','Desarrollo','Ingeniería de Software','Arquitectura, calidad y proceso de desarrollo','violet','Intermedio → Arquitecto','30 – 120 h','200000.00','La Ingeniería de Software es la disciplina que aplica principios de ingeniería al diseño, desarrollo, prueba y mantenimiento de software. Abarca todo el ciclo de vida del software (SDLC), metodologías ágiles, arquitecturas de software, aseguramiento de calidad y gestión de proyectos tecnológicos.','El 70% de los proyectos de software fallan por mala gestión y diseño deficiente. Un ingeniero de software formado construye sistemas que escalan, se mantienen y entregan valor real al negocio.','https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&q=80','https://www.youtube.com/embed/Y-LgmR302kc','1','1','14','2026-05-13 14:54:58');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('21','transaccionales','💳','Sistemas','Sistemas Transaccionales','Procesamiento de transacciones críticas','green','Avanzado','30 – 100 h','230000.00','Los sistemas transaccionales (OLTP) son plataformas diseñadas para gestionar operaciones de negocio en tiempo real con altísima disponibilidad, consistencia y durabilidad. Son el núcleo de la banca digital, e-commerce, reservas y cualquier sistema que no puede permitirse perder datos.','Un banco procesa millones de transacciones diariamente. Un fallo de 1 hora puede costar decenas de millones. Diseñar sistemas transaccionales robustos es una de las habilidades más valoradas de la industria.','https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&q=80','https://www.youtube.com/embed/5ZjhNTM8XU8','1','0','15','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('22','matematicas','📐','Ciencias','Matemáticas para TI','Fundamentos matemáticos del cómputo','rose','Básico → Avanzado','20 – 120 h','130000.00','Las matemáticas son el lenguaje universal de la informática. Álgebra lineal, cálculo, estadística, matemáticas discretas y teoría de grafos son la base de la IA, la criptografía, los algoritmos y los gráficos por computadora.','Álgebra lineal es la base de deep learning. La estadística sustenta la ciencia de datos. La criptografía nace de la teoría de números. Matemáticas = poder para resolver problemas que el resto no puede.','https://images.unsplash.com/photo-1509228468518-180dd4864904?w=800&q=80','https://www.youtube.com/embed/fNk_zzaMoSs','1','0','16','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('23','videojuegos','🎮','Creativo','Desarrollo de Videojuegos','Unity, Unreal y game design','pink','Básico → Pro','40 – 160 h','210000.00','El desarrollo de videojuegos combina programación, arte, diseño de niveles, música y narrativa para crear experiencias interactivas. Las industrias de videojuegos y gamificación empresarial son mercados de más de $200 mil millones anuales.','Los videojuegos son la industria de entretenimiento más grande del planeta, superando al cine y la música juntos. La gamificación empresarial, el metaverso y la realidad virtual abren mercados adicionales enormes.','https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&q=80','https://www.youtube.com/embed/gB1F9G0JXOo','1','0','17','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('24','mobile','📱','Desarrollo','Desarrollo Móvil','Android, iOS y multiplataforma','blue','Básico → Senior','40 – 150 h','220000.00','El desarrollo móvil abarca la creación de aplicaciones para dispositivos Android e iOS. Puede ser nativo (Kotlin/Java para Android, Swift para iOS), multiplataforma (Flutter, React Native, Xamarin) o híbrido (Ionic, Capacitor). El mercado móvil supera los $500 mil millones anuales.','El 60% del tráfico de internet viene de dispositivos móviles. Una app bien diseñada puede alcanzar millones de usuarios en días. La demanda de desarrolladores móviles supera la oferta en Latinoamérica.','https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&q=80','https://www.youtube.com/embed/fis26HvvDII','1','0','18','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('25','teoria-computacion','🧮','CS Fundamentals','Teoría de la Computación','Autómatas, lenguajes formales y computabilidad','slate','Avanzado','20 – 80 h','135000.00','La teoría de la computación estudia los fundamentos matemáticos de los computadores: qué problemas pueden resolverse algorítmicamente, qué tan eficientemente, y cuáles son los límites intrínsecos de la computación. Incluye autómatas, lenguajes formales, computabilidad y complejidad computacional.','Sin teoría de la computación no existirían los compiladores, los algoritmos de compresión, la criptografía, ni los sistemas de IA actuales. Es la base de toda la informática teórica y aplicada.','https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80','https://www.youtube.com/embed/9syvZr-9xwk','1','0','19','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('26','plataformas','🏢','Desarrollo','Desarrollo en Plataformas','Shopify, Salesforce, SAP, WordPress','gold','Básico → Certified','20 – 100 h','175000.00','El desarrollo basado en plataformas consiste en personalizar, extender y construir sobre plataformas existentes de alto valor empresarial: CMS como WordPress, e-commerce como Shopify, CRM como Salesforce, ERP como SAP, y low-code como Power Platform o Appian.','El 43% de todos los sitios web del mundo usan WordPress. Salesforce tiene más de 150,000 clientes empresariales. Un desarrollador certificado en estas plataformas tiene acceso inmediato a proyectos de alto valor.','https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80','https://www.youtube.com/embed/jGBnCMWEOf8','1','0','20','2026-05-13 14:55:22');
INSERT INTO `servicios` (`id`,`slug`,`icono`,`categoria`,`titulo`,`subtitulo`,`color`,`nivel`,`duracion`,`precio_base`,`definicion`,`importancia`,`foto_url`,`video_url`,`activo`,`destacado`,`orden`,`created_at`) VALUES ('27','fisica-computacional','⚛️','Ciencias','Física Computacional','Simulación y modelado numérico','cyan','Avanzado','30 – 100 h','170000.00','La física computacional aplica métodos numéricos y algoritmos para resolver problemas físicos que no tienen solución analítica. Incluye simulación de sistemas dinámicos, mecánica cuántica computacional, dinámica de fluidos, electromagnetismo numérico y modelado de partículas.','La física computacional impulsa los avances en meteorología, diseño aeroespacial, semiconductores, energía nuclear y biotecnología. Es esencial para ingenieros que trabajan en simulación científica de alto rendimiento.','https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80','https://www.youtube.com/embed/4i7GrHHhvFk','1','0','21','2026-05-13 14:55:22');

-- Tabla: proyectos
DROP TABLE IF EXISTS `proyectos`;
CREATE TABLE `proyectos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo` enum('propio','comunidad','cliente','academico') DEFAULT 'propio',
  `categoria` varchar(80) DEFAULT NULL,
  `subtipo` varchar(80) DEFAULT NULL,
  `icono` varchar(20) DEFAULT '?',
  `estado` enum('planeado','activo','pausado','completado','cancelado') DEFAULT 'planeado',
  `progreso` tinyint(3) unsigned DEFAULT 0 COMMENT '0-100%',
  `tecnologias` text DEFAULT NULL COMMENT 'CSV de tecnologías',
  `areas` text DEFAULT NULL COMMENT 'CSV de áreas',
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `presupuesto` decimal(14,2) DEFAULT NULL,
  `repositorio` varchar(255) DEFAULT NULL,
  `url_demo` varchar(255) DEFAULT NULL,
  `privado` tinyint(1) DEFAULT 0,
  `creado_por` int(10) unsigned DEFAULT NULL,
  `fecha_creacion` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_update` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_creado_por` (`creado_por`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos: proyectos
INSERT INTO `proyectos` (`id`,`titulo`,`descripcion`,`tipo`,`categoria`,`subtipo`,`icono`,`estado`,`progreso`,`tecnologias`,`areas`,`fecha_inicio`,`fecha_fin`,`presupuesto`,`repositorio`,`url_demo`,`privado`,`creado_por`,`fecha_creacion`,`fecha_update`) VALUES ('1','Virox','Videojuego Educativo','academico',NULL,NULL,'🚀','planeado','0','','','2026-05-21',NULL,NULL,NULL,NULL,'0','1','2026-05-20 21:25:38',NULL);

-- Tabla: proyecto_usuarios
DROP TABLE IF EXISTS `proyecto_usuarios`;
CREATE TABLE `proyecto_usuarios` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(10) unsigned NOT NULL,
  `usuario_id` int(10) unsigned NOT NULL,
  `rol_proyecto` varchar(100) DEFAULT 'Colaborador',
  `permisos` set('ver','editar','admin') DEFAULT 'ver',
  `fecha_ingreso` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_proy_usr` (`proyecto_id`,`usuario_id`),
  KEY `fk_pu_usuario` (`usuario_id`),
  CONSTRAINT `fk_pu_proyecto` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pu_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: proyecto_avances
DROP TABLE IF EXISTS `proyecto_avances`;
CREATE TABLE `proyecto_avances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(10) unsigned NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `completado` tinyint(1) DEFAULT 0,
  `fecha` date NOT NULL,
  `autor_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_proyecto` (`proyecto_id`),
  CONSTRAINT `fk_av_proy` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: cursos
DROP TABLE IF EXISTS `cursos`;
CREATE TABLE `cursos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(120) NOT NULL,
  `icono` varchar(20) DEFAULT '?',
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `imagen` varchar(400) DEFAULT NULL,
  `video_intro` varchar(400) DEFAULT NULL,
  `categoria` varchar(80) DEFAULT NULL,
  `tipo` enum('MOOC','NOOC','SPOC') DEFAULT 'MOOC',
  `nivel` enum('basico','intermedio','avanzado','experto') DEFAULT 'basico',
  `idioma` varchar(5) DEFAULT 'es',
  `duracion_horas` decimal(6,2) DEFAULT NULL,
  `precio` decimal(12,2) DEFAULT 0.00,
  `gratuito` tinyint(1) DEFAULT 1,
  `certificado` tinyint(1) DEFAULT 0,
  `instructor_id` int(10) unsigned DEFAULT NULL,
  `capacidad_max` smallint(5) unsigned DEFAULT NULL COMMENT 'NULL = ilimitado (MOOC)',
  `activo` tinyint(1) DEFAULT 1,
  `publicado` tinyint(1) DEFAULT 0,
  `destacado` tinyint(1) DEFAULT 0,
  `rating` decimal(3,2) DEFAULT 0.00 COMMENT 'Promedio calificaciones',
  `total_subs` int(10) unsigned DEFAULT 0 COMMENT 'Cache inscritos',
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  KEY `idx_tipo` (`tipo`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_nivel` (`nivel`),
  KEY `idx_instructor` (`instructor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: inscripciones
DROP TABLE IF EXISTS `inscripciones`;
CREATE TABLE `inscripciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `curso_id` int(10) unsigned NOT NULL,
  `progreso` tinyint(3) unsigned DEFAULT 0,
  `completado` tinyint(1) DEFAULT 0,
  `fecha_inscripcion` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_completado` datetime DEFAULT NULL,
  `ultima_leccion` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_inscripcion` (`usuario_id`,`curso_id`),
  KEY `idx_curso` (`curso_id`),
  KEY `idx_completado` (`completado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: certificados
DROP TABLE IF EXISTS `certificados`;
CREATE TABLE `certificados` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `curso_id` int(10) unsigned NOT NULL,
  `nombre` varchar(200) NOT NULL COMMENT 'Nombre del certificado',
  `url` varchar(400) DEFAULT NULL COMMENT 'URL del PDF generado',
  `codigo` varchar(32) NOT NULL COMMENT 'Código único de verificación',
  `fecha_emision` date NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_codigo` (`codigo`),
  UNIQUE KEY `uq_cert_usr_curso` (`usuario_id`,`curso_id`),
  KEY `idx_usuario` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: configuracion
DROP TABLE IF EXISTS `configuracion`;
CREATE TABLE `configuracion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `clave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `grupo` varchar(60) DEFAULT 'general',
  `tipo` enum('texto','numero','booleano','json') DEFAULT 'texto',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clave` (`clave`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Datos: configuracion
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('1','nombre_sistema','ContainerRz','general','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('2','nombre_publico','ContainerRz','general','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('3','slogan','Tecnología, ingenieria y aprendizaje interactivo en un solo ecosistema conectado.','general','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('4','version','1.0.0','general','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('5','modo_mantenimiento','0','general','booleano');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('6','mision','Democratizar el acceso a la educación en ciberseguridad y tecnología, proporcionando herramientas interactivas, recursos de calidad y un ecosistema colaborativo que permita a cada persona desarrollar sus habilidades digitales sin importar su contexto o ubicación.','empresa','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('7','vision','Ser la plataforma educativa de referencia en ciberseguridad para Latinoamérica, reconocida por su innovación, accesibilidad y compromiso con la formación de profesionales capaces de enfrentar los retos digitales del futuro.','empresa','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('8','acerca','Proyecto académico enfocado en ciberseguridad educativa, tecnología aplicada y aprendizaje interactivo. Construido con pasión por un equipo comprometido con la innovación y la democratización del conocimiento digital.','empresa','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('9','stat_modulos','21','estadisticas','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('10','stat_roles','7','estadisticas','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('11','stat_regiones','5','estadisticas','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('12','manual_url','manual.php','manual','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('13','manual_titulo','Manual del Usuario','manual','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('14','manual_subtitulo','Aprende a usar todas las funcionalidades de ContainerRz paso a paso.','manual','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('15','email','andres.rozogx@gmail.com','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('16','telefono','+57 321 277 1090','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('17','whatsapp','57 321 277 1090','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('18','web','www.teamvirox.com','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('19','ubicacion','Colombia','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('20','direccion','Bogotá, Colombia','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('21','horario','Lun – Vie: 8:00 AM – 6:00 PM','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('22','lat','4.6097','sig','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('23','lng','-74.0817','sig','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('24','instagram','','redes','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('25','facebook','','redes','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('26','twitter','','redes','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('27','linkedin','','redes','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('28','youtube','','redes','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('29','hero_slide1_tag','⬡ Plataforma Educativa · Tecnológica','hero','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('30','hero_slide1_titulo','Bienvenidos a ContainerRz','hero','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('31','hero_slide1_cuerpo','Tecnología, ciberseguridad y aprendizaje interactivo en un solo ecosistema conectado.','hero','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('32','hero_slide2_tag','🎯 Nuestra Misión','hero','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('33','hero_slide3_tag','🔭 Nuestra Visión','hero','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('34','ia_titulo','IA integrada al proyecto','ia','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('35','ia_descripcion','Herramientas y desarrollos de inteligencia artificial aplicados a ciberseguridad y aprendizaje interactivo.','ia','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('36','footer_copy','© 2025 Team VIROX — Todos los derechos reservados','footer','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('37','pasarela_principal','mercadopago','pagos','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('38','pasarela_secundaria','payco','pagos','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('39','moneda_default','COP','pagos','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('40','pago_nota_seguridad','Todos los pagos son procesados de forma segura con cifrado SSL. Precios en COP. Contáctanos para pagos en USD o EUR.','pagos','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('41','pago_nota_personalizado','¿Necesitas un plan personalizado? Diseñamos planes a medida para empresas y grupos con descuentos especiales.','pagos','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('42','contacto_desc','Envíanos tu mensaje, PQRS o sugerencia. Nuestro equipo responde en menos de 24 horas.','contacto','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('43','pqrs_dias_respuesta','15','contacto','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('44','pqrs_pts_registro','10','contacto','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('45','pqrs_pts_calificar','5','contacto','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('46','pqrs_pts_completada','15','contacto','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('47','pqrs_pts_sugerencia','20','contacto','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('48','equipo_titulo','Nuestro Equipo','equipo','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('49','equipo_subtitulo','Conoce a los colaboradores, especialistas y miembros que forman parte del ecosistema ContainerRz.','equipo','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('50','ia_modelo','claude-sonnet-4-20250514','ia','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('51','ia_max_tokens','1500','ia','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('52','ia_contexto_msgs','20','ia','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('53','ia_titulo_pagina','IA ContainerRz — Asistente Inteligente','ia','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('54','ia_bienvenida','Soy tu asistente inteligente. Puedo ayudarte con ciberseguridad, código, aprendizaje, proyectos, análisis de datos y mucho más.','ia','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('55','ultimo_backup','{\"filename\":\"backup_virox_solo_estructura_20260520_230218.sql\",\"tipo\":\"solo_estructura\",\"fecha\":\"2026-05-20 23:02:18\",\"size\":20673}','backups','json');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('57','google_oauth_habilitado','1','oauth','booleano');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('58','google_oauth_client_id','TU_CLIENT_ID_AQUI.apps.googleusercontent.com','oauth','texto');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('59','google_puntos_registro','50','oauth','numero');
INSERT INTO `configuracion` (`id`,`clave`,`valor`,`grupo`,`tipo`) VALUES ('60','google_auto_verificar','1','oauth','booleano');

-- Tabla: pagos
DROP TABLE IF EXISTS `pagos`;
CREATE TABLE `pagos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `referencia` varchar(100) NOT NULL COMMENT 'ID de la pasarela de pago',
  `tipo` enum('servicio','curso','plan','donacion') NOT NULL,
  `referencia_id` int(10) unsigned DEFAULT NULL,
  `monto` decimal(14,2) NOT NULL,
  `moneda` char(3) DEFAULT 'COP',
  `metodo` varchar(60) DEFAULT NULL COMMENT 'PSE, Tarjeta, Nequi...',
  `estado` enum('iniciado','pendiente','aprobado','rechazado','reembolsado') DEFAULT 'iniciado',
  `datos_pago` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Respuesta de la pasarela' CHECK (json_valid(`datos_pago`)),
  `ip_usuario` varchar(45) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_update` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_referencia` (`referencia`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: servicio_adquisiciones
DROP TABLE IF EXISTS `servicio_adquisiciones`;
CREATE TABLE `servicio_adquisiciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `servicio_id` int(10) unsigned NOT NULL,
  `plan_id` int(10) unsigned DEFAULT NULL,
  `estado` enum('pendiente','pagado','cancelado','reembolsado') DEFAULT 'pendiente',
  `monto` decimal(12,2) NOT NULL,
  `metodo_pago` varchar(60) DEFAULT NULL,
  `referencia` varchar(100) DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_servicio` (`servicio_id`),
  KEY `idx_estado` (`estado`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: pqrs
DROP TABLE IF EXISTS `pqrs`;
CREATE TABLE `pqrs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `folio` varchar(20) NOT NULL,
  `usuario_id` int(10) unsigned DEFAULT NULL,
  `nombre` varchar(150) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `categoria` enum('peticion','queja','reclamo','sugerencia','consulta','denuncia','felicitacion') DEFAULT 'consulta',
  `asunto` varchar(250) NOT NULL,
  `descripcion` text NOT NULL,
  `estrellas` tinyint(3) unsigned DEFAULT 0,
  `prioridad` enum('baja','normal','alta','urgente') DEFAULT 'normal',
  `estado` enum('abierto','proceso','revision','cerrado','rechazado') DEFAULT 'abierto',
  `pais` varchar(80) DEFAULT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lng` decimal(10,7) DEFAULT NULL,
  `idioma` varchar(5) DEFAULT 'es',
  `asignado_a` int(10) unsigned DEFAULT NULL,
  `respuesta` text DEFAULT NULL,
  `fecha_respuesta` datetime DEFAULT NULL,
  `puntos_bonus` int(10) unsigned DEFAULT 0,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_update` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_folio` (`folio`),
  KEY `idx_estado` (`estado`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_prioridad` (`prioridad`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: contacto_mensajes
DROP TABLE IF EXISTS `contacto_mensajes`;
CREATE TABLE `contacto_mensajes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `correo` varchar(180) NOT NULL,
  `asunto` varchar(200) DEFAULT NULL,
  `mensaje` text NOT NULL,
  `pais` varchar(80) DEFAULT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lng` decimal(10,7) DEFAULT NULL,
  `idioma` varchar(5) DEFAULT 'es',
  `leido` tinyint(1) DEFAULT 0,
  `respondido` tinyint(1) DEFAULT 0,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_leido` (`leido`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: mensajes_internos
DROP TABLE IF EXISTS `mensajes_internos`;
CREATE TABLE `mensajes_internos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `remitente_id` int(10) unsigned NOT NULL,
  `destinatario_id` int(10) unsigned NOT NULL,
  `asunto` varchar(250) NOT NULL,
  `mensaje` text NOT NULL,
  `leido` tinyint(1) DEFAULT 0,
  `archivado_rem` tinyint(1) DEFAULT 0 COMMENT 'Archivado por remitente',
  `archivado_dest` tinyint(1) DEFAULT 0 COMMENT 'Archivado por destinatario',
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_destinatario_leido` (`destinatario_id`,`leido`),
  KEY `idx_remitente` (`remitente_id`),
  KEY `idx_fecha` (`fecha`),
  CONSTRAINT `fk_msg_dest` FOREIGN KEY (`destinatario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_msg_rem` FOREIGN KEY (`remitente_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: publicaciones
DROP TABLE IF EXISTS `publicaciones`;
CREATE TABLE `publicaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(300) NOT NULL,
  `slug` varchar(300) NOT NULL,
  `resumen` varchar(500) DEFAULT NULL,
  `contenido` longtext DEFAULT NULL,
  `imagen` varchar(400) DEFAULT NULL,
  `autor_id` int(10) unsigned DEFAULT NULL,
  `categoria` varchar(80) DEFAULT NULL,
  `tags` varchar(300) DEFAULT NULL,
  `publicado` tinyint(1) DEFAULT 0,
  `destacado` tinyint(1) DEFAULT 0,
  `vistas` int(10) unsigned DEFAULT 0,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  `fecha_pub` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`(191)),
  KEY `idx_autor` (`autor_id`),
  KEY `idx_publicado` (`publicado`),
  KEY `idx_fecha` (`fecha`),
  FULLTEXT KEY `ft_titulo_resumen` (`titulo`,`resumen`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: noticias
DROP TABLE IF EXISTS `noticias`;
CREATE TABLE `noticias` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(300) NOT NULL,
  `cuerpo` text DEFAULT NULL,
  `imagen` varchar(400) DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_fecha` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: novedades
DROP TABLE IF EXISTS `novedades`;
CREATE TABLE `novedades` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo` enum('nuevo','mejora','mantenimiento','alerta') DEFAULT 'nuevo',
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: equipo
DROP TABLE IF EXISTS `equipo`;
CREATE TABLE `equipo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned DEFAULT NULL COMMENT 'Si existe cuenta, linkear',
  `nombre` varchar(150) NOT NULL,
  `rol` varchar(100) DEFAULT NULL,
  `cargo_equipo` varchar(100) DEFAULT NULL,
  `area_tecnologica` varchar(80) DEFAULT NULL,
  `tipo_equipo` varchar(80) DEFAULT NULL,
  `habilidades` text DEFAULT NULL,
  `disponible` tinyint(1) DEFAULT 1,
  `calificacion` decimal(3,2) DEFAULT 0.00,
  `num_proyectos` int(10) unsigned DEFAULT 0,
  `descripcion_equipo` text DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `github` varchar(255) DEFAULT NULL,
  `imagen` varchar(300) DEFAULT 'assets/avatar-default.png',
  `bio` text DEFAULT NULL,
  `activo` tinyint(1) DEFAULT 1,
  `orden` smallint(5) unsigned DEFAULT 0,
  `categoria_id` int(10) unsigned DEFAULT NULL,
  `correo` varchar(180) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `proyectos_csv` varchar(500) DEFAULT NULL COMMENT 'IDs de proyectos separados por coma',
  `areas_csv` varchar(500) DEFAULT NULL COMMENT 'Áreas de especialidad',
  PRIMARY KEY (`id`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabla: ia_conversaciones
DROP TABLE IF EXISTS `ia_conversaciones`;
CREATE TABLE `ia_conversaciones` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` int(10) unsigned NOT NULL,
  `titulo` varchar(200) DEFAULT NULL,
  `tool_id` varchar(50) DEFAULT 'asistente',
  `resumen` text DEFAULT NULL,
  `tokens_usados` int(10) unsigned DEFAULT 0,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_usuario_fecha` (`usuario_id`,`fecha`),
  CONSTRAINT `fk_ia_conv_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Historial de conversaciones con la IA VIROX';

SET FOREIGN_KEY_CHECKS = 1;
