<?php
include_once __DIR__ . '/../conexion.php'; 
session_start();

if (!isset($_SESSION['user_id']))          { header('Location: login.php');  exit(); }
if (($_SESSION['rol'] ?? '') !== 'superadmin') { header('Location: index.php'); exit(); }

$uid    = (int)$_SESSION['user_id'];
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'SuperAdmin');
$avatar = htmlspecialchars($_SESSION['avatar']    ?? '../assets/Tesla.png');

/* ──────────────── helpers ──────────────── */
function qrow($db,$sql,$t='',...$p):?array{
    $s=$db->prepare($sql);if(!$s)return null;
    if($t)$s->bind_param($t,...$p);
    $s->execute();$r=$s->get_result()->fetch_assoc();$s->close();return $r;
}
function qall($db,$sql,$t='',...$p):array{
    $s=$db->prepare($sql);if(!$s)return[];
    if($t)$s->bind_param($t,...$p);
    $s->execute();$rows=$s->get_result()->fetch_all(MYSQLI_ASSOC);$s->close();return $rows;
}
function qval($db,$sql,$t='',...$p):mixed{
    $r=qrow($db,$sql,$t,...$p);return $r?reset($r):0;
}
function sanitize(string $v):string{return htmlspecialchars(trim($v),ENT_QUOTES,'UTF-8');}


if ($_SERVER['REQUEST_METHOD']==='POST'){
    header('Content-Type: application/json');
    $a = $_POST['accion'] ?? '';

    if ($a==='upsert_config'){
        $clave=sanitize($_POST['clave']??'');
        $valor=htmlspecialchars($_POST['valor']??'',ENT_QUOTES,'UTF-8');
        $grupo=sanitize($_POST['grupo']??'general');
        $tipo =sanitize($_POST['tipo'] ??'texto');
        if($clave){
            $q=$conexion->prepare("INSERT INTO configuracion(clave,valor,grupo,tipo) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor),grupo=VALUES(grupo),tipo=VALUES(tipo)");
            if($q){$q->bind_param("ssss",$clave,$valor,$grupo,$tipo);$q->execute();$q->close();}
            // auditoría
            $ip  = $_SERVER['REMOTE_ADDR'] ?? '';
            $det = json_encode(['clave' => $clave, 'valor' => $valor]);
            $tbl = 'configuracion';
            $op  = 'UPDATE';

$aud = $conexion->prepare(
    "INSERT INTO auditoria(usuario_id, tabla, operacion, registro_id, datos_despues, ip, fecha)
     VALUES (?, ?, ?, ?, ?, ?, NOW())"
);
if ($aud) {
    $aud->bind_param("isssss", $uid, $tbl, $op, $clave, $det, $ip);
    $aud->execute();
    $aud->close();
}
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Clave vacía']);
        exit();
    }

    /* ── Servicios CRUD ── */
    if ($a==='crud_servicio'){
        $op   = $_POST['op']??'';
        $id   = (int)($_POST['id']??0);
        $fields=[
            'titulo'      =>sanitize($_POST['titulo']??''),
            'subtitulo'   =>sanitize($_POST['subtitulo']??''),
            'definicion'  =>htmlspecialchars($_POST['definicion']??'',ENT_QUOTES,'UTF-8'),
            'importancia' =>htmlspecialchars($_POST['importancia']??'',ENT_QUOTES,'UTF-8'),
            'categoria'   =>sanitize($_POST['categoria']??''),
            'icono'       =>sanitize($_POST['icono']??'🛠'),
            'nivel'       =>sanitize($_POST['nivel']??''),
            'duracion'    =>sanitize($_POST['duracion']??''),
            'precio_base' =>(float)($_POST['precio_base']??0),
            'foto'        =>sanitize($_POST['foto']??''),
            'video'       =>sanitize($_POST['video']??''),
            'color'       =>sanitize($_POST['color']??'green'),
            'activo'      =>(int)($_POST['activo']??1),
            'destacado'   =>(int)($_POST['destacado']??0),
        ];
        if ($op==='create' && $fields['titulo']){
            $q=$conexion->prepare("INSERT INTO servicios(titulo,subtitulo,definicion,importancia,categoria,icono,nivel,duracion,precio_base,foto,video,color,activo,destacado,slug,orden) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            if($q){
                $slug=strtolower(preg_replace('/[^a-z0-9]+/','-',$fields['titulo']));
                $ord=(int)qval($conexion,"SELECT COALESCE(MAX(orden),0)+1 FROM servicios");
                $q->bind_param("ssssssssdsssiiis",$fields['titulo'],$fields['subtitulo'],$fields['definicion'],$fields['importancia'],$fields['categoria'],$fields['icono'],$fields['nivel'],$fields['duracion'],$fields['precio_base'],$fields['foto'],$fields['video'],$fields['color'],$fields['activo'],$fields['destacado'],$slug,$ord);
                $q->execute();$lid=$conexion->insert_id;$q->close();
                echo json_encode(['ok'=>true,'id'=>$lid]);
            } else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='update' && $id){
            $q=$conexion->prepare("UPDATE servicios SET titulo=?,subtitulo=?,definicion=?,importancia=?,categoria=?,icono=?,nivel=?,duracion=?,precio_base=?,foto=?,video=?,color=?,activo=?,destacado=? WHERE id=?");
            if($q){$q->bind_param("ssssssssdsssiii",$fields['titulo'],$fields['subtitulo'],$fields['definicion'],$fields['importancia'],$fields['categoria'],$fields['icono'],$fields['nivel'],$fields['duracion'],$fields['precio_base'],$fields['foto'],$fields['video'],$fields['color'],$fields['activo'],$fields['destacado'],$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='delete' && $id){
            $q=$conexion->prepare("UPDATE servicios SET activo=0 WHERE id=?");
            if($q){$q->bind_param("i",$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op inválida']);
        exit();
    }

    /* ── Cursos CRUD ── */
    if ($a==='crud_curso'){
        $op=(string)($_POST['op']??'');
        $id=(int)($_POST['id']??0);
        if($op==='update'&&$id){
            $titulo=sanitize($_POST['titulo']??'');
            $desc=htmlspecialchars($_POST['descripcion']??'',ENT_QUOTES,'UTF-8');
            $nivel=sanitize($_POST['nivel']??'basico');
            $precio=(float)($_POST['precio']??0);
            $gratis=(int)($_POST['gratuito']??0);
            $pub=(int)($_POST['publicado']??1);
            $dest=(int)($_POST['destacado']??0);
            $q=$conexion->prepare("UPDATE cursos SET titulo=?,descripcion=?,nivel=?,precio=?,gratuito=?,publicado=?,destacado=? WHERE id=?");
            if($q){$q->bind_param("sssdiii i",$titulo,$desc,$nivel,$precio,$gratis,$pub,$dest,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='toggle'&&$id){
            $campo=in_array($_POST['campo']??'',['activo','publicado','destacado'])?$_POST['campo']:'activo';
            $val=(int)($_POST['valor']??1);
            $q=$conexion->prepare("UPDATE cursos SET {$campo}=? WHERE id=?");
            if($q){$q->bind_param("ii",$val,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op inválida']);
        exit();
    }

    /* ── Usuarios CRUD ── */
    if ($a==='crud_usuario'){
        $op=(string)($_POST['op']??'');
        $id=(int)($_POST['id']??0);
        if($op==='update'&&$id){
            $rol=in_array($_POST['rol']??'',['cliente','consultor','creador','empleado','admin','superadmin'])?$_POST['rol']:'cliente';
            $activo=(int)($_POST['activo']??1);
            $ver=(int)($_POST['verificado']??0);
            $area=sanitize($_POST['area_tecnologica']??'');
            $cargo=sanitize($_POST['cargo_equipo']??'');
            $q=$conexion->prepare("UPDATE usuarios SET rol=?,activo=?,verificado=?,area_tecnologica=?,cargo_equipo=? WHERE id=?");
            if($q){$q->bind_param("siiiss",$rol,$activo,$ver,$area,$cargo,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='delete'&&$id&&$id!==$uid){
            $q=$conexion->prepare("UPDATE usuarios SET activo=0 WHERE id=?");
            if($q){$q->bind_param("i",$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } elseif($op==='reset_pw'&&$id){
            $hash=password_hash('Virox@2025!',PASSWORD_BCRYPT,['cost'=>12]);
            $q=$conexion->prepare("UPDATE usuarios_seguridad SET password_hash=?,intentos_fallidos=0,bloqueado_hasta=NULL WHERE usuario_id=?");
            if($q){$q->bind_param("si",$hash,$id);$q->execute();$q->close();echo json_encode(['ok'=>true,'pw'=>'Virox@2025!']);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op inválida']);
        exit();
    }

    /* ── Proyectos CRUD ── */
    if ($a==='crud_proyecto'){
        $op=(string)($_POST['op']??'');
        $id=(int)($_POST['id']??0);
        if($op==='create'){
            $titulo=sanitize($_POST['titulo']??'');
            $desc=htmlspecialchars($_POST['descripcion']??'',ENT_QUOTES,'UTF-8');
            $tipo=in_array($_POST['tipo']??'',['propio','comunidad','cliente','academico'])?$_POST['tipo']:'propio';
            $ico=sanitize($_POST['icono']??'🚀');
            $areas=sanitize($_POST['areas']??'');
            $tecns=sanitize($_POST['tecnologias']??'');
            $fi=$_POST['fecha_inicio']??date('Y-m-d');
            $priv=(int)($_POST['privado']??0);
            if($titulo){
                $q=$conexion->prepare("INSERT INTO proyectos(titulo,descripcion,tipo,icono,areas,tecnologias,fecha_inicio,estado,privado,creado_por,fecha_creacion) VALUES(?,?,?,?,?,?,?,'planeado',?,?,NOW())");
                if($q){$q->bind_param("sssssssii",$titulo,$desc,$tipo,$ico,$areas,$tecns,$fi,$priv,$uid);$q->execute();$lid=$conexion->insert_id;$q->close();echo json_encode(['ok'=>true,'id'=>$lid]);}
                else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
            } else echo json_encode(['ok'=>false,'error'=>'Título requerido']);
        } elseif($op==='update'&&$id){
            $titulo=sanitize($_POST['titulo']??'');
            $desc=htmlspecialchars($_POST['descripcion']??'',ENT_QUOTES,'UTF-8');
            $estado=in_array($_POST['estado']??'',['planeado','activo','pausado','completado','cancelado'])?$_POST['estado']:'activo';
            $prog=min(100,max(0,(int)($_POST['progreso']??0)));
            $priv=(int)($_POST['privado']??0);
            $q=$conexion->prepare("UPDATE proyectos SET titulo=?,descripcion=?,estado=?,progreso=?,privado=?,fecha_update=NOW() WHERE id=?");
            if($q){$q->bind_param("sssiii",$titulo,$desc,$estado,$prog,$priv,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='delete'&&$id){
            $q=$conexion->prepare("DELETE FROM proyectos WHERE id=?");
            if($q){$q->bind_param("i",$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op inválida']);
        exit();
    }

    /* ── Contenido (noticias/novedades/publicaciones) CRUD ── */
    if ($a==='crud_contenido'){
        $tabla_raw=sanitize($_POST['tabla']??'');
        $tablas_ok=['noticias','novedades','publicaciones','galerias'];
        if(!in_array($tabla_raw,$tablas_ok)){echo json_encode(['ok'=>false,'error'=>'Tabla no permitida']);exit();}
        $tabla=$tabla_raw;
        $op=(string)($_POST['op']??'');
        $id=(int)($_POST['id']??0);
        if($op==='delete'&&$id){
            $campo_activo=($tabla==='novedades')?'activo':'activo';
            $q=$conexion->prepare("UPDATE `{$tabla}` SET activo=0 WHERE id=?");
            if(!$q)$q=$conexion->prepare("DELETE FROM `{$tabla}` WHERE id=?");
            if($q){$q->bind_param("i",$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='toggle'&&$id){
            $val=(int)($_POST['valor']??1);
            $campo=($tabla==='noticias'||$tabla==='publicaciones')?'publicado':'activo';
            $q=$conexion->prepare("UPDATE `{$tabla}` SET {$campo}=? WHERE id=?");
            if($q){$q->bind_param("ii",$val,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op no soportada']);
        exit();
    }

    /* ── ERP: pagos / adquisiciones ── */
    if ($a==='erp_accion'){
        $op=(string)($_POST['op']??'');
        $id=(int)($_POST['id']??0);
        if($op==='update_estado'&&$id){
            $estado=in_array($_POST['estado']??'',['pendiente','pagado','cancelado','reembolsado'])?$_POST['estado']:'pendiente';
            $q=$conexion->prepare("UPDATE servicio_adquisiciones SET estado=? WHERE id=?");
            if($q){$q->bind_param("si",$estado,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } elseif($op==='update_monto'&&$id){
            $monto=(float)($_POST['monto']??0);
            $q=$conexion->prepare("UPDATE servicio_adquisiciones SET monto=? WHERE id=?");
            if($q){$q->bind_param("di",$monto,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false]);
        } else echo json_encode(['ok'=>false,'error'=>'Op inválida']);
        exit();
    }

    /* ── Backup ── */
    if ($a==='generar_backup'){
        $tipo=in_array($_POST['tipo']??'',['completo','solo_datos','solo_estructura'])?$_POST['tipo']:'completo';
        $ts=date('Ymd_His');
        $filename="backup_virox_{$tipo}_{$ts}.sql";
        $path="/tmp/{$filename}";

        // Generar SQL de las tablas más críticas
        $tablas=['usuarios','usuarios_seguridad','servicios','proyectos','proyecto_usuarios','proyecto_avances','cursos','inscripciones','certificados','configuracion','pagos','servicio_adquisiciones','pqrs','contacto_mensajes','mensajes_internos','publicaciones','noticias','novedades','equipo','ia_conversaciones'];
        $sql_content="-- =============================================\n";
        $sql_content.="-- VIROX Backup: {$tipo}\n";
        $sql_content.="-- Fecha: ".date('Y-m-d H:i:s')."\n";
        $sql_content.="-- Generado por: SuperAdmin #{$uid}\n";
        $sql_content.="-- =============================================\n\n";
        $sql_content.="SET FOREIGN_KEY_CHECKS = 0;\nSET NAMES utf8mb4;\nUSE `container`;\n\n";

        foreach($tablas as $tbl){
            // Estructura
            if($tipo!=='solo_datos'){
                $res=$conexion->query("SHOW CREATE TABLE `{$tbl}`");
                if($res){$row=$res->fetch_assoc();$sql_content.="-- Tabla: {$tbl}\n";$sql_content.="DROP TABLE IF EXISTS `{$tbl}`;\n";$key=array_key_last($row);$sql_content.=$row[$key].";\n\n";}
            }
            // Datos
            if($tipo!=='solo_estructura'){
                $res=$conexion->query("SELECT * FROM `{$tbl}` LIMIT 5000");
                if($res&&$res->num_rows>0){
                    $sql_content.="-- Datos: {$tbl}\n";
                    $cols=[];$fi=$res->fetch_fields();foreach($fi as $f)$cols[]="`{$f->name}`";
                    $cols_str=implode(',',$cols);
                    while($row=$res->fetch_row()){
                        $vals=array_map(fn($v)=>is_null($v)?'NULL':"'".$conexion->real_escape_string($v)."'",$row);
                        $sql_content.="INSERT INTO `{$tbl}` ({$cols_str}) VALUES (".implode(',',$vals).");\n";
                    }
                    $sql_content.="\n";
                }
            }
        }
        $sql_content.="SET FOREIGN_KEY_CHECKS = 1;\n";

        // Guardar en servidor
        $backup_dir='backups/';
        if(!is_dir($backup_dir))@mkdir($backup_dir,0755,true);
        file_put_contents($backup_dir.$filename,$sql_content);

        // Registrar en configuracion
        $last=json_encode(['filename'=>$filename,'tipo'=>$tipo,'fecha'=>date('Y-m-d H:i:s'),'size'=>strlen($sql_content)]);
        $q=$conexion->prepare("INSERT INTO configuracion(clave,valor,grupo,tipo) VALUES('ultimo_backup',?,?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor),grupo=VALUES(grupo)");
        if($q){$g='backups';$t='json';$q->bind_param("sss",$last,$g,$t);$q->execute();$q->close();}

        echo json_encode(['ok'=>true,'filename'=>$filename,'size'=>strlen($sql_content),'rows'=>substr_count($sql_content,"\n")]);
        exit();
    }

    /* ── Descargar backup ── */
    if ($a==='descargar_backup'){
        $filename=basename($_POST['filename']??'');
        $path='backups/'.$filename;
        if($filename&&file_exists($path)){
            // Devolver contenido como base64
            $content=file_get_contents($path);
            echo json_encode(['ok'=>true,'content'=>base64_encode($content),'filename'=>$filename]);
        } else {
            echo json_encode(['ok'=>false,'error'=>'Archivo no encontrado']);
        }
        exit();
    }

    /* ── Eliminar backup ── */
    if ($a==='eliminar_backup'){
        $filename=basename($_POST['filename']??'');
        $path='backups/'.$filename;
        if($filename&&file_exists($path)){@unlink($path);echo json_encode(['ok'=>true]);}
        else echo json_encode(['ok'=>false,'error'=>'No encontrado']);
        exit();
    }

    /* ── Listar backups ── */
    if ($a==='listar_backups'){
        $dir='backups/';$files=[];
        if(is_dir($dir)){
            foreach(glob($dir.'backup_virox_*.sql') as $f){
                $files[]=['filename'=>basename($f),'size'=>filesize($f),'fecha'=>date('Y-m-d H:i:s',filemtime($f))];
            }
            usort($files,fn($a,$b)=>strcmp($b['fecha'],$a['fecha']));
        }
        echo json_encode(['ok'=>true,'backups'=>$files]);
        exit();
    }

    /* ── Limpiar caché ── */
    if ($a==='limpiar_cache'){
        $q=$conexion->query("DELETE FROM cache_sistema WHERE expira_en < NOW()");
        $rows=$q?$conexion->affected_rows:0;
        $q2=$conexion->query("DELETE FROM rate_limit WHERE bloqueado_hasta < NOW() AND bloqueado_hasta IS NOT NULL");
        echo json_encode(['ok'=>true,'eliminados'=>$rows]);
        exit();
    }

    /* ── PQRS gestionar ── */
    if ($a==='gestionar_pqrs'){
        $id=(int)($_POST['id']??0);
        $estado=in_array($_POST['estado']??'',['abierto','en_proceso','resuelto','cerrado'])?$_POST['estado']:'abierto';
        $resp=htmlspecialchars($_POST['respuesta']??'',ENT_QUOTES,'UTF-8');
        if($id){
            $q=$conexion->prepare("UPDATE pqrs SET estado=?,respuesta=?,fecha_respuesta=NOW(),respondido_por=? WHERE id=?");
            if($q){$q->bind_param("ssii",$estado,$resp,$uid,$id);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'ID inválido']);
        exit();
    }

    echo json_encode(['ok'=>false,'error'=>'Acción no reconocida: '.$a]);
    exit();
}

// ═══════════════════════════════════════════════════════════════════════
//  DATOS DEL DASHBOARD
// ═══════════════════════════════════════════════════════════════════════
$cfg_all = qall($conexion,"SELECT clave,valor,grupo,tipo FROM configuracion ORDER BY grupo,clave");
$cfg_map = []; foreach($cfg_all as $c) $cfg_map[$c['clave']] = $c['valor'];

/* Servicios */
$servicios = qall($conexion,"SELECT id,icono,titulo,subtitulo,categoria,nivel,duracion,precio_base,color,activo,destacado,slug FROM servicios ORDER BY categoria,titulo LIMIT 50");
$planes    = qall($conexion,"SELECT sp.*,s.titulo AS srv_titulo FROM servicio_planes sp JOIN servicios s ON s.id=sp.servicio_id ORDER BY sp.servicio_id,sp.orden LIMIT 100");

/* Cursos */
$cursos = qall($conexion,"SELECT c.*,u.nombre AS inst_nombre FROM cursos c LEFT JOIN usuarios u ON u.id=c.instructor_id WHERE c.activo=1 ORDER BY c.destacado DESC,c.id DESC LIMIT 40");

/* Usuarios */
$usuarios = qall($conexion,"SELECT u.id,u.nombre,u.apellido,u.username,u.rol,u.activo,u.verificado,u.fecha_registro,u.ultimo_acceso,u.area_tecnologica,u.cargo_equipo,us.correo FROM usuarios u LEFT JOIN usuarios_seguridad us ON us.usuario_id=u.id ORDER BY u.fecha_registro DESC LIMIT 120");

/* Proyectos */
$proyectos = qall($conexion,"SELECT p.*,u.nombre AS creador_nombre,(SELECT COUNT(*) FROM proyecto_usuarios pu WHERE pu.proyecto_id=p.id) AS miembros FROM proyectos p LEFT JOIN usuarios u ON u.id=p.creado_por ORDER BY p.fecha_creacion DESC LIMIT 60");

/* ERP: adquisiciones */
$adquisiciones = qall($conexion,"SELECT sa.*,s.titulo AS srv_titulo,s.icono AS srv_icono,s.precio_base,u.nombre AS cli_nombre,u.apellido AS cli_ap FROM servicio_adquisiciones sa JOIN servicios s ON s.id=sa.servicio_id JOIN usuarios u ON u.id=sa.usuario_id ORDER BY sa.fecha DESC LIMIT 80");

/* PQRS */
$pqrs_all = qall($conexion,"SELECT p.*,u.nombre AS usr_nom,u.apellido AS usr_ap FROM pqrs p LEFT JOIN usuarios u ON u.id=p.usuario_id ORDER BY FIELD(p.prioridad,'urgente','alta','normal','baja'),p.fecha DESC LIMIT 60");

/* Noticias y publicaciones */
$noticias    = qall($conexion,"SELECT id,titulo,fecha,activo FROM noticias ORDER BY fecha DESC LIMIT 20");
$novedades   = qall($conexion,"SELECT id,titulo,tipo,fecha FROM novedades ORDER BY fecha DESC LIMIT 20");
$publicaciones = qall($conexion,"SELECT id,titulo,fecha_pub,publicado FROM publicaciones ORDER BY fecha_pub DESC LIMIT 20");

/* Log auditoría */
$auditoria = qall($conexion,"SELECT a.*,u.nombre,u.apellido FROM auditoria a LEFT JOIN usuarios u ON u.id=a.usuario_id ORDER BY a.fecha DESC LIMIT 50");

/* Log accesos */
$log_accesos = qall($conexion,"SELECT la.*,u.nombre,u.apellido,u.rol FROM log_accesos la LEFT JOIN usuarios u ON u.id=la.usuario_id ORDER BY la.fecha DESC LIMIT 40");

/* Rate limit (bloqueos) */
$rate_limits = qall($conexion,"SELECT * FROM rate_limit WHERE bloqueado_hasta IS NOT NULL AND bloqueado_hasta > NOW() ORDER BY bloqueado_hasta DESC LIMIT 20");

/* KPIs generales */
$kpi = [
    'usuarios_total'   => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios"),
    'usuarios_activos' => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios WHERE activo=1"),
    'empleados'        => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios WHERE rol IN('empleado','admin','superadmin') AND activo=1"),
    'proyectos_total'  => (int)qval($conexion,"SELECT COUNT(*) FROM proyectos"),
    'proyectos_activos'=> (int)qval($conexion,"SELECT COUNT(*) FROM proyectos WHERE estado='activo'"),
    'servicios_total'  => (int)qval($conexion,"SELECT COUNT(*) FROM servicios WHERE activo=1"),
    'cursos_total'     => (int)qval($conexion,"SELECT COUNT(*) FROM cursos WHERE activo=1"),
    'ingresos_mes'     => (float)(qval($conexion,"SELECT COALESCE(SUM(monto),0) FROM servicio_adquisiciones WHERE estado='pagado' AND MONTH(fecha)=MONTH(NOW()) AND YEAR(fecha)=YEAR(NOW())") ?? 0),
    'ingresos_total'   => (float)(qval($conexion,"SELECT COALESCE(SUM(monto),0) FROM servicio_adquisiciones WHERE estado='pagado'") ?? 0),
    'pqrs_abiertas'    => (int)qval($conexion,"SELECT COUNT(*) FROM pqrs WHERE estado IN('abierto','en_proceso')"),
    'adq_pendientes'   => (int)qval($conexion,"SELECT COUNT(*) FROM servicio_adquisiciones WHERE estado='pendiente'"),
    'backups_cnt'      => count(glob('backups/backup_virox_*.sql') ?: []),
    'logins_hoy'       => (int)qval($conexion,"SELECT COUNT(*) FROM log_accesos WHERE accion='login_ok' AND DATE(fecha)=CURDATE()"),
    'cache_items'      => (int)qval($conexion,"SELECT COUNT(*) FROM cache_sistema WHERE expira_en > NOW()"),
];

/* Ingresos últimos 12 meses para gráfico */
$ingresos_12m = qall($conexion,"SELECT DATE_FORMAT(fecha,'%Y-%m') AS mes, COALESCE(SUM(monto),0) AS total FROM servicio_adquisiciones WHERE estado='pagado' AND fecha >= DATE_SUB(CURDATE(),INTERVAL 12 MONTH) GROUP BY mes ORDER BY mes ASC");

/* Usuarios por rol para gráfico */
$roles_dist = qall($conexion,"SELECT rol, COUNT(*) AS cnt FROM usuarios WHERE activo=1 GROUP BY rol ORDER BY cnt DESC");

/* Ultimo backup */
$ultimo_bk = json_decode($cfg_map['ultimo_backup'] ?? '{}', true);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SuperAdmin</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* ════════════ VARIABLES ════════════ */
:root{
  --n950:#010610;--n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
  --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
  --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
  --blue:#3b82f6;--blue-lt:#93c5fd;--blue-dim:rgba(59,130,246,.13);
  --purple:#8b5cf6;--purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
  --red:#ef4444;--red-lt:#fca5a5;--red-dim:rgba(239,68,68,.12);
  --orange:#f97316;--orange-dim:rgba(249,115,22,.13);
  --teal:#14b8a6;--teal-dim:rgba(20,184,166,.13);
  --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
  --sh-sm:0 4px 18px rgba(0,0,0,.4);--sh-md:0 10px 36px rgba(0,0,0,.5);--sh-lg:0 24px 64px rgba(0,0,0,.65);
  --r-sm:8px;--r-md:14px;--r-lg:20px;--r-xl:28px;
  --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
  --sw:270px;--th:64px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
html{scroll-behavior:smooth;}
body{font-family:var(--font-b);background:var(--n950);color:var(--txt);min-height:100vh;overflow-x:hidden;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-track{background:var(--n800);}
::-webkit-scrollbar-thumb{background:linear-gradient(var(--gold),var(--green));border-radius:99px;}
a{text-decoration:none;color:inherit;}
button{cursor:pointer;border:none;font-family:var(--font-b);background:none;}
img{display:block;max-width:100%;}

/* ════ LAYOUT ════ */
.sa-wrap{display:grid;grid-template-columns:var(--sw) 1fr;grid-template-rows:var(--th) 1fr;grid-template-areas:"sb tb""sb main";min-height:100vh;}

/* ════ SIDEBAR ════ */
.sa-sb{grid-area:sb;position:fixed;top:0;left:0;bottom:0;width:var(--sw);z-index:400;
  background:linear-gradient(180deg,#050d1a 0%,#020817 100%);
  border-right:1px solid rgba(218,165,32,.18);
  display:flex;flex-direction:column;transition:transform .3s;}
.sb-logo{display:flex;align-items:center;gap:12px;padding:0 20px;height:var(--th);
  border-bottom:1px solid rgba(218,165,32,.12);flex-shrink:0;}
.sb-logo-hex{width:38px;height:38px;border-radius:12px;
  background:linear-gradient(135deg,var(--gold),#8b6914);
  display:flex;align-items:center;justify-content:center;
  font-size:1rem;font-family:var(--font-d);font-weight:900;color:#000;
  box-shadow:0 0 16px rgba(218,165,32,.4);flex-shrink:0;}
.sb-logo-name{font-family:var(--font-d);font-size:.88rem;font-weight:900;color:var(--gold);letter-spacing:3px;}
.sb-logo-badge{margin-left:auto;padding:2px 7px;background:rgba(139,92,246,.2);border:1px solid rgba(139,92,246,.4);border-radius:99px;font-size:.55rem;font-weight:800;color:var(--purple-lt);letter-spacing:1px;white-space:nowrap;}

.sb-prof{display:flex;align-items:center;gap:11px;padding:14px 18px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;}
.sb-av{width:42px;height:42px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);box-shadow:0 0 14px rgba(218,165,32,.35);flex-shrink:0;}
.sb-name{font-size:.82rem;font-weight:700;color:var(--txt);}
.sb-role{font-size:.62rem;color:var(--gold-lt);text-transform:uppercase;letter-spacing:1px;}

.sb-nav{flex:1;overflow-y:auto;padding:10px 10px;overflow-x:hidden;}
.sb-nav::-webkit-scrollbar{width:2px;}
.sb-slbl{font-size:.56rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 10px 4px;}
.sb-item{display:flex;align-items:center;gap:11px;padding:10px 11px;border-radius:var(--r-md);
  color:var(--muted);font-size:.82rem;font-weight:600;cursor:pointer;
  transition:all .2s;border-left:3px solid transparent;margin-bottom:2px;}
.sb-item:hover{background:rgba(255,255,255,.05);color:var(--txt);}
.sb-item.on{background:var(--gold-dim);color:var(--gold-lt);border-left-color:var(--gold);}
.sb-item .sbi{width:17px;text-align:center;flex-shrink:0;}
.sb-item .sbb{margin-left:auto;padding:1px 6px;border-radius:99px;font-size:.57rem;font-weight:800;}
.sbb-red{background:var(--red);color:#fff;}
.sbb-gold{background:var(--gold);color:#000;}
.sbb-purple{background:var(--purple);color:#fff;}
.sb-sep{height:1px;background:rgba(255,255,255,.06);margin:7px 10px;}
.sb-foot{padding:12px 10px;border-top:1px solid rgba(255,255,255,.06);display:flex;gap:6px;flex-shrink:0;}
.sf-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border-radius:var(--r-md);font-size:.72rem;font-weight:700;transition:all .2s;}
.sfb-admin{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.2);color:var(--green-lt);}
.sfb-admin:hover{background:rgba(40,166,128,.2);}
.sfb-out{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;}
.sfb-out:hover{background:rgba(239,68,68,.2);}

/* ════ TOPBAR ════ */
.sa-tb{grid-area:tb;position:sticky;top:0;z-index:300;height:var(--th);
  background:rgba(2,8,23,.94);backdrop-filter:blur(22px);
  border-bottom:1px solid rgba(218,165,32,.14);
  display:flex;align-items:center;gap:14px;padding:0 24px;}
.tb-menu-btn{display:none;width:34px;height:34px;border-radius:var(--r-sm);background:rgba(255,255,255,.05);color:var(--muted);align-items:center;justify-content:center;}
.tb-ttl{font-family:var(--font-d);font-size:.82rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.tb-sub{font-size:.72rem;color:var(--muted);}
.tb-srch{flex:1;max-width:400px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:99px;padding:7px 16px;transition:all .2s;}
.tb-srch:focus-within{border-color:var(--gold);box-shadow:0 0 0 3px rgba(218,165,32,.1);}
.tb-srch input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:100%;}
.tb-srch input::placeholder{color:var(--dim);}
.tb-acts{margin-left:auto;display:flex;align-items:center;gap:8px;}
.tb-btn{width:33px;height:33px;border-radius:50%;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.78rem;transition:all .2s;position:relative;cursor:pointer;}
.tb-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}
.tb-ndot{position:absolute;top:5px;right:5px;width:7px;height:7px;border-radius:50%;background:var(--red);border:2px solid var(--n900);}
.tb-av{width:33px;height:33px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);cursor:pointer;}

/* ════ MAIN ════ */
.sa-main{grid-area:main;padding:26px;min-width:0;overflow-x:hidden;}
.sa-sec{display:none;animation:secIn .35s ease both;}
.sa-sec.on{display:block;}
@keyframes secIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* ════ HERO ════ */
.sa-hero{position:relative;overflow:hidden;border-radius:var(--r-xl);padding:28px 32px;margin-bottom:24px;
  background:linear-gradient(135deg,#0a1100,#090515,#001a0d);
  border:1px solid rgba(218,165,32,.25);}
.hero-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(218,165,32,.04)1px,transparent 1px),linear-gradient(90deg,rgba(218,165,32,.04)1px,transparent 1px);background-size:36px 36px;}
.hero-orb{position:absolute;border-radius:50%;filter:blur(80px);}
.ho1{width:350px;height:350px;background:radial-gradient(circle,rgba(218,165,32,.2),transparent 70%);top:-100px;right:-80px;animation:hoAnim 10s ease-in-out infinite;}
.ho2{width:280px;height:280px;background:radial-gradient(circle,rgba(139,92,246,.12),transparent 70%);bottom:-70px;left:-50px;animation:hoAnim 13s ease-in-out infinite reverse;}
.ho3{width:200px;height:200px;background:radial-gradient(circle,rgba(40,166,128,.1),transparent 70%);top:50%;right:30%;animation:hoAnim 8s ease-in-out infinite;}
@keyframes hoAnim{0%,100%{transform:translate(0,0)}50%{transform:translate(18px,-18px)}}
.hero-cnt{position:relative;z-index:1;display:flex;align-items:center;gap:24px;}
.hero-av{width:70px;height:70px;border-radius:50%;object-fit:cover;border:3px solid var(--gold);box-shadow:0 0 28px rgba(218,165,32,.5);flex-shrink:0;}
.hero-tag{display:inline-flex;align-items:center;gap:6px;padding:3px 10px;background:var(--purple-dim);border:1px solid rgba(139,92,246,.4);border-radius:99px;font-size:.62rem;font-weight:800;color:var(--purple-lt);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:6px;}
.hero-name{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--txt);letter-spacing:1px;margin-bottom:3px;}
.hero-sub{font-size:.8rem;color:var(--gold-lt);margin-bottom:10px;}
.hero-chips{display:flex;flex-wrap:wrap;gap:5px;}
.hero-chip{padding:3px 9px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.63rem;color:var(--muted);}
.hero-stats{margin-left:auto;display:grid;grid-template-columns:1fr 1fr;gap:12px 20px;flex-shrink:0;}
.hs{text-align:center;}
.hs-n{font-family:var(--font-d);font-size:1.5rem;font-weight:900;color:var(--gold);}
.hs-l{font-size:.58rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:1px;}

/* ════ KPI GRID ════ */
.kpi-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin-bottom:22px;}
.kpi-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:15px 16px;display:flex;align-items:center;gap:12px;transition:transform .25s,border-color .25s;cursor:pointer;}
.kpi-card:hover{transform:translateY(-3px);}
.kc-ico{width:40px;height:40px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.15rem;flex-shrink:0;}
.kci-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);}
.kci-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);}
.kci-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);}
.kci-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);}
.kci-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);}
.kci-orange{background:var(--orange-dim);border:1px solid rgba(249,115,22,.3);}
.kci-teal{background:var(--teal-dim);border:1px solid rgba(20,184,166,.3);}
.kc-num{font-family:var(--font-d);font-size:1.45rem;font-weight:900;color:var(--gold);line-height:1;}
.kc-lbl{font-size:.62rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

/* ════ SECTION HEADERS ════ */
.sec-hd{display:flex;align-items:center;gap:11px;margin-bottom:15px;}
.sec-hd h2{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.sec-hd-line{flex:1;height:1px;background:linear-gradient(to right,rgba(218,165,32,.35),transparent);}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 15px;border-radius:99px;font-size:.75rem;font-weight:700;transition:all .2s;cursor:pointer;white-space:nowrap;}
.btn-gold{background:var(--gold);color:#000;}
.btn-gold:hover{background:var(--gold-lt);}
.btn-green{background:var(--green);color:#fff;}
.btn-green:hover{background:var(--green-lt);}
.btn-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.btn-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt);}
.btn-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.btn-red:hover{background:var(--red);color:#fff;}
.btn-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);color:var(--purple-lt);}
.btn-purple:hover{background:var(--purple);color:#fff;}
.btn-sm{padding:4px 10px;font-size:.68rem;}

/* ════ CARD BASE ════ */
.card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);transition:border-color .2s;}
.card:hover{border-color:rgba(218,165,32,.18);}
.cp{padding:18px 20px;}

/* ════ TABLA ════ */
.t-wrap{overflow-x:auto;}
.tbl{width:100%;border-collapse:collapse;}
.tbl th{padding:9px 13px;text-align:left;font-size:.58rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.02);}
.tbl td{padding:10px 13px;font-size:.8rem;color:var(--muted);border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle;}
.tbl tr:hover td{background:rgba(255,255,255,.03);}
.tbl tr:last-child td{border-bottom:none;}

/* ════ BADGES ════ */
.b{padding:2px 9px;border-radius:99px;font-size:.62rem;font-weight:700;display:inline-flex;align-items:center;gap:3px;}
.b-superadmin{background:var(--purple-dim);color:var(--purple-lt);border:1px solid rgba(139,92,246,.3);}
.b-admin{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
.b-empleado{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.b-creador{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
.b-cliente,.b-consultor{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.1);}
.b-activo,.b-pagado{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.b-inactivo,.b-cancelado{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
.b-pendiente,.b-planeado{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
.b-completado,.b-resuelto{background:var(--teal-dim);color:#5eead4;border:1px solid rgba(20,184,166,.3);}
.b-pausado,.b-en_proceso{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
.b-urgente{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
.b-alta{background:var(--orange-dim);color:#fdba74;border:1px solid rgba(249,115,22,.3);}
.b-normal{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
.b-baja{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.b-verificado{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}

/* ════ ACT BUTTONS ════ */
.ab{display:inline-flex;align-items:center;gap:3px;padding:4px 9px;border-radius:var(--r-sm);font-size:.68rem;font-weight:700;transition:all .2s;cursor:pointer;}
.ab-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
.ab-gold:hover{background:var(--gold);color:#000;}
.ab-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
.ab-green:hover{background:var(--green);color:#fff;}
.ab-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.ab-red:hover{background:var(--red);color:#fff;}
.ab-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);color:var(--blue-lt);}
.ab-blue:hover{background:var(--blue);color:#fff;}
.ab-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.ab-ghost:hover{background:rgba(255,255,255,.12);color:var(--txt);}

/* ════ CONFIG PANEL ════ */
.cfg-group{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:20px;margin-bottom:14px;}
.cfg-gtitle{font-size:.7rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;gap:7px;}
.cfg-row{display:flex;align-items:flex-start;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.05);gap:16px;}
.cfg-row:last-child{border-bottom:none;}
.cfg-info .cfg-lbl{font-size:.82rem;font-weight:600;color:var(--txt);margin-bottom:2px;}
.cfg-info .cfg-key{font-size:.62rem;color:var(--dim);font-family:monospace;}
.cfg-ctrl{display:flex;align-items:center;gap:8px;flex-shrink:0;}
.cfg-inp{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-sm);color:var(--txt);font-family:var(--font-b);font-size:.8rem;padding:6px 10px;outline:none;transition:border-color .2s;min-width:180px;}
.cfg-inp:focus{border-color:var(--gold);}
textarea.cfg-inp{min-height:70px;resize:vertical;line-height:1.55;min-width:220px;}
.cfg-save-btn{padding:5px 13px;background:var(--gold);color:#000;border-radius:var(--r-sm);font-size:.7rem;font-weight:800;transition:all .2s;cursor:pointer;}
.cfg-save-btn:hover{background:var(--gold-lt);}

/* ════ PRECIO INPUT ════ */
.precio-wrap{display:flex;align-items:center;gap:6px;}
.precio-sym{font-size:.75rem;color:var(--dim);}
.precio-inp{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-sm);color:var(--gold-lt);font-family:var(--font-d);font-size:.9rem;padding:5px 9px;width:110px;outline:none;font-weight:700;}
.precio-inp:focus{border-color:var(--gold);}

/* ════ BACKUP CARDS ════ */
.bk-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;}
.bk-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:18px;display:flex;flex-direction:column;gap:10px;transition:border-color .25s;}
.bk-card:hover{border-color:rgba(218,165,32,.3);}
.bk-ico{font-size:2rem;margin-bottom:4px;}
.bk-name{font-size:.78rem;font-weight:700;color:var(--txt);word-break:break-all;}
.bk-meta{font-size:.68rem;color:var(--muted);}
.bk-size{font-family:var(--font-d);font-size:.75rem;color:var(--gold);}
.bk-actions{display:flex;gap:7px;margin-top:4px;}

/* ════ GRÁFICOS BARRAS ════ */
.chart-box{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px;}
.chart-ttl{font-size:.75rem;font-weight:700;color:var(--txt);margin-bottom:14px;display:flex;align-items:center;gap:6px;}
.bars{display:flex;align-items:flex-end;gap:5px;height:90px;}
.bar-col{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.bar-r{width:100%;border-radius:3px 3px 0 0;min-height:4px;transition:height .9s ease;cursor:pointer;}
.bar-r:hover{filter:brightness(1.3);}
.bar-lbl{font-size:.52rem;color:var(--dim);text-align:center;white-space:nowrap;}
.bar-val{font-size:.56rem;font-weight:700;color:var(--gold);}

/* ════ DONUT CHART (CSS puro) ════ */
.donut-wrap{display:flex;align-items:center;gap:20px;}
.donut{position:relative;width:100px;height:100px;flex-shrink:0;}
.donut svg{transform:rotate(-90deg);}
.donut-center{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;}
.donut-n{font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);}
.donut-l{font-size:.55rem;color:var(--dim);text-transform:uppercase;}
.donut-legend{display:flex;flex-direction:column;gap:5px;flex:1;}
.dl-item{display:flex;align-items:center;gap:7px;font-size:.72rem;color:var(--muted);}
.dl-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;}

/* ════ ERP ════ */
.erp-sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:18px;}
.erp-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;text-align:center;}
.erp-ico{font-size:1.7rem;margin-bottom:6px;}
.erp-num{font-family:var(--font-d);font-size:1.5rem;font-weight:900;color:var(--gold);}
.erp-lbl{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

/* ════ PQRS ════ */
.pqrs-it{padding:12px 16px;border-radius:var(--r-md);background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);margin-bottom:7px;cursor:pointer;transition:all .2s;}
.pqrs-it:hover{border-color:rgba(218,165,32,.2);background:rgba(255,255,255,.05);}
.pqrs-it.urgente{border-left:3px solid var(--red);}
.pqrs-it.alta{border-left:3px solid var(--orange);}
.pqrs-it.normal{border-left:3px solid var(--blue);}
.pqrs-it.baja{border-left:3px solid var(--green);}
.pit-top{display:flex;align-items:center;gap:8px;margin-bottom:4px;}
.pit-folio{font-family:var(--font-d);font-size:.6rem;color:var(--gold);}
.pit-ttl{font-size:.82rem;font-weight:700;color:var(--txt);flex:1;}

/* ════ LOG ════ */
.log-it{display:flex;align-items:center;gap:11px;padding:8px 13px;border-radius:var(--r-md);background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);margin-bottom:5px;font-size:.76rem;}
.li{width:26px;height:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.7rem;flex-shrink:0;}
.li-ok{background:var(--green-dim);color:var(--green-lt);}
.li-fail{background:var(--red-dim);color:var(--red-lt);}
.li-act{background:var(--gold-dim);color:var(--gold-lt);}

/* ════ EMPTY ════ */
.empty{text-align:center;padding:40px 20px;color:var(--dim);}
.empty-ico{font-size:2.8rem;margin-bottom:10px;opacity:.3;}

/* ════ MODAL ════ */
.sa-modal{position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;overflow-y:auto;}
.sa-modal.on{display:flex;}
.m-box{background:var(--n800);border:1px solid rgba(218,165,32,.22);border-radius:var(--r-xl);width:100%;max-width:580px;box-shadow:var(--sh-lg);animation:mboxIn .3s ease both;margin:auto;}
.m-box.wide{max-width:780px;}
@keyframes mboxIn{from{opacity:0;transform:scale(.95)translateY(14px)}to{opacity:1;transform:none}}
.m-hd{display:flex;align-items:center;justify-content:space-between;padding:17px 22px;border-bottom:1px solid rgba(255,255,255,.07);}
.m-ttl{font-family:var(--font-d);font-size:.84rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.m-close{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
.m-close:hover{background:var(--red-dim);color:#f87171;}
.m-body{padding:18px 22px;}
.m-foot{padding:13px 22px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:8px;justify-content:flex-end;}

/* Form inputs modal */
.fg{margin-bottom:12px;}
.fl{display:block;font-size:.67rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
.fi{width:100%;padding:9px 13px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.86rem;transition:all .2s;outline:none;}
.fi:focus{border-color:var(--gold);background:rgba(218,165,32,.05);}
textarea.fi{resize:vertical;min-height:75px;line-height:1.6;}
select.fi option{background:var(--n700);}
.fg-2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.fg-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;}

/* ════ TOGGLE ════ */
.tg{position:relative;width:38px;height:20px;flex-shrink:0;}
.tg input{display:none;}
.tg-sl{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:.3s;}
.tg-sl::before{content:'';position:absolute;width:14px;height:14px;background:#fff;border-radius:50%;top:3px;left:3px;transition:.3s;box-shadow:0 1px 3px rgba(0,0,0,.4);}
.tg input:checked + .tg-sl{background:var(--green);}
.tg input:checked + .tg-sl::before{transform:translateX(18px);}

/* ════ QUICK ACTIONS ════ */
.qa-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:9px;margin-bottom:20px;}
.qa{display:flex;flex-direction:column;align-items:center;gap:7px;padding:14px 8px;background:var(--n800);border:1.5px dashed rgba(255,255,255,.1);border-radius:var(--r-lg);cursor:pointer;transition:all .25s;text-align:center;}
.qa:hover{background:var(--gold-dim);border-color:var(--gold);transform:translateY(-3px);}
.qa-ico{font-size:1.6rem;}
.qa-lbl{font-size:.7rem;font-weight:700;color:var(--muted);}
.qa:hover .qa-lbl{color:var(--gold-lt);}

/* ════ TOAST ════ */
.toast-w{position:fixed;bottom:22px;right:22px;z-index:10000;display:flex;flex-direction:column;gap:7px;}
.tst{display:flex;align-items:center;gap:9px;padding:10px 16px;border-radius:var(--r-md);font-size:.8rem;font-weight:600;animation:tstIn .3s ease both;max-width:310px;box-shadow:var(--sh-md);}
@keyframes tstIn{from{opacity:0;transform:translateX(18px)}to{opacity:1;transform:none}}
.t-ok{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
.t-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.t-info{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}

/* ════ PROGRESS BAR ════ */
.prog-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;margin-top:4px;}
.prog-fill{height:100%;background:linear-gradient(to right,var(--gold),var(--green));border-radius:99px;}

/* ════ RESPONSIVE ════ */
@media(max-width:1024px){.sa-wrap{grid-template-columns:1fr;grid-template-areas:"tb""main";}.sa-sb{transform:translateX(-100%);}.sa-sb.open{transform:translateX(0);}.sa-main{padding:16px;}.tb-menu-btn{display:flex;}.hero-stats{display:none;}.kpi-grid{grid-template-columns:repeat(2,1fr);}}
@media(max-width:600px){.kpi-grid{grid-template-columns:repeat(2,1fr);}.qa-grid{grid-template-columns:repeat(2,1fr);}}
</style>
</head>
<body>
<div class="sa-wrap" id="saWrap">

<!-- ══════════ SIDEBAR ══════════ -->
<aside class="sa-sb" id="saSb">
  <div class="sb-logo">
    <div class="sb-logo-hex">SA</div>
    <span class="sb-logo-name">VIROX</span>
    <span class="sb-logo-badge">SADMIN</span>
  </div>
  <div class="sb-prof">
    <img src="<?= $avatar ?>" alt="sa" class="sb-av" onerror="this.src='../assets/Tesla.png'">
    <div><div class="sb-name"><?= $nombre ?></div><div class="sb-role">SA</div></div>
  </div>
  <nav class="sb-nav">
    <div class="sb-slbl">Control</div>
    <div class="sb-item on" onclick="showSec('dashboard',this)"><span class="sbi"><i class="fa fa-gauge-high"></i></span>Dashboard</div>
    <div class="sb-item" onclick="showSec('usuarios',this)"><span class="sbi"><i class="fa fa-users"></i></span>Usuarios<span class="sbb sbb-gold"><?= $kpi['usuarios_total'] ?></span></div>
    <div class="sb-item" onclick="showSec('proyectos',this)"><span class="sbi"><i class="fa fa-diagram-project"></i></span>Proyectos</div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Contenido</div>
    <div class="sb-item" onclick="showSec('servicios',this)"><span class="sbi"><i class="fa fa-store"></i></span>Servicios & Precios</div>
    <div class="sb-item" onclick="showSec('cursos',this)"><span class="sbi"><i class="fa fa-graduation-cap"></i></span>Cursos</div>
    <div class="sb-item" onclick="showSec('config',this)"><span class="sbi"><i class="fa fa-sliders"></i></span>Config. General</div>
    <div class="sb-item" onclick="showSec('contenido',this)"><span class="sbi"><i class="fa fa-newspaper"></i></span>Contenido Web</div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Operaciones</div>
    <div class="sb-item" onclick="showSec('erp',this)">
      <span class="sbi"><i class="fa fa-sack-dollar"></i></span>ERP & Finanzas
      <?php if($kpi['adq_pendientes']>0):?><span class="sbb sbb-red"><?= $kpi['adq_pendientes'] ?></span><?php endif;?>
    </div>
    <div class="sb-item" onclick="showSec('pqrs',this)">
      <span class="sbi"><i class="fa fa-clipboard-list"></i></span>PQRS
      <?php if($kpi['pqrs_abiertas']>0):?><span class="sbb sbb-red"><?= $kpi['pqrs_abiertas'] ?></span><?php endif;?>
    </div>
    <div class="sb-item" onclick="showSec('reportes',this)"><span class="sbi"><i class="fa fa-chart-bar"></i></span>Reportes</div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Sistema</div>
    <div class="sb-item" onclick="showSec('backups',this)"><span class="sbi"><i class="fa fa-database"></i></span>Backups<?php if($kpi['backups_cnt']>0):?><span class="sbb sbb-gold"><?= $kpi['backups_cnt'] ?></span><?php endif;?></div>
    <div class="sb-item" onclick="showSec('seguridad',this)"><span class="sbi"><i class="fa fa-shield-halved"></i></span>Seguridad & Log</div>
    <div class="sb-item" onclick="showSec('cache',this)"><span class="sbi"><i class="fa fa-bolt"></i></span>Caché & Optimización</div>
    <div class="sb-sep"></div>
    <div class="sb-item" onclick="window.location.href='../index.php'"><span class="sbi"><i class="fa fa-house"></i></span>Inicio VIROX</div>
    <div class="sb-item" onclick="window.location.href='../IA.php'"><span class="sbi"><i class="fa fa-robot"></i></span>Asistente IA</div>
  </nav>
  <div class="sb-foot">
    <a href="../logout.php" class="sf-btn sfb-out"><i class="fa fa-right-from-bracket"></i> Salir</a>
  </div>
</aside>

<!-- ══════════ TOPBAR ══════════ -->
<header class="sa-tb">
  <button class="tb-menu-btn" id="tbMenu" onclick="toggleSb()"><i class="fa fa-bars"></i></button>
  <div><div class="tb-ttl">SuperAdmin Panel</div><div class="tb-sub" id="tbSub">Dashboard</div></div>
  <div class="tb-srch"><i class="fa fa-search" style="color:var(--dim);font-size:.78rem;"></i><input type="text" placeholder="Buscar en todo el sistema..." id="gSearch"></div>
  <div class="tb-acts">
    <button class="tb-btn" onclick="showSec('pqrs')" title="PQRS">
      <i class="fa fa-bell"></i>
      <?php if($kpi['pqrs_abiertas']>0):?><span class="tb-ndot"></span><?php endif;?>
    </button>
    <button class="tb-btn" onclick="showSec('backups')" title="Backups"><i class="fa fa-database"></i></button>
    <img src="<?= $avatar ?>" alt="sa" class="tb-av" onclick="window.location.href='../perfil.php'" onerror="this.src='../assets/Tesla.png'">
  </div>
</header>

<!-- ══════════ MAIN ══════════ -->
<main class="sa-main">


<!-- ████ DASHBOARD ████ -->
<div class="sa-sec on" id="sec-dashboard">

  <!-- Hero -->
  <div class="sa-hero">
    <div class="hero-grid"></div><div class="hero-orb ho1"></div><div class="hero-orb ho2"></div><div class="hero-orb ho3"></div>
    <div class="hero-cnt">
      <img src="<?= $avatar ?>" class="hero-av" alt="" onerror="this.src='../assets/Tesla.png'">
      <div>
        <div class="hero-tag"><i class="fa fa-crown" style="font-size:.6rem;"></i>SuperAdmin</div>
        <div class="hero-name"><?= $nombre ?></div>
        <div class="hero-sub">Control total del sistema ContainerRz — Acceso irrestricto</div>
        <div class="hero-chips">
          <span class="hero-chip">CRUD completo</span>
          <span class="hero-chip">ERP & Finanzas</span>
          <span class="hero-chip">Backups</span>
          <span class="hero-chip">Config. sistema</span>
          <span class="hero-chip">Seguridad</span>
        </div>
      </div>
      <div class="hero-stats">
        <div class="hs"><div class="hs-n"><?= $kpi['usuarios_total'] ?></div><div class="hs-l">Usuarios</div></div>
        <div class="hs"><div class="hs-n"><?= $kpi['proyectos_activos'] ?></div><div class="hs-l">Proyectos</div></div>
        <div class="hs"><div class="hs-n">$<?= number_format($kpi['ingresos_mes']/1000,0) ?>K</div><div class="hs-l">Ingresos/mes</div></div>
        <div class="hs"><div class="hs-n"><?= $kpi['backups_cnt'] ?></div><div class="hs-l">Backups</div></div>
      </div>
    </div>
  </div>

  <!-- KPIs -->
  <div class="kpi-grid">
    <div class="kpi-card" onclick="showSec('usuarios')"><div class="kc-ico kci-blue"><i class="fa fa-users"></i></div><div><div class="kc-num"><?= $kpi['usuarios_total'] ?></div><div class="kc-lbl">Usuarios</div></div></div>
    <div class="kpi-card" onclick="showSec('proyectos')"><div class="kc-ico kci-purple"><i class="fa fa-diagram-project"></i></div><div><div class="kc-num"><?= $kpi['proyectos_activos'] ?></div><div class="kc-lbl">Proyectos activos</div></div></div>
    <div class="kpi-card" onclick="showSec('servicios')"><div class="kc-ico kci-gold"><i class="fa fa-store"></i></div><div><div class="kc-num"><?= $kpi['servicios_total'] ?></div><div class="kc-lbl">Servicios</div></div></div>
    <div class="kpi-card" onclick="showSec('cursos')"><div class="kc-ico kci-teal"><i class="fa fa-graduation-cap"></i></div><div><div class="kc-num"><?= $kpi['cursos_total'] ?></div><div class="kc-lbl">Cursos</div></div></div>
    <div class="kpi-card" onclick="showSec('erp')"><div class="kc-ico kci-green"><i class="fa fa-sack-dollar"></i></div><div><div class="kc-num">$<?= number_format($kpi['ingresos_mes'],0,',','.') ?></div><div class="kc-lbl">Ingresos mes</div></div></div>
    <div class="kpi-card" onclick="showSec('erp')"><div class="kc-ico kci-orange"><i class="fa fa-hourglass-half"></i></div><div><div class="kc-num"><?= $kpi['adq_pendientes'] ?></div><div class="kc-lbl">Pagos pendientes</div></div></div>
    <div class="kpi-card" onclick="showSec('pqrs')"><div class="kc-ico kci-red"><i class="fa fa-clipboard-list"></i></div><div><div class="kc-num"><?= $kpi['pqrs_abiertas'] ?></div><div class="kc-lbl">PQRS abiertas</div></div></div>
    <div class="kpi-card" onclick="showSec('backups')"><div class="kc-ico kci-gold"><i class="fa fa-database"></i></div><div><div class="kc-num"><?= $kpi['backups_cnt'] ?></div><div class="kc-lbl">Backups guardados</div></div></div>
  </div>

  <!-- Quick actions -->
  <div class="sec-hd"><h2>⚡ Acciones Rápidas</h2><div class="sec-hd-line"></div></div>
  <div class="qa-grid">
    <div class="qa" onclick="abrirModal('mNuevoProyecto')"><div class="qa-ico">🚀</div><div class="qa-lbl">Nuevo Proyecto</div></div>
    <div class="qa" onclick="abrirModal('mNuevoServicio')"><div class="qa-ico">🛠</div><div class="qa-lbl">Nuevo Servicio</div></div>
    <div class="qa" onclick="generarBackup('completo')"><div class="qa-ico">💾</div><div class="qa-lbl">Backup Ahora</div></div>
    <div class="qa" onclick="showSec('config')"><div class="qa-ico">⚙️</div><div class="qa-lbl">Configurar Sistema</div></div>
    <div class="qa" onclick="showSec('erp')"><div class="qa-ico">💰</div><div class="qa-lbl">Ver ERP</div></div>
    <div class="qa" onclick="showSec('reportes')"><div class="qa-ico">📊</div><div class="qa-lbl">Reportes</div></div>
    <div class="qa" onclick="limpiarCache()"><div class="qa-ico">🧹</div><div class="qa-lbl">Limpiar Caché</div></div>
    <div class="qa" onclick="showSec('seguridad')"><div class="qa-ico">🛡</div><div class="qa-lbl">Seguridad</div></div>
    <div class="qa" onclick="showSec('pqrs')"><div class="qa-ico">📋</div><div class="qa-lbl">Atender PQRS</div></div>
    <div class="qa" onclick="showSec('contenido')"><div class="qa-ico">📰</div><div class="qa-lbl">Gestionar Web</div></div>
  </div>

  <!-- Gráficos 2 col -->
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;">
    <div class="chart-box">
      <div class="chart-ttl"><i class="fa fa-chart-line" style="color:var(--gold);"></i>Ingresos últimos 12 meses</div>
      <?php
        $meses=[];$vals=[];$ing_map=[];
        foreach($ingresos_12m as $r)$ing_map[$r['mes']]=(float)$r['total'];
        $max_i=max(1,max(array_values($ing_map)?:[1]));
        for($i=11;$i>=0;$i--){$m=date('Y-m',strtotime("-{$i} months"));$meses[]=date('M',strtotime($m.'-01'));$vals[]=$ing_map[$m]??0;}
      ?>
      <div class="bars">
        <?php foreach($vals as $idx=>$v): ?>
        <div class="bar-col">
          <div class="bar-val"><?= $v>0?'$'.number_format($v/1000,0).'K':'' ?></div>
          <div class="bar-r" style="height:<?= max(4,round($v/$max_i*80)) ?>px;background:linear-gradient(to top,var(--gold),rgba(218,165,32,.3));"></div>
          <div class="bar-lbl"><?= $meses[$idx] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="chart-box">
      <div class="chart-ttl"><i class="fa fa-users" style="color:var(--blue-lt);"></i>Distribución roles</div>
      <?php
        $role_colors=['superadmin'=>'#8b5cf6','admin'=>'#DAA520','empleado'=>'#28A680','creador'=>'#3b82f6','consultor'=>'#f97316','cliente'=>'#526278'];
        $total_r=max(1,array_sum(array_column($roles_dist,'cnt')));
        $circumf=2*M_PI*38;
        $offset=0;$segments=[];
        foreach($roles_dist as $rd){
          $pct=$rd['cnt']/$total_r;
          $segments[]=['pct'=>$pct,'off'=>$offset,'color'=>$role_colors[$rd['rol']]??'#555','rol'=>$rd['rol'],'cnt'=>$rd['cnt']];
          $offset+=$pct*$circumf;
        }
      ?>
      <div class="donut-wrap">
        <div class="donut">
          <svg width="100" height="100" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="38" fill="none" stroke="rgba(255,255,255,.07)" stroke-width="14"/>
            <?php $off2=0; foreach($segments as $sg): $dash=round($sg['pct']*$circumf,2); ?>
            <circle cx="50" cy="50" r="38" fill="none" stroke="<?= $sg['color'] ?>" stroke-width="14"
                    stroke-dasharray="<?= $dash ?> <?= $circumf ?>"
                    stroke-dashoffset="-<?= $off2 ?>"
                    style="transition:all .8s ease;"/>
            <?php $off2+=$dash; endforeach; ?>
          </svg>
          <div class="donut-center"><div class="donut-n"><?= $kpi['usuarios_total'] ?></div><div class="donut-l">Total</div></div>
        </div>
        <div class="donut-legend">
          <?php foreach($segments as $sg): ?>
          <div class="dl-item"><div class="dl-dot" style="background:<?= $sg['color'] ?>;"></div><?= ucfirst($sg['rol']) ?> (<?= $sg['cnt'] ?>)</div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

</div><!-- /dashboard -->


<!-- ████ USUARIOS ████ -->
<div class="sa-sec" id="sec-usuarios">
  <div class="sec-hd"><h2>👥 Gestión Completa de Usuarios</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:7px;">
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('uTbl','activo','1')">Activos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('uTbl','activo','0')">Inactivos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('uTbl','activo','')">Todos</button>
    </div>
  </div>
  <div class="card" style="overflow:hidden;">
    <div class="t-wrap">
      <table class="tbl" id="uTbl">
        <thead><tr><th>#</th><th>Usuario</th><th>Correo</th><th>Rol</th><th>Área</th><th>Activo</th><th>Verificado</th><th>Registro</th><th>Último acceso</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach($usuarios as $u):
          $ini=mb_substr($u['nombre']??'U',0,1);
          $av=!empty($u['avatar'])?htmlspecialchars($u['avatar']):'';
        ?>
        <tr data-activo="<?= $u['activo'] ?>">
          <td style="color:var(--dim);font-size:.65rem;"><?= $u['id'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <?php if($av):?><img src="<?= $av ?>" style="width:28px;height:28px;border-radius:50%;object-fit:cover;border:1.5px solid var(--gold-dim);" onerror="this.style.display='none'"><?php else:?><div style="width:28px;height:28px;border-radius:50%;background:var(--gold-dim);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;color:var(--gold-lt);"><?= $ini ?></div><?php endif;?>
              <div><div style="font-size:.8rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($u['nombre'].' '.$u['apellido']) ?></div><div style="font-size:.62rem;color:var(--dim);">@<?= htmlspecialchars($u['username']) ?></div></div>
            </div>
          </td>
          <td style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($u['correo']??'—') ?></td>
          <td>
            <select onchange="crudUsuario('update',<?= $u['id'] ?>,{rol:this.value})"
                    style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:var(--txt);font-family:var(--font-b);font-size:.7rem;padding:3px 6px;outline:none;" <?= $u['id']==$uid?'disabled':'' ?>>
              <?php foreach(['cliente','consultor','creador','empleado','admin','superadmin'] as $r): ?>
              <option value="<?= $r ?>" <?= $u['rol']===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
              <?php endforeach;?>
            </select>
          </td>
          <td style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($u['area_tecnologica']??'—') ?></td>
          <td>
            <button onclick="crudUsuario('update',<?= $u['id'] ?>,{activo:<?= $u['activo']?0:1 ?>},this,'activo',<?= $u['activo']?0:1 ?>)"
                    class="b <?= $u['activo']?'b-activo':'b-inactivo' ?>" style="cursor:pointer;">
              <?= $u['activo']?'✅ Sí':'❌ No' ?>
            </button>
          </td>
          <td>
            <button onclick="crudUsuario('update',<?= $u['id'] ?>,{verificado:<?= $u['verificado']?0:1 ?>},this,'verificado',<?= $u['verificado']?0:1 ?>)"
                    class="b <?= $u['verificado']?'b-verificado':'b-pendiente' ?>" style="cursor:pointer;">
              <?= $u['verificado']?'🔵 Sí':'⏳ No' ?>
            </button>
          </td>
          <td style="font-size:.65rem;color:var(--dim);"><?= !empty($u['fecha_registro'])?date('d M Y',strtotime($u['fecha_registro'])):'—' ?></td>
          <td style="font-size:.65rem;color:var(--dim);"><?= !empty($u['ultimo_acceso'])?date('d M Y H:i',strtotime($u['ultimo_acceso'])):'—' ?></td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="ab ab-blue" onclick="resetPw(<?= $u['id'] ?>,'<?= htmlspecialchars($u['nombre'],ENT_QUOTES) ?>')" title="Resetear contraseña"><i class="fa fa-key"></i></button>
              <button class="ab ab-ghost" onclick="window.open('perfil.php?id=<?= $u['id'] ?>')" title="Ver perfil"><i class="fa fa-eye"></i></button>
              <?php if($u['id']!=$uid):?>
              <button class="ab ab-red" onclick="crudUsuario('delete',<?= $u['id'] ?>,{})" title="Desactivar"><i class="fa fa-trash"></i></button>
              <?php endif;?>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████ SERVICIOS & PRECIOS ████ -->
<div class="sa-sec" id="sec-servicios">
  <div class="sec-hd"><h2>🛠 Servicios & Precios</h2><div class="sec-hd-line"></div>
    <button class="btn btn-gold" onclick="abrirModal('mNuevoServicio')"><i class="fa fa-plus"></i> Nuevo servicio</button>
  </div>
  <?php if(empty($servicios)):?>
  <div class="empty"><div class="empty-ico">🛠</div><p>No hay servicios. Crea el primero.</p></div>
  <?php else:?>
  <div class="card" style="overflow:hidden;">
    <div class="t-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Servicio</th><th>Categoría</th><th>Nivel</th><th>Precio Base COP</th><th>Estado</th><th>Destacado</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach($servicios as $s):?>
        <tr>
          <td style="color:var(--dim);font-size:.65rem;"><?= $s['id'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="font-size:1.1rem;"><?= htmlspecialchars($s['icono']??'🛠') ?></span>
              <div><div style="font-size:.8rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($s['titulo']) ?></div><div style="font-size:.62rem;color:var(--dim);"><?= htmlspecialchars($s['subtitulo']??'') ?></div></div>
            </div>
          </td>
          <td><span class="b" style="background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.1);"><?= htmlspecialchars($s['categoria']??'—') ?></span></td>
          <td style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($s['nivel']??'—') ?></td>
          <td>
            <div class="precio-wrap">
              <span class="precio-sym">$</span>
              <input type="number" class="precio-inp" value="<?= (int)$s['precio_base'] ?>"
                     onblur="updatePrecio(<?= $s['id'] ?>,this.value,this)"
                     title="Editar precio base">
            </div>
          </td>
          <td>
            <button onclick="toggleServicio(<?= $s['id'] ?>,<?= $s['activo']?0:1 ?>,this)"
                    class="b <?= $s['activo']?'b-activo':'b-inactivo' ?>" style="cursor:pointer;">
              <?= $s['activo']?'✅ Activo':'❌ Inactivo' ?>
            </button>
          </td>
          <td>
            <button onclick="toggleDestacado(<?= $s['id'] ?>,<?= $s['destacado']?0:1 ?>,this)"
                    class="b <?= $s['destacado']?'b-verificado':'b-pendiente' ?>" style="cursor:pointer;">
              <?= $s['destacado']?'⭐ Sí':'— No' ?>
            </button>
          </td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="ab ab-gold" onclick="abrirModalEditServicio(<?= $s['id'] ?>,'<?= htmlspecialchars($s['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($s['subtitulo']??'',ENT_QUOTES) ?>','<?= htmlspecialchars($s['categoria']??'',ENT_QUOTES) ?>','<?= htmlspecialchars($s['icono']??'🛠',ENT_QUOTES) ?>','<?= htmlspecialchars($s['nivel']??'',ENT_QUOTES) ?>','<?= htmlspecialchars($s['duracion']??'',ENT_QUOTES) ?>')"><i class="fa fa-pen"></i></button>
              <button class="ab ab-red" onclick="eliminarServicio(<?= $s['id'] ?>,'<?= htmlspecialchars($s['titulo'],ENT_QUOTES) ?>')"><i class="fa fa-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
  <?php endif;?>
</div>


<!-- ████ CURSOS ████ -->
<div class="sa-sec" id="sec-cursos">
  <div class="sec-hd"><h2>🎓 Gestión de Cursos</h2><div class="sec-hd-line"></div></div>
  <div class="card" style="overflow:hidden;">
    <div class="t-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Curso</th><th>Nivel</th><th>Precio</th><th>Inscripciones</th><th>Publicado</th><th>Destacado</th><th>Gratuito</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach($cursos as $c):
          $inscritos=(int)qval($conexion,"SELECT COUNT(*) FROM inscripciones WHERE curso_id=?","i",$c['id']);
        ?>
        <tr>
          <td style="color:var(--dim);font-size:.65rem;"><?= $c['id'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="font-size:1rem;"><?= htmlspecialchars($c['icono']??'📚') ?></span>
              <div><div style="font-size:.8rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($c['titulo']) ?></div><div style="font-size:.62rem;color:var(--dim);"><?= htmlspecialchars($c['inst_nombre']??'—') ?></div></div>
            </div>
          </td>
          <td><span class="b <?= $c['nivel']==='avanzado'?'b-urgente':($c['nivel']==='intermedio'?'b-pausado':'b-baja') ?>"><?= ucfirst($c['nivel']??'—') ?></span></td>
          <td>
            <div class="precio-wrap"><span class="precio-sym">$</span>
              <input type="number" class="precio-inp" value="<?= (int)($c['precio']??0) ?>"
                     onblur="updateCursoPrecio(<?= $c['id'] ?>,this.value)">
            </div>
          </td>
          <td style="font-family:var(--font-d);font-size:.8rem;color:var(--gold);"><?= $inscritos ?></td>
          <td><button onclick="toggleCurso(<?= $c['id'] ?>,'publicado',<?= $c['publicado']?0:1 ?>,this)" class="b <?= $c['publicado']?'b-activo':'b-inactivo' ?>" style="cursor:pointer;"><?= $c['publicado']?'✅ Sí':'❌ No' ?></button></td>
          <td><button onclick="toggleCurso(<?= $c['id'] ?>,'destacado',<?= $c['destacado']?0:1 ?>,this)" class="b <?= $c['destacado']?'b-verificado':'b-pendiente' ?>" style="cursor:pointer;"><?= $c['destacado']?'⭐ Sí':'— No' ?></button></td>
          <td><button onclick="toggleCurso(<?= $c['id'] ?>,'gratuito',<?= $c['gratuito']?0:1 ?>,this)" class="b <?= $c['gratuito']?'b-activo':'b-pendiente' ?>" style="cursor:pointer;"><?= $c['gratuito']?'🆓 Sí':'💰 No' ?></button></td>
          <td><button class="ab ab-gold" onclick="abrirModal('mEditCurso');document.getElementById('ec_id').value=<?= $c['id'] ?>;document.getElementById('ec_titulo').value='<?= htmlspecialchars($c['titulo'],ENT_QUOTES) ?>';document.getElementById('ec_nivel').value='<?= $c['nivel']??'basico' ?>';document.getElementById('ec_precio').value=<?= $c['precio']??0 ?>;"><i class="fa fa-pen"></i></button></td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████ PROYECTOS ████ -->
<div class="sa-sec" id="sec-proyectos">
  <div class="sec-hd"><h2>🚀 Gestión Completa de Proyectos</h2><div class="sec-hd-line"></div>
    <button class="btn btn-gold" onclick="abrirModal('mNuevoProyecto')"><i class="fa fa-plus"></i> Nuevo</button>
  </div>
  <div class="card" style="overflow:hidden;">
    <div class="t-wrap">
      <table class="tbl">
        <thead><tr><th>#</th><th>Proyecto</th><th>Tipo</th><th>Estado</th><th>Progreso</th><th>Miembros</th><th>Creado por</th><th>Fecha</th><th>Privado</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach($proyectos as $p):?>
        <tr>
          <td style="color:var(--dim);font-size:.65rem;"><?= $p['id'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:8px;">
              <span style="font-size:1rem;"><?= htmlspecialchars($p['icono']??'🚀') ?></span>
              <div style="font-size:.8rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($p['titulo']) ?></div>
            </div>
          </td>
          <td style="font-size:.72rem;color:var(--muted);"><?= ucfirst($p['tipo']??'—') ?></td>
          <td>
            <select onchange="crudProyecto('update',<?= $p['id'] ?>,{estado:this.value})"
                    style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:var(--txt);font-family:var(--font-b);font-size:.7rem;padding:3px 6px;outline:none;">
              <?php foreach(['planeado','activo','pausado','completado','cancelado'] as $st):?>
              <option value="<?= $st ?>" <?= $p['estado']===$st?'selected':'' ?>><?= ucfirst($st) ?></option>
              <?php endforeach;?>
            </select>
          </td>
          <td>
            <div style="display:flex;align-items:center;gap:6px;">
              <input type="range" min="0" max="100" value="<?= $p['progreso']??0 ?>"
                     style="width:70px;accent-color:var(--gold);"
                     oninput="this.nextElementSibling.textContent=this.value+'%'"
                     onchange="crudProyecto('update',<?= $p['id'] ?>,{progreso:this.value})">
              <span style="font-size:.65rem;color:var(--gold);font-family:var(--font-d);width:30px;"><?= $p['progreso']??0 ?>%</span>
            </div>
          </td>
          <td style="text-align:center;font-family:var(--font-d);font-size:.8rem;color:var(--gold);"><?= $p['miembros'] ?></td>
          <td style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($p['creador_nombre']??'—') ?></td>
          <td style="font-size:.65rem;color:var(--dim);"><?= !empty($p['fecha_creacion'])?date('d M Y',strtotime($p['fecha_creacion'])):'—' ?></td>
          <td><span class="b <?= $p['privado']?'b-urgente':'b-baja' ?>"><?= $p['privado']?'🔒 Sí':'🌐 No' ?></span></td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="ab ab-gold" onclick="abrirModalEditProyecto(<?= $p['id'] ?>,'<?= htmlspecialchars($p['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($p['descripcion']??'',ENT_QUOTES) ?>','<?= $p['estado'] ?>',<?= $p['progreso']??0 ?>,<?= $p['privado']??0 ?>)"><i class="fa fa-pen"></i></button>
              <button class="ab ab-red" onclick="eliminarProyecto(<?= $p['id'] ?>,'<?= htmlspecialchars($p['titulo'],ENT_QUOTES) ?>')"><i class="fa fa-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████ CONFIG GENERAL ████ -->
<div class="sa-sec" id="sec-config">
  <div class="sec-hd"><h2>⚙️ Configuración del Sistema</h2><div class="sec-hd-line"></div>
    <button class="btn btn-ghost btn-sm" onclick="abrirModal('mNuevoConfig')"><i class="fa fa-plus"></i> Agregar clave</button>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
  <?php
    $cfg_grupos_web=['empresa'=>'🏢','general'=>'⚙️','contacto'=>'📞','seguridad'=>'🔒','hero'=>'🎬','ia'=>'🤖','footer'=>'📋','estadisticas'=>'📊'];
    $agrupados=[];
    foreach($cfg_all as $c)$agrupados[$c['grupo']][]=$c;
    foreach($agrupados as $grp=>$items):
      $ico=$cfg_grupos_web[$grp]??'📁';
  ?>
  <div class="cfg-group">
    <div class="cfg-gtitle"><?= $ico ?> <?= strtoupper($grp) ?></div>
    <?php foreach($items as $ci):?>
    <div class="cfg-row">
      <div class="cfg-info">
        <div class="cfg-lbl"><?= htmlspecialchars(str_replace(['_','-'],' ',ucfirst($ci['clave']))) ?></div>
        <div class="cfg-key"><?= htmlspecialchars($ci['clave']) ?></div>
      </div>
      <div class="cfg-ctrl">
        <?php if($ci['tipo']==='booleano'):?>
        <label class="tg"><input type="checkbox" <?= $ci['valor']?'checked':'' ?> onchange="guardarConfig('<?= htmlspecialchars($ci['clave'],ENT_QUOTES) ?>',this.checked?'1':'0','<?= $grp ?>','booleano')"><span class="tg-sl"></span></label>
        <?php elseif($ci['tipo']==='json'):?>
        <button class="cfg-save-btn" onclick="abrirEditJson('<?= htmlspecialchars($ci['clave'],ENT_QUOTES) ?>','<?= htmlspecialchars($ci['grupo'],ENT_QUOTES) ?>')">Editar JSON</button>
        <?php else:?>
        <?php $isLong=(strlen($ci['valor']??'')>60);?>
        <?php if($isLong):?>
        <textarea class="cfg-inp" id="cfg_<?= htmlspecialchars($ci['clave']) ?>"><?= htmlspecialchars($ci['valor']??'') ?></textarea>
        <?php else:?>
        <input type="<?= $ci['tipo']==='numero'?'number':'text' ?>" class="cfg-inp" id="cfg_<?= htmlspecialchars($ci['clave']) ?>" value="<?= htmlspecialchars($ci['valor']??'') ?>">
        <?php endif;?>
        <button class="cfg-save-btn" onclick="guardarConfig('<?= htmlspecialchars($ci['clave'],ENT_QUOTES) ?>',document.getElementById('cfg_<?= htmlspecialchars($ci['clave'],ENT_QUOTES) ?>').value,'<?= $grp ?>','<?= $ci['tipo'] ?>')">Guardar</button>
        <?php endif;?>
      </div>
    </div>
    <?php endforeach;?>
  </div>
  <?php endforeach;?>
  </div>
</div>


<!-- ████ CONTENIDO WEB ████ -->
<div class="sa-sec" id="sec-contenido">
  <div class="sec-hd"><h2>📰 Gestión de Contenido Web</h2><div class="sec-hd-line"></div></div>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;">

    <!-- Noticias -->
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:10px;"><h2 style="font-size:.78rem;">📰 Noticias (<?= count($noticias) ?>)</h2><div class="sec-hd-line"></div></div>
      <?php foreach($noticias as $n):?>
      <div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="flex:1;min-width:0;"><p style="font-size:.78rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($n['titulo']) ?></p><p style="font-size:.62rem;color:var(--dim);"><?= date('d M Y',strtotime($n['fecha'])) ?></p></div>
        <button onclick="toggleContenido('noticias',<?= $n['id'] ?>,<?= $n['activo']?0:1 ?>,this)" class="b <?= $n['activo']?'b-activo':'b-inactivo' ?>" style="cursor:pointer;font-size:.58rem;"><?= $n['activo']?'ON':'OFF' ?></button>
        <button onclick="eliminarContenido('noticias',<?= $n['id'] ?>)" class="ab ab-red" style="padding:3px 6px;"><i class="fa fa-trash fa-xs"></i></button>
      </div>
      <?php endforeach;?>
    </div>

    <!-- Novedades -->
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:10px;"><h2 style="font-size:.78rem;">🆕 Novedades (<?= count($novedades) ?>)</h2><div class="sec-hd-line"></div></div>
      <?php foreach($novedades as $n):?>
      <div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <span class="b b-<?= $n['tipo']==='alerta'?'urgente':($n['tipo']==='nuevo'?'activo':'pausado') ?>" style="font-size:.58rem;"><?= $n['tipo'] ?></span>
        <div style="flex:1;min-width:0;"><p style="font-size:.76rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($n['titulo']) ?></p></div>
        <button onclick="eliminarContenido('novedades',<?= $n['id'] ?>)" class="ab ab-red" style="padding:3px 6px;"><i class="fa fa-trash fa-xs"></i></button>
      </div>
      <?php endforeach;?>
    </div>

    <!-- Publicaciones -->
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:10px;"><h2 style="font-size:.78rem;">📝 Publicaciones (<?= count($publicaciones) ?>)</h2><div class="sec-hd-line"></div></div>
      <?php foreach($publicaciones as $pub):?>
      <div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="flex:1;min-width:0;"><p style="font-size:.76rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($pub['titulo']) ?></p><p style="font-size:.62rem;color:var(--dim);"><?= date('d M Y',strtotime($pub['fecha_pub'])) ?></p></div>
        <button onclick="toggleContenido('publicaciones',<?= $pub['id'] ?>,<?= $pub['publicado']?0:1 ?>,this)" class="b <?= $pub['publicado']?'b-activo':'b-inactivo' ?>" style="cursor:pointer;font-size:.58rem;"><?= $pub['publicado']?'ON':'OFF' ?></button>
        <button onclick="eliminarContenido('publicaciones',<?= $pub['id'] ?>)" class="ab ab-red" style="padding:3px 6px;"><i class="fa fa-trash fa-xs"></i></button>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>


<!-- ████ ERP & FINANZAS ████ -->
<div class="sa-sec" id="sec-erp">
  <div class="sec-hd"><h2>💰 ERP — Finanzas & Transacciones</h2><div class="sec-hd-line"></div></div>
  <div class="erp-sum">
    <div class="erp-card"><div class="erp-ico">💰</div><div class="erp-num">$<?= number_format($kpi['ingresos_mes'],0,',','.') ?></div><div class="erp-lbl">Ingresos este mes</div></div>
    <div class="erp-card"><div class="erp-ico">📈</div><div class="erp-num">$<?= number_format($kpi['ingresos_total'],0,',','.') ?></div><div class="erp-lbl">Ingresos totales</div></div>
    <div class="erp-card"><div class="erp-ico">⏳</div><div class="erp-num"><?= $kpi['adq_pendientes'] ?></div><div class="erp-lbl">Pagos pendientes</div></div>
    <div class="erp-card"><div class="erp-ico">✅</div><div class="erp-num"><?= count(array_filter($adquisiciones,fn($a)=>$a['estado']==='pagado')) ?></div><div class="erp-lbl">Pagos aprobados</div></div>
    <div class="erp-card"><div class="erp-ico">❌</div><div class="erp-num"><?= count(array_filter($adquisiciones,fn($a)=>$a['estado']==='cancelado')) ?></div><div class="erp-lbl">Cancelados</div></div>
  </div>
  <div class="sec-hd"><h2>📋 Todas las transacciones</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('erpTbl','estado','pendiente')">Pendientes</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('erpTbl','estado','pagado')">Pagados</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarTbl('erpTbl','estado','')">Todos</button>
    </div>
  </div>
  <div class="card" style="overflow:hidden;">
    <div class="t-wrap">
      <table class="tbl" id="erpTbl">
        <thead><tr><th>#</th><th>Servicio</th><th>Cliente</th><th>Monto</th><th>Método</th><th>Estado</th><th>Fecha</th><th>Editar</th></tr></thead>
        <tbody>
        <?php foreach($adquisiciones as $a):?>
        <tr data-estado="<?= $a['estado'] ?>">
          <td style="color:var(--dim);font-size:.62rem;">#<?= $a['id'] ?></td>
          <td><div style="display:flex;align-items:center;gap:6px;"><span><?= htmlspecialchars($a['srv_icono']??'🛠') ?></span><span style="font-size:.78rem;font-weight:600;color:var(--txt);"><?= htmlspecialchars($a['srv_titulo']) ?></span></div></td>
          <td style="font-size:.76rem;font-weight:600;color:var(--txt);"><?= htmlspecialchars($a['cli_nombre'].' '.($a['cli_ap']??'')) ?></td>
          <td>
            <div class="precio-wrap"><span class="precio-sym">$</span>
              <input type="number" class="precio-inp" value="<?= (int)$a['monto'] ?>"
                     onblur="erpUpdateMonto(<?= $a['id'] ?>,this.value)">
            </div>
          </td>
          <td style="font-size:.7rem;color:var(--muted);"><?= htmlspecialchars($a['metodo_pago']??'—') ?></td>
          <td>
            <select onchange="erpUpdateEstado(<?= $a['id'] ?>,this.value)"
                    style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:var(--txt);font-family:var(--font-b);font-size:.7rem;padding:3px 6px;outline:none;">
              <?php foreach(['pendiente','pagado','cancelado','reembolsado'] as $est):?>
              <option value="<?= $est ?>" <?= $a['estado']===$est?'selected':'' ?>><?= ucfirst($est) ?></option>
              <?php endforeach;?>
            </select>
          </td>
          <td style="font-size:.65rem;color:var(--dim);"><?= date('d M Y',strtotime($a['fecha'])) ?></td>
          <td><span class="b b-<?= $a['estado'] ?>"><?= ucfirst($a['estado']) ?></span></td>
        </tr>
        <?php endforeach;?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████ PQRS ████ -->
<div class="sa-sec" id="sec-pqrs">
  <div class="sec-hd"><h2>📋 PQRS — Peticiones & Reclamos</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="btn btn-ghost btn-sm" onclick="filtrarPqrs('abierto')">🔴 Abiertos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarPqrs('en_proceso')">🔵 En proceso</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarPqrs('resuelto')">🟢 Resueltos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarPqrs('')">Todos</button>
    </div>
  </div>
  <div id="pqrsListSA">
    <?php if(empty($pqrs_all)):?>
    <div class="empty"><div class="empty-ico">📋</div><p>Sin PQRS registradas.</p></div>
    <?php else:foreach($pqrs_all as $pq):?>
    <div class="pqrs-it <?= $pq['prioridad'] ?>" data-estado="<?= $pq['estado'] ?>"
         onclick="abrirModalPqrs(<?= $pq['id'] ?>,'<?= $pq['folio'] ?>','<?= htmlspecialchars($pq['asunto'],ENT_QUOTES) ?>','<?= htmlspecialchars($pq['descripcion'],ENT_QUOTES) ?>','<?= $pq['estado'] ?>')">
      <div class="pit-top">
        <span class="pit-folio"><?= $pq['folio'] ?></span>
        <span class="pit-ttl"><?= htmlspecialchars($pq['asunto']) ?></span>
        <span class="b b-<?= $pq['prioridad'] ?>"><?= ucfirst($pq['prioridad']) ?></span>
        <span class="b b-<?= $pq['estado'] ?>"><?= str_replace('_',' ',ucfirst($pq['estado'])) ?></span>
      </div>
      <div style="font-size:.72rem;color:var(--muted);display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden;"><?= htmlspecialchars($pq['descripcion']) ?></div>
      <div style="display:flex;gap:8px;margin-top:5px;flex-wrap:wrap;">
        <span style="font-size:.62rem;color:var(--muted);"><i class="fa fa-user fa-xs"></i> <?= htmlspecialchars($pq['usr_nom']??$pq['nombre']??'Anónimo') ?></span>
        <span style="font-size:.62rem;color:var(--muted);"><i class="fa fa-tag fa-xs"></i> <?= ucfirst($pq['categoria']) ?></span>
        <span style="font-size:.62rem;color:var(--dim);"><?= date('d M Y',strtotime($pq['fecha'])) ?></span>
      </div>
    </div>
    <?php endforeach;endif;?>
  </div>
</div>


<!-- ████ REPORTES ████ -->
<div class="sa-sec" id="sec-reportes">
  <div class="sec-hd"><h2>📊 Reportes Ejecutivos</h2><div class="sec-hd-line"></div>
    <button class="btn btn-gold btn-sm" onclick="exportarReporte()"><i class="fa fa-download"></i> Exportar CSV</button>
  </div>

  <!-- KPI summary -->
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:20px;">
    <?php
      $rpt_items=[
        ['Usuarios activos',$kpi['usuarios_activos'],'de '.$kpi['usuarios_total'].' totales','green'],
        ['Empleados',$kpi['empleados'],'activos en equipo','purple'],
        ['Proyectos activos',$kpi['proyectos_activos'],'de '.$kpi['proyectos_total'].' totales','blue'],
        ['Servicios activos',$kpi['servicios_total'],'en catálogo','gold'],
        ['Cursos activos',$kpi['cursos_total'],'disponibles','teal'],
        ['Ingresos mes','$'.number_format($kpi['ingresos_mes'],0,',','.'),date('F Y'),'green'],
        ['Ingresos total','$'.number_format($kpi['ingresos_total'],0,',','.'),'histórico','gold'],
        ['PQRS resueltas',count(array_filter($pqrs_all,fn($p)=>in_array($p['estado'],['resuelto','cerrado']))),'de '.count($pqrs_all).' totales','teal'],
      ];
      foreach($rpt_items as [$lbl,$val,$sub,$clr]):
    ?>
    <div class="card cp" style="text-align:center;">
      <div style="font-size:.62rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px;"><?= $lbl ?></div>
      <div style="font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--<?= $clr ?>-lt,var(--gold-lt));"><?= $val ?></div>
      <div style="font-size:.7rem;color:var(--muted);margin-top:3px;"><?= $sub ?></div>
    </div>
    <?php endforeach;?>
  </div>

  <!-- Gráfico ingresos mensual -->
  <div class="chart-box">
    <div class="chart-ttl"><i class="fa fa-chart-bar" style="color:var(--gold);"></i> Ingresos por mes (12 meses)</div>
    <?php
      $m2=[];$v2=[];$im2=[];
      foreach($ingresos_12m as $r)$im2[$r['mes']]=(float)$r['total'];
      $mx2=max(1,max(array_values($im2)?:[1]));
      for($i=11;$i>=0;$i--){$mo=date('Y-m',strtotime("-{$i} months"));$m2[]=date('M Y',strtotime($mo.'-01'));$v2[]=$im2[$mo]??0;}
    ?>
    <div class="bars">
      <?php foreach($v2 as $idx=>$v):?>
      <div class="bar-col">
        <div class="bar-val"><?= $v>0?'$'.number_format($v/1000,1).'K':'' ?></div>
        <div class="bar-r" style="height:<?= max(4,round($v/$mx2*80)) ?>px;background:linear-gradient(to top,var(--gold),rgba(218,165,32,.25));"></div>
        <div class="bar-lbl"><?= substr($m2[$idx],0,6) ?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>


<!-- ████ BACKUPS ████ -->
<div class="sa-sec" id="sec-backups">
  <div class="sec-hd"><h2>💾 Gestión de Backups</h2><div class="sec-hd-line"></div></div>

  <!-- Generar backup -->
  <div class="card cp" style="margin-bottom:18px;">
    <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">⚡ Generar nuevo backup</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
      <button class="btn btn-gold" onclick="generarBackup('completo')"><i class="fa fa-database"></i> Backup completo</button>
      <button class="btn btn-ghost" onclick="generarBackup('solo_datos')"><i class="fa fa-table"></i> Solo datos</button>
      <button class="btn btn-ghost" onclick="generarBackup('solo_estructura')"><i class="fa fa-sitemap"></i> Solo estructura</button>
      <div style="margin-left:auto;font-size:.75rem;color:var(--muted);">
        Último backup: <strong style="color:var(--gold-lt);"><?= isset($ultimo_bk['fecha']) ? date('d M Y H:i',strtotime($ultimo_bk['fecha'])) : 'Nunca' ?></strong>
      </div>
    </div>
    <div id="bkProgress" style="display:none;margin-top:12px;">
      <p style="font-size:.78rem;color:var(--muted);margin-bottom:6px;" id="bkMsg">Generando backup...</p>
      <div class="prog-bar"><div class="prog-fill" id="bkBar" style="width:0%;transition:width 2s linear;"></div></div>
    </div>
  </div>
  <!-- Programación automática -->
  <div class="card cp" style="margin-bottom:18px;">
    <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">⏰ Backup Automático</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
      <div>
        <div style="font-size:.78rem;font-weight:700;color:var(--txt);margin-bottom:4px;">Frecuencia</div>
        <select class="fi" id="bkFrecuencia" onchange="guardarConfig('backup_frecuencia',this.value,'backups','texto')">
          <option value="semanal" <?= ($cfg_map['backup_frecuencia']??'semanal')==='semanal'?'selected':'' ?>>📅 Semanal (recomendado)</option>
          <option value="mensual" <?= ($cfg_map['backup_frecuencia']??'')==='mensual'?'selected':'' ?>>📆 Mensual</option>
          <option value="diario"  <?= ($cfg_map['backup_frecuencia']??'')==='diario'?'selected':'' ?>>🗓 Diario</option>
        </select>
      </div>
      <div>
        <div style="font-size:.78rem;font-weight:700;color:var(--txt);margin-bottom:4px;">Tipo de backup automático</div>
        <select class="fi" id="bkTipoAuto" onchange="guardarConfig('backup_tipo_auto',this.value,'backups','texto')">
          <option value="completo" <?= ($cfg_map['backup_tipo_auto']??'completo')==='completo'?'selected':'' ?>>Completo</option>
          <option value="solo_datos" <?= ($cfg_map['backup_tipo_auto']??'')==='solo_datos'?'selected':'' ?>>Solo datos</option>
        </select>
      </div>
    </div>
    <p style="font-size:.72rem;color:var(--dim);margin-top:10px;"><i class="fa fa-info-circle" style="color:var(--gold);"></i> Los backups automáticos requieren configurar un cron job en el servidor: <code style="background:rgba(255,255,255,.06);padding:2px 7px;border-radius:4px;font-size:.7rem;">0 2 * * 1 php /ruta/cron/backup.php</code></p>
  </div>

  <!-- Lista de backups existentes -->
  <div class="sec-hd" style="margin-top:4px;"><h2>📁 Backups almacenados</h2><div class="sec-hd-line"></div>
    <button class="btn btn-ghost btn-sm" onclick="cargarBackups()"><i class="fa fa-refresh"></i> Actualizar</button>
  </div>
  <div class="bk-grid" id="bkGrid">
    <?php
      $bk_files=[];
      if(is_dir('backups/')){
        foreach(glob('backups/backup_virox_*.sql') as $f){
          $bk_files[]=['filename'=>basename($f),'size'=>filesize($f),'fecha'=>date('Y-m-d H:i:s',filemtime($f))];
        }
        usort($bk_files,fn($a,$b)=>strcmp($b['fecha'],$a['fecha']));
      }
      if(empty($bk_files)):
    ?>
    <div style="grid-column:1/-1;"><div class="empty"><div class="empty-ico">💾</div><p>No hay backups generados aún. Genera el primero.</p></div></div>
    <?php else: foreach($bk_files as $bk): $sz=round($bk['size']/1024,1); ?>
    <div class="bk-card" id="bk_<?= md5($bk['filename']) ?>">
      <div class="bk-ico">💾</div>
      <div class="bk-name"><?= htmlspecialchars($bk['filename']) ?></div>
      <div class="bk-meta">📅 <?= $bk['fecha'] ?></div>
      <div class="bk-size">📦 <?= $sz ?>KB</div>
      <div class="bk-actions">
        <button class="ab ab-green" onclick="descargarBackup('<?= htmlspecialchars($bk['filename'],ENT_QUOTES) ?>')"><i class="fa fa-download"></i> Descargar</button>
        <button class="ab ab-red" onclick="eliminarBackup('<?= htmlspecialchars($bk['filename'],ENT_QUOTES) ?>',this)"><i class="fa fa-trash"></i></button>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>


<!-- ████ SEGURIDAD & LOG ████ -->
<div class="sa-sec" id="sec-seguridad">
  <div class="sec-hd"><h2>🛡 Seguridad & Auditoría</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="btn btn-ghost btn-sm" onclick="filtrarLog2('login_ok')">✅ Logins OK</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarLog2('login_fail')">❌ Fallos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarLog2('')">Todos</button>
    </div>
  </div>

  <?php if(!empty($rate_limits)):?>
  <div style="background:var(--red-dim);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-md);padding:12px 16px;margin-bottom:14px;">
    <p style="font-size:.82rem;font-weight:700;color:var(--red-lt);margin-bottom:8px;"><i class="fa fa-shield-halved"></i> <?= count($rate_limits) ?> IP(s) bloqueadas actualmente</p>
    <?php foreach($rate_limits as $rl):?>
    <div style="display:flex;gap:10px;font-size:.72rem;color:var(--muted);padding:4px 0;border-bottom:1px solid rgba(255,255,255,.05);">
      <span style="font-family:monospace;color:var(--red-lt);"><?= htmlspecialchars($rl['ip']) ?></span>
      <span><?= htmlspecialchars($rl['endpoint']) ?></span>
      <span>Bloqueado hasta: <?= date('H:i d M',strtotime($rl['bloqueado_hasta'])) ?></span>
    </div>
    <?php endforeach;?>
  </div>
  <?php endif;?>

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <!-- Log accesos -->
    <div class="card cp">
      <p style="font-size:.68rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">🔐 Log de accesos</p>
      <div id="logListSA">
        <?php foreach($log_accesos as $log):
          $lic=match($log['accion']){'login_ok'=>'li-ok','login_fail'=>'li-fail',default=>'li-act'};
          $lif=match($log['accion']){'login_ok'=>'fa-right-to-bracket','login_fail'=>'fa-triangle-exclamation',default=>'fa-right-from-bracket'};
        ?>
        <div class="log-it" data-accion="<?= $log['accion'] ?>">
          <div class="li <?= $lic ?>"><i class="fa <?= $lif ?>"></i></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:.78rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars(($log['nombre']??'?').' '.($log['apellido']??'')) ?></div>
            <div style="font-size:.62rem;color:var(--dim);"><?= htmlspecialchars($log['ip']??'—') ?> · <?= date('d M H:i',strtotime($log['fecha'])) ?></div>
          </div>
          <span class="b b-<?= $log['accion']==='login_ok'?'activo':($log['accion']==='login_fail'?'urgente':'pausado') ?>" style="font-size:.58rem;"><?= str_replace('_',' ',$log['accion']) ?></span>
        </div>
        <?php endforeach;?>
      </div>
    </div>

    <!-- Auditoría -->
    <div class="card cp">
      <p style="font-size:.68rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">📋 Auditoría de cambios</p>
      <?php foreach($auditoria as $aud):?>
      <div class="log-it">
        <div class="li li-act"><i class="fa fa-pen-to-square"></i></div>
        <div style="flex:1;min-width:0;">
          <div style="font-size:.76rem;font-weight:600;color:var(--txt);"><?= htmlspecialchars(($aud['nombre']??'?').' '.($aud['apellido']??'')) ?> → <span style="color:var(--gold-lt);"><?= $aud['tabla'] ?></span></div>
          <div style="font-size:.62rem;color:var(--dim);"><?= $aud['operacion'] ?> · <?= htmlspecialchars($aud['ip']??'—') ?> · <?= date('d M H:i',strtotime($aud['fecha'])) ?></div>
        </div>
        <span class="b b-<?= $aud['operacion']==='DELETE'?'urgente':($aud['operacion']==='INSERT'?'activo':'pausado') ?>" style="font-size:.56rem;"><?= $aud['operacion'] ?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>
</div>


<!-- ████ CACHÉ & OPTIMIZACIÓN ████ -->
<div class="sa-sec" id="sec-cache">
  <div class="sec-hd"><h2>⚡ Caché & Optimización del Sistema</h2><div class="sec-hd-line"></div></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;">
    <div class="card cp" style="text-align:center;">
      <div style="font-size:2.5rem;margin-bottom:8px;">🗄</div>
      <div style="font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);"><?= $kpi['cache_items'] ?></div>
      <div style="font-size:.68rem;color:var(--muted);margin-top:2px;">Entradas en caché activas</div>
      <button class="btn btn-red" style="margin-top:10px;width:100%;justify-content:center;" onclick="limpiarCache()"><i class="fa fa-trash"></i> Limpiar caché</button>
    </div>
    <div class="card cp" style="text-align:center;">
      <div style="font-size:2.5rem;margin-bottom:8px;">🚫</div>
      <div style="font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--red-lt);"><?= count($rate_limits) ?></div>
      <div style="font-size:.68rem;color:var(--muted);margin-top:2px;">IPs bloqueadas actualmente</div>
      <button class="btn btn-ghost" style="margin-top:10px;width:100%;justify-content:center;" onclick="showSec('seguridad')"><i class="fa fa-eye"></i> Ver IPs bloqueadas</button>
    </div>
    <div class="card cp" style="text-align:center;">
      <div style="font-size:2.5rem;margin-bottom:8px;">📊</div>
      <div style="font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--green-lt);"><?= $kpi['logins_hoy'] ?></div>
      <div style="font-size:.68rem;color:var(--muted);margin-top:2px;">Logins exitosos hoy</div>
      <button class="btn btn-ghost" style="margin-top:10px;width:100%;justify-content:center;" onclick="showSec('seguridad')"><i class="fa fa-shield"></i> Ver log</button>
    </div>
    <div class="card cp" style="text-align:center;">
      <div style="font-size:2.5rem;margin-bottom:8px;">💾</div>
      <div style="font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);"><?= $kpi['backups_cnt'] ?></div>
      <div style="font-size:.68rem;color:var(--muted);margin-top:2px;">Backups disponibles</div>
      <button class="btn btn-green" style="margin-top:10px;width:100%;justify-content:center;" onclick="generarBackup('completo')"><i class="fa fa-database"></i> Generar backup</button>
    </div>
  </div>
  <div class="card cp" style="margin-top:14px;">
    <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">🔧 Herramientas de mantenimiento</p>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
      <button class="btn btn-ghost" onclick="limpiarCache()"><i class="fa fa-broom"></i> Limpiar caché expirada</button>
      <button class="btn btn-ghost" onclick="generarBackup('solo_datos')"><i class="fa fa-save"></i> Backup de datos</button>
      <button class="btn btn-ghost" onclick="showSec('config')"><i class="fa fa-gear"></i> Ir a configuración</button>
      <button class="btn btn-ghost" onclick="window.location.reload()"><i class="fa fa-refresh"></i> Recargar panel</button>
      <button class="btn btn-ghost" onclick="exportarReporte()"><i class="fa fa-file-csv"></i> Exportar CSV</button>
    </div>
  </div>
</div>


</main>
</div>

<!-- ══════════ MODALES ══════════ -->

<!-- Nuevo/Editar Servicio -->
<div class="sa-modal" id="mNuevoServicio">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl" id="mSrvTtl">🛠 Nuevo Servicio</span><button class="m-close" onclick="cerrarModal('mNuevoServicio')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <input type="hidden" id="srv_id" value="0">
      <div class="fg-2">
        <div class="fg"><label class="fl">Título *</label><input type="text" class="fi" id="srv_titulo" placeholder="Nombre del servicio"></div>
        <div class="fg"><label class="fl">Icono (emoji)</label><input type="text" class="fi" id="srv_icono" value="🛠" maxlength="4"></div>
      </div>
      <div class="fg"><label class="fl">Subtítulo</label><input type="text" class="fi" id="srv_sub" placeholder="Descripción corta"></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Categoría</label>
          <select class="fi" id="srv_cat">
            <?php foreach(['Desarrollo','Datos','Seguridad','Infraestructura','IA & Datos','Innovación','CS Fundamentals','Sistemas','Creativo','Ciencias'] as $cat):?>
            <option value="<?= $cat ?>"><?= $cat ?></option>
            <?php endforeach;?>
          </select>
        </div>
        <div class="fg"><label class="fl">Color tema</label>
          <select class="fi" id="srv_color">
            <?php foreach(['green','blue','red','purple','gold','teal','orange','indigo','cyan','emerald','slate','amber','violet','rose','pink','sky'] as $col):?>
            <option value="<?= $col ?>"><?= ucfirst($col) ?></option>
            <?php endforeach;?>
          </select>
        </div>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Nivel</label><input type="text" class="fi" id="srv_nivel" placeholder="Ej: Básico → Avanzado"></div>
        <div class="fg"><label class="fl">Duración</label><input type="text" class="fi" id="srv_dur" placeholder="Ej: 20 – 120 h"></div>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Precio base COP</label><input type="number" class="fi" id="srv_precio" value="0" min="0"></div>
        <div class="fg"><label class="fl" style="margin-bottom:14px;">Estado</label>
          <div style="display:flex;gap:12px;align-items:center;">
            <label style="display:flex;align-items:center;gap:6px;font-size:.78rem;color:var(--muted);">
              <label class="tg"><input type="checkbox" id="srv_activo" checked><span class="tg-sl"></span></label> Activo
            </label>
            <label style="display:flex;align-items:center;gap:6px;font-size:.78rem;color:var(--muted);">
              <label class="tg"><input type="checkbox" id="srv_dest"><span class="tg-sl"></span></label> Destacado
            </label>
          </div>
        </div>
      </div>
      <div class="fg"><label class="fl">Definición (texto completo)</label><textarea class="fi" id="srv_def" rows="3" placeholder="Descripción completa del servicio..."></textarea></div>
      <div class="fg"><label class="fl">Importancia</label><textarea class="fi" id="srv_imp" rows="2" placeholder="Por qué es importante..."></textarea></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">URL Foto</label><input type="text" class="fi" id="srv_foto" placeholder="https://..."></div>
        <div class="fg"><label class="fl">URL Video (embed)</label><input type="text" class="fi" id="srv_video" placeholder="https://youtube.com/embed/..."></div>
      </div>
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mNuevoServicio')">Cancelar</button>
      <button class="btn btn-gold" onclick="guardarServicio()"><i class="fa fa-save"></i> Guardar servicio</button>
    </div>
  </div>
</div>

<!-- Nuevo Proyecto -->
<div class="sa-modal" id="mNuevoProyecto">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">🚀 Nuevo Proyecto</span><button class="m-close" onclick="cerrarModal('mNuevoProyecto')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <div class="fg-2">
        <div class="fg" style="grid-column:1/-1;"><label class="fl">Título *</label><input type="text" class="fi" id="np_titulo" placeholder="Nombre del proyecto"></div>
        <div class="fg"><label class="fl">Tipo</label><select class="fi" id="np_tipo"><option value="propio">Propio</option><option value="comunidad">Comunidad</option><option value="cliente">Cliente</option><option value="academico">Académico</option></select></div>
        <div class="fg"><label class="fl">Icono (emoji)</label><input type="text" class="fi" id="np_icono" value="🚀" maxlength="4"></div>
      </div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="np_desc" rows="3"></textarea></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Áreas (CSV)</label><input type="text" class="fi" id="np_areas" placeholder="Backend, IA, Seguridad..."></div>
        <div class="fg"><label class="fl">Tecnologías (CSV)</label><input type="text" class="fi" id="np_tecn" placeholder="PHP, React, MySQL..."></div>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Fecha inicio</label><input type="date" class="fi" id="np_fecha" value="<?= date('Y-m-d') ?>"></div>
        <div class="fg"><label class="fl" style="margin-bottom:14px;">Privado</label><label class="tg" style="margin-top:4px;"><input type="checkbox" id="np_priv"><span class="tg-sl"></span></label></div>
      </div>
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mNuevoProyecto')">Cancelar</button>
      <button class="btn btn-gold" onclick="guardarProyecto()"><i class="fa fa-save"></i> Crear proyecto</button>
    </div>
  </div>
</div>

<!-- Editar Proyecto -->
<div class="sa-modal" id="mEditProyecto">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">✏️ Editar Proyecto</span><button class="m-close" onclick="cerrarModal('mEditProyecto')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <input type="hidden" id="ep_id">
      <div class="fg"><label class="fl">Título</label><input type="text" class="fi" id="ep_titulo"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="ep_desc" rows="3"></textarea></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Estado</label><select class="fi" id="ep_estado"><option value="planeado">Planeado</option><option value="activo">Activo</option><option value="pausado">Pausado</option><option value="completado">Completado</option><option value="cancelado">Cancelado</option></select></div>
        <div class="fg"><label class="fl">Progreso: <span id="ep_prog_val">0%</span></label><input type="range" id="ep_prog" min="0" max="100" style="width:100%;accent-color:var(--gold);margin-top:8px;" oninput="document.getElementById('ep_prog_val').textContent=this.value+'%'"></div>
      </div>
      <div class="fg"><label class="fl" style="margin-bottom:14px;">Privado</label><label class="tg" style="margin-top:4px;"><input type="checkbox" id="ep_priv"><span class="tg-sl"></span></label></div>
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mEditProyecto')">Cancelar</button>
      <button class="btn btn-gold" onclick="actualizarProyecto()"><i class="fa fa-save"></i> Guardar cambios</button>
    </div>
  </div>
</div>

<!-- Editar Curso -->
<div class="sa-modal" id="mEditCurso">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">✏️ Editar Curso</span><button class="m-close" onclick="cerrarModal('mEditCurso')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <input type="hidden" id="ec_id">
      <div class="fg"><label class="fl">Título</label><input type="text" class="fi" id="ec_titulo"></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Nivel</label><select class="fi" id="ec_nivel"><option value="basico">Básico</option><option value="intermedio">Intermedio</option><option value="avanzado">Avanzado</option></select></div>
        <div class="fg"><label class="fl">Precio COP</label><input type="number" class="fi" id="ec_precio" min="0"></div>
      </div>
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mEditCurso')">Cancelar</button>
      <button class="btn btn-gold" onclick="guardarCurso()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>

<!-- Nueva clave config -->
<div class="sa-modal" id="mNuevoConfig">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">➕ Nueva clave de configuración</span><button class="m-close" onclick="cerrarModal('mNuevoConfig')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <div class="fg"><label class="fl">Clave (sin espacios)</label><input type="text" class="fi" id="nc_clave" placeholder="mi_clave_config"></div>
      <div class="fg"><label class="fl">Valor</label><textarea class="fi" id="nc_valor" rows="3"></textarea></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Grupo</label><input type="text" class="fi" id="nc_grupo" value="general"></div>
        <div class="fg"><label class="fl">Tipo</label><select class="fi" id="nc_tipo"><option value="texto">Texto</option><option value="numero">Número</option><option value="booleano">Booleano</option><option value="json">JSON</option></select></div>
      </div>
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mNuevoConfig')">Cancelar</button>
      <button class="btn btn-gold" onclick="guardarNuevaConfig()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>

<!-- PQRS -->
<div class="sa-modal" id="mPqrs">
  <div class="m-box wide">
    <div class="m-hd"><span class="m-ttl">📋 PQRS — <span id="pq_folio"></span></span><button class="m-close" onclick="cerrarModal('mPqrs')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:14px;margin-bottom:12px;">
        <p style="font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:6px;" id="pq_asunto"></p>
        <p style="font-size:.78rem;color:var(--muted);line-height:1.65;" id="pq_desc"></p>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Cambiar estado</label><select class="fi" id="pq_estado"><option value="abierto">🔴 Abierto</option><option value="en_proceso">🔵 En proceso</option><option value="resuelto">🟢 Resuelto</option><option value="cerrado">⚫ Cerrado</option></select></div>
      </div>
      <div class="fg"><label class="fl">Respuesta al usuario *</label><textarea class="fi" id="pq_resp" rows="4" placeholder="Escribe la respuesta..."></textarea></div>
      <input type="hidden" id="pq_id">
    </div>
    <div class="m-foot">
      <button class="btn btn-ghost" onclick="cerrarModal('mPqrs')">Cancelar</button>
      <button class="btn btn-gold" onclick="guardarPqrs()"><i class="fa fa-paper-plane"></i> Guardar respuesta</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast-w" id="toastW"></div>

<!-- ══════════ JS ══════════ -->
<script>
/* ════ NAVEGACIÓN ════ */
const SEC_NAMES={dashboard:'Dashboard',usuarios:'Usuarios',servicios:'Servicios & Precios',cursos:'Cursos',proyectos:'Proyectos',config:'Configuración',contenido:'Contenido Web',erp:'ERP & Finanzas',pqrs:'PQRS',reportes:'Reportes',backups:'Backups',seguridad:'Seguridad & Log',cache:'Caché & Optimización'};
function showSec(id,el){
  document.querySelectorAll('.sa-sec').forEach(s=>s.classList.remove('on'));
  document.querySelectorAll('.sb-item').forEach(i=>i.classList.remove('on'));
  document.getElementById('sec-'+id)?.classList.add('on');
  if(el)el.classList.add('on');
  else document.querySelector(`.sb-item[onclick*="'${id}'"]`)?.classList.add('on');
  document.getElementById('tbSub').textContent=SEC_NAMES[id]||id;
  document.querySelector('.sa-main')?.scrollTo({top:0,behavior:'smooth'});
  if(window.innerWidth<1024)closeSb();
}
function toggleSb(){document.getElementById('saSb').classList.toggle('open');}
function closeSb(){document.getElementById('saSb').classList.remove('open');}

/* ════ MODALES ════ */
function abrirModal(id){document.getElementById(id).classList.add('on');document.body.style.overflow='hidden';}
function cerrarModal(id){document.getElementById(id).classList.remove('on');document.body.style.overflow='';}
document.querySelectorAll('.sa-modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m){m.classList.remove('on');document.body.style.overflow=''}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.sa-modal.on').forEach(m=>m.classList.remove('on'));document.body.style.overflow=''}});

/* ════ TOAST ════ */
function toast(msg,tipo='ok',dur=3500){
  const w=document.getElementById('toastW'),t=document.createElement('div');
  const icons={ok:'fa-circle-check',err:'fa-triangle-exclamation',info:'fa-circle-info'};
  t.className=`tst t-${tipo}`;
  t.innerHTML=`<i class="fa ${icons[tipo]||'fa-info'}"></i>${msg}`;
  w.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(16px)';t.style.transition='all .3s';setTimeout(()=>t.remove(),300);},dur);
}

/* ════ FETCH ════ */
async function postAction(data){
  const fd=new FormData();
  Object.entries(data).forEach(([k,v])=>fd.append(k,v));
  try{const r=await fetch('',{method:'POST',body:fd});return await r.json();}
  catch(e){return{ok:false,error:'Error de conexión'};}
}

/* ════ FILTROS ════ */
function filtrarTbl(tblId,campo,val){
  document.querySelectorAll('#'+tblId+' tbody tr').forEach(tr=>{
    tr.style.display=(!val||tr.dataset[campo]===val)?'':'none';
  });
}
function filtrarPqrs(estado){
  document.querySelectorAll('#pqrsListSA .pqrs-it').forEach(el=>{
    el.style.display=(!estado||el.dataset.estado===estado)?'':'none';
  });
}
function filtrarLog2(accion){
  document.querySelectorAll('#logListSA .log-it').forEach(el=>{
    el.style.display=(!accion||el.dataset.accion===accion)?'':'none';
  });
}

/* ════ CONFIGURACIÓN ════ */
async function guardarConfig(clave,valor,grupo,tipo){
  const r=await postAction({accion:'upsert_config',clave,valor,grupo,tipo});
  if(r.ok)toast(`⚙️ Config guardada: <strong>${clave}</strong>`,'ok');
  else toast('Error: '+r.error,'err');
}
function abrirEditJson(clave,grupo){
  toast('📋 Editor JSON — Usa Configuración para editar esta clave.','info');
}
async function guardarNuevaConfig(){
  const clave=document.getElementById('nc_clave').value.trim().replace(/\s+/g,'_');
  const valor=document.getElementById('nc_valor').value;
  const grupo=document.getElementById('nc_grupo').value;
  const tipo=document.getElementById('nc_tipo').value;
  if(!clave){toast('La clave no puede estar vacía','err');return;}
  const r=await postAction({accion:'upsert_config',clave,valor,grupo,tipo});
  if(r.ok){toast('✅ Nueva configuración guardada','ok');cerrarModal('mNuevoConfig');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ════ SERVICIOS ════ */
function abrirModalEditServicio(id,titulo,sub,cat,ico,nivel,dur){
  document.getElementById('srv_id').value=id;
  document.getElementById('srv_titulo').value=titulo;
  document.getElementById('srv_sub').value=sub;
  document.getElementById('srv_cat').value=cat;
  document.getElementById('srv_icono').value=ico;
  document.getElementById('srv_nivel').value=nivel;
  document.getElementById('srv_dur').value=dur;
  document.getElementById('mSrvTtl').textContent='✏️ Editar Servicio';
  abrirModal('mNuevoServicio');
}
async function guardarServicio(){
  const id=document.getElementById('srv_id').value;
  const op=id&&id!=='0'?'update':'create';
  const payload={
    accion:'crud_servicio',op,id,
    titulo:document.getElementById('srv_titulo').value,
    subtitulo:document.getElementById('srv_sub').value,
    definicion:document.getElementById('srv_def').value,
    importancia:document.getElementById('srv_imp').value,
    categoria:document.getElementById('srv_cat').value,
    icono:document.getElementById('srv_icono').value||'🛠',
    nivel:document.getElementById('srv_nivel').value,
    duracion:document.getElementById('srv_dur').value,
    precio_base:document.getElementById('srv_precio').value,
    foto:document.getElementById('srv_foto').value,
    video:document.getElementById('srv_video').value,
    color:document.getElementById('srv_color').value,
    activo:document.getElementById('srv_activo').checked?1:0,
    destacado:document.getElementById('srv_dest').checked?1:0,
  };
  const r=await postAction(payload);
  if(r.ok){toast('✅ Servicio guardado exitosamente','ok');cerrarModal('mNuevoServicio');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
async function updatePrecio(id,precio,el){
  const r=await postAction({accion:'crud_servicio',op:'update',id,precio_base:precio});
  if(r.ok){toast('💰 Precio actualizado: $'+Number(precio).toLocaleString('es'),'ok');}
  else{toast('Error al actualizar precio','err');el.focus();}
}
async function toggleServicio(id,activo,btn){
  const r=await postAction({accion:'crud_servicio',op:'update',id,activo});
  if(r.ok){btn.textContent=activo?'✅ Activo':'❌ Inactivo';btn.className='b '+(activo?'b-activo':'b-inactivo');btn.setAttribute('onclick',`toggleServicio(${id},${activo?0:1},this)`);}
  else toast('Error','err');
}
async function toggleDestacado(id,dest,btn){
  const r=await postAction({accion:'crud_servicio',op:'update',id,destacado:dest});
  if(r.ok){btn.textContent=dest?'⭐ Sí':'— No';btn.className='b '+(dest?'b-verificado':'b-pendiente');btn.setAttribute('onclick',`toggleDestacado(${id},${dest?0:1},this)`);}
  else toast('Error','err');
}
async function eliminarServicio(id,titulo){
  if(!confirm(`¿Desactivar el servicio "${titulo}"? Podrás reactivarlo después.`))return;
  const r=await postAction({accion:'crud_servicio',op:'delete',id});
  if(r.ok){toast('🗑 Servicio desactivado','info');setTimeout(()=>location.reload(),1000);}
  else toast('Error: '+r.error,'err');
}

/* ════ PROYECTOS ════ */
function abrirModalEditProyecto(id,titulo,desc,estado,prog,priv){
  document.getElementById('ep_id').value=id;
  document.getElementById('ep_titulo').value=titulo;
  document.getElementById('ep_desc').value=desc;
  document.getElementById('ep_estado').value=estado;
  document.getElementById('ep_prog').value=prog;
  document.getElementById('ep_prog_val').textContent=prog+'%';
  document.getElementById('ep_priv').checked=priv==1;
  abrirModal('mEditProyecto');
}
async function guardarProyecto(){
  const r=await postAction({accion:'crud_proyecto',op:'create',
    titulo:document.getElementById('np_titulo').value,
    descripcion:document.getElementById('np_desc').value,
    tipo:document.getElementById('np_tipo').value,
    icono:document.getElementById('np_icono').value||'🚀',
    areas:document.getElementById('np_areas').value,
    tecnologias:document.getElementById('np_tecn').value,
    fecha_inicio:document.getElementById('np_fecha').value,
    privado:document.getElementById('np_priv').checked?1:0,
  });
  if(r.ok){toast('🚀 Proyecto creado','ok');cerrarModal('mNuevoProyecto');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
async function actualizarProyecto(){
  const id=document.getElementById('ep_id').value;
  const r=await postAction({accion:'crud_proyecto',op:'update',id,
    titulo:document.getElementById('ep_titulo').value,
    descripcion:document.getElementById('ep_desc').value,
    estado:document.getElementById('ep_estado').value,
    progreso:document.getElementById('ep_prog').value,
    privado:document.getElementById('ep_priv').checked?1:0,
  });
  if(r.ok){toast('✅ Proyecto actualizado','ok');cerrarModal('mEditProyecto');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
async function crudProyecto(op,id,data){
  const r=await postAction({accion:'crud_proyecto',op,id,...data});
  if(!r.ok)toast('Error: '+r.error,'err');
  else if(op!=='update')toast('✅ Actualizado','ok');
}
async function eliminarProyecto(id,titulo){
  if(!confirm(`¿Eliminar PERMANENTEMENTE el proyecto "${titulo}"? Esta acción no se puede deshacer.`))return;
  const r=await postAction({accion:'crud_proyecto',op:'delete',id});
  if(r.ok){toast('🗑 Proyecto eliminado','info');setTimeout(()=>location.reload(),1000);}
  else toast('Error: '+r.error,'err');
}

/* ════ USUARIOS ════ */
async function crudUsuario(op,id,data,btn=null,campo=null,nuevoVal=null){
  const payload={accion:'crud_usuario',op,id,...data};
  const r=await postAction(payload);
  if(r.ok){
    toast('✅ Usuario actualizado','ok');
    if(op==='reset_pw')toast(`🔑 Nueva contraseña: <strong>${r.pw}</strong>`,'info',8000);
    if(btn&&campo==='activo'){btn.textContent=nuevoVal?'✅ Sí':'❌ No';btn.className='b '+(nuevoVal?'b-activo':'b-inactivo');btn.setAttribute('onclick',`crudUsuario('update',${id},{activo:${nuevoVal?0:1}},this,'activo',${nuevoVal?0:1})`);}
    if(btn&&campo==='verificado'){btn.textContent=nuevoVal?'🔵 Sí':'⏳ No';btn.className='b '+(nuevoVal?'b-verificado':'b-pendiente');btn.setAttribute('onclick',`crudUsuario('update',${id},{verificado:${nuevoVal?0:1}},this,'verificado',${nuevoVal?0:1})`);}
    if(op==='delete')setTimeout(()=>location.reload(),1000);
  }else toast('Error: '+r.error,'err');
}
async function resetPw(id,nombre){
  if(!confirm(`¿Resetear la contraseña de ${nombre}?\nNueva contraseña: Virox@2025!`))return;
  crudUsuario('reset_pw',id,{});
}

/* ════ CURSOS ════ */
async function toggleCurso(id,campo,val,btn){
  const r=await postAction({accion:'crud_curso',op:'toggle',id,campo,valor:val});
  if(r.ok){const labels={publicado:[val?'✅ Sí':'❌ No',val?'b-activo':'b-inactivo'],destacado:[val?'⭐ Sí':'— No',val?'b-verificado':'b-pendiente'],gratuito:[val?'🆓 Sí':'💰 No',val?'b-activo':'b-pendiente']};btn.textContent=labels[campo][0];btn.className='b '+labels[campo][1];btn.setAttribute('onclick',`toggleCurso(${id},'${campo}',${val?0:1},this)`);}
  else toast('Error: '+r.error,'err');
}
async function updateCursoPrecio(id,precio){
  const r=await postAction({accion:'crud_curso',op:'update',id,titulo:' ',nivel:'basico',precio,gratuito:0,publicado:1,destacado:0});
  if(r.ok)toast('💰 Precio del curso actualizado','ok');
}
async function guardarCurso(){
  const id=document.getElementById('ec_id').value;
  const r=await postAction({accion:'crud_curso',op:'update',id,titulo:document.getElementById('ec_titulo').value,nivel:document.getElementById('ec_nivel').value,precio:document.getElementById('ec_precio').value,gratuito:0,publicado:1,destacado:0});
  if(r.ok){toast('✅ Curso actualizado','ok');cerrarModal('mEditCurso');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ════ ERP ════ */
async function erpUpdateEstado(id,estado){
  const r=await postAction({accion:'erp_accion',op:'update_estado',id,estado});
  if(r.ok)toast('✅ Estado actualizado: '+estado,'ok');
  else toast('Error: '+r.error,'err');
}
async function erpUpdateMonto(id,monto){
  const r=await postAction({accion:'erp_accion',op:'update_monto',id,monto});
  if(r.ok)toast('💰 Monto actualizado: $'+Number(monto).toLocaleString('es'),'ok');
  else toast('Error al actualizar monto','err');
}

/* ════ PQRS ════ */
function abrirModalPqrs(id,folio,asunto,desc,estado){
  document.getElementById('pq_id').value=id;
  document.getElementById('pq_folio').textContent=folio;
  document.getElementById('pq_asunto').textContent=asunto;
  document.getElementById('pq_desc').textContent=desc;
  document.getElementById('pq_estado').value=estado;
  document.getElementById('pq_resp').value='';
  abrirModal('mPqrs');
}
async function guardarPqrs(){
  const id=document.getElementById('pq_id').value;
  const estado=document.getElementById('pq_estado').value;
  const respuesta=document.getElementById('pq_resp').value.trim();
  if(!respuesta){toast('Escribe una respuesta','err');return;}
  const r=await postAction({accion:'gestionar_pqrs',id,estado,respuesta});
  if(r.ok){toast('✅ PQRS respondida','ok');cerrarModal('mPqrs');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ════ CONTENIDO ════ */
async function toggleContenido(tabla,id,val,btn){
  const r=await postAction({accion:'crud_contenido',tabla,op:'toggle',id,valor:val});
  if(r.ok){btn.textContent=val?'ON':'OFF';btn.className='b '+(val?'b-activo':'b-inactivo');}
  else toast('Error: '+r.error,'err');
}
async function eliminarContenido(tabla,id){
  if(!confirm('¿Eliminar este elemento?'))return;
  const r=await postAction({accion:'crud_contenido',tabla,op:'delete',id});
  if(r.ok){toast('🗑 Eliminado','info');setTimeout(()=>location.reload(),800);}
  else toast('Error: '+r.error,'err');
}

/* ════ BACKUPS ════ */
async function generarBackup(tipo){
  const progress=document.getElementById('bkProgress');
  const bar=document.getElementById('bkBar');
  const msg=document.getElementById('bkMsg');
  progress.style.display='block';
  bar.style.width='0%';
  msg.textContent='Iniciando backup '+tipo+'...';
  setTimeout(()=>{bar.style.width='60%';msg.textContent='Exportando tablas...';},100);
  setTimeout(()=>{bar.style.width='90%';msg.textContent='Finalizando...';},2000);
  const r=await postAction({accion:'generar_backup',tipo});
  bar.style.width='100%';
  if(r.ok){
    msg.textContent=`✅ Backup generado: ${r.filename} (${r.size} bytes)`;
    toast(`💾 Backup <strong>${tipo}</strong> creado: ${r.filename}`,'ok',6000);
    setTimeout(()=>{progress.style.display='none';cargarBackups();},2000);
  }else{
    msg.textContent='❌ Error: '+(r.error||'desconocido');
    toast('Error al generar backup: '+r.error,'err');
  }
}
async function cargarBackups(){
  const r=await postAction({accion:'listar_backups'});
  if(!r.ok)return;
  const grid=document.getElementById('bkGrid');
  if(!grid)return;
  if(!r.backups.length){grid.innerHTML='<div style="grid-column:1/-1;"><div class="empty"><div class="empty-ico">💾</div><p>No hay backups generados.</p></div></div>';return;}
  grid.innerHTML=r.backups.map(bk=>`
    <div class="bk-card" id="bk_${md5lite(bk.filename)}">
      <div class="bk-ico">💾</div>
      <div class="bk-name">${escHtml(bk.filename)}</div>
      <div class="bk-meta">📅 ${bk.fecha}</div>
      <div class="bk-size">📦 ${(bk.size/1024).toFixed(1)}KB</div>
      <div class="bk-actions">
        <button class="ab ab-green" onclick="descargarBackup('${escHtml(bk.filename)}')"><i class="fa fa-download"></i> Descargar</button>
        <button class="ab ab-red" onclick="eliminarBackup('${escHtml(bk.filename)}',this)"><i class="fa fa-trash"></i></button>
      </div>
    </div>`).join('');
}
async function descargarBackup(filename){
  toast('⬇️ Preparando descarga...','info');
  const r=await postAction({accion:'descargar_backup',filename});
  if(r.ok){
    const bytes=atob(r.content);
    const arr=new Uint8Array(bytes.length);
    for(let i=0;i<bytes.length;i++)arr[i]=bytes.charCodeAt(i);
    const blob=new Blob([arr],{type:'application/sql'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');a.href=url;a.download=r.filename;a.click();
    URL.revokeObjectURL(url);
    toast('✅ Backup descargado: '+r.filename,'ok');
  }else toast('Error: '+r.error,'err');
}
async function eliminarBackup(filename,btn){
  if(!confirm(`¿Eliminar el backup "${filename}"?`))return;
  const r=await postAction({accion:'eliminar_backup',filename});
  if(r.ok){btn.closest('.bk-card').remove();toast('🗑 Backup eliminado','info');}
  else toast('Error: '+r.error,'err');
}

/* ════ CACHÉ ════ */
async function limpiarCache(){
  const r=await postAction({accion:'limpiar_cache'});
  if(r.ok)toast(`🧹 Caché limpiada: ${r.eliminados} registros eliminados`,'ok');
  else toast('Error: '+r.error,'err');
}

/* ════ BÚSQUEDA GLOBAL ════ */
document.getElementById('gSearch').addEventListener('keydown',e=>{
  if(e.key!=='Enter')return;
  const q=e.target.value.toLowerCase();if(!q)return;
  ['uTbl','erpTbl'].forEach(id=>{
    document.querySelectorAll('#'+id+' tbody tr').forEach(tr=>{
      tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none';
    });
  });
  toast(`🔍 Buscando: "${q}"... Revisa la sección activa.`,'info');
});

/* ════ EXPORTAR CSV ════ */
function exportarReporte(){
  const rows=[['Métrica','Valor']];
  rows.push(['Usuarios totales','<?= $kpi["usuarios_total"] ?>']);
  rows.push(['Usuarios activos','<?= $kpi["usuarios_activos"] ?>']);
  rows.push(['Empleados','<?= $kpi["empleados"] ?>']);
  rows.push(['Proyectos activos','<?= $kpi["proyectos_activos"] ?>']);
  rows.push(['Servicios activos','<?= $kpi["servicios_total"] ?>']);
  rows.push(['Cursos activos','<?= $kpi["cursos_total"] ?>']);
  rows.push(['Ingresos mes','<?= $kpi["ingresos_mes"] ?>']);
  rows.push(['Ingresos total','<?= $kpi["ingresos_total"] ?>']);
  rows.push(['PQRS abiertas','<?= $kpi["pqrs_abiertas"] ?>']);
  const csv=rows.map(r=>r.join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download='virox_reporte_'+new Date().toISOString().slice(0,10)+'.csv';a.click();
  URL.revokeObjectURL(url);
  toast('📊 Reporte CSV exportado','ok');
}

/* ════ UTILS ════ */
function escHtml(s){const d=document.createElement('div');d.appendChild(document.createTextNode(s));return d.innerHTML;}
function md5lite(s){let h=0;for(let i=0;i<s.length;i++)h=(Math.imul(31,h)+s.charCodeAt(i))|0;return Math.abs(h).toString(16);}

/* ════ ANIMACIONES ════ */
const ro=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';}}),{threshold:.04});
document.querySelectorAll('.kpi-card,.bk-card,.erp-card,.pqrs-it,.log-it,.cfg-group').forEach((el,i)=>{
  el.style.opacity='0';el.style.transform='translateY(12px)';
  el.style.transition=`opacity .4s ease ${i*.03}s,transform .4s ease ${i*.03}s`;
  ro.observe(el);
});

/* ════ INIT ════ */
const urlSec=new URLSearchParams(location.search).get('sec');
if(urlSec)showSec(urlSec);
</script>
</body>
</html>