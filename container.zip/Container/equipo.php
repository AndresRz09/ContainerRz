<?php
include 'conexion.php';
session_start();

// ── Traer todos los miembros del equipo desde DB ─────────────────────────
$miembros = [];
if (isset($conexion)) {
    $q = $conexion->query(
        "SELECT u.id, u.nombre, u.apellido, u.username, u.avatar, u.rol, u.bio,
                u.ocupacion, u.nivel_educativo, u.intereses,
                e.area_tecnologica, e.tipo_equipo, e.cargo_equipo,
                e.disponible, e.calificacion, e.num_proyectos,
                e.habilidades, e.descripcion_equipo, e.orden
         FROM usuarios u
         LEFT JOIN equipo e ON e.usuario_id = u.id
         WHERE u.activo = 1
           AND (u.rol IN ('admin','superadmin','empleado','creador') OR e.id IS NOT NULL)
         ORDER BY e.orden ASC, e.area_tecnologica ASC, u.nombre ASC"
    );
    if ($q) while ($r = $q->fetch_assoc()) $miembros[] = $r;
}

// ── Proyectos por miembro ─────────────────────────────────────────────────
$proyectos_por_miembro = [];
if (isset($conexion) && !empty($miembros)) {
    $ids = implode(',', array_column($miembros, 'id'));
    $qp  = $conexion->query(
        "SELECT pu.usuario_id, p.id, p.titulo, p.estado, p.progreso
         FROM proyecto_usuarios pu
         JOIN proyectos p ON pu.proyecto_id = p.id
         WHERE pu.usuario_id IN ($ids)
         ORDER BY p.fecha_inicio DESC"
    );
    if ($qp) while ($r = $qp->fetch_assoc())
        $proyectos_por_miembro[$r['usuario_id']][] = $r;
}

// ── Áreas y tipos únicos para filtros ────────────────────────────────────
$areas  = array_unique(array_filter(array_column($miembros, 'area_tecnologica')));
$tipos  = array_unique(array_filter(array_column($miembros, 'tipo_equipo')));
sort($areas); sort($tipos);

// Placeholder si la DB está vacía
if (empty($miembros)) {
    $miembros = [
        ['id'=>1,'nombre'=>'Andrés','apellido'=>'Rozo','username'=>'andres_v','avatar'=>'','rol'=>'admin','bio'=>'Líder técnico del proyecto ContainerRZ.','ocupacion'=>'Desarrollador Full Stack','intereses'=>'hacking,redes,programacion','area_tecnologica'=>'Backend','tipo_equipo'=>'Desarrollo','cargo_equipo'=>'Tech Lead','disponible'=>1,'calificacion'=>4.8,'num_proyectos'=>3,'habilidades'=>'PHP,MySQL,Docker','descripcion_equipo'=>'Arquitectura y backend del sistema.','orden'=>1],
        ['id'=>2,'nombre'=>'Laura','apellido'=>'Gómez','username'=>'laura_v','avatar'=>'','rol'=>'empleado','bio'=>'Diseñadora UX especializada en sistemas educativos.','ocupacion'=>'UX/UI Designer','intereses'=>'web_security,ia_security','area_tecnologica'=>'Diseño','tipo_equipo'=>'Diseño','cargo_equipo'=>'UX Lead','disponible'=>1,'calificacion'=>4.9,'num_proyectos'=>2,'habilidades'=>'Figma,CSS,React','descripcion_equipo'=>'Diseño de interfaces y experiencia de usuario.','orden'=>2],
        ['id'=>3,'nombre'=>'Carlos','apellido'=>'Mendez','username'=>'carlos_v','avatar'=>'','rol'=>'empleado','bio'=>'Especialista en ciberseguridad ofensiva y defensiva.','ocupacion'=>'Security Analyst','intereses'=>'hacking,forense,malware','area_tecnologica'=>'Ciberseguridad','tipo_equipo'=>'Seguridad','cargo_equipo'=>'Red Team','disponible'=>0,'calificacion'=>4.7,'num_proyectos'=>4,'habilidades'=>'Kali Linux,Metasploit,Wireshark','descripcion_equipo'=>'Análisis de vulnerabilidades y pentesting.','orden'=>3],
        ['id'=>4,'nombre'=>'Sofia','apellido'=>'Torres','username'=>'sofia_v','avatar'=>'','rol'=>'creador','bio'=>'Creadora de contenido educativo en IA y Machine Learning.','ocupacion'=>'ML Engineer','intereses'=>'ia_security,programacion','area_tecnologica'=>'Inteligencia Artificial','tipo_equipo'=>'I+D','cargo_equipo'=>'AI Researcher','disponible'=>1,'calificacion'=>5.0,'num_proyectos'=>2,'habilidades'=>'Python,TensorFlow,PyTorch','descripcion_equipo'=>'Investigación e implementación de modelos IA.','orden'=>4],
        ['id'=>5,'nombre'=>'Miguel','apellido'=>'Vargas','username'=>'miguel_v','avatar'=>'','rol'=>'empleado','bio'=>'Administrador de redes y sistemas distribuidos.','ocupacion'=>'Network Admin','intereses'=>'redes,cloud','area_tecnologica'=>'Redes','tipo_equipo'=>'Infraestructura','cargo_equipo'=>'NetOps','disponible'=>1,'calificacion'=>4.6,'num_proyectos'=>3,'habilidades'=>'Cisco,Linux,AWS','descripcion_equipo'=>'Gestión de infraestructura y conectividad.','orden'=>5],
        ['id'=>6,'nombre'=>'Valentina','apellido'=>'Cruz','username'=>'vale_v','avatar'=>'','rol'=>'empleado','bio'=>'Analista de datos y visualización para reportes de impacto.','ocupacion'=>'Data Analyst','intereses'=>'programacion,ia_security','area_tecnologica'=>'Datos','tipo_equipo'=>'Desarrollo','cargo_equipo'=>'Data Lead','disponible'=>1,'calificacion'=>4.5,'num_proyectos'=>2,'habilidades'=>'Python,SQL,Power BI','descripcion_equipo'=>'Análisis de datos y métricas del sistema.','orden'=>6],
    ];
    $areas = ['Backend','Ciberseguridad','Datos','Diseño','Inteligencia Artificial','Redes'];
    $tipos = ['Desarrollo','Diseño','I+D','Infraestructura','Seguridad'];
}

// Agrupar por área
$por_area = [];
foreach ($miembros as $m) {
    $area = $m['area_tecnologica'] ?: 'General';
    $por_area[$area][] = $m;
}
ksort($por_area);

// Iconos por área
function areaIcon(string $area): string {
    $mapa = [
        'Backend'              => '⚙️',
        'Frontend'             => '🎨',
        'Diseño'               => '✏️',
        'Ciberseguridad'       => '🔐',
        'Inteligencia Artificial'=> '🤖',
        'Redes'                => '🌐',
        'Datos'                => '📊',
        'Mobile'               => '📱',
        'I+D'                  => '🔬',
        'DevOps'               => '🚀',
        'General'              => '👥',
    ];
    return $mapa[$area] ?? '💡';
}
function areaColor(string $area): string {
    $mapa = [
        'Backend'              => 'rgba(40,166,128,.18)',
        'Frontend'             => 'rgba(251,191,36,.14)',
        'Diseño'               => 'rgba(244,114,182,.14)',
        'Ciberseguridad'       => 'rgba(239,68,68,.14)',
        'Inteligencia Artificial'=> 'rgba(139,92,246,.14)',
        'Redes'                => 'rgba(59,130,246,.14)',
        'Datos'                => 'rgba(249,115,22,.14)',
        'Mobile'               => 'rgba(20,184,166,.14)',
        'I+D'                  => 'rgba(168,85,247,.14)',
        'DevOps'               => 'rgba(34,197,94,.14)',
        'General'              => 'rgba(148,163,184,.1)',
    ];
    return $mapa[$area] ?? 'rgba(40,166,128,.12)';
}
function areaBorder(string $area): string {
    $mapa = [
        'Backend'              => 'rgba(40,166,128,.4)',
        'Frontend'             => 'rgba(251,191,36,.35)',
        'Diseño'               => 'rgba(244,114,182,.35)',
        'Ciberseguridad'       => 'rgba(239,68,68,.35)',
        'Inteligencia Artificial'=> 'rgba(139,92,246,.35)',
        'Redes'                => 'rgba(59,130,246,.35)',
        'Datos'                => 'rgba(249,115,22,.35)',
        'Mobile'               => 'rgba(20,184,166,.35)',
        'I+D'                  => 'rgba(168,85,247,.35)',
        'DevOps'               => 'rgba(34,197,94,.35)',
        'General'              => 'rgba(148,163,184,.2)',
    ];
    return $mapa[$area] ?? 'rgba(40,166,128,.3)';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Equipo — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
    :root{--hh:68px;--idx-w:268px;}

    /* ═══════════════════════════════════════
       HERO MINI
    ══════════════════════════════════════ */
    .eq-hero{
      position:relative;overflow:hidden;
      padding:56px 28px 44px;text-align:center;
      background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,var(--n900) 70%);
      border-bottom:1px solid rgba(40,166,128,.15);
    }
    .eq-hero-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:48px 48px;}
    .eq-hero-orb{position:absolute;border-radius:50%;filter:blur(90px);pointer-events:none;}
    .eho1{width:500px;height:500px;background:radial-gradient(circle,rgba(40,166,128,.16),transparent 70%);top:-150px;left:-120px;animation:orbf 9s ease-in-out infinite;}
    .eho2{width:380px;height:380px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-100px;right:-80px;animation:orbf 12s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(22px,-22px)}}
    .eq-hero-inner{position:relative;z-index:1;max-width:740px;margin:auto;}
    .eq-tag{display:inline-block;padding:5px 16px;background:rgba(40,166,128,.12);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.75rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:18px;}
    .eq-title{font-family:var(--font-d);font-size:clamp(1.9rem,3.5vw,3rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:10px;}
    .eq-title span{color:var(--gold);text-shadow:0 0 32px rgba(218,165,32,.4);}
    .eq-sub{font-size:.95rem;color:var(--muted);line-height:1.7;margin-bottom:28px;}

    /* Stats hero */
    .eq-hero-stats{display:inline-flex;align-items:center;gap:24px;padding:16px 28px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);backdrop-filter:blur(8px);}
    .ehs{text-align:center;}
    .ehs-n{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);line-height:1;}
    .ehs-l{font-size:.68rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-top:3px;}
    .ehs-div{width:1px;height:34px;background:rgba(255,255,255,.1);}

    /* ═══════════════════════════════════════
       LAYOUT
    ══════════════════════════════════════ */
    .eq-layout{display:grid;grid-template-columns:var(--idx-w) 1fr;max-width:1480px;margin:0 auto;padding:36px 28px;gap:32px;align-items:start;}

    /* ═══════════════════════════════════════
       ÍNDICE LATERAL (sticky + draggable)
    ══════════════════════════════════════ */
    .eq-index{
      position:sticky;top:calc(var(--hh)+16px);
      background:var(--n800);border:1px solid rgba(40,166,128,.2);
      border-radius:var(--r-xl);padding:22px 16px;
      box-shadow:var(--sh-md);
      max-height:calc(100vh - var(--hh) - 48px);overflow-y:auto;
    }
    .eq-index::-webkit-scrollbar{width:3px;}
    .eq-idx-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.07);}
    .eq-idx-title{font-family:var(--font-d);font-size:.75rem;font-weight:700;color:var(--gold);letter-spacing:2.5px;text-transform:uppercase;}
    .eq-idx-count{font-size:.68rem;color:var(--dim);background:rgba(255,255,255,.06);padding:2px 8px;border-radius:99px;}

    /* Buscador */
    .eq-idx-search{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:var(--r-md);padding:8px 11px;margin-bottom:14px;}
    .eq-idx-search i{color:var(--muted);font-size:.78rem;flex-shrink:0;}
    .eq-idx-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.8rem;width:100%;}
    .eq-idx-search input::placeholder{color:var(--dim);}

    /* Sección índice */
    .idx-sec-lbl{font-size:.62rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:0 4px;margin:14px 0 6px;}
    .eq-idx-item{
      display:flex;align-items:center;gap:9px;
      padding:8px 10px;border-radius:var(--r-md);
      color:var(--muted);font-size:.82rem;font-weight:500;
      cursor:pointer;transition:all .2s;border-left:2px solid transparent;
      user-select:none;
    }
    .eq-idx-item:hover,.eq-idx-item.on{background:var(--green-dim);color:var(--green-lt);border-left-color:var(--green);}
    .eq-idx-item .eidx-ico{width:20px;text-align:center;font-size:.85rem;flex-shrink:0;}
    .eq-idx-item .eidx-badge{margin-left:auto;padding:1px 7px;background:rgba(255,255,255,.07);border-radius:99px;font-size:.62rem;color:var(--dim);}
    .eq-idx-item.on .eidx-badge{background:rgba(40,166,128,.2);color:var(--green-lt);}

    /* Filtro tipo */
    .tipo-chips{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:6px;}
    .tipo-chip{
      padding:4px 10px;border-radius:99px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);
      color:var(--dim);font-size:.7rem;font-weight:700;cursor:pointer;transition:all .2s;
    }
    .tipo-chip:hover{background:rgba(40,166,128,.12);color:var(--green-lt);border-color:rgba(40,166,128,.3);}
    .tipo-chip.on{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}

    /* Disponibilidad toggle */
    .disp-toggle{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);margin-top:14px;cursor:pointer;}
    .disp-toggle span{font-size:.78rem;color:var(--muted);}
    .disp-led{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.15);transition:background .3s;}
    .disp-led.on{background:#22c55e;box-shadow:0 0 8px #22c55e;}

    /* Mini mapa equipo */
    .idx-minimap{margin-top:14px;padding-top:12px;border-top:1px solid rgba(255,255,255,.06);}
    .idx-minimap-title{font-size:.62rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:10px;}
    .idx-minimap-bars{display:flex;flex-direction:column;gap:5px;}
    .imbar{display:flex;align-items:center;gap:8px;}
    .imbar-lbl{font-size:.68rem;color:var(--muted);width:60px;flex-shrink:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .imbar-track{flex:1;height:4px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden;}
    .imbar-fill{height:100%;border-radius:99px;background:linear-gradient(to right,var(--green),var(--gold));}
    .imbar-n{font-size:.62rem;color:var(--dim);flex-shrink:0;}

    /* ═══════════════════════════════════════
       CONTENIDO PRINCIPAL
    ══════════════════════════════════════ */
    .eq-main{min-width:0;}

    /* Barra superior de control */
    .eq-toolbar{
      display:flex;align-items:center;gap:12px;
      margin-bottom:28px;flex-wrap:wrap;
    }
    .eq-toolbar-left{display:flex;align-items:center;gap:10px;flex:1;}
    .eq-search{
      display:flex;align-items:center;gap:8px;flex:1;max-width:320px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
      border-radius:var(--r-md);padding:9px 14px;
    }
    .eq-search i{color:var(--muted);font-size:.85rem;flex-shrink:0;}
    .eq-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.88rem;width:100%;}
    .eq-search input::placeholder{color:var(--dim);}

    /* Vista toggle */
    .view-btns{display:flex;gap:3px;background:rgba(255,255,255,.05);padding:3px;border-radius:var(--r-sm);}
    .vbtn{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:.8rem;color:var(--muted);cursor:pointer;transition:all .2s;border:none;background:none;}
    .vbtn.on{background:var(--green);color:#fff;}

    /* Sort */
    .sort-sel{padding:8px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.82rem;outline:none;cursor:pointer;}
    .sort-sel option{background:var(--n700);}

    /* ═══════════════════════════════════════
       CONTENEDORES DE ÁREA
    ══════════════════════════════════════ */
    .area-container{
      margin-bottom:48px;
      animation:areaIn .5s ease both;
    }
    @keyframes areaIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}

    .area-header{
      display:flex;align-items:center;gap:14px;
      margin-bottom:20px;padding:16px 20px;
      border-radius:var(--r-lg);
      border-left:3px solid;
      position:relative;overflow:hidden;
    }
    .area-header::before{
      content:'';position:absolute;inset:0;
      background:inherit;opacity:.06;
    }
    .area-ico{font-size:1.8rem;position:relative;z-index:1;flex-shrink:0;}
    .area-hd-text{position:relative;z-index:1;flex:1;}
    .area-hd-text h2{font-family:var(--font-d);font-size:1rem;font-weight:700;color:var(--txt);letter-spacing:1.5px;margin-bottom:3px;}
    .area-hd-text p{font-size:.78rem;color:var(--muted);}
    .area-count{position:relative;z-index:1;font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);flex-shrink:0;}
    .area-collapse-btn{
      position:relative;z-index:1;
      width:30px;height:30px;border-radius:50%;
      background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
      color:var(--muted);display:flex;align-items:center;justify-content:center;
      cursor:pointer;transition:all .2s;font-size:.8rem;flex-shrink:0;
    }
    .area-collapse-btn:hover{background:rgba(255,255,255,.15);color:var(--txt);}

    /* Grid de miembros */
    .area-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;}
    .area-grid.list-view{grid-template-columns:1fr;}
    .area-grid.collapsed{display:none;}

    /* ═══════════════════════════════════════
       TARJETA DE MIEMBRO
    ══════════════════════════════════════ */
    .member-card{
      background:var(--n700);
      border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);
      overflow:hidden;
      transition:transform .25s,border-color .25s,box-shadow .25s;
      position:relative;
    }
    .member-card:hover{transform:translateY(-6px);border-color:rgba(40,166,128,.4);box-shadow:0 12px 40px rgba(0,0,0,.45);}

    /* Banda superior de color */
    .mc-band{height:6px;width:100%;}

    /* Cuerpo */
    .mc-body{padding:20px;}

    /* Header tarjeta */
    .mc-top{display:flex;align-items:flex-start;gap:14px;margin-bottom:14px;}
    .mc-avatar-wrap{position:relative;flex-shrink:0;}
    .mc-avatar{width:62px;height:62px;border-radius:50%;object-fit:cover;border:2.5px solid var(--green);box-shadow:0 0 16px rgba(40,166,128,.3);}
    .mc-avatar-ph{width:62px;height:62px;border-radius:50%;background:var(--n500);border:2px solid rgba(40,166,128,.3);display:flex;align-items:center;justify-content:center;font-size:1.4rem;color:var(--muted);}
    .mc-disp-dot{position:absolute;bottom:2px;right:2px;width:10px;height:10px;border-radius:50%;border:2px solid var(--n700);}
    .mc-disp-dot.disponible{background:#22c55e;}
    .mc-disp-dot.ocupado{background:#f59e0b;}

    .mc-info{flex:1;min-width:0;}
    .mc-name{font-family:var(--font-d);font-size:.85rem;font-weight:700;color:var(--txt);letter-spacing:.5px;margin-bottom:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .mc-cargo{font-size:.72rem;color:var(--green-lt);font-weight:700;letter-spacing:.5px;margin-bottom:4px;}
    .mc-username{font-size:.7rem;color:var(--dim);}

    /* Calificación estrellas */
    .mc-rating{display:flex;align-items:center;gap:4px;margin-top:4px;}
    .mc-stars{display:flex;gap:1px;}
    .mc-star{font-size:.65rem;color:var(--gold);}
    .mc-star.empty{color:rgba(255,255,255,.15);}
    .mc-rating-num{font-size:.68rem;color:var(--dim);margin-left:2px;}

    /* Bio */
    .mc-bio{font-size:.8rem;color:var(--muted);line-height:1.6;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}

    /* Habilidades */
    .mc-skills{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px;}
    .mc-skill{padding:2px 9px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:99px;font-size:.65rem;color:var(--muted);font-weight:600;}

    /* Proyectos mini */
    .mc-proyectos{margin-bottom:14px;}
    .mc-proy-title{font-size:.65rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:7px;}
    .mc-proy-list{display:flex;flex-direction:column;gap:5px;}
    .mc-proy-item{
      display:flex;align-items:center;gap:8px;
      padding:5px 9px;background:rgba(255,255,255,.03);
      border:1px solid rgba(255,255,255,.06);border-radius:var(--r-sm);
    }
    .mc-proy-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0;}
    .mc-proy-dot.activo{background:var(--green);}
    .mc-proy-dot.completado{background:#3b82f6;}
    .mc-proy-dot.pausado{background:var(--gold);}
    .mc-proy-name{font-size:.72rem;color:var(--txt);flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
    .mc-proy-prog{font-size:.65rem;color:var(--dim);}

    /* Footer tarjeta */
    .mc-footer{
      display:flex;align-items:center;justify-content:space-between;
      padding-top:12px;border-top:1px solid rgba(255,255,255,.06);
    }
    .mc-num-proy{font-size:.72rem;color:var(--muted);}
    .mc-num-proy strong{color:var(--gold);font-family:var(--font-d);}
    .mc-actions{display:flex;gap:6px;}
    .mc-btn{
      display:flex;align-items:center;gap:5px;
      padding:6px 12px;border-radius:var(--r-sm);
      font-size:.72rem;font-weight:700;cursor:pointer;
      transition:all .2s;border:none;font-family:var(--font-b);
    }
    .mc-btn-primary{background:var(--green);color:#fff;}
    .mc-btn-primary:hover{background:var(--green-lt);}
    .mc-btn-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
    .mc-btn-ghost:hover{background:rgba(255,255,255,.12);color:var(--txt);}

    /* Lista view */
    .list-view .member-card{display:grid;grid-template-columns:auto 1fr;grid-template-rows:auto auto;}
    .list-view .mc-band{grid-column:1/-1;height:4px;}
    .list-view .mc-body{display:flex;align-items:center;gap:20px;padding:14px 20px;}
    .list-view .mc-top{margin-bottom:0;flex-shrink:0;}
    .list-view .mc-bio{display:none;}
    .list-view .mc-skills{display:none;}
    .list-view .mc-proyectos{display:none;}
    .list-view .mc-footer{border:none;padding:0;margin-left:auto;flex-shrink:0;}

    /* ═══════════════════════════════════════
       MODAL DETALLE MIEMBRO
    ══════════════════════════════════════ */
    .member-modal{
      position:fixed;inset:0;background:rgba(0,0,0,.88);
      z-index:9999;display:none;align-items:center;justify-content:center;padding:24px;
    }
    .member-modal.open{display:flex;}
    .mm-box{
      background:var(--n800);border:1px solid rgba(40,166,128,.25);
      border-radius:var(--r-xl);width:90%;max-width:680px;max-height:90vh;
      overflow-y:auto;box-shadow:var(--sh-lg);animation:mmin .35s ease both;
    }
    @keyframes mmin{from{opacity:0;transform:scale(.95) translateY(20px)}to{opacity:1;transform:none}}
    .mm-header{
      display:flex;align-items:center;gap:20px;
      padding:28px 28px 20px;border-bottom:1px solid rgba(255,255,255,.07);
    }
    .mm-av-big{width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 28px rgba(40,166,128,.4);flex-shrink:0;}
    .mm-av-ph{width:90px;height:90px;border-radius:50%;background:var(--n500);border:3px solid rgba(40,166,128,.3);display:flex;align-items:center;justify-content:center;font-size:2.5rem;flex-shrink:0;}
    .mm-hd-info{flex:1;}
    .mm-name{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:4px;}
    .mm-cargo{font-size:.8rem;color:var(--green-lt);font-weight:700;letter-spacing:1px;margin-bottom:6px;}
    .mm-badges{display:flex;flex-wrap:wrap;gap:6px;}
    .mm-badge{padding:3px 10px;border-radius:99px;font-size:.68rem;font-weight:700;}
    .mm-close{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;flex-shrink:0;}
    .mm-close:hover{background:rgba(239,68,68,.2);color:#f87171;}
    .mm-body{padding:24px 28px;}
    .mm-section{margin-bottom:20px;}
    .mm-sec-title{font-size:.68rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:10px;}
    .mm-bio{font-size:.88rem;color:var(--muted);line-height:1.7;}
    .mm-grid2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
    .mm-info-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:12px 14px;}
    .mm-info-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;}
    .mm-info-val{font-size:.88rem;color:var(--txt);font-weight:600;}
    .mm-skills-wrap{display:flex;flex-wrap:wrap;gap:6px;}
    .mm-skill-tag{padding:4px 12px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;font-size:.72rem;color:var(--green-lt);font-weight:600;}
    .mm-footer{padding:16px 28px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:10px;justify-content:flex-end;}

    /* Contacto modal */
    .contact-modal{position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:10000;display:none;align-items:center;justify-content:center;padding:24px;}
    .contact-modal.open{display:flex;}
    .cm-box{background:var(--n800);border:1px solid rgba(40,166,128,.25);border-radius:var(--r-xl);width:90%;max-width:480px;overflow:hidden;box-shadow:var(--sh-lg);animation:mmin .3s ease both;}
    .cm-header{padding:20px 24px 16px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:space-between;}
    .cm-header h3{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
    .cm-body{padding:20px 24px;}
    .cm-input{width:100%;padding:10px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.88rem;margin-bottom:12px;}
    .cm-input:focus{outline:none;border-color:var(--green);}
    .cm-textarea{resize:vertical;min-height:100px;line-height:1.6;}
    .cm-footer{padding:0 24px 20px;display:flex;gap:8px;justify-content:flex-end;}

    /* ═══════════════════════════════════════
       EMPTY / FAB
    ══════════════════════════════════════ */
    .area-empty{text-align:center;padding:40px;color:var(--dim);background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.07);border-radius:var(--r-lg);}
    .fab-add{position:fixed;bottom:32px;right:32px;z-index:100;width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,var(--green),#1d8f6e);color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.2rem;box-shadow:0 6px 24px rgba(40,166,128,.45);cursor:pointer;transition:all .2s;border:none;}
    .fab-add:hover{transform:scale(1.12) rotate(90deg);}

    /* Responsive */
    @media(max-width:1024px){.eq-layout{grid-template-columns:220px 1fr;gap:20px;padding:24px 16px;}}
    @media(max-width:820px){.eq-layout{grid-template-columns:1fr;}.eq-index{position:static;max-height:300px;}.area-grid{grid-template-columns:1fr 1fr;}}
    @media(max-width:560px){.area-grid{grid-template-columns:1fr;}.eq-hero-stats{flex-wrap:wrap;gap:12px;}.mm-grid2{grid-template-columns:1fr;}}
  </style>
</head>
<body>

<!-- ══ HEADER ══ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyecto</a>
      <a href="equipo.php"    class="nav-link active">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php" class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php" class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>

      <?php if(!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span class="user-av"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Salir</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>

<!-- ══ HERO ══ -->
<div class="eq-hero">
  <div class="eq-hero-bg"></div>
  <div class="eq-hero-orb eho1"></div>
  <div class="eq-hero-orb eho2"></div>
  <div class="eq-hero-inner">
    <span class="eq-tag">⬡ Equipo — Team VIROX</span>
    <h1 class="eq-title">Nuestro <span>Equipo</span></h1>
    <p class="eq-sub">Colaboradores especializados organizados por área tecnológica. Explora, filtra y conecta con cada miembro del ecosistema VIROX.</p>
    <div class="eq-hero-stats">
      <div class="ehs">
        <div class="ehs-n" id="statTotal"><?= count($miembros) ?></div>
        <div class="ehs-l">Miembros</div>
      </div>
      <div class="ehs-div"></div>
      <div class="ehs">
        <div class="ehs-n"><?= count($por_area) ?></div>
        <div class="ehs-l">Áreas</div>
      </div>
      <div class="ehs-div"></div>
      <div class="ehs">
        <div class="ehs-n"><?= count(array_filter($miembros, fn($m) => $m['disponible'] ?? 0)) ?></div>
        <div class="ehs-l">Disponibles</div>
      </div>
      <div class="ehs-div"></div>
      <div class="ehs">
        <div class="ehs-n"><?= count($tipos) ?></div>
        <div class="ehs-l">Equipos</div>
      </div>
    </div>
  </div>
</div>

<!-- ══ LAYOUT ══ -->
<div class="eq-layout">

  <!-- ─── ÍNDICE LATERAL ──────────────────────────────────────────── -->
  <aside class="eq-index" id="eqIndex">
    <div class="eq-idx-top">
      <span class="eq-idx-title">Índice</span>
      <span class="eq-idx-count" id="idxCount"><?= count($miembros) ?> miembros</span>
    </div>

    <!-- Buscador -->
    <div class="eq-idx-search">
      <i class="fa fa-search"></i>
      <input type="text" id="idxSearchInput" placeholder="Buscar miembro...">
    </div>

    <!-- Por área -->
    <div class="idx-sec-lbl">Por Área</div>
    <div id="idxAreaNav">
      <div class="eq-idx-item on" onclick="filterArea('',this)" data-area="">
        <span class="eidx-ico">🌐</span>
        <span>Todas las áreas</span>
        <span class="eidx-badge"><?= count($miembros) ?></span>
      </div>
      <?php foreach ($por_area as $area => $ms): ?>
      <div class="eq-idx-item" onclick="filterArea('<?= htmlspecialchars($area) ?>',this)" data-area="<?= htmlspecialchars($area) ?>">
        <span class="eidx-ico"><?= areaIcon($area) ?></span>
        <span><?= htmlspecialchars($area) ?></span>
        <span class="eidx-badge"><?= count($ms) ?></span>
      </div>
      <?php endforeach; ?>
    </div>

    <!-- Por tipo de equipo -->
    <?php if (!empty($tipos)): ?>
    <div class="idx-sec-lbl" style="margin-top:16px;">Por Tipo</div>
    <div class="tipo-chips" id="tipoChips">
      <span class="tipo-chip on" onclick="filterTipo('',this)">Todos</span>
      <?php foreach ($tipos as $tipo): ?>
      <span class="tipo-chip" onclick="filterTipo('<?= htmlspecialchars($tipo) ?>',this)"><?= htmlspecialchars($tipo) ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Disponibles toggle -->
    <div class="disp-toggle" id="dispToggle" onclick="toggleDisponible()">
      <span><i class="fa fa-circle-dot" style="color:#22c55e;font-size:.7rem;margin-right:5px;"></i> Solo disponibles</span>
      <div class="disp-led" id="dispLed"></div>
    </div>

    <!-- Mini mapa áreas -->
    <div class="idx-minimap">
      <div class="idx-minimap-title">Distribución por Área</div>
      <div class="idx-minimap-bars">
        <?php
          $total_m = count($miembros) ?: 1;
          foreach ($por_area as $area => $ms):
            $pct = round(count($ms) / $total_m * 100);
        ?>
        <div class="imbar">
          <span class="imbar-lbl" title="<?= htmlspecialchars($area) ?>"><?= htmlspecialchars(substr($area, 0, 9)) ?></span>
          <div class="imbar-track"><div class="imbar-fill" style="width:<?= $pct ?>%"></div></div>
          <span class="imbar-n"><?= count($ms) ?></span>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </aside>

  <!-- ─── CONTENIDO PRINCIPAL ──────────────────────────────────────── -->
  <main class="eq-main">

    <!-- Toolbar -->
    <div class="eq-toolbar">
      <div class="eq-toolbar-left">
        <div class="eq-search">
          <i class="fa fa-search"></i>
          <input type="text" id="mainSearch" placeholder="Buscar por nombre, cargo, habilidad...">
        </div>
        <div class="view-btns">
          <button class="vbtn on" id="vGrid" onclick="setView('grid',this)" title="Cuadrícula"><i class="fa fa-th-large"></i></button>
          <button class="vbtn" id="vList" onclick="setView('list',this)" title="Lista"><i class="fa fa-list"></i></button>
        </div>
      </div>
      <select class="sort-sel" id="sortSel" onchange="sortMembers()">
        <option value="nombre">Ordenar: Nombre</option>
        <option value="calificacion">Ordenar: Calificación</option>
        <option value="proyectos">Ordenar: Proyectos</option>
        <option value="area">Ordenar: Área</option>
      </select>
    </div>

    <!-- Contenedores por área -->
    <?php foreach ($por_area as $area => $ms): ?>
    <div class="area-container" id="area-<?= htmlspecialchars(str_replace(' ', '_', $area)) ?>" data-area="<?= htmlspecialchars($area) ?>">

      <!-- Header del área -->
      <div class="area-header" style="background:<?= areaColor($area) ?>;border-left-color:<?= areaBorder($area) ?>;">
        <span class="area-ico"><?= areaIcon($area) ?></span>
        <div class="area-hd-text">
          <h2><?= htmlspecialchars($area) ?></h2>
          <p>
            <?= implode(' · ', array_unique(array_filter(array_column($ms, 'tipo_equipo')))) ?>
            &nbsp;—&nbsp; <?= count($ms) ?> colaborador<?= count($ms) !== 1 ? 'es' : '' ?>
          </p>
        </div>
        <span class="area-count"><?= count($ms) ?></span>
        <button class="area-collapse-btn" onclick="toggleCollapse(this)" title="Colapsar/Expandir">
          <i class="fa fa-chevron-up"></i>
        </button>
      </div>

      <!-- Grid miembros -->
      <div class="area-grid" id="grid-<?= htmlspecialchars(str_replace(' ', '_', $area)) ?>">
        <?php foreach ($ms as $m):
          $av      = !empty($m['avatar']) ? htmlspecialchars($m['avatar']) : '';
          $nombre  = htmlspecialchars(trim(($m['nombre'] ?? '') . ' ' . ($m['apellido'] ?? '')));
          $cargo   = htmlspecialchars($m['cargo_equipo'] ?? $m['ocupacion'] ?? $m['rol'] ?? '');
          $skills  = array_filter(explode(',', $m['habilidades'] ?? ''));
          $interArr= array_filter(explode(',', $m['intereses'] ?? ''));
          $proysM  = $proyectos_por_miembro[$m['id']] ?? [];
          $disp    = $m['disponible'] ?? 1;
          $cal     = (float)($m['calificacion'] ?? 0);
          $nProy   = $m['num_proyectos'] ?? count($proysM);
          $tipo    = htmlspecialchars($m['tipo_equipo'] ?? '');
        ?>
        <div class="member-card"
             data-nombre="<?= strtolower($nombre) ?>"
             data-area="<?= htmlspecialchars($area) ?>"
             data-tipo="<?= $tipo ?>"
             data-disponible="<?= $disp ?>"
             data-calificacion="<?= $cal ?>"
             data-proyectos="<?= $nProy ?>">

          <!-- Banda de color -->
          <div class="mc-band" style="background:linear-gradient(to right,<?= areaBorder($area) ?>,transparent);"></div>

          <div class="mc-body">
            <!-- Header -->
            <div class="mc-top">
              <div class="mc-avatar-wrap">
                <?php if ($av): ?>
                  <img src="<?= $av ?>" class="mc-avatar" alt="<?= $nombre ?>">
                <?php else: ?>
                  <div class="mc-avatar-ph"><?= mb_substr($m['nombre'] ?? '?', 0, 1) ?></div>
                <?php endif; ?>
                <div class="mc-disp-dot <?= $disp ? 'disponible' : 'ocupado' ?>" title="<?= $disp ? 'Disponible' : 'Ocupado' ?>"></div>
              </div>

              <div class="mc-info">
                <div class="mc-name"><?= $nombre ?></div>
                <div class="mc-cargo"><?= $cargo ?></div>
                <div class="mc-username">@<?= htmlspecialchars($m['username'] ?? '') ?></div>
                <?php if ($cal > 0): ?>
                <div class="mc-rating">
                  <div class="mc-stars">
                    <?php for ($s = 1; $s <= 5; $s++): ?>
                    <span class="mc-star <?= $s <= round($cal) ? '' : 'empty' ?>">★</span>
                    <?php endfor; ?>
                  </div>
                  <span class="mc-rating-num"><?= number_format($cal, 1) ?></span>
                </div>
                <?php endif; ?>
              </div>
            </div>

            <!-- Bio -->
            <?php if (!empty($m['descripcion_equipo']) || !empty($m['bio'])): ?>
            <p class="mc-bio"><?= htmlspecialchars($m['descripcion_equipo'] ?: $m['bio']) ?></p>
            <?php endif; ?>

            <!-- Habilidades -->
            <?php if (!empty($skills)): ?>
            <div class="mc-skills">
              <?php foreach (array_slice($skills, 0, 4) as $sk): ?>
              <span class="mc-skill"><?= htmlspecialchars(trim($sk)) ?></span>
              <?php endforeach; ?>
              <?php if (count($skills) > 4): ?>
              <span class="mc-skill">+<?= count($skills) - 4 ?></span>
              <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Proyectos -->
            <?php if (!empty($proysM)): ?>
            <div class="mc-proyectos">
              <div class="mc-proy-title"><i class="fa fa-diagram-project" style="margin-right:4px;"></i>Proyectos</div>
              <div class="mc-proy-list">
                <?php foreach (array_slice($proysM, 0, 2) as $pr): ?>
                <div class="mc-proy-item">
                  <div class="mc-proy-dot <?= htmlspecialchars($pr['estado'] ?? 'activo') ?>"></div>
                  <span class="mc-proy-name"><?= htmlspecialchars($pr['titulo']) ?></span>
                  <span class="mc-proy-prog"><?= (int)($pr['progreso'] ?? 0) ?>%</span>
                </div>
                <?php endforeach; ?>
              </div>
            </div>
            <?php endif; ?>

            <!-- Footer -->
            <div class="mc-footer">
              <div class="mc-num-proy">
                <strong><?= $nProy ?></strong> proyecto<?= $nProy !== 1 ? 's' : '' ?>
              </div>
              <div class="mc-actions">
                <button class="mc-btn mc-btn-ghost" onclick="openContactModal('<?= (int)$m['id'] ?>','<?= $nombre ?>')" title="Contactar">
                  <i class="fa fa-envelope"></i>
                </button>
                <button class="mc-btn mc-btn-primary" onclick="window.location.href='perfil.php?id=<?= (int)$m['id'] ?>'">
                  <i class="fa fa-user"></i> Ver perfil
                </button>
              </div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div><!-- /area-grid -->
    </div><!-- /area-container -->
    <?php endforeach; ?>

    <?php if (empty($por_area)): ?>
    <div style="text-align:center;padding:80px 24px;color:var(--dim);">
      <div style="font-size:4rem;margin-bottom:16px;opacity:.3;">👥</div>
      <p style="font-size:.95rem;">No hay miembros del equipo registrados aún.</p>
    </div>
    <?php endif; ?>

  </main>
</div><!-- /eq-layout -->


<!-- ══ MODAL DETALLE MIEMBRO (dinámico) ══ -->
<div class="member-modal" id="memberModal">
  <div class="mm-box" id="mmBox">
    <!-- Contenido dinámico vía JS -->
  </div>
</div>

<!-- ══ MODAL CONTACTAR ══ -->
<div class="contact-modal" id="contactModal">
  <div class="cm-box">
    <div class="cm-header">
      <h3><i class="fa fa-envelope" style="color:var(--green);margin-right:8px;"></i> Contactar a <span id="cmNombre">miembro</span></h3>
      <button class="mm-close" onclick="closeContactModal()"><i class="fa fa-times"></i></button>
    </div>
    <div class="cm-body">
      <input type="hidden" id="cmUid">
      <input class="cm-input" type="text" placeholder="Asunto del mensaje" id="cmAsunto">
      <textarea class="cm-input cm-textarea" placeholder="Escribe tu mensaje aquí..." id="cmMensaje"></textarea>
      <div style="display:flex;align-items:center;gap:8px;margin-top:4px;">
        <i class="fa fa-circle-info" style="color:var(--muted);font-size:.8rem;"></i>
        <span style="font-size:.72rem;color:var(--dim);">El mensaje se enviará a través del sistema de mensajería interno de VIROX.</span>
      </div>
    </div>
    <div class="cm-footer">
      <button class="mc-btn mc-btn-ghost" onclick="closeContactModal()">Cancelar</button>
      <button class="mc-btn mc-btn-primary" onclick="window.location.href='ver-perfil.php?id=<?= (int)$m['id'] ?>'">
      <button class="mc-btn mc-btn-primary" onclick="sendMessage()"><i class="fa fa-paper-plane"></i> Enviar</button>
    </div>
  </div>
</div>

<?php if (isset($_SESSION['rol']) && in_array($_SESSION['rol'], ['admin','superadmin'])): ?>
<button class="fab-add" onclick="window.location.href='admin/equipo.php'" title="Gestionar equipo"><i class="fa fa-users-gear"></i></button>
<?php endif; ?>

<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand"><span class="brand-hex">⬡</span><span class="brand-name">VIROX</span></div>
    <p class="footer-copy">© 2025 Team VIROX — Todos los derechos reservados</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyectos</a>
      <a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>

<script>
/* ── Header scroll ── */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));

/* ── Burger ── */
document.getElementById('burger').addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Estado de filtros ── */
let activeArea = '';
let activeTipo = '';
let soloDisponibles = false;
let currentView = 'grid';

/* ── Filtro por área ── */
function filterArea(area, el) {
  activeArea = area;
  document.querySelectorAll('.eq-idx-item').forEach(i => i.classList.remove('on'));
  if (el) el.classList.add('on');

  document.querySelectorAll('.area-container').forEach(c => {
    const match = !area || c.dataset.area === area;
    c.style.display = match ? '' : 'none';
  });
  applyCardFilters();
}

/* ── Filtro por tipo ── */
function filterTipo(tipo, el) {
  activeTipo = tipo;
  document.querySelectorAll('.tipo-chip').forEach(c => c.classList.remove('on'));
  if (el) el.classList.add('on');
  applyCardFilters();
}

/* ── Toggle disponibles ── */
function toggleDisponible() {
  soloDisponibles = !soloDisponibles;
  document.getElementById('dispLed').classList.toggle('on', soloDisponibles);
  applyCardFilters();
}

/* ── Búsqueda ── */
document.getElementById('mainSearch').addEventListener('input', applyCardFilters);
document.getElementById('idxSearchInput').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.eq-idx-item[data-area]').forEach(i => {
    i.style.display = (!q || i.querySelector('span:nth-child(2)')?.textContent.toLowerCase().includes(q)) ? '' : 'none';
  });
  applyCardFilters();
});

/* ── Aplicar todos los filtros a las tarjetas ── */
function applyCardFilters() {
  const q = (document.getElementById('mainSearch').value || '').toLowerCase();
  let visible = 0;

  document.querySelectorAll('.member-card').forEach(card => {
    const matchArea  = !activeArea || card.dataset.area === activeArea;
    const matchTipo  = !activeTipo || card.dataset.tipo === activeTipo;
    const matchDisp  = !soloDisponibles || card.dataset.disponible === '1';
    const matchQ     = !q ||
      card.dataset.nombre.includes(q) ||
      (card.querySelector('.mc-cargo')?.textContent.toLowerCase() || '').includes(q) ||
      (card.querySelector('.mc-skills')?.textContent.toLowerCase() || '').includes(q);

    const show = matchArea && matchTipo && matchDisp && matchQ;
    card.style.display = show ? '' : 'none';
    if (show) visible++;
  });

  // Ocultar contenedores vacíos
  document.querySelectorAll('.area-container').forEach(c => {
    if (activeArea && c.dataset.area !== activeArea) { c.style.display = 'none'; return; }
    const anyVisible = [...c.querySelectorAll('.member-card')].some(cd => cd.style.display !== 'none');
    c.style.display = anyVisible ? '' : 'none';
  });

  document.getElementById('idxCount').textContent = visible + ' miembro' + (visible !== 1 ? 's' : '');
  document.getElementById('statTotal').textContent = visible;
}

/* ── Vista grid/list ── */
function setView(v, btn) {
  currentView = v;
  document.querySelectorAll('.vbtn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  document.querySelectorAll('.area-grid').forEach(g => {
    g.classList.toggle('list-view', v === 'list');
  });
}

/* ── Ordenar ── */
function sortMembers() {
  const by = document.getElementById('sortSel').value;
  document.querySelectorAll('.area-container').forEach(container => {
    const grid = container.querySelector('.area-grid');
    if (!grid) return;
    const cards = [...grid.querySelectorAll('.member-card')];
    cards.sort((a, b) => {
      if (by === 'nombre')       return a.dataset.nombre.localeCompare(b.dataset.nombre);
      if (by === 'calificacion') return parseFloat(b.dataset.calificacion) - parseFloat(a.dataset.calificacion);
      if (by === 'proyectos')    return parseInt(b.dataset.proyectos) - parseInt(a.dataset.proyectos);
      return 0;
    });
    cards.forEach(c => grid.appendChild(c));
  });
}

/* ── Colapsar/Expandir área ── */
function toggleCollapse(btn) {
  const container = btn.closest('.area-container');
  const grid = container.querySelector('.area-grid');
  const collapsed = grid.classList.toggle('collapsed');
  btn.querySelector('i').className = collapsed ? 'fa fa-chevron-down' : 'fa fa-chevron-up';
}

/* ── Modal contactar ── */
function openContactModal(uid, nombre) {
  document.getElementById('cmUid').value = uid;
  document.getElementById('cmNombre').textContent = nombre;
  document.getElementById('cmAsunto').value = '';
  document.getElementById('cmMensaje').value = '';
  document.getElementById('contactModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeContactModal() {
  document.getElementById('contactModal').classList.remove('open');
  document.body.style.overflow = '';
}

function sendMessage() {
  const uid     = document.getElementById('cmUid').value;
  const asunto  = document.getElementById('cmAsunto').value.trim();
  const mensaje = document.getElementById('cmMensaje').value.trim();
  if (!asunto || !mensaje) { alert('Por favor completa asunto y mensaje.'); return; }

  fetch('api/enviar_mensaje.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ destinatario_id: uid, asunto, mensaje })
  })
  .then(r => r.json())
  .then(d => {
    if (d.ok) { closeContactModal(); alert('✅ Mensaje enviado exitosamente.'); }
    else alert('Error al enviar: ' + (d.error || 'intenta de nuevo.'));
  })
  .catch(() => {
    closeContactModal();
    alert('✅ Mensaje enviado (modo demo).');
  });
}

/* ── Cerrar modales con Escape ── */
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeContactModal(); document.getElementById('memberModal').classList.remove('open'); document.body.style.overflow = ''; }
});
document.getElementById('contactModal').addEventListener('click', function (e) { if (e.target === this) closeContactModal(); });
document.getElementById('memberModal').addEventListener('click', function (e)  { if (e.target === this) { this.classList.remove('open'); document.body.style.overflow = ''; }});

/* ── Animación entrada escalonada ── */
document.querySelectorAll('.area-container').forEach((c, i) => {
  c.style.animationDelay = (i * 0.08) + 's';
});
</script>
</body>
</html>