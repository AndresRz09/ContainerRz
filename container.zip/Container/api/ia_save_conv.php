<?php

header('Content-Type: application/json; charset=utf-8');
session_start();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['ok' => false]);
    exit;
}

require_once __DIR__ . '/../../conexion.php';
require_once __DIR__ . '/../config.php';

$body    = json_decode(file_get_contents('php://input'), true) ?? [];
$userId  = (int)$_SESSION['user_id'];
$titulo  = mb_substr($body['titulo']  ?? 'Sin título', 0, 100);
$tool    = preg_replace('/[^a-z_]/', '', $body['tool']    ?? 'asistente');
$resumen = mb_substr($body['resumen'] ?? '', 0, 500);

// Contar cuántas tiene ya (limitar a MAX_SAVED_CONVS)
$countQ = $conexion->prepare("SELECT COUNT(*) FROM ia_conversaciones WHERE usuario_id = ?");
$countQ->bind_param("i", $userId);
$countQ->execute();
$countQ->bind_result($total);
$countQ->fetch();
$countQ->close();

if ($total >= MAX_SAVED_CONVS) {
    // Eliminar la más antigua
    $conexion->query(
        "DELETE FROM ia_conversaciones WHERE usuario_id = $userId
         ORDER BY fecha ASC LIMIT 1"
    );
}

$stmt = $conexion->prepare(
    "INSERT INTO ia_conversaciones (usuario_id, titulo, herramienta, resumen, fecha)
     VALUES (?, ?, ?, ?, NOW())"
);
$stmt->bind_param("isss", $userId, $titulo, $tool, $resumen);
$ok  = $stmt->execute();
$id  = $conexion->insert_id;
$stmt->close();

echo json_encode(['ok' => $ok, 'id' => $id]);
