<?php

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');

// ── Seguridad básica: solo POST desde el mismo origen ─────────────
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

// Verificar sesión (opcional: permite uso anónimo limitado)
session_start();
require_once __DIR__ . '/../config.php';

// ── Parsear body ──────────────────────────────────────────────────
$body = json_decode(file_get_contents('php://input'), true);
if (!$body) {
    http_response_code(400);
    echo json_encode(['error' => 'Cuerpo JSON inválido']);
    exit;
}

$agentId  = preg_replace('/[^a-z_]/', '', $body['agentId']  ?? 'asistente');
$messages = $body['messages'] ?? [];
$override = $body['provider'] ?? null; // el usuario puede forzar un proveedor

// ── Validar mensajes ──────────────────────────────────────────────
if (empty($messages) || !is_array($messages)) {
    http_response_code(400);
    echo json_encode(['error' => 'No hay mensajes']);
    exit;
}

// Limitar historial enviado a la API
$messages = array_slice($messages, -MAX_HISTORY_MSGS);

// ── Determinar proveedor ──────────────────────────────────────────
$providers = AGENT_PROVIDERS;
$provider  = $override ?? ($providers[$agentId] ?? 'claude');

// ── Prompts de sistema para cada agente ──────────────────────────
$SYSTEM_PROMPTS = [
    'asistente'   => 'Eres un asistente experto en tecnología y ciberseguridad de la plataforma ContainerRZ. Responde de forma clara, precisa y educativa en español.',
    'ciberseg'    => 'Eres un experto en ciberseguridad ofensiva y defensiva. Analiza vulnerabilidades, explica amenazas, hacking ético y buenas prácticas. Responde siempre en español.',
    'codigo'      => 'Eres un experto desarrollador. Genera código limpio, bien comentado y optimizado. Soportas PHP, Python, JS, SQL, Kotlin, Bash y más. Siempre explica tu solución en español.',
    'aprendizaje' => 'Eres un tutor pedagógico especializado en tecnología. Crea rutas de aprendizaje, explica paso a paso, genera ejercicios y evalúa el progreso. Responde en español.',
    'analisis'    => 'Eres un analista de datos experto. Interpreta datasets, encuentra patrones, genera insights accionables y sugiere visualizaciones. Responde en español.',
    'proyectos'   => 'Eres un experto en gestión de proyectos de software con metodologías ágiles (Scrum/Kanban). Planifica, define KPIs, estructura tareas. Responde en español.',
    'redaccion'   => 'Eres un experto en comunicación técnica. Redacta documentación, artículos técnicos, reportes ejecutivos y contenido educativo con claridad profesional en español.',
    'redes'       => 'Eres un experto en redes y administración de sistemas. Ayuda con servidores, diagnóstico de red, protocolos, VPNs y arquitecturas cloud. Responde en español.',
    'ia_explica'  => 'Eres un experto en IA y Machine Learning. Explica algoritmos, modelos, métricas y aplica conceptos de IA a problemas reales de forma comprensible en español.',
    'optimizador' => 'Eres un experto en optimización de rendimiento. Analiza cuellos de botella en código, bases de datos y arquitecturas. Propone mejoras concretas en español.',
];

$systemPrompt = $SYSTEM_PROMPTS[$agentId] ?? $SYSTEM_PROMPTS['asistente'];

// ── Enrutar al proveedor ──────────────────────────────────────────
try {
    switch ($provider) {
        case 'gemini':
            $result = callGemini($systemPrompt, $messages);
            break;
        case 'openai':
            $result = callOpenAI($systemPrompt, $messages);
            break;
        case 'claude':
        default:
            $result = callClaude($systemPrompt, $messages);
            break;
    }

    echo json_encode([
        'text'     => $result['text'],
        'provider' => $provider,
        'model'    => $result['model'],
        'tokens'   => $result['tokens'] ?? 0,
    ]);

} catch (Exception $e) {
    // Si el proveedor falla, intentar con Claude como fallback
    if ($provider !== 'claude') {
        try {
            $result = callClaude($systemPrompt, $messages);
            echo json_encode([
                'text'     => $result['text'],
                'provider' => 'claude (fallback)',
                'model'    => $result['model'],
                'tokens'   => $result['tokens'] ?? 0,
                'warning'  => "Fallback desde $provider: " . $e->getMessage(),
            ]);
        } catch (Exception $e2) {
            http_response_code(500);
            echo json_encode(['error' => 'Todos los proveedores fallaron: ' . $e2->getMessage()]);
        }
    } else {
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage()]);
    }
}


// ══════════════════════════════════════════════════════════════════
//  CLAUDE (Anthropic)
// ══════════════════════════════════════════════════════════════════
function callClaude(string $system, array $messages): array {
    $payload = [
        'model'      => CLAUDE_MODEL,
        'max_tokens' => MAX_TOKENS,
        'system'     => $system,
        'messages'   => $messages,
    ];

    $response = httpPost(
        'https://api.anthropic.com/v1/messages',
        $payload,
        [
            'x-api-key: '      . ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01',
        ]
    );

    $data = json_decode($response, true);

    if (isset($data['error'])) {
        throw new Exception('Claude: ' . ($data['error']['message'] ?? 'Error desconocido'));
    }

    $text = '';
    foreach (($data['content'] ?? []) as $block) {
        if ($block['type'] === 'text') $text .= $block['text'];
    }

    return [
        'text'   => trim($text) ?: 'Sin respuesta de Claude.',
        'model'  => $data['model'] ?? CLAUDE_MODEL,
        'tokens' => ($data['usage']['input_tokens'] ?? 0) + ($data['usage']['output_tokens'] ?? 0),
    ];
}


// ══════════════════════════════════════════════════════════════════
//  GEMINI (Google)
// ══════════════════════════════════════════════════════════════════
function callGemini(string $system, array $messages): array {
    // Gemini usa un formato distinto: systemInstruction + contents
    $contents = [];
    foreach ($messages as $m) {
        $contents[] = [
            'role'  => $m['role'] === 'assistant' ? 'model' : 'user',
            'parts' => [['text' => $m['content']]],
        ];
    }

    $payload = [
        'systemInstruction' => ['parts' => [['text' => $system]]],
        'contents'          => $contents,
        'generationConfig'  => [
            'maxOutputTokens' => MAX_TOKENS,
            'temperature'     => 0.7,
        ],
    ];

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/'
         . GEMINI_MODEL . ':generateContent?key=' . GEMINI_API_KEY;

    $response = httpPost($url, $payload);
    $data     = json_decode($response, true);

    if (isset($data['error'])) {
        throw new Exception('Gemini: ' . ($data['error']['message'] ?? 'Error'));
    }

    $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

    return [
        'text'   => trim($text) ?: 'Sin respuesta de Gemini.',
        'model'  => GEMINI_MODEL,
        'tokens' => $data['usageMetadata']['totalTokenCount'] ?? 0,
    ];
}


// ══════════════════════════════════════════════════════════════════
//  OPENAI (GPT)
// ══════════════════════════════════════════════════════════════════
function callOpenAI(string $system, array $messages): array {
    // OpenAI incluye el system como primer mensaje
    $openaiMessages = array_merge(
        [['role' => 'system', 'content' => $system]],
        $messages
    );

    $payload = [
        'model'      => OPENAI_MODEL,
        'messages'   => $openaiMessages,
        'max_tokens' => MAX_TOKENS,
        'temperature'=> 0.7,
    ];

    $response = httpPost(
        'https://api.openai.com/v1/chat/completions',
        $payload,
        ['Authorization: Bearer ' . OPENAI_API_KEY]
    );

    $data = json_decode($response, true);

    if (isset($data['error'])) {
        throw new Exception('OpenAI: ' . ($data['error']['message'] ?? 'Error'));
    }

    $text = $data['choices'][0]['message']['content'] ?? '';

    return [
        'text'   => trim($text) ?: 'Sin respuesta de OpenAI.',
        'model'  => $data['model'] ?? OPENAI_MODEL,
        'tokens' => $data['usage']['total_tokens'] ?? 0,
    ];
}


// ══════════════════════════════════════════════════════════════════
//  HELPER HTTP (cURL)
// ══════════════════════════════════════════════════════════════════
function httpPost(string $url, array $payload, array $extraHeaders = []): string {
    $ch = curl_init($url);

    $headers = array_merge(
        ['Content-Type: application/json'],
        $extraHeaders
    );

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    if ($curlErr) throw new Exception("cURL: $curlErr");
    if ($response === false) throw new Exception("Sin respuesta del servidor");

    return $response;
}
