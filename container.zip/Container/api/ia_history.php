<?php

header('Content-Type: application/json; charset=utf-8');
session_start();

if (empty($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

require_once __DIR__ . '/../../conexion.php';

$userId = (int)$_SESSION['user_id'];
$action = $_GET['action'] ?? $_POST['action'] ?? 'list';

switch ($action) {

    case 'list':
        $q = $conexion->prepare(
            "SELECT id, titulo, herramienta, resumen, fecha
             FROM ia_conversaciones
             WHERE usuario_id = ?
             ORDER BY fecha DESC LIMIT 20"
        );
        $q->bind_param("i", $userId);
        $q->execute();
        $result = $q->get_result();
        $rows   = [];
        while ($r = $result->fetch_assoc()) $rows[] = $r;
        $q->close();
        echo json_encode(['ok' => true, 'data' => $rows]);
        break;

    case 'delete':
        $id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
        if (!$id) { echo json_encode(['ok' => false]); break; }
        $q = $conexion->prepare(
            "DELETE FROM ia_conversaciones WHERE id = ? AND usuario_id = ?"
        );
        $q->bind_param("ii", $id, $userId);
        $ok = $q->execute();
        $q->close();
        echo json_encode(['ok' => $ok]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Acción desconocida']);
}
