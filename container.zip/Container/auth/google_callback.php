<?php
session_start();

require_once dirname(__DIR__) . '/config/google_oauth.php';
require_once dirname(__DIR__) . '/conexion.php';

// ── Helpers ──────────────────────────────────────────────────
function oauthError(string $msg, string $redirect = '../login.php'): void {
    $_SESSION['oauth_error'] = $msg;
    header('Location: ' . $redirect);
    exit();
}

function httpPost(string $url, array $data): ?array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($data),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($err || !$resp) return null;
    return json_decode($resp, true);
}

function httpGet(string $url, string $token): ?array {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resp = curl_exec($ch);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($err || !$resp) return null;
    return json_decode($resp, true);
}

// ── 1. Verificar errores de Google ───────────────────────────
if (isset($_GET['error'])) {
    $googleError = htmlspecialchars($_GET['error']);
    oauthError("Google rechazó el acceso: {$googleError}");
}

// ── 2. Validar parámetros obligatorios ───────────────────────
if (empty($_GET['code']) || empty($_GET['state'])) {
    oauthError('Parámetros de OAuth incompletos.');
}

// ── 3. Validar state (anti-CSRF) ─────────────────────────────
if (
    !isset($_SESSION['google_oauth_state']) ||
    !hash_equals($_SESSION['google_oauth_state'], $_GET['state'])
) {
    unset($_SESSION['google_oauth_state']);
    oauthError('Estado OAuth inválido. Posible ataque CSRF.');
}
unset($_SESSION['google_oauth_state']);

// ── 4. Intercambiar code por access_token ────────────────────
$tokenData = httpPost(GOOGLE_TOKEN_URL, [
    'code'          => $_GET['code'],
    'client_id'     => GOOGLE_CLIENT_ID,
    'client_secret' => GOOGLE_CLIENT_SECRET,
    'redirect_uri'  => GOOGLE_REDIRECT_URI,
    'grant_type'    => 'authorization_code',
]);

if (!$tokenData || empty($tokenData['access_token'])) {
    oauthError('No se pudo obtener el token de acceso de Google.');
}

$accessToken = $tokenData['access_token'];

// ── 5. Obtener datos del usuario de Google ───────────────────
$googleUser = httpGet(GOOGLE_USER_URL, $accessToken);

if (!$googleUser || empty($googleUser['email'])) {
    oauthError('No se pudieron obtener los datos del usuario de Google.');
}

// Extraer campos de Google
$googleId    = $googleUser['sub']            ?? '';
$email       = strtolower(trim($googleUser['email']     ?? ''));
$nombre      = $googleUser['given_name']     ?? '';
$apellido    = $googleUser['family_name']    ?? '';
$avatar      = $googleUser['picture']        ?? '';
$verificado  = ($googleUser['email_verified'] ?? false) ? 1 : 0;
$nombreFull  = trim($nombre . ' ' . $apellido) ?: $email;

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    oauthError('El email recibido de Google no es válido.');
}

// ── 6. Buscar si ya existe la cuenta por correo ──────────────
$stmt = $conexion->prepare(
    "SELECT us.*, u.nombre, u.apellido, u.rol, u.avatar, u.activo, u.id AS uid
     FROM usuarios_seguridad us
     INNER JOIN usuarios u ON us.usuario_id = u.id
     WHERE us.correo = ?
     LIMIT 1"
);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

$usuario = $result ? $result->fetch_assoc() : null;

// ── 7a. Usuario existente — iniciar sesión ───────────────────
if ($usuario) {

    if (!$usuario['activo']) {
        oauthError('Tu cuenta está desactivada. Contacta al soporte.');
    }

    // Actualizar avatar desde Google si no tiene uno propio
    if (!empty($avatar) && strpos($usuario['avatar'] ?? '', 'avatar-default') !== false) {
        $upd = $conexion->prepare("UPDATE usuarios SET avatar = ? WHERE id = ?");
        $upd->bind_param("si", $avatar, $usuario['uid']);
        $upd->execute();
        $upd->close();
        $usuario['avatar'] = $avatar;
    }

    // Registrar último acceso
    $upd2 = $conexion->prepare("UPDATE usuarios SET ultimo_acceso = NOW() WHERE id = ?");
    $upd2->bind_param("i", $usuario['uid']);
    $upd2->execute();
    $upd2->close();

    $userId  = $usuario['uid'];
    $userRol = $usuario['rol'];
    $userAvatar = $usuario['avatar'] ?: 'assets/avatar-default.png';
    $userNombre = $usuario['nombre'];

} else {
    // ── 7b. Usuario nuevo — crear cuenta automáticamente ────────
    // Generar username único
    $baseUsername = preg_replace('/[^a-z0-9]/', '', strtolower($nombre . $apellido));
    $baseUsername = $baseUsername ?: 'user' . rand(1000, 9999);

    $username = $baseUsername;
    $sufijo   = 1;
    while (true) {
        $chk = $conexion->prepare("SELECT id FROM usuarios WHERE username = ? LIMIT 1");
        $chk->bind_param("s", $username);
        $chk->execute();
        $chk->get_result()->num_rows === 0
            ? ($chk->close() && true)
            : ($chk->close() && ($username = $baseUsername . $sufijo++) && false);
        if ($conexion->prepare("SELECT id FROM usuarios WHERE username = ? LIMIT 1")->bind_param("s", $username)) break;
        // Reintento simple
        $ck2 = $conexion->prepare("SELECT id FROM usuarios WHERE username = ? LIMIT 1");
        $ck2->bind_param("s", $username);
        $ck2->execute();
        if ($ck2->get_result()->num_rows === 0) { $ck2->close(); break; }
        $ck2->close();
        $username = $baseUsername . (++$sufijo);
    }

    // Fecha de nacimiento por defecto (requerida por la tabla)
    $fechaNac = '2000-01-01';
    $fechaExp = '2020-01-01';

    $conexion->begin_transaction();
    try {
        // Insertar en usuarios
        $ins = $conexion->prepare(
            "INSERT INTO usuarios
                (nombre, apellido, username, tipo_documento, identificacion,
                 fecha_nacimiento, fecha_expedicion, avatar, verificado, activo, rol,
                 tipo_usuario, fecha_registro)
             VALUES (?, ?, ?, 'CC', ?, ?, ?, ?, ?, 1, 'cliente', 'cliente', NOW())"
        );
        $idDoc = 'GOOGLE_' . $googleId;
        $ins->bind_param(
            "ssssssi",
            $nombre, $apellido, $username, $idDoc,
            $fechaNac, $fechaExp,
            $avatar, $verificado
        );
        $ins->execute();
        $userId = $conexion->insert_id;
        $ins->close();

        // Insertar en usuarios_seguridad (sin contraseña — login solo por Google)
        $pwHash = password_hash(bin2hex(random_bytes(32)), PASSWORD_BCRYPT, ['cost' => 12]);
        $ins2 = $conexion->prepare(
            "INSERT INTO usuarios_seguridad
                (usuario_id, correo, identificacion, password_hash, fecha_cambio_pass)
             VALUES (?, ?, ?, ?, NOW())"
        );
        $ins2->bind_param("isss", $userId, $email, $idDoc, $pwHash);
        $ins2->execute();
        $ins2->close();

        // Crear registro CRM
        $ins3 = $conexion->prepare("INSERT INTO usuario_crm (usuario_id) VALUES (?)");
        $ins3->bind_param("i", $userId);
        $ins3->execute();
        $ins3->close();

        // Sumar puntos de bienvenida
        $ins4 = $conexion->prepare(
            "INSERT INTO puntos_usuario (usuario_id, puntos, motivo) VALUES (?, 50, 'Registro con Google OAuth')"
        );
        $ins4->bind_param("i", $userId);
        $ins4->execute();
        $ins4->close();

        $conexion->commit();

        $userRol    = 'cliente';
        $userAvatar = $avatar ?: 'assets/avatar-default.png';
        $userNombre = $nombre;

    } catch (Exception $e) {
        $conexion->rollback();
        oauthError('Error al crear la cuenta: ' . $e->getMessage());
    }
}

// ── 8. Obtener novedades para el intro ───────────────────────
$novedades = [];
$qn = $conexion->prepare("SELECT titulo, descripcion FROM novedades ORDER BY fecha DESC LIMIT 4");
if ($qn) {
    $qn->execute();
    $rn = $qn->get_result();
    while ($nov = $rn->fetch_assoc()) $novedades[] = $nov;
    $qn->close();
}

// ── 9. Crear sesión ──────────────────────────────────────────
session_regenerate_id(true);
$_SESSION['user_id']    = $userId;
$_SESSION['user_name']  = $nombreFull;
$_SESSION['rol']        = $userRol;
$_SESSION['avatar']     = $userAvatar;
$_SESSION['correo']     = $email;
$_SESSION['show_intro'] = true;
$_SESSION['novedades']  = $novedades;
$_SESSION['login_via']  = 'google';

// ── 10. Redirección según rol con intro ──────────────────────
$redirect = match($userRol) {
    'superadmin' => '../superadmin/index.php',
    'admin'      => '../admin/index.php',
    'empleado'   => '../empleado/index.php',
    default      => '../index.php',
};

$redirectFinal = $_SESSION['oauth_redirect_after'] ?? $redirect;
unset($_SESSION['oauth_redirect_after']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Bienvenido — Team VIROX</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{--gold:#DAA520;--green:#28A680;--green-lt:#35d4a8;--n900:#020817;--n800:#0c1526;--txt:#f0f4f8;--muted:#8da0b8;--font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;}
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);height:100vh;overflow:hidden;display:flex;align-items:center;justify-content:center;}
    .intro-bg{position:fixed;inset:0;}
    .ibg-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:56px 56px;}
    .iorb{position:absolute;border-radius:50%;filter:blur(100px);}
    .iorb1{width:600px;height:600px;background:radial-gradient(circle,rgba(40,166,128,.15),transparent 70%);top:-150px;left:-150px;animation:iorf 10s ease-in-out infinite;}
    .iorb2{width:500px;height:500px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-100px;right:-100px;animation:iorf 13s ease-in-out infinite reverse;}
    @keyframes iorf{0%,100%{transform:translate(0,0)}50%{transform:translate(30px,-30px)}}

    /* Lock screen */
    .lock-screen{position:fixed;inset:0;z-index:10;display:flex;flex-direction:column;align-items:center;justify-content:center;background:rgba(2,8,23,.95);backdrop-filter:blur(20px);animation:lockIn .8s ease both;}
    @keyframes lockIn{from{opacity:0}to{opacity:1}}
    .lock-time{font-family:var(--font-d);font-size:5rem;font-weight:900;color:var(--txt);letter-spacing:4px;line-height:1;margin-bottom:8px;text-shadow:0 0 40px rgba(40,166,128,.3);}
    .lock-date{font-size:1rem;color:var(--muted);letter-spacing:2px;margin-bottom:48px;}
    .lock-av-wrap{position:relative;width:100px;height:100px;margin-bottom:16px;cursor:pointer;}
    .lock-av{width:100%;height:100%;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 30px rgba(40,166,128,.4);}
    .lock-ring{position:absolute;inset:-6px;border-radius:50%;border:1px dashed rgba(40,166,128,.4);animation:lspin 8s linear infinite;}
    @keyframes lspin{to{transform:rotate(360deg)}}
    /* Badge Google */
    .lock-google-badge{position:absolute;bottom:-4px;right:-4px;width:28px;height:28px;background:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid var(--n900);}
    .lock-google-badge img{width:18px;}
    .lock-name{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .lock-role{font-size:.78rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;margin-bottom:8px;}
    .lock-via{font-size:.72rem;color:var(--muted);margin-bottom:24px;display:flex;align-items:center;gap:6px;}
    .lock-via img{width:14px;}
    .lock-hint{font-size:.82rem;color:var(--muted);animation:pulse 2s ease-in-out infinite;}
    @keyframes pulse{0%,100%{opacity:.5}50%{opacity:1}}

    /* Intro screen */
    .intro-screen{position:fixed;inset:0;z-index:20;background:var(--n900);display:none;flex-direction:column;align-items:center;justify-content:center;padding:48px 24px;}
    .intro-screen.show{display:flex;}
    @keyframes introEl{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}
    .intro-logo{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);letter-spacing:4px;margin-bottom:40px;opacity:0;animation:introEl .6s ease .2s both;}
    .intro-av{width:110px;height:110px;border-radius:50%;object-fit:cover;border:4px solid var(--green);box-shadow:0 0 40px rgba(40,166,128,.5);margin-bottom:20px;opacity:0;animation:introEl .6s ease .4s both;}
    .intro-welcome{font-family:var(--font-d);font-size:1.4rem;font-weight:700;color:var(--txt);margin-bottom:6px;opacity:0;animation:introEl .6s ease .6s both;}
    .intro-name{font-family:var(--font-d);font-size:2.1rem;font-weight:900;color:var(--gold);margin-bottom:6px;opacity:0;animation:introEl .6s ease .7s both;text-shadow:0 0 24px rgba(218,165,32,.5);}
    .intro-role{font-size:.85rem;color:var(--green-lt);letter-spacing:3px;text-transform:uppercase;margin-bottom:6px;opacity:0;animation:introEl .6s ease .85s both;}
    .intro-google{font-size:.75rem;color:var(--muted);display:flex;align-items:center;gap:6px;margin-bottom:48px;opacity:0;animation:introEl .6s ease .95s both;}
    .intro-google img{width:14px;}

    .intro-news{width:100%;max-width:680px;opacity:0;animation:introEl .6s ease 1s both;}
    .intro-news-title{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;text-align:center;}
    .news-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;}
    .news-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:14px;text-align:center;animation:introEl .5s ease both;}
    .news-card:nth-child(1){animation-delay:1.1s} .news-card:nth-child(2){animation-delay:1.2s}
    .news-card:nth-child(3){animation-delay:1.3s} .news-card:nth-child(4){animation-delay:1.4s}
    .news-card-ico{font-size:1.5rem;margin-bottom:6px;}
    .news-card-ttl{font-size:.75rem;font-weight:700;color:var(--txt);line-height:1.3;}

    .intro-loader{position:fixed;bottom:0;left:0;right:0;height:3px;background:rgba(255,255,255,.06);z-index:30;}
    .intro-loader-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));width:0%;transition:width 3.5s ease;box-shadow:0 0 10px var(--green);}
    .intro-skip{position:fixed;bottom:24px;right:24px;z-index:30;padding:8px 18px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.78rem;color:var(--muted);cursor:pointer;transition:all .2s;font-family:var(--font-b);}
    .intro-skip:hover{background:rgba(255,255,255,.12);color:var(--txt);}
  </style>
</head>
<body>
  <div class="intro-bg">
    <div class="ibg-grid"></div>
    <div class="iorb iorb1"></div>
    <div class="iorb iorb2"></div>
  </div>

  <!-- Lock screen con badge de Google -->
  <div class="lock-screen" id="lockScreen">
    <div class="lock-time" id="lockTime">--:--</div>
    <div class="lock-date" id="lockDate">--</div>
    <div class="lock-av-wrap" onclick="unlockScreen()">
      <img src="<?= htmlspecialchars($userAvatar) ?>" class="lock-av" alt="Avatar"
           onerror="this.src='../assets/avatar-default.png'">
      <div class="lock-ring"></div>
      <div class="lock-google-badge">
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="G">
      </div>
    </div>
    <div class="lock-name"><?= htmlspecialchars($userNombre) ?></div>
    <div class="lock-role"><?= htmlspecialchars(ucfirst($userRol)) ?></div>
    <div class="lock-via">
      <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google">
      Autenticado con Google
    </div>
    <div class="lock-hint"><i class="fa fa-hand-pointer"></i> Haz clic para ingresar</div>
  </div>

  <!-- Intro screen -->
  <div class="intro-screen" id="introScreen">
    <div class="intro-logo">⬡ VIROX</div>
    <img src="<?= htmlspecialchars($userAvatar) ?>" class="intro-av" alt="Avatar"
         onerror="this.src='../assets/avatar-default.png'">
    <div class="intro-welcome">Bienvenido<?= $usuario ? ' de nuevo' : '' ?>,</div>
    <div class="intro-name"><?= htmlspecialchars($userNombre) ?></div>
    <div class="intro-role"><?= htmlspecialchars(ucfirst($userRol)) ?> — Team VIROX</div>
    <div class="intro-google">
      <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="G">
      Sesión iniciada con Google · <?= htmlspecialchars($email) ?>
    </div>

    <?php if (!empty($novedades)): ?>
    <div class="intro-news">
      <div class="intro-news-title">📌 Novedades para ti</div>
      <div class="news-cards">
        <?php foreach ($novedades as $nov): ?>
        <div class="news-card">
          <div class="news-card-ico">🔔</div>
          <div class="news-card-ttl"><?= htmlspecialchars($nov['titulo']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="intro-loader"><div class="intro-loader-fill" id="loaderFill"></div></div>
  <button class="intro-skip" onclick="goRedirect()">Omitir →</button>

  <script>
    const REDIRECT = "<?= htmlspecialchars($redirectFinal) ?>";

    // Reloj
    function updateClock() {
      const now = new Date();
      const h = String(now.getHours()).padStart(2,'0');
      const m = String(now.getMinutes()).padStart(2,'0');
      document.getElementById('lockTime').textContent = h + ':' + m;
      const days   = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
      const months = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
      document.getElementById('lockDate').textContent =
        days[now.getDay()] + ', ' + now.getDate() + ' de ' + months[now.getMonth()];
    }
    updateClock();
    setInterval(updateClock, 1000);

    function unlockScreen() {
      const lock = document.getElementById('lockScreen');
      lock.style.transition = 'opacity .5s, transform .5s';
      lock.style.opacity    = '0';
      lock.style.transform  = 'scale(1.05)';
      setTimeout(() => { lock.style.display = 'none'; showIntro(); }, 500);
    }

    function showIntro() {
      document.getElementById('introScreen').classList.add('show');
      setTimeout(() => { document.getElementById('loaderFill').style.width = '100%'; }, 100);
      setTimeout(goRedirect, 3800);
    }

    function goRedirect() {
      window.location.href = REDIRECT;
    }
  </script>
</body>
</html>
<?php exit(); ?>