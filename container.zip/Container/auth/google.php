<?php

session_start();

require_once dirname(__DIR__) . '/config/google_oauth.php';

// Verificar que las keys estén configuradas
if (
    GOOGLE_CLIENT_ID     === 'TU_CLIENT_ID_AQUI.apps.googleusercontent.com' ||
    GOOGLE_CLIENT_SECRET === 'TU_CLIENT_SECRET_AQUI'
) {
    die('<p style="font-family:sans-serif;color:red;padding:40px;">
        ⚠️ <strong>Google OAuth no configurado.</strong><br>
        Edita <code>config/google_oauth.php</code> con tus credenciales de Google Console.
    </p>');
}


$state = bin2hex(random_bytes(16));
$_SESSION['google_oauth_state'] = $state;


$_SESSION['oauth_redirect_after'] = $_GET['next'] ?? 'index.php';

// Construir la URL de autorización de Google
$params = http_build_query([
    'client_id'     => GOOGLE_CLIENT_ID,
    'redirect_uri'  => GOOGLE_REDIRECT_URI,
    'response_type' => 'code',
    'scope'         => GOOGLE_SCOPES,
    'access_type'   => 'online',
    'state'         => $state,
    'prompt'        => 'select_account',  // Siempre muestra el selector de cuenta
]);

header('Location: ' . GOOGLE_AUTH_URL . '?' . $params);
exit();