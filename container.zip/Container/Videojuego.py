import turtle
import time
import random

# Configuración de la ventana
ventana = turtle.Screen()
ventana.title("Juego de Snake")
ventana.bgcolor("black")
ventana.setup(width=600, height=600)
ventana.tracer(0) # Apaga las animaciones automáticas

# Cabeza de la serpiente
cabeza = turtle.Turtle()
cabeza.speed(0)
cabeza.shape("square")
cabeza.color("green")
cabeza.penup()
cabeza.goto(0, 0)
cabeza.direction = "stop"

# Comida de la serpiente
comida = turtle.Turtle()
comida.speed(0)
comida.shape("circle")
comida.color("red")
comida.penup()
comida.goto(0, 100)

# Segmentos del cuerpo de la serpiente
cuerpo = []

# Funciones de movimiento
def arriba():
    if cabeza.direction != "down":
        cabeza.direction = "up"

def abajo():
    if cabeza.direction != "up":
        cabeza.direction = "down"

def izquierda():
    if cabeza.direction != "right":
        cabeza.direction = "left"

def derecha():
    if cabeza.direction != "left":
        cabeza.direction = "right"

def mover():
    if cabeza.direction == "up":
        y = cabeza.ycor()
        cabeza.sety(y + 20)
    if cabeza.direction == "down":
        y = cabeza.ycor()
        cabeza.sety(y - 20)
    if cabeza.direction == "left":
        x = cabeza.xcor()
        cabeza.setx(x - 20)
    if cabeza.direction == "right":
        x = cabeza.xcor()
        cabeza.setx(x + 20)

# Teclado
ventana.listen()
ventana.onkeypress(arriba, "Up")
ventana.onkeypress(abajo, "Down")
ventana.onkeypress(izquierda, "Left")
ventana.onkeypress(derecha, "Right")

# Bucle principal del juego
while True:
    ventana.update()

    # Colisión con los bordes de la pantalla
    if cabeza.xcor() > 280 or cabeza.xcor() < -280 or cabeza.ycor() > 280 or cabeza.ycor() < -280:
        time.sleep(1)
        cabeza.goto(0, 0)
        cabeza.direction = "stop"
        
        # Esconder el cuerpo al reiniciar
        for segmento in cuerpo:
            segmento.goto(1000, 1000)
        cuerpo.clear()

    # Colisión con la comida
    if cabeza.distance(comida) < 20:
        # Mover la comida a una posición aleatoria
        x = random.randint(-280, 280)
        y = random.randint(-280, 280)
        comida.goto(x, y)

        # Añadir un nuevo segmento al cuerpo
        nuevo_segmento = turtle.Turtle()
        nuevo_segmento.speed(0)
        nuevo_segmento.shape("square")
        nuevo_segmento.color("lightgreen")
        nuevo_segmento.penup()
        cuerpo.append(nuevo_segmento)

    # Mover el cuerpo de la serpiente en orden inverso
    total_segmentos = len(cuerpo)
    for i in range(total_segmentos - 1, 0, -1):
        x = cuerpo[i - 1].xcor()
        y = cuerpo[i - 1].ycor()
        cuerpo[i].goto(x, y)

    # Mover el primer segmento al lugar de la cabeza
    if total_segmentos > 0:
        x = cabeza.xcor()
        y = cabeza.ycor()
        cuerpo[0].goto(x, y)

    mover()

    # Colisión con el propio cuerpo
    for segmento in cuerpo:
        if segmento.distance(cabeza) < 20:
            time.sleep(1)
            cabeza.goto(0, 0)
            cabeza.direction = "stop"
            
            # Esconder el cuerpo al reiniciar
            for seg in cuerpo:
                seg.goto(1000, 1000)
            cuerpo.clear()

    time.sleep(0.1) # Controla la velocidad del juego
