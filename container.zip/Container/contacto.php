<?php
include 'conexion.php';
session_start();

$usuario_nombre = $_SESSION['user_name'] ?? '';
$usuario_correo = $_SESSION['correo']    ?? '';
$usuario_id     = $_SESSION['user_id']   ?? 0;

$success = '';
$error   = '';

$cfg = [];
if (isset($conexion)) {
    $qc = $conexion->query(
        "SELECT clave, valor FROM configuracion
         WHERE clave IN ('email','telefono','whatsapp','web','ubicacion',
                         'direccion','lat','lng','horario','instagram',
                         'facebook','twitter','linkedin','youtube')"
    );
    if ($qc) while ($row = $qc->fetch_assoc()) $cfg[$row['clave']] = $row['valor'];
}

// Valores por defecto
$cfg += [
    'email'     => 'contacto@teamvirox.com',
    'telefono'  => '+57 300 000 0000',
    'whatsapp'  => '573000000000',
    'web'       => 'www.teamvirox.com',
    'ubicacion' => 'Colombia',
    'direccion' => 'Bogotá, Colombia',
    'lat'       => '4.6097',
    'lng'       => '-74.0817',
    'horario'   => 'Lun – Vie: 8:00 AM – 6:00 PM',
    'instagram' => '',
    'facebook'  => '',
    'twitter'   => '',
    'linkedin'  => '',
    'youtube'   => '',
];

// ── PROCESAR FORMULARIO DE CONTACTO ─────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tipo_form'])) {

    $tipo   = $_POST['tipo_form'];
    $nombre = htmlspecialchars(trim($_POST['nombre']  ?? ''), ENT_QUOTES);
    $correo = filter_var(trim($_POST['correo'] ?? ''), FILTER_SANITIZE_EMAIL);
    $asunto = htmlspecialchars(trim($_POST['asunto']  ?? ''), ENT_QUOTES);
    $msg    = htmlspecialchars(trim($_POST['mensaje'] ?? ''), ENT_QUOTES);
    $pais   = htmlspecialchars(trim($_POST['pais']    ?? ''), ENT_QUOTES);
    $lat_u  = (float)($_POST['lat_user'] ?? 0);
    $lng_u  = (float)($_POST['lng_user'] ?? 0);
    $idioma = htmlspecialchars(trim($_POST['idioma']  ?? 'es'), ENT_QUOTES);

    // PQRS specific
    $categoria_pqrs = $_POST['categoria_pqrs'] ?? 'consulta';
    $estrellas      = (int)($_POST['estrellas']      ?? 0);
    $prioridad      = $_POST['prioridad']      ?? 'normal';

    $errores = [];
    if (empty($nombre))  $errores[] = "El nombre es obligatorio.";
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "Correo no válido.";
    if (empty($msg))     $errores[] = "El mensaje no puede estar vacío.";

    if (empty($errores) && isset($conexion)) {
        if ($tipo === 'contacto') {
            $stmt = $conexion->prepare(
                "INSERT INTO contacto_mensajes
                 (nombre, correo, asunto, mensaje, pais, lat, lng, idioma, fecha)
                 VALUES (?,?,?,?,?,?,?,?,NOW())"
            );
            if ($stmt) {
                $stmt->bind_param("sssssdds", $nombre, $correo, $asunto, $msg, $pais, $lat_u, $lng_u, $idioma);
                if ($stmt->execute()) $success = "¡Mensaje enviado! Te responderemos pronto.";
                else $errores[] = "Error al enviar. Intenta de nuevo.";
                $stmt->close();
            }
        } elseif ($tipo === 'pqrs') {
            $folio = 'PQRS-' . strtoupper(substr(md5(uniqid()), 0, 8));
            $stmt  = $conexion->prepare(
                "INSERT INTO pqrs
                 (folio, usuario_id, nombre, correo, categoria, asunto, descripcion,
                  estrellas, prioridad, estado, pais, lat, lng, idioma, fecha)
                 VALUES (?,?,?,?,?,?,?,?,?,'abierto',?,?,?,?,NOW())"
            );
            if ($stmt) {
                $stmt->bind_param(
                    "sisssssissdds",
                    $folio, $usuario_id, $nombre, $correo,
                    $categoria_pqrs, $asunto, $msg,
                    $estrellas, $prioridad,
                    $pais, $lat_u, $lng_u, $idioma
                );
                if ($stmt->execute()) $success = "PQRS registrada con folio: <strong>{$folio}</strong>. Recibirás respuesta en tu correo.";
                else $errores[] = "Error al registrar la PQRS.";
                $stmt->close();
            }
        }
    }

    if (!empty($errores)) $error = implode('|', $errores);
}

// ── Categorías PQRS ─────────────────────────────────────────────────
$categorias_pqrs = [
    'peticion'   => ['📋', 'Petición',    'Solicitud de información o servicio'],
    'queja'      => ['😤', 'Queja',       'Inconformidad con un producto o servicio'],
    'reclamo'    => ['⚠️', 'Reclamo',     'Derecho que consideras vulnerado'],
    'sugerencia' => ['💡', 'Sugerencia',  'Propuesta de mejora para VIROX'],
    'consulta'   => ['❓', 'Consulta',    'Pregunta o inquietud general'],
    'denuncia'   => ['🚨', 'Denuncia',    'Reporte de irregularidades o faltas'],
    'felicitacion'=> ['⭐', 'Felicitación','Reconocimiento por buen servicio'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Contacto — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- Leaflet.js para mapa SIG -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
  <style>

    :root {
      --n900:#020817; --n800:#0c1526; --n700:#111827; --n600:#182035;
      --n500:#1e2d47; --n400:#243450;
      --gold:#DAA520; --gold-lt:#f0c840; --gold-dim:rgba(218,165,32,.14);
      --green:#28A680; --green-lt:#35d4a8; --green-dim:rgba(40,166,128,.14);
      --red:#ef4444; --red-dim:rgba(239,68,68,.12);
      --blue:#3b82f6; --blue-dim:rgba(59,130,246,.12);
      --txt:#f0f4f8; --muted:#8da0b8; --dim:#526278;
      --sh-sm:0 4px 18px rgba(0,0,0,.35);
      --sh-md:0 10px 36px rgba(0,0,0,.5);
      --sh-lg:0 24px 64px rgba(0,0,0,.6);
      --r-sm:8px; --r-md:14px; --r-lg:22px; --r-xl:32px;
      --font:'Syne',sans-serif;
      --hh:68px;
    }

    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;scroll-padding-top:calc(var(--hh)+20px);}
    body{font-family:var(--font);background:var(--n900);color:var(--txt);overflow-x:hidden;}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);} ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;}
    button{cursor:pointer;border:none;font-family:var(--font);}

    /* ══ HEADER ══════════════════════════════════════════════════ */
    .site-header{
      position:sticky;top:0;z-index:1000;height:var(--hh);
      background:rgba(2,8,23,.9);backdrop-filter:blur(18px);
      border-bottom:1px solid rgba(40,166,128,.2);
      transition:box-shadow .3s,border-color .3s;
    }
    .site-header.hdr-on{box-shadow:0 4px 40px rgba(0,0,0,.65);border-bottom-color:rgba(218,165,32,.25);}
    .header-inner{max-width:1480px;margin:auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 28px;}
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-hex{font-size:1.5rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green));}
    .brand-name{font-size:1.45rem;font-weight:900;color:var(--gold);letter-spacing:4px;text-shadow:0 0 18px rgba(218,165,32,.5);}
    .main-nav{display:flex;align-items:center;gap:4px;}
    .nav-link{padding:8px 15px;border-radius:var(--r-sm);font-weight:600;font-size:.9rem;color:var(--muted);letter-spacing:.4px;transition:all .2s;}
    .nav-link:hover,.nav-link.active{color:var(--txt);background:rgba(255,255,255,.06);}
    .nav-link.active{color:var(--green-lt);border-bottom:2px solid var(--green);}
    .nav-cta{margin-left:12px;padding:9px 20px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.88rem;transition:all .2s;}
    .nav-cta:hover{background:var(--gold);transform:translateY(-2px);}
    .user-wrap{position:relative;margin-left:12px;}
    .user-pill{display:flex;align-items:center;gap:8px;padding:8px 16px;background:var(--green-dim);border:1px solid var(--green);border-radius:99px;color:var(--txt);font-weight:600;font-size:.88rem;transition:background .2s;}
    .user-pill:hover{background:rgba(40,166,128,.25);}
    .user-av{width:26px;height:26px;background:var(--n500);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;}
    .user-drop{display:none;position:absolute;right:0;top:calc(100% + 10px);background:var(--n600);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-md);min-width:200px;overflow:hidden;box-shadow:var(--sh-md);z-index:200;}
    .user-wrap:hover .user-drop{display:block;}
    .user-drop a{display:flex;align-items:center;gap:10px;padding:12px 16px;font-size:.88rem;color:var(--txt);transition:background .2s;}
    .user-drop a:hover{background:rgba(255,255,255,.06);}
    .drop-danger{color:#f87171 !important;}
    .burger{display:none;flex-direction:column;gap:5px;padding:8px;background:none;}
    .burger span{display:block;width:24px;height:2px;background:var(--txt);border-radius:99px;transition:transform .3s,opacity .3s;}
    .burger-x span:nth-child(1){transform:translateY(7px) rotate(45deg);}
    .burger-x span:nth-child(2){opacity:0;}
    .burger-x span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}

    /* ══ HERO ════════════════════════════════════════════════════ */
    .ct-hero{
      position:relative;padding:60px 28px 48px;text-align:center;
      background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,var(--n900) 70%);
      border-bottom:1px solid rgba(40,166,128,.15);overflow:hidden;
    }
    .ct-hero-grid{
      position:absolute;inset:0;
      background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),
                       linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);
      background-size:52px 52px;
    }
    .ct-orb{position:absolute;border-radius:50%;filter:blur(90px);}
    .co1{width:450px;height:450px;background:radial-gradient(circle,rgba(40,166,128,.15),transparent 70%);top:-120px;left:-80px;animation:orbf 9s ease-in-out infinite;}
    .co2{width:350px;height:350px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-60px;right:-40px;animation:orbf 11s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}
    .ct-hero-content{position:relative;z-index:1;max-width:680px;margin:auto;}
    .ct-hero-tag{display:inline-block;padding:4px 14px;background:var(--green-dim);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.75rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:16px;}
    .ct-hero h1{font-size:clamp(1.8rem,3.5vw,3.2rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:10px;}
    .ct-hero h1 span{color:var(--gold);text-shadow:0 0 28px rgba(218,165,32,.4);}
    .ct-hero p{font-size:.95rem;color:var(--muted);line-height:1.7;}

    /* Tabs de navegación interna */
    .ct-tabs{
      display:flex;justify-content:center;gap:6px;
      padding:24px 28px 0;max-width:1480px;margin:0 auto;
    }
    .ct-tab{
      display:flex;align-items:center;gap:8px;
      padding:10px 22px;border-radius:var(--r-md);
      font-size:.88rem;font-weight:700;color:var(--muted);
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);
      cursor:pointer;transition:all .25s;
    }
    .ct-tab:hover{background:rgba(255,255,255,.08);color:var(--txt);}
    .ct-tab.on{background:var(--green-dim);border-color:rgba(40,166,128,.4);color:var(--green-lt);}
    .ct-tab.pqrs-tab.on{background:var(--gold-dim);border-color:rgba(218,165,32,.4);color:var(--gold-lt);}

    /* ══ LAYOUT PRINCIPAL ════════════════════════════════════════ */
    .ct-layout{max-width:1480px;margin:0 auto;padding:40px 28px;display:flex;flex-direction:column;gap:48px;}

    /* Secciones */
    .ct-section{display:none;animation:secIn .4s ease both;}
    .ct-section.on{display:block;}
    @keyframes secIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}

    /* ══ SECCIÓN MAPA SIG ════════════════════════════════════════ */
    .map-section{display:grid;grid-template-columns:1fr 340px;gap:24px;align-items:start;}

    /* Mapa Leaflet */
    .map-container{
      background:var(--n800);border:1px solid rgba(40,166,128,.2);
      border-radius:var(--r-xl);overflow:hidden;
      box-shadow:var(--sh-md);position:relative;
    }
    .map-hd{
      display:flex;align-items:center;justify-content:space-between;
      padding:14px 20px;border-bottom:1px solid rgba(255,255,255,.06);
      background:linear-gradient(to right,rgba(40,166,128,.06),transparent);
    }
    .map-hd-left{display:flex;align-items:center;gap:10px;}
    .map-hd-ico{font-size:1.1rem;}
    .map-hd-title{font-size:.9rem;font-weight:700;color:var(--txt);}
    .map-hd-sub{font-size:.72rem;color:var(--muted);}
    .map-detect-btn{
      display:flex;align-items:center;gap:6px;
      padding:7px 14px;background:var(--green);color:#fff;
      border-radius:var(--r-md);font-size:.78rem;font-weight:700;
      transition:all .2s;
    }
    .map-detect-btn:hover{background:var(--green-lt);transform:translateY(-2px);}

    #sigMap{height:360px;width:100%;}

    /* Filtros de mapa */
    .map-filters{
      display:flex;gap:6px;padding:10px 16px;flex-wrap:wrap;
      border-top:1px solid rgba(255,255,255,.05);
      background:rgba(0,0,0,.2);
    }
    .map-filter{
      display:flex;align-items:center;gap:5px;
      padding:4px 10px;border-radius:99px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
      font-size:.7rem;color:var(--muted);cursor:pointer;transition:all .2s;
    }
    .map-filter.on{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}
    .map-dot{width:7px;height:7px;border-radius:50%;background:var(--green);}
    .map-dot.gold{background:var(--gold);}
    .map-dot.blue{background:var(--blue);}
    .map-dot.red{background:var(--red);}

    /* Info de ubicación detectada */
    .location-info{
      background:var(--n800);border:1px solid rgba(40,166,128,.2);
      border-radius:var(--r-xl);padding:24px;box-shadow:var(--sh-md);
    }
    .li-hd{display:flex;align-items:center;gap:10px;margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.06);}
    .li-ico{width:38px;height:38px;border-radius:var(--r-md);background:var(--green-dim);border:1px solid rgba(40,166,128,.3);display:flex;align-items:center;justify-content:center;font-size:1.1rem;}
    .li-title{font-size:.88rem;font-weight:700;color:var(--txt);}
    .li-sub{font-size:.72rem;color:var(--muted);}

    .li-row{display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04);}
    .li-row:last-child{border-bottom:none;}
    .li-lbl{font-size:.68rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;width:70px;flex-shrink:0;}
    .li-val{font-size:.82rem;color:var(--txt);font-weight:600;}
    .li-badge{padding:2px 8px;border-radius:99px;font-size:.65rem;font-weight:700;}
    .li-badge.green{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
    .li-badge.gold{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
    .li-badge.blue{background:var(--blue-dim);color:#93c5fd;border:1px solid rgba(59,130,246,.3);}

    .li-loading{
      display:flex;flex-direction:column;align-items:center;gap:10px;
      padding:24px;text-align:center;color:var(--muted);font-size:.82rem;
    }
    .li-spinner{
      width:32px;height:32px;border:2px solid rgba(255,255,255,.1);
      border-top-color:var(--green);border-radius:50%;
      animation:spin 1s linear infinite;
    }
    @keyframes spin{to{transform:rotate(360deg)}}

    /* Compatibilidad de idioma */
    .lang-card{
      margin-top:14px;padding:14px;
      background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
      border-radius:var(--r-md);
    }
    .lang-flag{font-size:1.8rem;margin-bottom:6px;}
    .lang-info{font-size:.78rem;color:var(--muted);line-height:1.5;}
    .lang-info strong{color:var(--gold-lt);display:block;margin-bottom:3px;}

    /* ══ SECCIÓN CONTÁCTENOS ═════════════════════════════════════ */
    .contact-grid{display:grid;grid-template-columns:1fr 420px;gap:28px;align-items:start;}

    /* Formulario */
    .form-card{
      background:var(--n800);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-xl);padding:32px;box-shadow:var(--sh-md);
    }
    .form-card-hd{margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);}
    .form-card-hd h2{font-size:1.1rem;font-weight:800;color:var(--txt);margin-bottom:4px;}
    .form-card-hd p{font-size:.82rem;color:var(--muted);}

    .frow{display:grid;gap:14px;margin-bottom:14px;}
    .frow-2{grid-template-columns:1fr 1fr;}
    .fgroup{display:flex;flex-direction:column;gap:5px;}
    .fgroup label{font-size:.7rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;}
    .finput{
      padding:11px 14px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
      border-radius:var(--r-md);color:var(--txt);font-family:var(--font);font-size:.88rem;
      transition:all .2s;width:100%;
    }
    .finput:focus{outline:none;border-color:var(--green);background:rgba(40,166,128,.06);box-shadow:0 0 0 3px rgba(40,166,128,.1);}
    select.finput option{background:var(--n700);}
    textarea.finput{resize:vertical;min-height:100px;line-height:1.6;}

    .btn-submit{
      display:flex;align-items:center;justify-content:center;gap:9px;
      width:100%;padding:13px;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.95rem;
      transition:all .2s;box-shadow:0 4px 20px rgba(40,166,128,.35);
      margin-top:18px;
    }
    .btn-submit:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(40,166,128,.45);}

    /* Mensajes de éxito/error */
    .msg-ok{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);padding:14px 18px;margin-bottom:18px;display:flex;align-items:flex-start;gap:10px;font-size:.85rem;color:var(--green-lt);animation:msgIn .4s ease;}
    .msg-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-md);padding:14px 18px;margin-bottom:18px;animation:msgIn .4s ease;}
    .msg-err ul{list-style:none;display:flex;flex-direction:column;gap:4px;}
    .msg-err li{font-size:.82rem;color:#fca5a5;display:flex;gap:6px;}
    .msg-err li::before{content:'✕';color:var(--red);}
    @keyframes msgIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:none}}

    /* Panel lateral de contacto */
    .contact-side{display:flex;flex-direction:column;gap:16px;}

    /* Tarjeta de info */
    .info-card{
      background:var(--n800);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);padding:22px;
    }
    .info-card-title{font-size:.78rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.06);}
    .info-row{display:flex;align-items:flex-start;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.04);}
    .info-row:last-child{border-bottom:none;}
    .info-ico{width:34px;height:34px;border-radius:var(--r-sm);background:var(--green-dim);border:1px solid rgba(40,166,128,.25);display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;}
    .info-txt strong{display:block;font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
    .info-txt span{font-size:.75rem;color:var(--muted);}
    .info-txt a{color:var(--green-lt);transition:color .2s;}
    .info-txt a:hover{color:var(--gold);}

    /* Horario */
    .horario-badge{
      display:inline-flex;align-items:center;gap:6px;
      padding:4px 10px;border-radius:99px;
      background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);
      font-size:.7rem;color:#86efac;font-weight:700;
    }
    .horario-dot{width:6px;height:6px;background:#22c55e;border-radius:50%;animation:pdot 1.8s ease-in-out infinite;}
    @keyframes pdot{0%,100%{opacity:1}50%{opacity:.3}}

    /* Redes sociales */
    .social-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:8px;}
    .soc-btn{
      display:flex;flex-direction:column;align-items:center;gap:6px;
      padding:12px 8px;border-radius:var(--r-md);
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      font-size:.72rem;color:var(--muted);transition:all .25s;text-decoration:none;
    }
    .soc-btn:hover{transform:translateY(-4px);}
    .soc-btn i{font-size:1.3rem;}
    .soc-btn.wa:hover{background:rgba(37,211,102,.12);color:#25D366;border-color:rgba(37,211,102,.3);}
    .soc-btn.ig:hover{background:rgba(225,48,108,.12);color:#E1306C;border-color:rgba(225,48,108,.3);}
    .soc-btn.fb:hover{background:rgba(24,119,242,.12);color:#1877F2;border-color:rgba(24,119,242,.3);}
    .soc-btn.tw:hover{background:rgba(29,161,242,.12);color:#1DA1F2;border-color:rgba(29,161,242,.3);}
    .soc-btn.li:hover{background:rgba(10,102,194,.12);color:#0A66C2;border-color:rgba(10,102,194,.3);}
    .soc-btn.yt:hover{background:rgba(255,0,0,.12);color:#FF0000;border-color:rgba(255,0,0,.3);}
    .soc-btn.em:hover{background:var(--green-dim);color:var(--green-lt);border-color:rgba(40,166,128,.3);}

    /* Mapa mini en info */
    #miniMap{height:160px;width:100%;border-radius:var(--r-md);overflow:hidden;margin-top:12px;}

    /* ══ SECCIÓN PQRS ════════════════════════════════════════════ */
    .pqrs-layout{display:grid;grid-template-columns:1fr 360px;gap:28px;align-items:start;}

    .pqrs-card{
      background:var(--n800);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-xl);padding:32px;box-shadow:var(--sh-md);
    }
    .pqrs-hd{margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);}
    .pqrs-hd-top{display:flex;align-items:center;gap:12px;margin-bottom:6px;}
    .pqrs-badge{
      padding:4px 12px;border-radius:99px;
      background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);
      font-size:.7rem;font-weight:700;color:var(--gold-lt);letter-spacing:1px;
    }
    .pqrs-hd h2{font-size:1.1rem;font-weight:800;color:var(--txt);margin-bottom:4px;}
    .pqrs-hd p{font-size:.82rem;color:var(--muted);}

    /* Selector de categoría PQRS */
    .pqrs-cats{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-bottom:20px;}
    .pqrs-cat{
      display:flex;flex-direction:column;align-items:center;gap:5px;
      padding:12px 8px;border-radius:var(--r-md);
      background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.08);
      cursor:pointer;transition:all .2s;text-align:center;
    }
    .pqrs-cat:hover{background:rgba(255,255,255,.08);}
    .pqrs-cat.on{background:var(--gold-dim);border-color:var(--gold);}
    .pqrs-cat-ico{font-size:1.4rem;}
    .pqrs-cat-nm{font-size:.72rem;font-weight:700;color:var(--txt);}
    .pqrs-cat.on .pqrs-cat-nm{color:var(--gold-lt);}
    .pqrs-cat-desc{font-size:.62rem;color:var(--muted);line-height:1.3;}
    input[name="categoria_pqrs"]{display:none;}

    /* Prioridad */
    .priority-btns{display:flex;gap:8px;margin-bottom:14px;}
    .prio-btn{
      flex:1;padding:8px;border-radius:var(--r-md);
      background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.08);
      font-size:.75rem;font-weight:700;color:var(--muted);cursor:pointer;transition:all .2s;
      font-family:var(--font);
    }
    .prio-btn:hover{background:rgba(255,255,255,.08);}
    .prio-btn[data-p="baja"].on{background:rgba(34,197,94,.12);border-color:#22c55e;color:#86efac;}
    .prio-btn[data-p="normal"].on{background:var(--blue-dim);border-color:var(--blue);color:#93c5fd;}
    .prio-btn[data-p="alta"].on{background:rgba(249,115,22,.12);border-color:#f97316;color:#fdba74;}
    .prio-btn[data-p="urgente"].on{background:var(--red-dim);border-color:var(--red);color:#fca5a5;}
    input[name="prioridad"]{display:none;}

    /* Sistema de calificación con estrellas */
    .rating-section{
      background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);padding:20px;margin-bottom:18px;
    }
    .rating-title{font-size:.78rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;}
    .stars-wrap{display:flex;align-items:center;gap:8px;margin-bottom:10px;}
    .star-btn{font-size:2rem;color:rgba(255,255,255,.15);cursor:pointer;transition:all .15s;background:none;padding:0;line-height:1;}
    .star-btn:hover,.star-btn.on{color:var(--gold);filter:drop-shadow(0 0 6px rgba(218,165,32,.5));transform:scale(1.15);}
    .star-label{font-size:.82rem;font-weight:700;color:var(--muted);transition:color .2s;}
    .star-label.rated{color:var(--gold-lt);}
    .stars-desc{font-size:.75rem;color:var(--dim);margin-top:6px;min-height:18px;transition:all .2s;}

    /* Panel lateral PQRS — estados y guía */
    .pqrs-side{display:flex;flex-direction:column;gap:16px;}
    .pqrs-info-card{
      background:var(--n800);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);padding:22px;
    }
    .pic-title{font-size:.78rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.06);}

    /* Timeline de estados */
    .pqrs-timeline{display:flex;flex-direction:column;gap:0;}
    .ptl-item{display:flex;gap:12px;padding-bottom:16px;position:relative;}
    .ptl-item:not(:last-child)::before{content:'';position:absolute;left:11px;top:24px;width:2px;height:calc(100% - 16px);background:rgba(255,255,255,.07);}
    .ptl-dot{width:24px;height:24px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.7rem;z-index:1;}
    .ptl-dot.open{background:var(--green-dim);border:2px solid var(--green);color:var(--green);}
    .ptl-dot.process{background:var(--blue-dim);border:2px solid var(--blue);color:var(--blue);}
    .ptl-dot.review{background:var(--gold-dim);border:2px solid var(--gold);color:var(--gold);}
    .ptl-dot.closed{background:rgba(255,255,255,.06);border:2px solid rgba(255,255,255,.15);color:var(--dim);}
    .ptl-content{flex:1;}
    .ptl-title{font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
    .ptl-desc{font-size:.72rem;color:var(--muted);line-height:1.45;}
    .ptl-time{font-size:.65rem;color:var(--dim);margin-top:2px;}

    /* Bonificaciones */
    .bonus-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:4px;}
    .bonus-card{
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);
      border-radius:var(--r-md);padding:12px 10px;text-align:center;
    }
    .bonus-ico{font-size:1.4rem;margin-bottom:4px;}
    .bonus-pts{font-size:1rem;font-weight:800;color:var(--gold);}
    .bonus-lbl{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;}

    /* ══ FOOTER ══════════════════════════════════════════════════ */
    .site-footer{background:#050d1a;border-top:1px solid rgba(40,166,128,.12);padding:32px 28px;margin-top:60px;}
    .footer-inner{max-width:1480px;margin:auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;}
    .footer-brand{display:flex;align-items:center;gap:10px;}
    .footer-copy{font-size:.8rem;color:var(--dim);}
    .footer-nav{display:flex;gap:18px;}
    .footer-nav a{font-size:.8rem;color:var(--dim);font-weight:600;transition:color .2s;}
    .footer-nav a:hover{color:var(--green);}

    /* ══ LEAFLET PERSONALIZADO ═══════════════════════════════════ */
    .leaflet-container{background:#0c1526;}
    .leaflet-tile{filter:brightness(.7) saturate(.4) hue-rotate(180deg);}
    .custom-marker{
      width:36px;height:36px;border-radius:50%;
      background:var(--green);border:3px solid #fff;
      display:flex;align-items:center;justify-content:center;
      box-shadow:0 4px 16px rgba(40,166,128,.6);
      font-size:1rem;
    }
    .user-marker{background:var(--gold);border-color:var(--n800);box-shadow:0 4px 16px rgba(218,165,32,.6);}
    .leaflet-popup-content-wrapper{background:var(--n600);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);color:var(--txt);box-shadow:var(--sh-md);}
    .leaflet-popup-tip{background:var(--n600);}
    .leaflet-popup-content{font-family:var(--font);font-size:.82rem;color:var(--txt);}

    /* ══ RESPONSIVE ══════════════════════════════════════════════ */
    @media(max-width:1024px){
      .map-section,.contact-grid,.pqrs-layout{grid-template-columns:1fr;}
      .map-container{order:1;} .location-info{order:0;}
    }
    @media(max-width:820px){
      .burger{display:flex;}
      .main-nav{position:fixed;top:var(--hh);left:0;right:0;background:var(--n800);flex-direction:column;padding:20px;gap:6px;border-bottom:1px solid rgba(255,255,255,.06);transform:translateY(-110%);transition:transform .35s ease;z-index:999;}
      .nav-open{transform:translateY(0)!important;}
      .ct-tabs{overflow-x:auto;justify-content:flex-start;padding:16px 16px 0;}
      .ct-layout{padding:24px 16px;}
      .pqrs-cats{grid-template-columns:repeat(3,1fr);}
    }
    @media(max-width:560px){
      .frow-2{grid-template-columns:1fr;}
      .social-grid{grid-template-columns:repeat(3,1fr);}
      .priority-btns{flex-wrap:wrap;}
      .pqrs-cats{grid-template-columns:repeat(2,1fr);}
      .bonus-grid{grid-template-columns:1fr 1fr;}
    }
  </style>
</head>
<body>

<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php" class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php" class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link active">Contacto</a>
      <?php if(!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span class="user-av"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuario') ?></span>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Salir</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ══ HERO ═══════════════════════════════════════════════════════════ -->
<div class="ct-hero">
  <div class="ct-hero-grid"></div>
  <div class="ct-orb co1"></div>
  <div class="ct-orb co2"></div>
  <div class="ct-hero-content">
    <span class="ct-hero-tag">⬡ Contáctanos — Team VIROX</span>
    <h1>Estamos para <span>Escucharte</span></h1>
    <p>Envíanos tu mensaje, PQRS o sugerencia. Nuestro equipo responde en menos de 24 horas.</p>
  </div>
</div>

<!-- ══ TABS ═══════════════════════════════════════════════════════════ -->
<div class="ct-tabs">
  <button class="ct-tab on" onclick="showSection('mapa', this)">
    <i class="fa fa-map-location-dot"></i> Mapa SIG
  </button>
  <button class="ct-tab" onclick="showSection('contacto', this)">
    <i class="fa fa-envelope"></i> Contáctenos
  </button>
  <button class="ct-tab pqrs-tab" onclick="showSection('pqrs', this)">
    <i class="fa fa-clipboard-list"></i> PQRS
  </button>
</div>


<!-- ══ LAYOUT ════════════════════════════════════════════════════════ -->
<div class="ct-layout">

  <!-- Mensajes globales -->
  <?php if ($success): ?>
  <div class="msg-ok">
    <i class="fa fa-circle-check fa-lg"></i>
    <div><?= $success ?></div>
  </div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="msg-err">
    <ul><?php foreach (explode('|', $error) as $e): ?>
      <li><?= htmlspecialchars($e) ?></li>
    <?php endforeach; ?></ul>
  </div>
  <?php endif; ?>


  <!-- ══════════════════════════════════════════════════════════════
       SECCIÓN 1 — MAPA SIG
  ══════════════════════════════════════════════════════════════ -->
  <div class="ct-section on" id="sec-mapa">
    <div class="map-section">

      <!-- Mapa principal -->
      <div class="map-container">
        <div class="map-hd">
          <div class="map-hd-left">
            <span class="map-hd-ico">🗺</span>
            <div>
              <div class="map-hd-title">Sistema de Información Geográfica</div>
              <div class="map-hd-sub">Detecta tu ubicación para clasificar y personalizar tu PQRS</div>
            </div>
          </div>
          <button class="map-detect-btn" onclick="detectLocation()">
            <i class="fa fa-location-crosshairs"></i> Detectar ubicación
          </button>
        </div>

        <div id="sigMap"></div>

        <div class="map-filters">
          <div class="map-filter on" onclick="toggleMapFilter(this, 'oficinas')">
            <div class="map-dot"></div> Oficinas VIROX
          </div>
          <div class="map-filter" onclick="toggleMapFilter(this, 'usuarios')">
            <div class="map-dot gold"></div> Usuarios activos
          </div>
          <div class="map-filter" onclick="toggleMapFilter(this, 'pqrs')">
            <div class="map-dot blue"></div> PQRS abiertas
          </div>
          <div class="map-filter" onclick="toggleMapFilter(this, 'incidentes')">
            <div class="map-dot red"></div> Incidentes
          </div>
        </div>
      </div>

      <!-- Panel de info de ubicación -->
      <div class="location-info">
        <div class="li-hd">
          <div class="li-ico">📍</div>
          <div>
            <div class="li-title">Tu Ubicación</div>
            <div class="li-sub">Detectada automáticamente</div>
          </div>
        </div>

        <div id="locationData">
          <div class="li-loading">
            <div class="li-spinner"></div>
            <span>Presiona "Detectar ubicación" para iniciar</span>
          </div>
        </div>

        <!-- Info de idioma detectado -->
        <div class="lang-card" id="langCard" style="display:none;">
          <div class="lang-flag" id="langFlag">🌐</div>
          <div class="lang-info">
            <strong id="langName">Idioma detectado</strong>
            <span id="langDesc">El formulario se adaptará a tu región.</span>
          </div>
        </div>

        <!-- Botón ir a PQRS con datos prellenados -->
        <button
          onclick="showSection('pqrs', document.querySelectorAll('.ct-tab')[2])"
          id="goToPqrs"
          style="display:none;width:100%;margin-top:16px;padding:11px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.85rem;transition:all .2s;"
          onmouseover="this.style.background='var(--green-lt)'"
          onmouseout="this.style.background='var(--green)'">
          <i class="fa fa-clipboard-list"></i> Crear PQRS con mi ubicación →
        </button>
      </div>

    </div>
  </div><!-- /sec-mapa -->


  <!-- ══════════════════════════════════════════════════════════════
       SECCIÓN 2 — CONTÁCTENOS
  ══════════════════════════════════════════════════════════════ -->
  <div class="ct-section" id="sec-contacto">
    <div class="contact-grid">

      <!-- Formulario principal -->
      <div class="form-card">
        <div class="form-card-hd">
          <h2>📧 Envíanos un Mensaje</h2>
          <p>Respuesta garantizada en menos de 24 horas hábiles.</p>
        </div>

        <form method="POST" id="contactForm">
          <input type="hidden" name="tipo_form" value="contacto">
          <input type="hidden" name="lat_user"  id="f_lat" value="0">
          <input type="hidden" name="lng_user"  id="f_lng" value="0">
          <input type="hidden" name="pais"      id="f_pais" value="<?= htmlspecialchars($cfg['ubicacion']) ?>">
          <input type="hidden" name="idioma"    id="f_idioma" value="es">

          <div class="frow frow-2">
            <div class="fgroup">
              <label>Nombre completo <span style="color:var(--red)">*</span></label>
              <input class="finput" type="text" name="nombre" required
                     value="<?= htmlspecialchars($usuario_nombre) ?>" placeholder="Tu nombre">
            </div>
            <div class="fgroup">
              <label>Correo electrónico <span style="color:var(--red)">*</span></label>
              <input class="finput" type="email" name="correo" required
                     value="<?= htmlspecialchars($usuario_correo) ?>" placeholder="correo@ejemplo.com">
            </div>
          </div>

          <div class="frow frow-2">
            <div class="fgroup">
              <label>Tipo de consulta</label>
              <select class="finput" name="asunto">
                <option value="Información general">ℹ️ Información general</option>
                <option value="Servicios tecnológicos">🛠 Servicios tecnológicos</option>
                <option value="Educación y cursos">🎓 Educación y cursos</option>
                <option value="Colaboración / Alianza">🤝 Colaboración / Alianza</option>
                <option value="Soporte técnico">⚙️ Soporte técnico</option>
                <option value="Prensa / Medios">📰 Prensa / Medios</option>
                <option value="Otro">💬 Otro</option>
              </select>
            </div>
            <div class="fgroup">
              <label>Región <span id="regionDetected" style="color:var(--green-lt);font-size:.65rem;"></span></label>
              <input class="finput" type="text" name="region" id="regionInput"
                     placeholder="Tu país / región" value="<?= htmlspecialchars($cfg['ubicacion']) ?>">
            </div>
          </div>

          <div class="frow">
            <div class="fgroup">
              <label>Mensaje <span style="color:var(--red)">*</span></label>
              <textarea class="finput" name="mensaje" required rows="5"
                        placeholder="Describe tu consulta con el mayor detalle posible..."></textarea>
            </div>
          </div>

          <!-- Adjunto -->
          <div class="frow">
            <div class="fgroup">
              <label>Adjunto (opcional)</label>
              <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;background:rgba(255,255,255,.04);border:1px dashed rgba(255,255,255,.12);border-radius:var(--r-md);cursor:pointer;" onclick="document.getElementById('adjunto').click()">
                <i class="fa fa-paperclip" style="color:var(--muted);"></i>
                <span style="font-size:.82rem;color:var(--muted);" id="adjuntoLabel">Haz clic para adjuntar un archivo (PDF, JPG, PNG — máx. 5MB)</span>
                <input type="file" id="adjunto" name="adjunto" accept=".pdf,.jpg,.jpeg,.png" style="display:none" onchange="updateAdjunto(this)">
              </div>
            </div>
          </div>

          <!-- Términos -->
          <div style="display:flex;align-items:flex-start;gap:10px;margin-top:8px;">
            <input type="checkbox" id="terminos" required style="width:16px;height:16px;accent-color:var(--green);margin-top:2px;flex-shrink:0;">
            <label for="terminos" style="font-size:.78rem;color:var(--muted);line-height:1.5;">
              Acepto el <a href="terminos.php" style="color:var(--gold);font-weight:700;">tratamiento de datos personales</a> y la
              <a href="privacidad.php" style="color:var(--gold);font-weight:700;">política de privacidad</a> de Team VIROX.
            </label>
          </div>

          <button type="submit" class="btn-submit">
            <i class="fa fa-paper-plane"></i> Enviar Mensaje
          </button>
        </form>
      </div>

      <!-- Panel lateral -->
      <div class="contact-side">

        <!-- Info de contacto -->
        <div class="info-card">
          <div class="info-card-title">📞 Información de Contacto</div>
          <div class="info-row">
            <div class="info-ico">📧</div>
            <div class="info-txt">
              <strong>Email</strong>
              <span><a href="mailto:<?= $cfg['email'] ?>"><?= htmlspecialchars($cfg['email']) ?></a></span>
            </div>
          </div>
          <div class="info-row">
            <div class="info-ico">📱</div>
            <div class="info-txt">
              <strong>Teléfono / WhatsApp</strong>
              <span><a href="https://wa.me/<?= preg_replace('/[^0-9]/','',$cfg['whatsapp']) ?>" target="_blank"><?= htmlspecialchars($cfg['telefono']) ?></a></span>
            </div>
          </div>
          <div class="info-row">
            <div class="info-ico">📍</div>
            <div class="info-txt">
              <strong>Ubicación</strong>
              <span><?= htmlspecialchars($cfg['direccion']) ?></span>
            </div>
          </div>
          <div class="info-row">
            <div class="info-ico">🌐</div>
            <div class="info-txt">
              <strong>Web</strong>
              <span><a href="https://<?= $cfg['web'] ?>" target="_blank"><?= htmlspecialchars($cfg['web']) ?></a></span>
            </div>
          </div>
          <div class="info-row">
            <div class="info-ico">🕒</div>
            <div class="info-txt">
              <strong>Horario</strong>
              <span>
                <span class="horario-badge">
                  <span class="horario-dot"></span> En línea
                </span>
                <br><small style="color:var(--dim);font-size:.7rem;margin-top:3px;display:block;"><?= htmlspecialchars($cfg['horario']) ?></small>
              </span>
            </div>
          </div>
        </div>

        <!-- Redes sociales -->
        <div class="info-card">
          <div class="info-card-title">🌐 Redes Sociales</div>
          <div class="social-grid">
            <a href="https://wa.me/<?= preg_replace('/[^0-9]/','',$cfg['whatsapp']) ?>" target="_blank" class="soc-btn wa">
              <i class="fa-brands fa-whatsapp"></i> WhatsApp
            </a>
            <?php if ($cfg['instagram']): ?>
            <a href="<?= htmlspecialchars($cfg['instagram']) ?>" target="_blank" class="soc-btn ig">
              <i class="fa-brands fa-instagram"></i> Instagram
            </a>
            <?php endif; ?>
            <?php if ($cfg['facebook']): ?>
            <a href="<?= htmlspecialchars($cfg['facebook']) ?>" target="_blank" class="soc-btn fb">
              <i class="fa-brands fa-facebook"></i> Facebook
            </a>
            <?php endif; ?>
            <?php if ($cfg['twitter']): ?>
            <a href="<?= htmlspecialchars($cfg['twitter']) ?>" target="_blank" class="soc-btn tw">
              <i class="fa-brands fa-twitter"></i> Twitter
            </a>
            <?php endif; ?>
            <?php if ($cfg['linkedin']): ?>
            <a href="<?= htmlspecialchars($cfg['linkedin']) ?>" target="_blank" class="soc-btn li">
              <i class="fa-brands fa-linkedin"></i> LinkedIn
            </a>
            <?php endif; ?>
            <?php if ($cfg['youtube']): ?>
            <a href="<?= htmlspecialchars($cfg['youtube']) ?>" target="_blank" class="soc-btn yt">
              <i class="fa-brands fa-youtube"></i> YouTube
            </a>
            <?php endif; ?>
            <a href="mailto:<?= $cfg['email'] ?>" class="soc-btn em">
              <i class="fa fa-envelope"></i> Email
            </a>
          </div>
        </div>

        <!-- Mini mapa -->
        <div class="info-card">
          <div class="info-card-title">📌 Nuestra Ubicación</div>
          <div id="miniMap"></div>
        </div>

      </div><!-- /contact-side -->
    </div>
  </div><!-- /sec-contacto -->


  <!-- ══════════════════════════════════════════════════════════════
       SECCIÓN 3 — PQRS
  ══════════════════════════════════════════════════════════════ -->
  <div class="ct-section" id="sec-pqrs">
    <div class="pqrs-layout">

      <!-- Formulario PQRS -->
      <div class="pqrs-card">
        <div class="pqrs-hd">
          <div class="pqrs-hd-top">
            <h2>📋 Petición, Queja, Reclamo y Sugerencia</h2>
            <span class="pqrs-badge">PQRS</span>
          </div>
          <p>Tu opinión es valiosa. Registra tu solicitud y te responderemos en máximo 15 días hábiles.</p>
        </div>

        <form method="POST" id="pqrsForm">
          <input type="hidden" name="tipo_form" value="pqrs">
          <input type="hidden" name="lat_user"  id="p_lat" value="0">
          <input type="hidden" name="lng_user"  id="p_lng" value="0">
          <input type="hidden" name="pais"      id="p_pais" value="<?= htmlspecialchars($cfg['ubicacion']) ?>">
          <input type="hidden" name="idioma"    id="p_idioma" value="es">
          <input type="hidden" name="estrellas" id="pqrs_estrellas" value="0">
          <input type="hidden" name="prioridad" id="pqrs_prioridad" value="normal">
          <input type="hidden" name="categoria_pqrs" id="pqrs_categoria" value="consulta">

          <!-- 1. Categoría -->
          <p style="font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;">1. Selecciona el tipo de PQRS</p>
          <div class="pqrs-cats">
            <?php foreach ($categorias_pqrs as $key => [$ico, $nm, $desc]): ?>
            <div class="pqrs-cat <?= $key === 'consulta' ? 'on' : '' ?>"
                 onclick="selectPqrsCat('<?= $key ?>', this)">
              <div class="pqrs-cat-ico"><?= $ico ?></div>
              <div class="pqrs-cat-nm"><?= $nm ?></div>
              <div class="pqrs-cat-desc"><?= $desc ?></div>
            </div>
            <?php endforeach; ?>
          </div>

          <!-- 2. Prioridad -->
          <p style="font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;margin-top:6px;">2. Prioridad</p>
          <div class="priority-btns">
            <button type="button" class="prio-btn" data-p="baja"    onclick="selectPrio('baja',this)">🟢 Baja</button>
            <button type="button" class="prio-btn on" data-p="normal" onclick="selectPrio('normal',this)">🔵 Normal</button>
            <button type="button" class="prio-btn" data-p="alta"    onclick="selectPrio('alta',this)">🟠 Alta</button>
            <button type="button" class="prio-btn" data-p="urgente" onclick="selectPrio('urgente',this)">🔴 Urgente</button>
          </div>

          <!-- 3. Datos personales -->
          <p style="font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;margin-top:18px;">3. Datos de contacto</p>
          <div class="frow frow-2">
            <div class="fgroup">
              <label>Nombre completo <span style="color:var(--red)">*</span></label>
              <input class="finput" type="text" name="nombre" required
                     value="<?= htmlspecialchars($usuario_nombre) ?>" placeholder="Tu nombre">
            </div>
            <div class="fgroup">
              <label>Correo electrónico <span style="color:var(--red)">*</span></label>
              <input class="finput" type="email" name="correo" required
                     value="<?= htmlspecialchars($usuario_correo) ?>" placeholder="correo@ejemplo.com">
            </div>
          </div>
          <div class="frow frow-2">
            <div class="fgroup">
              <label>Teléfono</label>
              <input class="finput" type="tel" name="telefono" placeholder="+57 300 000 0000">
            </div>
            <div class="fgroup">
              <label>País / Región <span id="pqrsRegionBadge" style="color:var(--green-lt);font-size:.65rem;"></span></label>
              <input class="finput" type="text" name="region_pqrs" id="pqrsRegionInput"
                     placeholder="Tu país" value="<?= htmlspecialchars($cfg['ubicacion']) ?>">
            </div>
          </div>

          <!-- 4. Detalle -->
          <p style="font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;margin-top:6px;">4. Detalle de la solicitud</p>
          <div class="frow">
            <div class="fgroup">
              <label>Asunto <span style="color:var(--red)">*</span></label>
              <input class="finput" type="text" name="asunto" required placeholder="Resumen de tu solicitud en una línea">
            </div>
          </div>
          <div class="frow">
            <div class="fgroup">
              <label>Descripción detallada <span style="color:var(--red)">*</span></label>
              <textarea class="finput" name="mensaje" required rows="5"
                        placeholder="Explica tu solicitud con el mayor detalle posible. Incluye fechas, referencias o cualquier información relevante..."></textarea>
            </div>
          </div>

          <!-- 5. Calificación con estrellas -->
          <p style="font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;margin-top:6px;">5. Calificación de la experiencia</p>
          <div class="rating-section">
            <div class="rating-title">¿Cómo calificarías tu experiencia con Team VIROX?</div>
            <div class="stars-wrap">
              <button type="button" class="star-btn" data-n="1" onclick="setRating(1)">★</button>
              <button type="button" class="star-btn" data-n="2" onclick="setRating(2)">★</button>
              <button type="button" class="star-btn" data-n="3" onclick="setRating(3)">★</button>
              <button type="button" class="star-btn" data-n="4" onclick="setRating(4)">★</button>
              <button type="button" class="star-btn" data-n="5" onclick="setRating(5)">★</button>
              <span class="star-label" id="starLabel">Sin calificar</span>
            </div>
            <div class="stars-desc" id="starDesc">Haz clic en las estrellas para calificar. Tu opinión nos ayuda a mejorar.</div>
          </div>

          <!-- Términos -->
          <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:6px;">
            <input type="checkbox" id="terminos_pqrs" required style="width:16px;height:16px;accent-color:var(--gold);margin-top:2px;flex-shrink:0;">
            <label for="terminos_pqrs" style="font-size:.78rem;color:var(--muted);line-height:1.5;">
              Acepto el tratamiento de mis datos personales conforme a la
              <a href="privacidad.php" style="color:var(--gold);font-weight:700;">política de privacidad</a> y
              <a href="terminos.php"   style="color:var(--gold);font-weight:700;">términos de uso</a>.
            </label>
          </div>

          <button type="submit" class="btn-submit" style="background:linear-gradient(135deg,var(--gold),#b8860b);">
            <i class="fa fa-paper-plane"></i> Registrar PQRS
          </button>
        </form>
      </div><!-- /pqrs-card -->

      <!-- Panel lateral PQRS -->
      <div class="pqrs-side">

        <!-- ¿Qué es PQRS? -->
        <div class="pqrs-info-card">
          <div class="pic-title">ℹ️ ¿Qué es PQRS?</div>
          <p style="font-size:.8rem;color:var(--muted);line-height:1.65;margin-bottom:14px;">
            Sistema de atención ciudadana que permite a los usuarios registrar peticiones, quejas, reclamos, sugerencias y denuncias de forma estructurada y con seguimiento.
          </p>
          <?php foreach ($categorias_pqrs as $key => [$ico, $nm, $desc]): ?>
          <div style="display:flex;align-items:flex-start;gap:8px;margin-bottom:8px;">
            <span style="font-size:1rem;flex-shrink:0;"><?= $ico ?></span>
            <div>
              <strong style="font-size:.78rem;color:var(--txt);display:block;"><?= $nm ?></strong>
              <span style="font-size:.7rem;color:var(--muted);"><?= $desc ?></span>
            </div>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Proceso de atención -->
        <div class="pqrs-info-card">
          <div class="pic-title">⏱ Proceso de Atención</div>
          <div class="pqrs-timeline">
            <div class="ptl-item">
              <div class="ptl-dot open"><i class="fa fa-inbox fa-xs"></i></div>
              <div class="ptl-content">
                <div class="ptl-title">Recepción</div>
                <div class="ptl-desc">Tu solicitud es registrada y se genera un folio único de seguimiento.</div>
                <div class="ptl-time">Inmediato</div>
              </div>
            </div>
            <div class="ptl-item">
              <div class="ptl-dot process"><i class="fa fa-gear fa-xs"></i></div>
              <div class="ptl-content">
                <div class="ptl-title">En Proceso</div>
                <div class="ptl-desc">El área responsable revisa y atiende tu solicitud.</div>
                <div class="ptl-time">1 – 5 días hábiles</div>
              </div>
            </div>
            <div class="ptl-item">
              <div class="ptl-dot review"><i class="fa fa-magnifying-glass fa-xs"></i></div>
              <div class="ptl-content">
                <div class="ptl-title">Revisión</div>
                <div class="ptl-desc">Se valida la solución antes de enviar la respuesta final.</div>
                <div class="ptl-time">5 – 10 días hábiles</div>
              </div>
            </div>
            <div class="ptl-item">
              <div class="ptl-dot closed"><i class="fa fa-check fa-xs"></i></div>
              <div class="ptl-content">
                <div class="ptl-title">Cierre</div>
                <div class="ptl-desc">Respuesta enviada a tu correo con el resultado de la gestión.</div>
                <div class="ptl-time">Máx. 15 días hábiles</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Bonificaciones -->
        <div class="pqrs-info-card">
          <div class="pic-title">🎁 Bonificaciones PQRS</div>
          <p style="font-size:.75rem;color:var(--muted);margin-bottom:12px;line-height:1.55;">
            Al registrar tu PQRS y calificar el servicio, recibes puntos que se acumulan en tu perfil VIROX.
          </p>
          <div class="bonus-grid">
            <div class="bonus-card">
              <div class="bonus-ico">📋</div>
              <div class="bonus-pts">+10 pts</div>
              <div class="bonus-lbl">Registrar PQRS</div>
            </div>
            <div class="bonus-card">
              <div class="bonus-ico">⭐</div>
              <div class="bonus-pts">+5 pts</div>
              <div class="bonus-lbl">Calificar servicio</div>
            </div>
            <div class="bonus-card">
              <div class="bonus-ico">✅</div>
              <div class="bonus-pts">+15 pts</div>
              <div class="bonus-lbl">PQRS completada</div>
            </div>
            <div class="bonus-card">
              <div class="bonus-ico">💡</div>
              <div class="bonus-pts">+20 pts</div>
              <div class="bonus-lbl">Sugerencia aceptada</div>
            </div>
          </div>
          <div style="margin-top:12px;padding:10px 12px;background:var(--gold-dim);border:1px solid rgba(218,165,32,.25);border-radius:var(--r-md);font-size:.75rem;color:var(--gold-lt);">
            🏆 Los puntos se canjean por acceso a cursos, certificados y beneficios exclusivos en la plataforma.
          </div>
        </div>

        <!-- Consultar PQRS existente -->
        <div class="pqrs-info-card">
          <div class="pic-title">🔍 Consultar Estado</div>
          <p style="font-size:.75rem;color:var(--muted);margin-bottom:12px;">Ingresa el folio de tu PQRS para ver el estado actual.</p>
          <div style="display:flex;gap:8px;">
            <input type="text" id="folioInput" placeholder="Ej: PQRS-AB123456"
                   style="flex:1;padding:9px 12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font);font-size:.82rem;outline:none;">
            <button onclick="consultarFolio()"
                    style="padding:9px 14px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.8rem;transition:all .2s;">
              <i class="fa fa-search"></i>
            </button>
          </div>
          <div id="folioResult" style="margin-top:10px;font-size:.78rem;color:var(--muted);"></div>
        </div>

      </div><!-- /pqrs-side -->
    </div>
  </div><!-- /sec-pqrs -->

</div><!-- /ct-layout -->


<!-- ══ FOOTER ════════════════════════════════════════════════════════ -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name" style="font-size:1.2rem;letter-spacing:3px;">VIROX</span>
    </div>
    <p class="footer-copy">© 2025 Team VIROX — Todos los derechos reservados</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyectos</a>
      <a href="equipo.php">Equipo</a>
      <a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>


<script>
/* ════════════════════════════════════════════════════════════════════
   HEADER SCROLL
════════════════════════════════════════════════════════════════════ */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));

document.getElementById('burger')?.addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ════════════════════════════════════════════════════════════════════
   TABS DE SECCIÓN
════════════════════════════════════════════════════════════════════ */
function showSection(id, btn) {
  document.querySelectorAll('.ct-section').forEach(s => s.classList.remove('on'));
  document.querySelectorAll('.ct-tab').forEach(t => t.classList.remove('on'));
  document.getElementById('sec-' + id).classList.add('on');
  btn.classList.add('on');

  // Inicializar mapa cuando se activa
  if (id === 'mapa' && !window._mapInit)  initSigMap();
  if (id === 'contacto' && !window._miniMapInit) initMiniMap();
  window.scrollTo({ top: document.getElementById('siteHeader').offsetHeight, behavior: 'smooth' });
}

/* ════════════════════════════════════════════════════════════════════
   MAPA SIG — LEAFLET
════════════════════════════════════════════════════════════════════ */
let sigMap, miniMap, userMarker;

function initSigMap() {
  window._mapInit = true;

  sigMap = L.map('sigMap', { zoomControl: true, attributionControl: false }).setView(
    [<?= $cfg['lat'] ?>, <?= $cfg['lng'] ?>], 5
  );

  // Tile oscuro
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 18, opacity: 0.6,
  }).addTo(sigMap);

  // Marcador principal VIROX
  const viroxIco = L.divIcon({
    html: '<div class="custom-marker">⬡</div>',
    className: '', iconSize: [36,36], iconAnchor: [18,36],
  });
  L.marker([<?= $cfg['lat'] ?>, <?= $cfg['lng'] ?>], { icon: viroxIco })
    .addTo(sigMap)
    .bindPopup('<strong style="font-family:Syne">⬡ Team VIROX</strong><br><?= htmlspecialchars($cfg['direccion']) ?>');

  // Puntos de ejemplo (usuarios / pqrs)
  addSamplePoints();
}

function addSamplePoints() {
  const points = [
    { lat: 4.6097, lng: -74.0817, tipo: 'usuarios', label: '🎓 5 Usuarios activos — Bogotá' },
    { lat: 6.2518, lng: -75.5636, tipo: 'usuarios', label: '🎓 3 Usuarios activos — Medellín' },
    { lat: 3.4516, lng: -76.5320, tipo: 'pqrs',     label: '📋 2 PQRS abiertas — Cali' },
    { lat: 10.9878,lng: -74.7889, tipo: 'pqrs',     label: '📋 1 PQRS abierta — Barranquilla' },
    { lat: 7.8939, lng: -72.5078, tipo: 'incidentes',label:'🚨 Incidente — Cúcuta' },
    { lat:-0.2295,  lng:-78.5243, tipo: 'usuarios', label: '🎓 2 Usuarios — Quito, Ecuador' },
    { lat: 4.7110, lng: -74.0721, tipo: 'oficinas',  label: '🏢 Oficina Virtual VIROX' },
  ];

  const colors = { oficinas:'#28A680', usuarios:'#DAA520', pqrs:'#3b82f6', incidentes:'#ef4444' };

  points.forEach(p => {
    const ico = L.circleMarker([p.lat, p.lng], {
      radius: 7, fillColor: colors[p.tipo] || '#fff',
      color: '#fff', weight: 1.5, opacity: .9, fillOpacity: .8,
    }).addTo(sigMap)
      .bindPopup(`<span style="font-family:Syne;font-size:.82rem;">${p.label}</span>`);
    ico.options._tipo = p.tipo;
  });
}

function initMiniMap() {
  window._miniMapInit = true;
  miniMap = L.map('miniMap', { zoomControl:false, dragging:false, scrollWheelZoom:false, attributionControl:false })
    .setView([<?= $cfg['lat'] ?>, <?= $cfg['lng'] ?>], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom:18, opacity:0.5 }).addTo(miniMap);
  const ico = L.divIcon({ html:'<div class="custom-marker">⬡</div>', className:'', iconSize:[30,30], iconAnchor:[15,30] });
  L.marker([<?= $cfg['lat'] ?>, <?= $cfg['lng'] ?>], { icon: ico }).addTo(miniMap);
}

function toggleMapFilter(el, tipo) {
  el.classList.toggle('on');
  if (!sigMap) return;
  sigMap.eachLayer(layer => {
    if (layer.options._tipo === tipo) {
      const visible = el.classList.contains('on');
      layer.setStyle({ opacity: visible ? .9 : 0, fillOpacity: visible ? .8 : 0 });
    }
  });
}

/* ════════════════════════════════════════════════════════════════════
   DETECCIÓN DE UBICACIÓN
════════════════════════════════════════════════════════════════════ */
function detectLocation() {
  if (!navigator.geolocation) {
    alert('Tu navegador no soporta geolocalización.');
    return;
  }

  document.getElementById('locationData').innerHTML = `
    <div class="li-loading">
      <div class="li-spinner"></div>
      <span>Detectando tu ubicación...</span>
    </div>`;

  navigator.geolocation.getCurrentPosition(
    pos => {
      const { latitude: lat, longitude: lng, accuracy } = pos.coords;
      reverseGeocode(lat, lng, accuracy);
    },
    err => {
      document.getElementById('locationData').innerHTML =
        `<div class="li-loading" style="color:var(--red-dim);">
           <i class="fa fa-triangle-exclamation" style="font-size:1.5rem;color:var(--red);"></i>
           <span>No se pudo obtener la ubicación: ${err.message}</span>
         </div>`;
    },
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

async function reverseGeocode(lat, lng, accuracy) {
  try {
    const res  = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&accept-language=es`);
    const data = await res.json();
    const addr = data.address || {};

    const pais    = addr.country     || 'Desconocido';
    const ciudad  = addr.city || addr.town || addr.village || addr.county || 'Desconocido';
    const depto   = addr.state       || '';
    const cp      = addr.postcode    || '–';
    const iso     = addr.country_code?.toUpperCase() || '??';

    // Detectar idioma
    const idiomaMap = {
      CO:'es',MX:'es',AR:'es',CL:'es',PE:'es',VE:'es',EC:'es',
      US:'en',GB:'en',CA:'en',AU:'en',
      BR:'pt',PT:'pt',
      FR:'fr',DE:'de',IT:'it',
    };
    const idioma  = idiomaMap[iso] || 'es';

    // Actualizar campos hidden en formularios
    ['f_lat','p_lat'].forEach(id => { const el = document.getElementById(id); if(el) el.value = lat; });
    ['f_lng','p_lng'].forEach(id => { const el = document.getElementById(id); if(el) el.value = lng; });
    ['f_pais','p_pais'].forEach(id => { const el = document.getElementById(id); if(el) el.value = pais; });
    ['f_idioma','p_idioma'].forEach(id => { const el = document.getElementById(id); if(el) el.value = idioma; });

    // Actualizar campos visibles
    const regionInputs = ['regionInput','pqrsRegionInput'];
    regionInputs.forEach(id => { const el = document.getElementById(id); if(el) el.value = `${ciudad}, ${pais}`; });
    ['regionDetected','pqrsRegionBadge'].forEach(id => {
      const el = document.getElementById(id);
      if(el) el.textContent = '✓ Detectado automáticamente';
    });

    // Mostrar info de ubicación
    document.getElementById('locationData').innerHTML = `
      <div class="li-row">
        <span class="li-lbl">País</span>
        <span class="li-val">${pais} <span class="li-badge green">${iso}</span></span>
      </div>
      <div class="li-row">
        <span class="li-lbl">Ciudad</span>
        <span class="li-val">${ciudad}</span>
      </div>
      <div class="li-row">
        <span class="li-lbl">Depto.</span>
        <span class="li-val">${depto || '–'}</span>
      </div>
      <div class="li-row">
        <span class="li-lbl">C.P.</span>
        <span class="li-val">${cp}</span>
      </div>
      <div class="li-row">
        <span class="li-lbl">Coord.</span>
        <span class="li-val" style="font-size:.72rem;">${lat.toFixed(4)}, ${lng.toFixed(4)}</span>
      </div>
      <div class="li-row">
        <span class="li-lbl">Precisión</span>
        <span class="li-val"><span class="li-badge ${accuracy < 100 ? 'green' : 'gold'}">${accuracy < 100 ? '± ' + Math.round(accuracy) + 'm' : 'Aprox.'}</span></span>
      </div>
    `;

    // Info de idioma
    const langInfo = {
      es: ['🇪🇸', 'Español', 'Los formularios se mostrarán en español y adaptarán la clasificación a tu región.'],
      en: ['🇺🇸', 'English', 'Forms will be displayed in English based on your detected region.'],
      pt: ['🇧🇷', 'Português', 'Os formulários serão apresentados em português.'],
      fr: ['🇫🇷', 'Français', 'Les formulaires seront affichés en français.'],
      de: ['🇩🇪', 'Deutsch', 'Die Formulare werden auf Deutsch angezeigt.'],
    };
    const [flag, langNm, langDsc] = langInfo[idioma] || langInfo['es'];
    document.getElementById('langFlag').textContent  = flag;
    document.getElementById('langName').textContent  = langNm;
    document.getElementById('langDesc').textContent  = langDsc;
    document.getElementById('langCard').style.display = 'block';
    document.getElementById('goToPqrs').style.display = 'block';

    // Añadir marcador de usuario en el mapa
    if (sigMap) {
      const userIco = L.divIcon({
        html:'<div class="custom-marker user-marker">👤</div>',
        className:'', iconSize:[36,36], iconAnchor:[18,36],
      });
      if (userMarker) sigMap.removeLayer(userMarker);
      userMarker = L.marker([lat, lng], { icon: userIco })
        .addTo(sigMap)
        .bindPopup(`<strong style="font-family:Syne">📍 Tu ubicación</strong><br>${ciudad}, ${pais}`)
        .openPopup();
      sigMap.flyTo([lat, lng], 10, { duration: 1.5 });
    }

  } catch(e) {
    document.getElementById('locationData').innerHTML =
      '<div class="li-loading"><span style="color:var(--muted);">No se pudo obtener detalles de ubicación.</span></div>';
  }
}

/* ════════════════════════════════════════════════════════════════════
   CALIFICACIÓN POR ESTRELLAS
════════════════════════════════════════════════════════════════════ */
const starLabels = ['', '⭐ Muy malo', '⭐⭐ Regular', '⭐⭐⭐ Bueno', '⭐⭐⭐⭐ Muy bueno', '⭐⭐⭐⭐⭐ Excelente'];
const starDescs  = [
  '',
  'Lamentamos tu mala experiencia. Tu PQRS tiene prioridad alta.',
  'Gracias por tu honestidad. Trabajaremos en mejorar.',
  'Buen servicio. Seguimos trabajando para ser mejores.',
  'Nos alegra que tu experiencia haya sido muy buena.',
  '¡Excelente! Tu calificación nos motiva a seguir adelante.',
];

let currentRating = 0;

function setRating(n) {
  currentRating = n;
  document.getElementById('pqrs_estrellas').value = n;
  document.querySelectorAll('.star-btn').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });
  const lbl = document.getElementById('starLabel');
  lbl.textContent = starLabels[n];
  lbl.classList.add('rated');
  document.getElementById('starDesc').textContent = starDescs[n];
  // Ajustar prioridad automáticamente según calificación baja
  if (n <= 2) selectPrio('alta', document.querySelector('.prio-btn[data-p="alta"]'));
}

/* ════════════════════════════════════════════════════════════════════
   SELECCIÓN DE CATEGORÍA PQRS
════════════════════════════════════════════════════════════════════ */
function selectPqrsCat(key, el) {
  document.querySelectorAll('.pqrs-cat').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('pqrs_categoria').value = key;
}

/* ════════════════════════════════════════════════════════════════════
   PRIORIDAD
════════════════════════════════════════════════════════════════════ */
function selectPrio(p, el) {
  if (!el) return;
  document.querySelectorAll('.prio-btn').forEach(b => b.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('pqrs_prioridad').value = p;
}

/* ════════════════════════════════════════════════════════════════════
   CONSULTAR FOLIO PQRS
════════════════════════════════════════════════════════════════════ */
function consultarFolio() {
  const folio = document.getElementById('folioInput').value.trim().toUpperCase();
  const res   = document.getElementById('folioResult');
  if (!folio) { res.innerHTML = '<span style="color:var(--red);">Ingresa un folio válido.</span>'; return; }

  res.innerHTML = '<i class="fa fa-spinner fa-spin" style="color:var(--green);"></i> Consultando...';

  fetch(`api/pqrs_consulta.php?folio=${encodeURIComponent(folio)}`)
    .then(r => r.json())
    .then(data => {
      if (data.found) {
        const estados = { abierto:'🟢 Abierto', proceso:'🔵 En proceso', revision:'🟡 En revisión', cerrado:'✅ Cerrado' };
        res.innerHTML = `
          <div style="padding:10px;background:rgba(40,166,128,.08);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-md);">
            <div style="font-weight:700;color:var(--txt);margin-bottom:4px;">📋 ${data.folio}</div>
            <div style="font-size:.72rem;color:var(--muted);">Estado: ${estados[data.estado] || data.estado}</div>
            <div style="font-size:.72rem;color:var(--muted);">Categoría: ${data.categoria}</div>
            <div style="font-size:.72rem;color:var(--muted);">Fecha: ${data.fecha}</div>
          </div>`;
      } else {
        res.innerHTML = `<span style="color:var(--muted);font-size:.78rem;">No se encontró el folio <strong>${folio}</strong>.</span>`;
      }
    })
    .catch(() => {
      res.innerHTML = '<span style="color:var(--muted);font-size:.78rem;">Servicio no disponible. Intenta más tarde.</span>';
    });
}

/* ════════════════════════════════════════════════════════════════════
   UTILIDADES
════════════════════════════════════════════════════════════════════ */
function updateAdjunto(input) {
  const lbl = document.getElementById('adjuntoLabel');
  if (input.files.length) {
    const name = input.files[0].name;
    const size = (input.files[0].size / 1024 / 1024).toFixed(2);
    lbl.innerHTML = `<i class="fa fa-file" style="color:var(--green);"></i> ${name} (${size} MB)`;
    lbl.style.color = 'var(--green-lt)';
  }
}

/* ════════════════════════════════════════════════════════════════════
   INIT
════════════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  // Inicializar mapa SIG al cargar
  setTimeout(initSigMap, 300);

  // Abrir sección según hash en URL
  const hash = window.location.hash.replace('#','');
  if (['contacto','pqrs','mapa'].includes(hash)) {
    const tabs = { mapa:0, contacto:1, pqrs:2 };
    const btn = document.querySelectorAll('.ct-tab')[tabs[hash]];
    if (btn) showSection(hash, btn);
  }

  // Si hay mensaje de éxito, ir a la sección correspondiente
  <?php if ($success): ?>
  setTimeout(() => document.querySelector('.msg-ok')?.scrollIntoView({ behavior:'smooth', block:'center' }), 200);
  <?php endif; ?>
});
</script>
</body>
</html>