<?php

include 'conexion.php';
session_start();

// ── 1. CONFIGURACIÓN GLOBAL ──────────────────────────────────
$cfg = [];
if (isset($conexion)) {
    $qcfg = $conexion->query(
        "SELECT clave, valor FROM configuracion
         WHERE grupo IN ('empresa','general','estadisticas','manual','contacto','hero','ia','footer')"
    );
    if ($qcfg) while ($r = $qcfg->fetch_assoc()) $cfg[$r['clave']] = $r['valor'];
}

$nombre_sistema = $cfg['nombre_sistema']     ?? 'ContainerRz';
$nombre_publico = $cfg['nombre_publico']     ?? 'ContainerRz';
$slogan         = $cfg['slogan']             ?? 'Tecnología, ingeniería y aprendizaje interactivo.';
$mision         = $cfg['mision']             ?? 'Democratizar el acceso a la educación en tecnología.';
$vision         = $cfg['vision']             ?? 'Ser la plataforma educativa de referencia en Latinoamérica.';
$acerca         = $cfg['acerca']             ?? 'Proyecto académico enfocado en tecnología aplicada.';
$manual_url     = $cfg['manual_url']         ?? 'manual.php';
$manual_titulo  = $cfg['manual_titulo']      ?? 'Manual del Usuario';
$manual_sub     = $cfg['manual_subtitulo']   ?? 'Aprende a usar todas las funcionalidades paso a paso.';
$stat_modulos   = $cfg['stat_modulos']       ?? '21';
$stat_roles     = $cfg['stat_roles']         ?? '7';
$stat_regiones  = $cfg['stat_regiones']      ?? '5';
$footer_copy    = $cfg['footer_copy']        ?? '© 2025 ContainerRz — Todos los derechos reservados';
$ia_titulo      = $cfg['ia_titulo']          ?? 'IA integrada al proyecto';
$ia_desc        = $cfg['ia_descripcion']     ?? 'Herramientas y desarrollos de inteligencia artificial.';
$email          = $cfg['email']              ?? 'contacto@teamvirox.com';
$web            = $cfg['web']                ?? 'www.teamvirox.com';
$ubicacion      = $cfg['ubicacion']          ?? 'Colombia';
$hero_s1_tag    = $cfg['hero_slide1_tag']    ?? '⬡ Plataforma Educativa · Tecnológica';
$hero_s1_cuerpo = $cfg['hero_slide1_cuerpo'] ?? $slogan;
$hero_s2_tag    = $cfg['hero_slide2_tag']    ?? '🎯 Nuestra Misión';
$hero_s3_tag    = $cfg['hero_slide3_tag']    ?? '🔭 Nuestra Visión';

// ── 2. SERVICIOS (6 destacados) ──────────────────────────────
$servicios_preview = [];
if (isset($conexion)) {
    $qs = $conexion->query(
        "SELECT icono, titulo, definicion, slug, color, precio_base
         FROM servicios WHERE activo = 1
         ORDER BY destacado DESC, orden ASC LIMIT 6"
    );
    if ($qs) while ($s = $qs->fetch_assoc()) $servicios_preview[] = $s;
}

// ── 3. PROYECTOS (4 públicos recientes) ──────────────────────
$proyectos_preview = [];
if (isset($conexion)) {
    $qp = $conexion->query(
        "SELECT id, titulo, descripcion, estado, progreso, icono
         FROM proyectos WHERE privado = 0
         ORDER BY fecha_creacion DESC LIMIT 4"
    );
    if ($qp) while ($p = $qp->fetch_assoc()) $proyectos_preview[] = $p;
}

// ── 4. EQUIPO (usuarios disponibles) ─────────────────────────
$equipo_lista = [];
if (isset($conexion)) {
    $qe = $conexion->query(
        "SELECT nombre, apellido, avatar, ocupacion, cargo_equipo, rol
         FROM usuarios
         WHERE activo = 1 AND disponible = 1
         ORDER BY id ASC LIMIT 6"
    );
    if ($qe) while ($e = $qe->fetch_assoc()) $equipo_lista[] = $e;
}

// ── 5. HERRAMIENTAS IA (3 primeras activas) ───────────────────
$ia_tools = [];
if (isset($conexion)) {
    $qi = $conexion->query(
        "SELECT icono, nombre, descripcion
         FROM ia_herramientas WHERE activo = 1
         ORDER BY id ASC LIMIT 3"
    );
    if ($qi) while ($h = $qi->fetch_assoc()) $ia_tools[] = $h;
}

// ── 6. PUBLICACIONES (3 más recientes) ───────────────────────
$publicaciones = [];
if (isset($conexion)) {
    $qpub = $conexion->query(
        "SELECT id, titulo, resumen, fecha_pub
         FROM publicaciones WHERE publicado = 1
         ORDER BY fecha_pub DESC LIMIT 3"
    );
    if ($qpub) while ($pub = $qpub->fetch_assoc()) $publicaciones[] = $pub;
}

// ── 7. GALERÍAS (6 activas ordenadas) ────────────────────────
$galerias = [];
if (isset($conexion)) {
    $qg = $conexion->query(
        "SELECT titulo, imagen
         FROM galerias WHERE activo = 1
         ORDER BY orden ASC LIMIT 6"
    );
    if ($qg) while ($g = $qg->fetch_assoc()) $galerias[] = $g;
}

// ── 8. NOTICIAS SIDEBAR (3 más recientes) ────────────────────
$noticias = [];
if (isset($conexion)) {
    $qn = $conexion->query(
        "SELECT titulo, fecha
         FROM noticias WHERE activo = 1
         ORDER BY fecha DESC LIMIT 3"
    );
    if ($qn) while ($n = $qn->fetch_assoc()) $noticias[] = $n;
}

// ── Mapa de colores accent para servicios ────────────────────
$color_accent = [
    'green'  => '#35d4a8', 'blue'   => '#93c5fd', 'purple' => '#c4b5fd',
    'gold'   => '#f0c840', 'red'    => '#fca5a5', 'teal'   => '#5eead4',
    'orange' => '#fdba74', 'indigo' => '#a5b4fc', 'cyan'   => '#67e8f9',
    'emerald'=> '#6ee7b7', 'slate'  => '#94a3b8', 'amber'  => '#fde68a',
    'violet' => '#c4b5fd', 'rose'   => '#fda4af', 'pink'   => '#f9a8d4',
    'sky'    => '#7dd3fc',
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title><?= htmlspecialchars($nombre_sistema) ?> — Inicio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ════════════════════════════════════════════════════════
       VARIABLES & RESET
    ════════════════════════════════════════════════════════ */
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --sh-md:0 10px 36px rgba(0,0,0,.5);
      --r-sm:8px;--r-md:14px;--r-lg:22px;
      --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
      --hh:68px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);overflow-x:hidden;}
    a{text-decoration:none;color:inherit;}
    button{cursor:pointer;border:none;font-family:inherit;}
    ::-webkit-scrollbar{width:5px;}
    ::-webkit-scrollbar-track{background:var(--n800);}
    ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}

    /* ════════════════════════════════════════════════════════
       HEADER
    ════════════════════════════════════════════════════════ */
    .site-header{
      position:sticky;top:0;z-index:900;height:var(--hh);
      background:rgba(2,8,23,.92);backdrop-filter:blur(20px);
      border-bottom:1px solid rgba(40,166,128,.2);
      transition:box-shadow .3s;
    }
    .site-header.hdr-on{box-shadow:0 4px 40px rgba(0,0,0,.65);border-bottom-color:rgba(218,165,32,.25);}
    .header-inner{max-width:1480px;margin:auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 28px;}
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-hex{font-size:1.5rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green));}
    .brand-name{font-family:var(--font-d);font-size:1.3rem;font-weight:900;color:var(--gold);letter-spacing:4px;text-shadow:0 0 18px rgba(218,165,32,.5);}
    .main-nav{display:flex;align-items:center;gap:4px;}
    .nav-link{padding:8px 14px;border-radius:var(--r-sm);font-weight:600;font-size:.88rem;color:var(--muted);transition:all .2s;}
    .nav-link:hover,.nav-link.active{color:var(--txt);background:rgba(255,255,255,.06);}
    .nav-link.active{color:var(--green-lt);border-bottom:2px solid var(--green);}
    .nav-cta{margin-left:12px;padding:9px 20px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.88rem;transition:all .2s;}
    .nav-cta:hover{background:var(--gold);transform:translateY(-2px);}
    .user-wrap{position:relative;margin-left:12px;}
    .user-pill{display:flex;align-items:center;gap:8px;padding:8px 16px;background:var(--green-dim);border:1px solid var(--green);border-radius:99px;color:var(--txt);font-weight:600;font-size:.88rem;transition:background .2s;}
    .user-drop{display:none;position:absolute;right:0;top:calc(100% + 10px);background:var(--n600);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-md);min-width:200px;overflow:hidden;box-shadow:var(--sh-md);z-index:200;}
    .user-wrap:hover .user-drop{display:block;}
    .user-drop a{display:flex;align-items:center;gap:10px;padding:12px 16px;font-size:.88rem;color:var(--txt);transition:background .2s;}
    .user-drop a:hover{background:rgba(255,255,255,.06);}
    .drop-danger{color:#f87171!important;}
    .burger{display:none;flex-direction:column;gap:5px;padding:8px;background:none;}
    .burger span{display:block;width:24px;height:2px;background:var(--txt);border-radius:99px;transition:transform .3s,opacity .3s;}
    .burger-x span:nth-child(1){transform:translateY(7px) rotate(45deg);}
    .burger-x span:nth-child(2){opacity:0;}
    .burger-x span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}

    /* ════════════════════════════════════════════════════════
       HERO SLIDER
    ════════════════════════════════════════════════════════ */
    .hero{
      position:relative;min-height:100vh;
      display:flex;align-items:center;
      overflow:hidden;
      background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,var(--n900) 70%);
    }
    .hero-bg{position:absolute;inset:0;z-index:0;}
    .hgrid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:52px 52px;}
    .orb{position:absolute;border-radius:50%;filter:blur(90px);}
    .orb-a{width:500px;height:500px;background:radial-gradient(circle,rgba(40,166,128,.18),transparent 70%);top:-100px;left:-100px;animation:orbf 10s ease-in-out infinite;}
    .orb-b{width:400px;height:400px;background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-80px;right:-60px;animation:orbf 13s ease-in-out infinite reverse;}
    .orb-c{width:300px;height:300px;background:radial-gradient(circle,rgba(59,130,246,.08),transparent 70%);top:40%;left:50%;transform:translate(-50%,-50%);animation:orbf 8s ease-in-out infinite;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}

    .hslider{position:relative;z-index:1;width:100%;max-width:1100px;margin:0 auto;padding:80px 40px 100px;}
    .hslide{display:none;animation:slidein .6s ease both;}
    .hslide--on{display:flex;align-items:center;gap:60px;}
    @keyframes slidein{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:none}}
    .hslide-content{flex:1;}
    .htag{display:inline-block;padding:5px 14px;background:var(--green-dim);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.75rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:18px;}
    .htag--gold{background:var(--gold-dim);border-color:rgba(218,165,32,.35);color:var(--gold-lt);}
    .htag--green{background:var(--green-dim);border-color:rgba(40,166,128,.35);color:var(--green-lt);}
    .htitle{font-family:var(--font-d);font-size:clamp(2rem,4vw,3.4rem);font-weight:900;color:var(--txt);line-height:1.1;margin-bottom:16px;letter-spacing:1px;}
    .htitle--mv{font-size:clamp(1.8rem,3.2vw,2.8rem);}
    .haccent{color:var(--gold);text-shadow:0 0 30px rgba(218,165,32,.5);font-style:normal;}
    .hsub{font-size:1rem;color:var(--muted);line-height:1.7;margin-bottom:28px;max-width:540px;}
    .hbody{font-size:.95rem;color:var(--muted);line-height:1.8;margin-bottom:28px;max-width:540px;}
    .hbtns{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:40px;}
    .btn-primary{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.9rem;transition:all .2s;}
    .btn-primary:hover{background:var(--gold);transform:translateY(-2px);}
    .btn-outline{display:inline-flex;align-items:center;gap:8px;padding:12px 24px;background:transparent;border:1px solid rgba(255,255,255,.2);color:var(--txt);border-radius:var(--r-md);font-weight:600;font-size:.9rem;transition:all .2s;}
    .btn-outline:hover,.btn-outline--gold:hover{border-color:var(--gold);color:var(--gold);}
    .btn-outline--green:hover{border-color:var(--green);color:var(--green-lt);}
    .btn-sm{padding:9px 18px;font-size:.82rem;}
    .hstats{display:inline-flex;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-lg);overflow:hidden;}
    .hst{padding:14px 22px;text-align:center;border-right:1px solid rgba(255,255,255,.07);}
    .hst:last-child{border-right:none;}
    .hst-n{display:block;font-family:var(--font-d);font-size:1.7rem;font-weight:900;color:var(--gold);}
    .hst-l{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;}

    /* Deco anillos */
    .hslide-deco{flex-shrink:0;width:210px;height:210px;position:relative;display:flex;align-items:center;justify-content:center;}
    .dring{position:absolute;border-radius:50%;border:1px solid rgba(218,165,32,.25);}
    .dring-a{inset:0;animation:hspin 10s linear infinite;}
    .dring-b{inset:30px;border-color:rgba(218,165,32,.15);animation:hspin 7s linear infinite reverse;}
    .dring--green{border-color:rgba(40,166,128,.25);}
    @keyframes hspin{to{transform:rotate(360deg)}}
    .dico{font-size:3.2rem;position:relative;z-index:1;}

    /* Controles hero */
    .hcontrols{position:absolute;bottom:32px;left:50%;transform:translateX(-50%);display:flex;align-items:center;gap:16px;z-index:2;}
    .hctrl{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.15);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
    .hctrl:hover{background:var(--green);color:#fff;}
    .hdots{display:flex;gap:8px;}
    .hdot{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.2);border:none;cursor:pointer;transition:all .2s;padding:0;}
    .hdot--on{background:var(--green);width:24px;border-radius:99px;}
    .scroll-pill{position:absolute;bottom:24px;right:40px;width:24px;height:40px;border:2px solid rgba(255,255,255,.15);border-radius:99px;display:flex;justify-content:center;padding-top:6px;}
    .scroll-ball{width:4px;height:8px;background:var(--green);border-radius:99px;animation:sball 1.6s ease-in-out infinite;}
    @keyframes sball{0%,100%{transform:translateY(0);opacity:1}80%{transform:translateY(12px);opacity:0}}

    /* ════════════════════════════════════════════════════════
       BANDA MANUAL
    ════════════════════════════════════════════════════════ */
    .manual-band{
      background:linear-gradient(135deg,rgba(40,166,128,.1),rgba(218,165,32,.06));
      border-top:1px solid rgba(40,166,128,.18);
      border-bottom:1px solid rgba(40,166,128,.18);
    }
    .manual-band-inner{max-width:1200px;margin:auto;padding:18px 28px;display:flex;align-items:center;gap:16px;}
    .mb-icon{font-size:2rem;}
    .mb-text{flex:1;}
    .mb-text strong{display:block;color:var(--txt);font-size:.92rem;margin-bottom:2px;}
    .mb-text span{font-size:.8rem;color:var(--muted);}
    .mb-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.83rem;transition:all .2s;white-space:nowrap;}
    .mb-btn:hover{background:var(--gold);transform:translateY(-2px);}

    /* ════════════════════════════════════════════════════════
       PAGE LAYOUT
    ════════════════════════════════════════════════════════ */
    .page-layout{max-width:1480px;margin:0 auto;display:grid;grid-template-columns:220px 1fr;padding:0 0 60px;}

    /* ════════════════════════════════════════════════════════
       SIDEBAR
    ════════════════════════════════════════════════════════ */
    .sidebar{
      padding:28px 18px;
      border-right:1px solid rgba(255,255,255,.06);
      position:sticky;top:var(--hh);
      height:calc(100vh - var(--hh));
      overflow-y:auto;
    }
    .sidebar::-webkit-scrollbar{width:3px;}
    .sb-top{margin-bottom:16px;}
    .sb-label{font-size:.65rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;}
    .sb-rule{height:1px;background:rgba(255,255,255,.06);margin-top:8px;}
    .snav{display:flex;flex-direction:column;gap:2px;margin-bottom:24px;}
    .snav-lnk{display:flex;align-items:center;gap:10px;padding:9px 12px;border-radius:10px;font-size:.8rem;color:var(--muted);transition:all .2s;}
    .snav-lnk:hover,.snav-lnk.snav-on{background:var(--green-dim);color:var(--green-lt);}
    .si{font-size:.95rem;width:18px;text-align:center;}
    .sa{margin-left:auto;font-size:.75rem;opacity:.4;}
    .sb-news{margin-top:4px;}
    .sb-news-title{font-size:.65rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1px;margin-bottom:10px;}
    .news-row{display:flex;gap:8px;margin-bottom:10px;align-items:flex-start;}
    .ndot{width:6px;height:6px;border-radius:50%;background:var(--green);flex-shrink:0;margin-top:5px;}
    .nttl{font-size:.73rem;color:var(--txt);line-height:1.35;}
    .ndt{font-size:.64rem;color:var(--dim);}
    .nempty{font-size:.75rem;color:var(--dim);}

    /* ════════════════════════════════════════════════════════
       MAIN CONTENT
    ════════════════════════════════════════════════════════ */
    .vmain{padding:36px 40px;}

    /* Secciones */
    .vsec{margin-bottom:56px;opacity:0;transform:translateY(20px);transition:opacity .5s,transform .5s;}
    .vsec-in{opacity:1;transform:none;}
    .vsec-hd{display:flex;align-items:center;gap:14px;margin-bottom:22px;}
    .vnum{font-family:var(--font-d);font-size:.7rem;color:var(--dim);letter-spacing:1px;}
    .vttl{font-family:var(--font-d);font-size:1.05rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
    .vline{flex:1;height:1px;background:rgba(255,255,255,.07);}
    .vmore{font-size:.75rem;color:var(--green-lt);font-weight:700;padding:5px 12px;border-radius:99px;border:1px solid rgba(40,166,128,.3);transition:all .2s;white-space:nowrap;}
    .vmore:hover{background:var(--green);color:#fff;}
    .vempty{display:flex;flex-direction:column;align-items:center;gap:10px;padding:36px;background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);border-radius:var(--r-lg);color:var(--dim);font-size:.82rem;text-align:center;}
    .vempty span{font-size:2rem;}

    /* Grids */
    .vgrid{display:grid;gap:16px;}
    .g3{grid-template-columns:repeat(3,1fr);}
    .g2{grid-template-columns:repeat(2,1fr);}

    /* Servicios */
    .vcard{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:20px;transition:transform .2s,box-shadow .2s;}
    .vcard:hover{transform:translateY(-4px);box-shadow:var(--sh-md);}
    .vc-ico{font-size:2rem;margin-bottom:10px;}
    .vc-title{font-size:.92rem;font-weight:800;color:var(--txt);margin-bottom:6px;}
    .vc-desc{font-size:.76rem;color:var(--muted);line-height:1.55;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;}
    .vc-link{font-size:.74rem;color:var(--green-lt);font-weight:700;transition:color .2s;}
    .vc-link:hover{color:var(--gold);}
    .vcbadge{display:inline-block;font-size:.62rem;padding:3px 10px;border-radius:99px;background:var(--gold-dim);color:var(--gold-lt);font-weight:700;}
    .vcard-ph{opacity:.65;}

    /* Proyectos */
    .proj-card{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:20px;transition:transform .2s;}
    .proj-card:hover{transform:translateY(-3px);}
    .proj-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;}
    .vbadge{padding:3px 10px;border-radius:99px;font-size:.64rem;font-weight:700;}
    .vb-green{background:rgba(40,166,128,.15);color:var(--green-lt);}
    .vb-gold{background:var(--gold-dim);color:var(--gold-lt);}
    .vb-blue{background:rgba(59,130,246,.15);color:#93c5fd;}
    .proj-id{font-size:.64rem;color:var(--dim);}
    .proj-ttl{font-size:.9rem;font-weight:800;color:var(--txt);margin-bottom:6px;}
    .proj-desc{font-size:.76rem;color:var(--muted);line-height:1.5;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
    .prog-bar-wrap{height:4px;background:rgba(255,255,255,.06);border-radius:99px;margin-bottom:12px;overflow:hidden;}
    .prog-bar-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;}

    /* Equipo */
    .team-row{display:flex;gap:20px;flex-wrap:wrap;}
    .tmember{text-align:center;cursor:pointer;transition:transform .2s;}
    .tmember:hover{transform:translateY(-4px);}
    .tm-wrap{position:relative;width:80px;height:80px;margin:0 auto 10px;}
    .tm-img{width:100%;height:100%;border-radius:50%;object-fit:cover;border:2px solid var(--green);}
    .tm-ring{position:absolute;inset:-4px;border-radius:50%;border:1px dashed rgba(40,166,128,.4);animation:hspin 8s linear infinite;}
    .tm-glow{position:absolute;inset:-8px;border-radius:50%;background:radial-gradient(circle,rgba(40,166,128,.12),transparent 70%);}
    .tm-name{font-size:.8rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
    .tm-role{font-size:.66rem;color:var(--muted);}

    /* IA */
    .ia-hero{display:grid;grid-template-columns:1fr auto;gap:24px;align-items:center;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:26px;margin-bottom:20px;}
    .ia-hero-txt h3{font-size:1.05rem;font-weight:800;color:var(--txt);margin-bottom:8px;}
    .ia-hero-txt p{font-size:.82rem;color:var(--muted);line-height:1.65;margin-bottom:16px;}
    .ia-anim{position:relative;width:90px;height:90px;display:flex;align-items:center;justify-content:center;flex-shrink:0;}
    .ia-c{position:absolute;border-radius:50%;border:1px solid;}
    .ia-c1{inset:0;border-color:rgba(40,166,128,.3);animation:hspin 6s linear infinite;}
    .ia-c2{inset:14px;border-color:rgba(218,165,32,.2);animation:hspin 4s linear infinite reverse;}
    .ia-c3{inset:26px;border-color:rgba(40,166,128,.15);animation:hspin 8s linear infinite;}
    .ia-ico{font-size:1.8rem;position:relative;z-index:1;}
    .vc-ia{border-color:rgba(40,166,128,.15);}

    /* Publicaciones */
    .pub-card{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:20px;transition:transform .2s;}
    .pub-card:hover{transform:translateY(-3px);}
    .pub-date{font-size:.64rem;color:var(--green-lt);font-weight:700;text-transform:uppercase;letter-spacing:1px;}
    .pub-ttl{font-size:.88rem;font-weight:800;color:var(--txt);margin:6px 0;}
    .pub-desc{font-size:.76rem;color:var(--muted);line-height:1.5;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}

    /* Galería mosaico */
    .gmosaic{display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:160px 160px;gap:10px;}
    .gmi{position:relative;overflow:hidden;border-radius:var(--r-md);cursor:pointer;background:var(--n600);}
    .gmi-big{grid-column:span 2;grid-row:span 2;}
    .gmi img{width:100%;height:100%;object-fit:cover;transition:transform .4s;}
    .gmi:hover img{transform:scale(1.06);}
    .gmi-ov{position:absolute;inset:0;background:rgba(0,0,0,.5);display:flex;flex-direction:column;align-items:center;justify-content:center;opacity:0;transition:opacity .3s;gap:8px;}
    .gmi:hover .gmi-ov{opacity:1;}
    .gmi-tit{font-size:.78rem;font-weight:700;color:#fff;text-align:center;padding:0 10px;}
    .gmi-empty{display:flex;align-items:center;justify-content:center;font-size:2rem;opacity:.25;}

    /* Contacto */
    .contact-strip{display:flex;align-items:center;gap:20px;flex-wrap:wrap;padding:22px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);}
    .ci{display:flex;align-items:center;gap:12px;}
    .ci-ico{font-size:1.3rem;}
    .ci-lbl{display:block;font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;}
    .ci-val{font-size:.85rem;color:var(--txt);font-weight:600;}

    /* Acerca */
    .about-card{display:flex;gap:20px;align-items:flex-start;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;}
    .about-hex{font-size:2.8rem;color:var(--green);filter:drop-shadow(0 0 10px var(--green));flex-shrink:0;}
    .about-body h3{font-family:var(--font-d);font-size:.95rem;color:var(--gold);margin-bottom:10px;}
    .about-body p{font-size:.85rem;color:var(--muted);line-height:1.7;}

    /* Modal galería */
    .vmodal{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;display:none;align-items:center;justify-content:center;}
    .vmodal-on{display:flex;}
    .vmodal-box{position:relative;max-width:90vw;max-height:90vh;border-radius:var(--r-lg);overflow:hidden;}
    .vmodal-box img{max-width:100%;max-height:85vh;display:block;}
    .vmodal-close{position:absolute;top:12px;right:12px;width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.15);color:#fff;border:none;cursor:pointer;font-size:.85rem;display:flex;align-items:center;justify-content:center;}
    .vmodal-cap{text-align:center;padding:12px;font-size:.8rem;color:var(--muted);}

    /* Footer */
    .site-footer{background:#050d1a;border-top:1px solid rgba(40,166,128,.12);padding:28px;}
    .footer-inner{max-width:1480px;margin:auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;}
    .footer-brand{display:flex;align-items:center;gap:10px;}
    .footer-copy{font-size:.78rem;color:var(--dim);}
    .footer-nav{display:flex;gap:18px;}
    .footer-nav a{font-size:.78rem;color:var(--dim);font-weight:600;transition:color .2s;}
    .footer-nav a:hover{color:var(--green);}

    /* ════════════════════════════════════════════════════════
       RESPONSIVE
    ════════════════════════════════════════════════════════ */
    @media(max-width:1100px){.g3{grid-template-columns:repeat(2,1fr);}}
    @media(max-width:820px){
      .burger{display:flex;}
      .main-nav{position:fixed;top:var(--hh);left:0;right:0;background:var(--n800);flex-direction:column;padding:20px;gap:6px;border-bottom:1px solid rgba(255,255,255,.06);transform:translateY(-110%);transition:transform .35s ease;z-index:999;}
      .nav-open{transform:translateY(0)!important;}
      .page-layout{grid-template-columns:1fr;}
      .sidebar{display:none;}
      .vmain{padding:24px 20px;}
      .g3,.g2{grid-template-columns:1fr;}
      .gmosaic{grid-template-columns:1fr 1fr;grid-template-rows:auto;}
      .gmi-big{grid-column:span 2;grid-row:span 1;}
      .hslide--on{flex-direction:column;gap:30px;}
      .hslide-deco{width:160px;height:160px;}
      .ia-hero{grid-template-columns:1fr;}
      .contact-strip{flex-direction:column;align-items:flex-start;}
    }
    @media(max-width:520px){
      .g3,.g2{grid-template-columns:1fr;}
      .hslider{padding:60px 20px 80px;}
    }
  </style>
</head>
<body>

<!-- ════════════════════════════════════════════════════════════
     HEADER
════════════════════════════════════════════════════════════ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name"><?= htmlspecialchars($nombre_sistema) ?></span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link active">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php"        class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php"        class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>
      <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span class="user-av"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuario') ?></span>
            <i class="fa fa-chevron-down fa-xs"></i>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Cerrar sesión</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ════════════════════════════════════════════════════════════
     HERO SLIDER — datos desde BD (configuracion)
════════════════════════════════════════════════════════════ -->
<section class="hero">
  <div class="hero-bg">
    <div class="hgrid"></div>
    <div class="orb orb-a"></div>
    <div class="orb orb-b"></div>
    <div class="orb orb-c"></div>
  </div>

  <div class="hslider" id="hslider">

    <!-- Slide 1: Bienvenida -->
    <div class="hslide hslide--on" data-i="0">
      <div class="hslide-content">
        <span class="htag"><?= htmlspecialchars($hero_s1_tag) ?></span>
        <h1 class="htitle">
          Bienvenidos a<br>
          <em class="haccent"><?= htmlspecialchars($nombre_sistema) ?></em>
        </h1>
        <p class="hsub"><?= htmlspecialchars($hero_s1_cuerpo) ?></p>
        <div class="hbtns">
          <a href="#servicios" class="btn-primary"><i class="fa fa-compass"></i> Explorar</a>
          <a href="proyecto.php" class="btn-outline">Conocer proyecto <i class="fa fa-arrow-right fa-xs"></i></a>
        </div>
        <div class="hstats">
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_modulos ?>">0</span>
            <span class="hst-l">Módulos</span>
          </div>
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_roles ?>">0</span>
            <span class="hst-l">Roles</span>
          </div>
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_regiones ?>">0</span>
            <span class="hst-l">Regiones</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Slide 2: Misión -->
    <div class="hslide" data-i="1">
      <div class="hslide-content">
        <span class="htag htag--gold"><?= htmlspecialchars($hero_s2_tag) ?></span>
        <h2 class="htitle htitle--mv">Misión</h2>
        <p class="hbody"><?= htmlspecialchars($mision) ?></p>
        <a href="proyecto.php#mision" class="btn-outline btn-outline--gold">
          Leer más <i class="fa fa-arrow-right fa-xs"></i>
        </a>
      </div>
      <div class="hslide-deco">
        <div class="dring dring-a"></div>
        <div class="dring dring-b"></div>
        <span class="dico">🎯</span>
      </div>
    </div>

    <!-- Slide 3: Visión -->
    <div class="hslide" data-i="2">
      <div class="hslide-content">
        <span class="htag htag--green"><?= htmlspecialchars($hero_s3_tag) ?></span>
        <h2 class="htitle htitle--mv">Visión</h2>
        <p class="hbody"><?= htmlspecialchars($vision) ?></p>
        <a href="proyecto.php#vision" class="btn-outline btn-outline--green">
          Leer más <i class="fa fa-arrow-right fa-xs"></i>
        </a>
      </div>
      <div class="hslide-deco">
        <div class="dring dring-a dring--green"></div>
        <div class="dring dring-b dring--green"></div>
        <span class="dico">🔭</span>
      </div>
    </div>

  </div><!-- /hslider -->

  <div class="hcontrols">
    <button class="hctrl" id="hPrev"><i class="fa fa-chevron-left"></i></button>
    <div class="hdots" id="hdots">
      <button class="hdot hdot--on" data-g="0"></button>
      <button class="hdot" data-g="1"></button>
      <button class="hdot" data-g="2"></button>
    </div>
    <button class="hctrl" id="hNext"><i class="fa fa-chevron-right"></i></button>
  </div>
  <div class="scroll-pill"><div class="scroll-ball"></div></div>
</section>


<!-- ════════════════════════════════════════════════════════════
     BANDA MANUAL — desde BD
════════════════════════════════════════════════════════════ -->
<div class="manual-band">
  <div class="manual-band-inner">
    <div class="mb-icon">📖</div>
    <div class="mb-text">
      <strong><?= htmlspecialchars($manual_titulo) ?></strong>
      <span><?= htmlspecialchars($manual_sub) ?></span>
    </div>
    <a href="<?= htmlspecialchars($manual_url) ?>" class="mb-btn" target="_blank">
      <i class="fa fa-book-open"></i> Ver Manual
    </a>
  </div>
</div>


<!-- ════════════════════════════════════════════════════════════
     LAYOUT
════════════════════════════════════════════════════════════ -->
<div class="page-layout">

  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="sb-top">
      <span class="sb-label">Índice</span>
      <div class="sb-rule"></div>
    </div>
    <nav class="snav">
      <?php
        $nav_items = [
          ['#servicios',    '🛠','Servicios'],
          ['#proyectos',    '🚀','Proyectos'],
          ['#equipo',       '👥','Equipo'],
          ['#ia',           '🤖','IA'],
          ['#publicaciones','📄','Publicaciones'],
          ['#galerias',     '🖼','Galerías'],
          ['#contacto',     '📞','Contacto'],
          ['#acerca',       'ℹ', 'Acerca de'],
        ];
        foreach ($nav_items as [$href, $ico, $lbl]):
      ?>
      <a href="<?= $href ?>" class="snav-lnk">
        <span class="si"><?= $ico ?></span>
        <span><?= $lbl ?></span>
        <span class="sa">›</span>
      </a>
      <?php endforeach; ?>
    </nav>

    <!-- Noticias desde BD -->
    <div class="sb-news">
      <p class="sb-news-title">📌 Noticias</p>
      <?php if (!empty($noticias)): ?>
        <?php foreach ($noticias as $n): ?>
        <div class="news-row">
          <span class="ndot"></span>
          <div>
            <p class="nttl"><?= htmlspecialchars($n['titulo']) ?></p>
            <span class="ndt"><?= date('d M Y', strtotime($n['fecha'])) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="nempty">Sin noticias recientes.</p>
      <?php endif; ?>
    </div>
  </aside>


  <!-- MAIN -->
  <main class="vmain">

    <!-- ══ 01 SERVICIOS ════════════════════════════════════════ -->
    <section id="servicios" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">01</span>
        <h2 class="vttl">Servicios</h2>
        <div class="vline"></div>
        <a href="servicios.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="vgrid g3">
        <?php if (!empty($servicios_preview)): ?>
          <?php foreach ($servicios_preview as $s):
            $acc = $color_accent[$s['color']] ?? '#35d4a8';
          ?>
          <div class="vcard" style="border-color:<?= $acc ?>22;">
            <div class="vc-ico"><?= htmlspecialchars($s['icono'] ?? '🛠') ?></div>
            <h3 class="vc-title"><?= htmlspecialchars($s['titulo']) ?></h3>
            <p class="vc-desc"><?= htmlspecialchars(mb_substr($s['definicion'] ?? '', 0, 120)) ?>...</p>
            <a href="servicios.php#<?= htmlspecialchars($s['slug']) ?>" class="vc-link">Ver servicio ›</a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <?php
            $ph = [['🔐','Seguridad Ofensiva','Pentesting y análisis de vulnerabilidades.'],
                   ['🛡','Defensa Digital','Hardening y protección de sistemas.'],
                   ['🧠','IA Aplicada','Inteligencia artificial en ciberseguridad.'],
                   ['🌐','Redes Seguras','Auditoría de infraestructuras de red.'],
                   ['🔍','Análisis Forense','Investigación de evidencia digital.'],
                   ['📊','Consultoría','Asesoría en seguridad informática.']];
            foreach ($ph as [$i,$n,$d]):
          ?>
          <div class="vcard vcard-ph">
            <div class="vc-ico"><?= $i ?></div>
            <h3 class="vc-title"><?= $n ?></h3>
            <p class="vc-desc"><?= $d ?></p>
            <span class="vcbadge">Próximamente</span>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </section>


    <!-- ══ 02 PROYECTOS ════════════════════════════════════════ -->
    <section id="proyectos" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">02</span>
        <h2 class="vttl">Proyectos</h2>
        <div class="vline"></div>
        <a href="proyecto.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="vgrid g2">
        <?php if (!empty($proyectos_preview)): ?>
          <?php foreach ($proyectos_preview as $p):
            $label = match($p['estado'] ?? '') {
              'completado' => 'Completado', 'pausado'  => 'Pausado',
              'planeado'   => 'Planeado',   'cancelado'=> 'Cancelado',
              default      => 'En progreso',
            };
            $bc = match($p['estado'] ?? '') {
              'completado' => 'vb-green', 'planeado' => 'vb-blue', default => 'vb-gold',
            };
            $prog = min(100, max(0, (int)($p['progreso'] ?? 0)));
          ?>
          <div class="proj-card">
            <div class="proj-top">
              <span class="vbadge <?= $bc ?>">
                <?= htmlspecialchars($p['icono'] ?? '🚀') ?> <?= $label ?>
              </span>
              <span class="proj-id">#<?= (int)$p['id'] ?></span>
            </div>
            <h3 class="proj-ttl"><?= htmlspecialchars($p['titulo']) ?></h3>
            <p class="proj-desc"><?= htmlspecialchars(mb_substr($p['descripcion'] ?? '', 0, 140)) ?>...</p>
            <?php if ($prog > 0): ?>
            <div class="prog-bar-wrap">
              <div class="prog-bar-fill" style="width:<?= $prog ?>%;"></div>
            </div>
            <?php endif; ?>
            <a href="proyecto.php?id=<?= (int)$p['id'] ?>" class="vc-link">
              Ver proyecto <i class="fa fa-arrow-right fa-xs"></i>
            </a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty"><span>🚀</span><p>Los proyectos se cargarán desde la base de datos.</p></div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ══ 03 EQUIPO ═══════════════════════════════════════════ -->
    <section id="equipo" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">03</span>
        <h2 class="vttl">Equipo</h2>
        <div class="vline"></div>
        <a href="equipo.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="team-row">
        <?php if (!empty($equipo_lista)): ?>
          <?php foreach ($equipo_lista as $e):
            $img = !empty($e['avatar'])
              ? htmlspecialchars($e['avatar'], ENT_QUOTES)
              : 'assets/avatar-default.png';
            $nm  = htmlspecialchars(trim(($e['nombre'] ?? '') . ' ' . ($e['apellido'] ?? '')));
            $rol = htmlspecialchars($e['cargo_equipo'] ?? $e['ocupacion'] ?? $e['rol'] ?? '—');
          ?>
          <div class="tmember">
            <div class="tm-wrap">
              <img src="<?= $img ?>" alt="<?= $nm ?>" class="tm-img"
                   onerror="this.src='assets/avatar-default.png'">
              <div class="tm-ring"></div>
              <div class="tm-glow"></div>
            </div>
            <p class="tm-name"><?= $nm ?></p>
            <span class="tm-role"><?= $rol ?></span>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty"><span>👥</span><p>El equipo se cargará desde la base de datos.</p></div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ══ 04 INTELIGENCIA ARTIFICIAL ══════════════════════════ -->
    <section id="ia" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">04</span>
        <h2 class="vttl">Inteligencia Artificial</h2>
        <div class="vline"></div>
        <a href="IA.php" class="vmore">Explorar ›</a>
      </div>
      <div class="ia-hero">
        <div class="ia-hero-txt">
          <h3><?= htmlspecialchars($ia_titulo) ?></h3>
          <p><?= htmlspecialchars($ia_desc) ?></p>
          <a href="IA.php" class="btn-primary btn-sm"><i class="fa fa-robot"></i> Explorar IA</a>
        </div>
        <div class="ia-anim">
          <div class="ia-c ia-c1"></div>
          <div class="ia-c ia-c2"></div>
          <div class="ia-c ia-c3"></div>
          <span class="ia-ico">🤖</span>
        </div>
      </div>
      <?php if (!empty($ia_tools)): ?>
      <div class="vgrid g3">
        <?php foreach ($ia_tools as $h): ?>
        <div class="vcard vc-ia">
          <div class="vc-ico"><?= htmlspecialchars($h['icono'] ?? '🤖') ?></div>
          <h3 class="vc-title"><?= htmlspecialchars($h['nombre']) ?></h3>
          <p class="vc-desc"><?= htmlspecialchars($h['descripcion']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </section>


    <!-- ══ 05 PUBLICACIONES ════════════════════════════════════ -->
    <section id="publicaciones" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">05</span>
        <h2 class="vttl">Publicaciones</h2>
        <div class="vline"></div>
        <a href="publicaciones.php" class="vmore">Ver todas ›</a>
      </div>
      <div class="vgrid g3">
        <?php if (!empty($publicaciones)): ?>
          <?php foreach ($publicaciones as $pub):
            $fecha = !empty($pub['fecha_pub'])
              ? date('d M Y', strtotime($pub['fecha_pub'])) : '—';
          ?>
          <div class="pub-card">
            <span class="pub-date"><?= $fecha ?></span>
            <h3 class="pub-ttl"><?= htmlspecialchars($pub['titulo']) ?></h3>
            <p class="pub-desc"><?= htmlspecialchars(mb_substr($pub['resumen'] ?? '', 0, 110)) ?>...</p>
            <a href="publicaciones.php?id=<?= (int)$pub['id'] ?>" class="vc-link">Leer más ›</a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty"><span>📄</span><p>Las publicaciones se cargarán desde la base de datos.</p></div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ══ 06 GALERÍAS ═════════════════════════════════════════ -->
    <section id="galerias" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">06</span>
        <h2 class="vttl">Galerías</h2>
        <div class="vline"></div>
        <a href="galerias.php" class="vmore">Ver todas ›</a>
      </div>
      <div class="gmosaic">
        <?php if (!empty($galerias)): ?>
          <?php foreach ($galerias as $i => $g):
            $img = htmlspecialchars($g['imagen'], ENT_QUOTES);
            $tit = htmlspecialchars($g['titulo'],  ENT_QUOTES);
            $cls = ($i === 0) ? 'gmi gmi-big' : 'gmi';
          ?>
          <div class="<?= $cls ?>" onclick="openGal('<?= $img ?>','<?= $tit ?>')">
            <img src="<?= $img ?>" alt="<?= $tit ?>" loading="lazy">
            <div class="gmi-ov">
              <span class="gmi-tit"><?= $tit ?></span>
              <i class="fa fa-expand" style="color:#fff;font-size:1.1rem;"></i>
            </div>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <?php for ($i = 0; $i < 6; $i++):
            $cls = ($i === 0) ? 'gmi gmi-big gmi-empty' : 'gmi gmi-empty';
          ?>
          <div class="<?= $cls ?>"><span>🖼</span></div>
          <?php endfor; ?>
        <?php endif; ?>
      </div>
    </section>


    <!-- ══ 07 CONTACTO ═════════════════════════════════════════ -->
    <section id="contacto" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">07</span>
        <h2 class="vttl">Contacto</h2>
        <div class="vline"></div>
      </div>
      <div class="contact-strip">
        <?php foreach ([['📧','Email',$email],['🌐','Web',$web],['📍','Lugar',$ubicacion]] as [$ico,$lbl,$val]): ?>
        <div class="ci">
          <span class="ci-ico"><?= $ico ?></span>
          <div>
            <span class="ci-lbl"><?= $lbl ?></span>
            <span class="ci-val"><?= htmlspecialchars($val) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
        <a href="contacto.php" class="btn-primary" style="margin-left:auto;">
          <i class="fa fa-paper-plane"></i> Ir a contacto
        </a>
      </div>
    </section>


    <!-- ══ 08 ACERCA DE ════════════════════════════════════════ -->
    <section id="acerca" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">08</span>
        <h2 class="vttl">Acerca de</h2>
        <div class="vline"></div>
      </div>
      <div class="about-card">
        <div class="about-hex">⬡</div>
        <div class="about-body">
          <h3><?= htmlspecialchars($nombre_publico) ?></h3>
          <p><?= htmlspecialchars($acerca) ?></p>
        </div>
      </div>
    </section>

  </main>
</div><!-- /page-layout -->


<!-- Modal galería -->
<div class="vmodal" id="galModal">
  <div class="vmodal-box">
    <button class="vmodal-close" onclick="closeGal()"><i class="fa fa-times"></i></button>
    <img id="galImg" src="" alt="">
    <p id="galTitle" class="vmodal-cap"></p>
  </div>
</div>


<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name"><?= htmlspecialchars($nombre_publico) ?></span>
    </div>
    <p class="footer-copy"><?= htmlspecialchars($footer_copy) ?></p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyecto</a>
      <a href="contacto.php">Contacto</a>
      <a href="<?= htmlspecialchars($manual_url) ?>">Manual</a>
    </nav>
  </div>
</footer>


<script>
/* ── Header scroll ──────────────────────────────────────── */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));

/* ── Burger ─────────────────────────────────────────────── */
document.getElementById('burger').addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Hero Slider ─────────────────────────────────────────── */
(function () {
  const slides = document.querySelectorAll('.hslide');
  const dots   = document.querySelectorAll('.hdot');
  let cur = 0, timer;

  function go(n) {
    slides[cur].classList.remove('hslide--on');
    dots[cur].classList.remove('hdot--on');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('hslide--on');
    dots[cur].classList.add('hdot--on');
  }
  function auto()  { timer = setInterval(() => go(cur + 1), 6000); }
  function reset() { clearInterval(timer); auto(); }

  document.getElementById('hNext').onclick = () => { go(cur + 1); reset(); };
  document.getElementById('hPrev').onclick = () => { go(cur - 1); reset(); };
  dots.forEach(d => d.addEventListener('click', () => { go(+d.dataset.g); reset(); }));

  // Swipe táctil
  let tx = 0;
  const sl = document.getElementById('hslider');
  sl.addEventListener('touchstart', e => tx = e.touches[0].clientX, { passive: true });
  sl.addEventListener('touchend',   e => {
    const dx = e.changedTouches[0].clientX - tx;
    if (Math.abs(dx) > 50) { go(dx < 0 ? cur + 1 : cur - 1); reset(); }
  }, { passive: true });
  auto();
})();

/* ── Contadores animados ────────────────────────────────── */
document.querySelectorAll('.hst-n').forEach(el => {
  new IntersectionObserver(entries => {
    if (!entries[0].isIntersecting) return;
    const end = +el.dataset.target;
    let n = 0;
    const t = setInterval(() => {
      n += Math.ceil(end / 30);
      if (n >= end) { n = end; clearInterval(t); }
      el.textContent = n;
    }, 40);
  }, { threshold: 1 }).observe(el);
});

/* ── Sidebar activo ─────────────────────────────────────── */
document.querySelectorAll('section[id]').forEach(sec => {
  new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      document.querySelectorAll('.snav-lnk').forEach(l => l.classList.remove('snav-on'));
      const a = document.querySelector(`.snav-lnk[href="#${sec.id}"]`);
      if (a) a.classList.add('snav-on');
    }
  }, { rootMargin: '-30% 0px -60% 0px' }).observe(sec);
});

/* ── Reveal secciones ───────────────────────────────────── */
document.querySelectorAll('.vsec').forEach(s => {
  new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) s.classList.add('vsec-in');
  }, { threshold: 0.08 }).observe(s);
});

/* ── Modal galería ──────────────────────────────────────── */
function openGal(src, title) {
  document.getElementById('galImg').src = src;
  document.getElementById('galTitle').textContent = title;
  document.getElementById('galModal').classList.add('vmodal-on');
  document.body.style.overflow = 'hidden';
}
function closeGal() {
  document.getElementById('galModal').classList.remove('vmodal-on');
  document.body.style.overflow = '';
}
document.getElementById('galModal').addEventListener('click', function (e) {
  if (e.target === this) closeGal();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeGal(); });
</script>
</body>
</html>