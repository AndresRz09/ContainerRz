from abc import ABC, abstractmethod

class Operacion(ABC):
    @abstractmethod
    def ejecutar(self, a, b):
        pass

class Suma(Operacion):
    def ejecutar(self, a, b):
        return a + b

class Resta(Operacion):
    def ejecutar(self, a, b):
        return a - b

class Multiplicacion(Operacion):
    def ejecutar(self, a, b):
        return a * b

class Division(Operacion):
    def ejecutar(self, a, b):
        if b == 0:
            return "No se puede dividir entre cero"
        return a / b

class ProcesadorDatos:
    def __init__(self, lista_numeros):
        self.datos = lista_numeros

    def obtener_promedio(self):
        return sum(self.datos) / len(self.datos)

def mostrar_menu():
    print("\nCalculatorRz")
    print("1. Sumar")
    print("2. Restar")
    print("3. Multiplicar")
    print("4. Dividir")
    print("5. Calcular promedio")
    print("6. Salir")


def obtener_operacion(opcion):
    if opcion == "1":
        return Suma()
    elif opcion == "2":
        return Resta()
    elif opcion == "3":
        return Multiplicacion()
    elif opcion == "4":
        return Division()
    else:
        return None

while True:
    mostrar_menu()
    opcion = input("Selecciona una opción: ")

    if opcion == "6":
        print("¡Gracias!, Hasta luego")
        break

    if opcion in ["1", "2", "3", "4"]:
        try:
            a = float(input("Ingresa el primer número: "))
            b = float(input("Ingresa el segundo número: "))
        except ValueError:
            print("Debes ingresar números válidos")
            continue

        operacion = obtener_operacion(opcion)

        if operacion:
            resultado = operacion.ejecutar(a, b)
            print(f"Resultado: {resultado}")
        else:
            print("Opción inválida")

    elif opcion == "5":
        try:
            datos = input("Ingresa números separados por coma: ")
            lista = [float(x) for x in datos.split(",")]
            procesador = ProcesadorDatos(lista)
            promedio = procesador.obtener_promedio()
            print(f"El promedio es: {promedio:.2f}")
        except:
            print("Error al procesar los datos")
    else:
        print("Opción inválida")