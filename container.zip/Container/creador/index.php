<?php
// ═══════════════════════════════════════════════════════════════════════
//  VIROX — creador/index.php  |  Panel del Creador de Contenido
//  Roles permitidos: creador, admin, superadmin
// ═══════════════════════════════════════════════════════════════════════
include '../conexion.php';
session_start();

if (!isset($_SESSION['user_id']))  { header('Location: ../login.php'); exit(); }
if (!in_array($_SESSION['rol'] ?? '', ['creador','admin','superadmin'])) {
    header('Location: ../index.php'); exit();
}

$uid    = (int)$_SESSION['user_id'];
$rol    = $_SESSION['rol']      ?? 'creador';
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'Creador');
$avatar = htmlspecialchars($_SESSION['avatar']    ?? '../assets/avatar-default.png');

/* ── helpers ── */
function qrow($db,$sql,$t='',...$p):?array{
    $s=$db->prepare($sql);if(!$s)return null;
    if($t)$s->bind_param($t,...$p);
    $s->execute();$r=$s->get_result()->fetch_assoc();$s->close();return $r;
}
function qall($db,$sql,$t='',...$p):array{
    $s=$db->prepare($sql);if(!$s)return[];
    if($t)$s->bind_param($t,...$p);
    $s->execute();$rows=$s->get_result()->fetch_all(MYSQLI_ASSOC);$s->close();return $rows;
}
function qval($db,$sql,$t='',...$p):mixed{
    $r=qrow($db,$sql,$t,...$p);return $r?reset($r):0;
}
function cfg($db,string $k,$def=''){
    $r=qrow($db,"SELECT valor FROM configuracion WHERE clave=? LIMIT 1","s",$k);
    return $r?$r['valor']:$def;
}

// ═══════════════════════════════════════════════════════════════════════
//  PROCESAR ACCIONES AJAX
// ═══════════════════════════════════════════════════════════════════════
if($_SERVER['REQUEST_METHOD']==='POST'){
    header('Content-Type: application/json');
    $a=$_POST['accion']??'';

    /* ── Crear/editar contenido ── */
    if($a==='upsert_contenido'){
        $id   =(int)($_POST['id']??0);
        $titulo  =htmlspecialchars(trim($_POST['titulo']??''),ENT_QUOTES);
        $desc    =htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $tipo    =in_array($_POST['tipo']??'',['video','podcast','infografia','presentacion','audio','documento'])?$_POST['tipo']:'video';
        $tags    =htmlspecialchars(trim($_POST['tags']??''),ENT_QUOTES);
        $cat     =htmlspecialchars(trim($_POST['categoria']??''),ENT_QUOTES);
        $duracion=htmlspecialchars(trim($_POST['duracion']??''),ENT_QUOTES);
        $pub     =(int)($_POST['publicado']??0);
        $dest    =(int)($_POST['destacado']??0);
        $canal_id=(int)($_POST['canal_id']??0);

        // Verificar que el canal pertenece al usuario
        $check=qrow($conexion,"SELECT id FROM canales_ad WHERE id=? AND usuario_id=?","ii",$canal_id,$uid);
        if(!$check&&$canal_id){ echo json_encode(['ok'=>false,'error'=>'Canal no válido']); exit(); }

        if($id){
            $q=$conexion->prepare("UPDATE contenido_ad SET titulo=?,descripcion=?,tipo=?,tags=?,categoria=?,duracion=?,publicado=?,destacado=? WHERE id=? AND usuario_id=?");
            if($q){$q->bind_param("ssssssiiii",$titulo,$desc,$tipo,$tags,$cat,$duracion,$pub,$dest,$id,$uid);$q->execute();$q->close();}
            echo json_encode(['ok'=>true]);
        } else {
            if(!$titulo){echo json_encode(['ok'=>false,'error'=>'Título requerido']);exit();}
            $q=$conexion->prepare("INSERT INTO contenido_ad(canal_id,usuario_id,titulo,descripcion,tipo,tags,categoria,duracion,publicado,destacado,vistas,likes,fecha_publicacion) VALUES(?,?,?,?,?,?,?,?,?,?,0,0,NOW())");
            if($q){$q->bind_param("iissssssi i",$canal_id,$uid,$titulo,$desc,$tipo,$tags,$cat,$duracion,$pub,$dest);$q->execute();$lid=$conexion->insert_id;$q->close();echo json_encode(['ok'=>true,'id'=>$lid]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        }
        exit();
    }

    /* ── Eliminar contenido ── */
    if($a==='delete_contenido'){
        $id=(int)($_POST['id']??0);
        $q=$conexion->prepare("DELETE FROM contenido_ad WHERE id=? AND usuario_id=?");
        if($q){$q->bind_param("ii",$id,$uid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
        else echo json_encode(['ok'=>false]);
        exit();
    }

    /* ── Toggle publicado ── */
    if($a==='toggle_publicado'){
        $id=(int)($_POST['id']??0);
        $val=(int)($_POST['valor']??0);
        $q=$conexion->prepare("UPDATE contenido_ad SET publicado=? WHERE id=? AND usuario_id=?");
        if($q){$q->bind_param("iii",$val,$id,$uid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
        else echo json_encode(['ok'=>false]);
        exit();
    }

    /* ── Actualizar canal ── */
    if($a==='update_canal'){
        $canal_id=(int)($_POST['canal_id']??0);
        $nombre_c=htmlspecialchars(trim($_POST['nombre']??''),ENT_QUOTES);
        $desc_c  =htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $avatar_c=htmlspecialchars(trim($_POST['avatar']??''),ENT_QUOTES);
        if($canal_id&&$nombre_c){
            $q=$conexion->prepare("UPDATE canales_ad SET nombre=?,descripcion=?,avatar=? WHERE id=? AND usuario_id=?");
            if($q){$q->bind_param("sssii",$nombre_c,$desc_c,$avatar_c,$canal_id,$uid);$q->execute();$q->close();echo json_encode(['ok'=>true]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos inválidos']);
        exit();
    }

    /* ── Crear canal ── */
    if($a==='crear_canal'){
        $nombre_c=htmlspecialchars(trim($_POST['nombre']??''),ENT_QUOTES);
        $desc_c  =htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $av_c    =htmlspecialchars(trim($_POST['avatar']??'📺'),ENT_QUOTES);
        if($nombre_c){
            $exist=qval($conexion,"SELECT COUNT(*) FROM canales_ad WHERE usuario_id=?","i",$uid);
            if($exist>0){echo json_encode(['ok'=>false,'error'=>'Ya tienes un canal creado']);exit();}
            $q=$conexion->prepare("INSERT INTO canales_ad(usuario_id,nombre,descripcion,avatar,verificado,activo) VALUES(?,?,?,?,0,1)");
            if($q){$q->bind_param("isss",$uid,$nombre_c,$desc_c,$av_c);$q->execute();$lid=$conexion->insert_id;$q->close();echo json_encode(['ok'=>true,'id'=>$lid]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Nombre requerido']);
        exit();
    }

    /* ── Crear playlist ── */
    if($a==='crear_playlist'){
        $canal_id=(int)($_POST['canal_id']??0);
        $titulo  =htmlspecialchars(trim($_POST['titulo']??''),ENT_QUOTES);
        $desc    =htmlspecialchars(trim($_POST['descripcion']??''),ENT_QUOTES);
        $publica =(int)($_POST['publica']??1);
        $check=qrow($conexion,"SELECT id FROM canales_ad WHERE id=? AND usuario_id=?","ii",$canal_id,$uid);
        if($check&&$titulo){
            $ord=(int)qval($conexion,"SELECT COALESCE(MAX(orden),0)+1 FROM playlists_ad WHERE canal_id=?","i",$canal_id);
            $q=$conexion->prepare("INSERT INTO playlists_ad(canal_id,titulo,descripcion,publica,orden) VALUES(?,?,?,?,?)");
            if($q){$q->bind_param("issii",$canal_id,$titulo,$desc,$publica,$ord);$q->execute();$lid=$conexion->insert_id;$q->close();echo json_encode(['ok'=>true,'id'=>$lid]);}
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos inválidos']);
        exit();
    }

    /* ── Guardar nota/script ── */
    if($a==='guardar_nota'){
        $clave="nota_creador_".$uid;
        $contenido=$conexion->real_escape_string($_POST['contenido']??'');
        $q=$conexion->prepare("INSERT INTO configuracion(clave,valor,grupo,tipo) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE valor=VALUES(valor)");
        if($q){$g="creador_{$uid}";$t="texto";$q->bind_param("ssss",$clave,$contenido,$g,$t);$q->execute();$q->close();}
        echo json_encode(['ok'=>true]);
        exit();
    }

    echo json_encode(['ok'=>false,'error'=>'Acción no reconocida']);
    exit();
}

// ═══════════════════════════════════════════════════════════════════════
//  CARGAR DATOS
// ═══════════════════════════════════════════════════════════════════════

/* Mi canal */
$mi_canal = qrow($conexion,
    "SELECT ca.*, COUNT(DISTINCT s.id) AS suscriptores,
            COUNT(DISTINCT co.id) AS total_videos
     FROM canales_ad ca
     LEFT JOIN suscripciones_ad s ON s.canal_id=ca.id
     LEFT JOIN contenido_ad co ON co.canal_id=ca.id
     WHERE ca.usuario_id=? GROUP BY ca.id LIMIT 1","i",$uid
);

/* Mis contenidos */
$mis_contenidos = qall($conexion,
    "SELECT co.*, ca.nombre AS canal_nombre
     FROM contenido_ad co
     LEFT JOIN canales_ad ca ON ca.id=co.canal_id
     WHERE co.usuario_id=?
     ORDER BY co.fecha_publicacion DESC LIMIT 50","i",$uid
);

/* Stats de contenidos */
$stats_videos   = count(array_filter($mis_contenidos, fn($c)=>$c['tipo']==='video'));
$stats_podcasts = count(array_filter($mis_contenidos, fn($c)=>$c['tipo']==='podcast'));
$stats_infos    = count(array_filter($mis_contenidos, fn($c)=>$c['tipo']==='infografia'));
$stats_pub      = count(array_filter($mis_contenidos, fn($c)=>$c['publicado']));
$total_vistas   = (int)qval($conexion,"SELECT COALESCE(SUM(vistas),0) FROM contenido_ad WHERE usuario_id=?","i",$uid);
$total_likes    = (int)qval($conexion,"SELECT COALESCE(SUM(likes),0) FROM contenido_ad WHERE usuario_id=?","i",$uid);

/* Ingresos del canal */
$ing_mes = (float)qval($conexion,
    "SELECT COALESCE(SUM(monto),0) FROM ingresos_canal WHERE canal_id=? AND MONTH(fecha)=MONTH(NOW())","i",$mi_canal['id']??0
);
$ing_total = (float)qval($conexion,
    "SELECT COALESCE(SUM(monto),0) FROM ingresos_canal WHERE canal_id=?","i",$mi_canal['id']??0
);

/* Playlists */
$playlists = $mi_canal ? qall($conexion,
    "SELECT pl.*, COUNT(pc.id) AS total FROM playlists_ad pl
     LEFT JOIN playlist_contenido pc ON pc.playlist_id=pl.id
     WHERE pl.canal_id=? GROUP BY pl.id ORDER BY pl.orden ASC","i",$mi_canal['id']
) : [];

/* Comentarios recientes en mis contenidos */
$comentarios = qall($conexion,
    "SELECT c.*, co.titulo AS contenido_titulo, u.nombre AS autor_nombre, u.avatar AS autor_avatar
     FROM comentarios_ad c
     JOIN contenido_ad co ON co.id=c.contenido_id
     LEFT JOIN usuarios u ON u.id=c.usuario_id
     WHERE co.usuario_id=?
     ORDER BY c.fecha DESC LIMIT 15","i",$uid
);

/* Suscriptores recientes */
$nuevos_subs = $mi_canal ? qall($conexion,
    "SELECT s.fecha, u.nombre, u.apellido, u.avatar
     FROM suscripciones_ad s
     JOIN usuarios u ON u.id=s.usuario_id
     WHERE s.canal_id=?
     ORDER BY s.fecha DESC LIMIT 10","i",$mi_canal['id']
) : [];

/* Barras de vistas 7 días */
$barras_raw = [];
for($i=6;$i>=0;$i--){
    $dia=date('Y-m-d',strtotime("-{$i} days"));
    $v=(int)qval($conexion,
        "SELECT COALESCE(SUM(vistas),0) FROM contenido_ad WHERE usuario_id=? AND DATE(fecha_publicacion)=?","is",$uid,$dia
    );
    $barras_raw[]=['dia'=>date('D',strtotime($dia)),'val'=>$v];
}
$max_bar=max(1,max(array_column($barras_raw,'val')));

/* Nota del creador */
$mi_nota = cfg($conexion,"nota_creador_{$uid}",'');

/* Cursos creados como instructor */
$mis_cursos = qall($conexion,
    "SELECT c.*, COUNT(DISTINCT i.id) AS inscritos
     FROM cursos c
     LEFT JOIN inscripciones i ON i.curso_id=c.id
     WHERE c.instructor_id=? AND c.activo=1
     GROUP BY c.id ORDER BY c.id DESC LIMIT 12","i",$uid
);

/* Contenidos pendientes de publicar */
$borradores = array_filter($mis_contenidos, fn($c)=>!$c['publicado']);

/* Top contenidos por vistas */
$top_contenidos = qall($conexion,
    "SELECT * FROM contenido_ad WHERE usuario_id=? ORDER BY vistas DESC LIMIT 5","i",$uid
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Studio Creador — Team VIROX</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* ════════ VARIABLES (mismo sistema VIROX) ════════ */
:root{
  --n950:#010610;--n900:#020817;--n800:#0c1526;
  --n700:#111827;--n600:#182035;--n500:#1e2d47;--n400:#243450;
  --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.13);
  --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.13);
  --blue:#3b82f6;--blue-lt:#93c5fd;--blue-dim:rgba(59,130,246,.13);
  --purple:#8b5cf6;--purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
  --red:#ef4444;--red-lt:#fca5a5;--red-dim:rgba(239,68,68,.12);
  --orange:#f97316;--orange-dim:rgba(249,115,22,.13);
  --teal:#14b8a6;--teal-dim:rgba(20,184,166,.13);
  --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
  --sh-sm:0 4px 18px rgba(0,0,0,.4);
  --sh-md:0 10px 36px rgba(0,0,0,.5);
  --sh-lg:0 24px 64px rgba(0,0,0,.65);
  --r-sm:8px;--r-md:14px;--r-lg:20px;--r-xl:28px;
  --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
  --sw:72px;--sw-exp:250px;--th:64px;
  /* Acento del creador: purple */
  --accent:var(--purple);--accent-lt:var(--purple-lt);--accent-dim:var(--purple-dim);
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
html{scroll-behavior:smooth;}
body{font-family:var(--font-b);background:var(--n950);color:var(--txt);overflow-x:hidden;min-height:100vh;}
::-webkit-scrollbar{width:5px;height:5px;}
::-webkit-scrollbar-track{background:var(--n800);}
::-webkit-scrollbar-thumb{background:linear-gradient(var(--purple),var(--green));border-radius:99px;}
a{text-decoration:none;color:inherit;}
button{cursor:pointer;border:none;font-family:var(--font-b);background:none;}
img{display:block;max-width:100%;}

/* ════ LAYOUT ════ */
.cr-wrap{display:grid;grid-template-columns:var(--sw) 1fr;grid-template-rows:var(--th) 1fr;grid-template-areas:"sb tb""sb main";min-height:100vh;}

/* ════ SIDEBAR ════ */
.cr-sb{
  grid-area:sb;position:fixed;top:0;left:0;bottom:0;
  width:var(--sw);z-index:300;
  background:var(--n900);
  border-right:1px solid rgba(139,92,246,.18);
  display:flex;flex-direction:column;
  transition:width .3s cubic-bezier(.4,0,.2,1);overflow:hidden;
}
.cr-sb:hover,.cr-sb.expanded{width:var(--sw-exp);box-shadow:4px 0 40px rgba(0,0,0,.55);}
.sb-logo{display:flex;align-items:center;gap:12px;padding:14px 18px;height:var(--th);border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;white-space:nowrap;overflow:hidden;}
.sb-logo-ico{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--purple),#5b21b6);display:flex;align-items:center;justify-content:center;font-size:.85rem;color:#fff;font-family:var(--font-d);font-weight:900;flex-shrink:0;box-shadow:0 0 14px rgba(139,92,246,.45);}
.sb-logo-txt{font-family:var(--font-d);font-size:.82rem;font-weight:900;color:var(--purple-lt);letter-spacing:2px;opacity:0;transition:opacity .2s .1s;white-space:nowrap;}
.cr-sb:hover .sb-logo-txt,.cr-sb.expanded .sb-logo-txt{opacity:1;}
.sb-profile{display:flex;align-items:center;gap:10px;padding:12px 18px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;overflow:hidden;white-space:nowrap;}
.sb-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid var(--purple);box-shadow:0 0 12px rgba(139,92,246,.3);flex-shrink:0;}
.sb-uinfo{opacity:0;transition:opacity .2s .1s;}
.cr-sb:hover .sb-uinfo,.cr-sb.expanded .sb-uinfo{opacity:1;}
.sb-uname{font-size:.8rem;font-weight:700;color:var(--txt);}
.sb-urole{font-size:.6rem;color:var(--purple-lt);text-transform:uppercase;letter-spacing:1px;}
.sb-nav{flex:1;overflow-y:auto;overflow-x:hidden;padding:10px 0;}
.sb-nav::-webkit-scrollbar{width:2px;}
.sb-slbl{font-size:.57rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 18px 4px;opacity:0;transition:opacity .2s;white-space:nowrap;}
.cr-sb:hover .sb-slbl,.cr-sb.expanded .sb-slbl{opacity:1;}
.sb-item{display:flex;align-items:center;gap:13px;padding:10px 18px;cursor:pointer;transition:background .2s,color .2s;white-space:nowrap;overflow:hidden;border-left:3px solid transparent;border-radius:0 var(--r-md) var(--r-md) 0;margin:1px 8px 1px 0;}
.sb-item:hover{background:rgba(255,255,255,.05);color:var(--txt);}
.sb-item.on{background:var(--accent-dim);border-left-color:var(--accent);color:var(--accent-lt);}
.sb-item-ico{width:34px;height:34px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;}
.sb-item.on .sb-item-ico{background:rgba(139,92,246,.2);}
.sb-item-lbl{font-size:.83rem;font-weight:600;color:var(--muted);opacity:0;transition:opacity .2s .05s;}
.cr-sb:hover .sb-item-lbl,.cr-sb.expanded .sb-item-lbl{opacity:1;}
.sb-item:hover .sb-item-lbl,.sb-item.on .sb-item-lbl{color:var(--txt);}
.sb-item.on .sb-item-lbl{color:var(--accent-lt);}
.sb-badge{margin-left:auto;padding:1px 6px;border-radius:99px;font-size:.58rem;font-weight:800;background:var(--red);color:#fff;opacity:0;transition:opacity .2s;flex-shrink:0;}
.cr-sb:hover .sb-badge,.cr-sb.expanded .sb-badge{opacity:1;}
.sb-badge.gold{background:var(--gold);color:#000;}
.sb-sep{height:1px;background:rgba(255,255,255,.06);margin:7px 12px;}
.sb-foot{padding:12px 10px;border-top:1px solid rgba(255,255,255,.06);display:flex;gap:6px;flex-shrink:0;}
.sf-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:5px;padding:8px;border-radius:var(--r-md);font-size:.72rem;font-weight:700;transition:all .2s;}
.sfb-home{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.2);color:var(--green-lt);}
.sfb-home:hover{background:rgba(40,166,128,.2);}
.sfb-out{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;}
.sfb-out:hover{background:rgba(239,68,68,.2);}

/* ════ TOPBAR ════ */
.cr-tb{
  grid-area:tb;position:sticky;top:0;z-index:200;height:var(--th);
  background:rgba(2,8,23,.92);backdrop-filter:blur(22px);
  border-bottom:1px solid rgba(139,92,246,.15);
  display:flex;align-items:center;gap:12px;padding:0 22px 0 18px;
}
.tb-burger{display:none;width:34px;height:34px;border-radius:var(--r-sm);background:rgba(255,255,255,.05);color:var(--muted);align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;}
.tb-ttl{font-family:var(--font-d);font-size:.82rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.tb-sub{font-size:.72rem;color:var(--muted);}
.tb-search{flex:1;max-width:380px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:99px;padding:7px 16px;transition:all .2s;}
.tb-search:focus-within{border-color:var(--purple);box-shadow:0 0 0 3px rgba(139,92,246,.1);}
.tb-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:100%;}
.tb-search input::placeholder{color:var(--dim);}
.tb-acts{margin-left:auto;display:flex;align-items:center;gap:8px;}
.tb-act-btn{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.8rem;transition:all .2s;position:relative;cursor:pointer;}
.tb-act-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}
.tb-act-btn.primary{background:var(--purple);border-color:var(--purple);color:#fff;box-shadow:0 0 12px rgba(139,92,246,.4);}
.tb-notif-dot{position:absolute;top:5px;right:5px;width:7px;height:7px;border-radius:50%;background:var(--red);border:2px solid var(--n900);}
.tb-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid var(--purple);cursor:pointer;}

/* ════ MAIN ════ */
.cr-main{grid-area:main;padding:26px;min-width:0;}
.cr-sec{display:none;animation:secIn .38s ease both;}
.cr-sec.on{display:block;}
@keyframes secIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

/* ════ HERO STUDIO ════ */
.studio-hero{
  position:relative;overflow:hidden;
  border-radius:var(--r-xl);padding:28px 32px;
  background:linear-gradient(135deg,#0f0520,#080317,#050d1a);
  border:1px solid rgba(139,92,246,.25);margin-bottom:22px;
}
.sh-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(139,92,246,.05)1px,transparent 1px),linear-gradient(90deg,rgba(139,92,246,.05)1px,transparent 1px);background-size:40px 40px;}
.sh-orb{position:absolute;border-radius:50%;filter:blur(80px);}
.sho1{width:350px;height:350px;background:radial-gradient(circle,rgba(139,92,246,.2),transparent 70%);top:-100px;right:-80px;animation:sho 9s ease-in-out infinite;}
.sho2{width:280px;height:280px;background:radial-gradient(circle,rgba(40,166,128,.1),transparent 70%);bottom:-70px;left:-60px;animation:sho 12s ease-in-out infinite reverse;}
.sho3{width:180px;height:180px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);top:40%;right:25%;animation:sho 7s ease-in-out infinite;}
@keyframes sho{0%,100%{transform:translate(0,0)}50%{transform:translate(16px,-16px)}}
.sh-cnt{position:relative;z-index:1;display:flex;align-items:center;gap:22px;}
.sh-av{width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid var(--purple);box-shadow:0 0 28px rgba(139,92,246,.5);flex-shrink:0;}
.sh-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;background:var(--accent-dim);border:1px solid rgba(139,92,246,.4);border-radius:99px;font-size:.62rem;font-weight:800;color:var(--purple-lt);letter-spacing:1.5px;text-transform:uppercase;margin-bottom:6px;}
.sh-name{font-family:var(--font-d);font-size:1.3rem;font-weight:900;color:var(--txt);letter-spacing:1px;margin-bottom:3px;}
.sh-canal{font-size:.78rem;color:var(--purple-lt);margin-bottom:10px;}
.sh-chips{display:flex;flex-wrap:wrap;gap:5px;}
.sh-chip{padding:3px 9px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.63rem;color:var(--muted);}
.sh-stats{margin-left:auto;display:grid;grid-template-columns:1fr 1fr;gap:12px 22px;flex-shrink:0;}
.shs{text-align:center;}
.shs-n{font-family:var(--font-d);font-size:1.5rem;font-weight:900;color:var(--gold);}
.shs-l{font-size:.58rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:1px;}

/* ════ STATS GRID ════ */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:12px;margin-bottom:22px;}
.stat-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:15px 17px;display:flex;align-items:center;gap:12px;transition:transform .25s,border-color .25s;cursor:pointer;}
.stat-card:hover{transform:translateY(-3px);}
.sc-ico{width:40px;height:40px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;}
.sci-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);}
.sci-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);}
.sci-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);}
.sci-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);}
.sci-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);}
.sci-teal{background:var(--teal-dim);border:1px solid rgba(20,184,166,.3);}
.sc-num{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);line-height:1;}
.sc-lbl{font-size:.62rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

/* ════ SECTION HEADERS ════ */
.sec-hd{display:flex;align-items:center;gap:11px;margin-bottom:15px;}
.sec-hd h2{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.sec-hd-line{flex:1;height:1px;background:linear-gradient(to right,rgba(139,92,246,.35),transparent);}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 16px;border-radius:99px;font-size:.75rem;font-weight:700;transition:all .2s;cursor:pointer;white-space:nowrap;}
.btn-purple{background:var(--purple);color:#fff;box-shadow:0 4px 16px rgba(139,92,246,.3);}
.btn-purple:hover{background:var(--purple-lt);transform:translateY(-2px);}
.btn-green{background:var(--green);color:#fff;}
.btn-green:hover{background:var(--green-lt);}
.btn-gold{background:var(--gold);color:#000;}
.btn-gold:hover{background:var(--gold-lt);}
.btn-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.btn-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt);}
.btn-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.btn-red:hover{background:var(--red);color:#fff;}
.btn-sm{padding:4px 10px;font-size:.68rem;}

/* ════ CARD BASE ════ */
.card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);}
.card:hover{border-color:rgba(139,92,246,.2);}
.cp{padding:18px 20px;}

/* ════ CONTENIDO TABLE ════ */
.cont-table-wrap{overflow-x:auto;}
.cont-table{width:100%;border-collapse:collapse;}
.cont-table th{padding:9px 13px;text-align:left;font-size:.59rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.02);}
.cont-table td{padding:11px 13px;font-size:.82rem;color:var(--muted);border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle;}
.cont-table tr:hover td{background:rgba(255,255,255,.03);}
.cont-table tr:last-child td{border-bottom:none;}
.cont-thumb{width:64px;height:40px;border-radius:var(--r-sm);object-fit:cover;background:var(--n700);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
.cont-info-name{font-size:.82rem;font-weight:700;color:var(--txt);}
.cont-info-meta{font-size:.65rem;color:var(--dim);}

/* Badges */
.badge{padding:2px 9px;border-radius:99px;font-size:.62rem;font-weight:700;display:inline-flex;align-items:center;gap:3px;}
.b-pub{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.b-borr{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
.b-video{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
.b-podcast{background:var(--purple-dim);color:var(--purple-lt);border:1px solid rgba(139,92,246,.3);}
.b-info{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
.b-audio{background:var(--teal-dim);color:#5eead4;border:1px solid rgba(20,184,166,.3);}
.b-doc{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}

/* Botones acción */
.ab{display:inline-flex;align-items:center;gap:3px;padding:4px 9px;border-radius:var(--r-sm);font-size:.68rem;font-weight:700;transition:all .2s;cursor:pointer;}
.ab-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);color:var(--purple-lt);}
.ab-purple:hover{background:var(--purple);color:#fff;}
.ab-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
.ab-green:hover{background:var(--green);color:#fff;}
.ab-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.ab-red:hover{background:var(--red);color:#fff;}
.ab-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.ab-ghost:hover{background:rgba(255,255,255,.12);color:var(--txt);}

/* ════ ANALYTICS CHART ════ */
.chart-box{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px;}
.chart-ttl{font-size:.78rem;font-weight:700;color:var(--txt);margin-bottom:14px;display:flex;align-items:center;gap:6px;}
.bars{display:flex;align-items:flex-end;gap:5px;height:90px;}
.bar-col{display:flex;flex-direction:column;align-items:center;gap:3px;flex:1;}
.bar{width:100%;border-radius:4px 4px 0 0;min-height:4px;transition:height .9s ease;cursor:pointer;}
.bar:hover{filter:brightness(1.3);}
.bar-v{font-size:.55rem;font-weight:700;color:var(--gold);}
.bar-l{font-size:.54rem;color:var(--dim);text-align:center;}

/* ════ EDITOR HERRAMIENTAS ════ */
.tools-mosaic{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;}
.tool-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;cursor:pointer;transition:all .25s;}
.tool-card:hover{transform:translateY(-4px);box-shadow:var(--sh-sm);}
.tc-ico{font-size:2rem;}
.tc-name{font-size:.84rem;font-weight:700;color:var(--txt);}
.tc-desc{font-size:.68rem;color:var(--muted);line-height:1.4;}
.tc-tag{padding:2px 8px;border-radius:99px;font-size:.6rem;font-weight:700;margin-top:4px;}
.tc-free{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
.tc-paid{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
.tc-online{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
.tc-open{padding:5px 12px;background:var(--accent-dim);border:1px solid rgba(139,92,246,.25);border-radius:99px;font-size:.68rem;font-weight:700;color:var(--accent-lt);transition:all .2s;margin-top:2px;}
.tool-card:hover .tc-open{background:var(--purple);color:#fff;}

/* ════ PLAYLIST ════ */
.pl-list{display:flex;flex-direction:column;gap:8px;}
.pl-item{display:flex;align-items:center;gap:12px;padding:12px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);transition:all .2s;cursor:pointer;}
.pl-item:hover{background:rgba(255,255,255,.06);border-color:rgba(139,92,246,.2);}
.pl-ico{width:40px;height:40px;border-radius:var(--r-md);background:var(--accent-dim);display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;}
.pl-title{font-size:.84rem;font-weight:700;color:var(--txt);}
.pl-meta{font-size:.68rem;color:var(--muted);margin-top:2px;}

/* ════ COMENTARIOS ════ */
.comment-item{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);margin-bottom:8px;transition:border-color .2s;}
.comment-item:hover{border-color:rgba(139,92,246,.2);}
.cm-av{width:32px;height:32px;border-radius:50%;object-fit:cover;border:1.5px solid var(--purple-dim);flex-shrink:0;}
.cm-av-ph{width:32px;height:32px;border-radius:50%;background:var(--purple-dim);display:flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:700;color:var(--purple-lt);flex-shrink:0;}
.cm-body{flex:1;}
.cm-autor{font-size:.8rem;font-weight:700;color:var(--txt);}
.cm-contenido{font-size:.68rem;color:var(--purple-lt);margin-bottom:3px;}
.cm-texto{font-size:.78rem;color:var(--muted);line-height:1.5;}
.cm-fecha{font-size:.62rem;color:var(--dim);margin-top:3px;}

/* ════ NOTA PAD ════ */
.note-pad{background:rgba(218,165,32,.04);border:1px solid rgba(218,165,32,.2);border-radius:var(--r-lg);padding:16px;}
.note-pad textarea{width:100%;background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.85rem;line-height:1.7;resize:none;min-height:140px;}
.note-pad textarea::placeholder{color:var(--dim);}

/* ════ QUICK ACTIONS ════ */
.qa-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:20px;}
.qa{display:flex;flex-direction:column;align-items:center;gap:7px;padding:15px 8px;background:var(--n800);border:1.5px dashed rgba(255,255,255,.1);border-radius:var(--r-lg);cursor:pointer;transition:all .25s;text-align:center;}
.qa:hover{background:var(--accent-dim);border-color:var(--purple);transform:translateY(-3px);}
.qa-ico{font-size:1.7rem;}
.qa-lbl{font-size:.7rem;font-weight:700;color:var(--muted);}
.qa:hover .qa-lbl{color:var(--purple-lt);}

/* ════ SUSCRIPTORES ════ */
.sub-item{display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);}
.sub-av{width:30px;height:30px;border-radius:50%;object-fit:cover;border:1.5px solid var(--purple-dim);}
.sub-av-ph{width:30px;height:30px;border-radius:50%;background:var(--purple-dim);display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;color:var(--purple-lt);}
.sub-name{font-size:.8rem;font-weight:600;color:var(--txt);}
.sub-fecha{font-size:.62rem;color:var(--dim);}

/* ════ MODAL ════ */
.cr-modal{position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;overflow-y:auto;}
.cr-modal.on{display:flex;}
.m-box{background:var(--n800);border:1px solid rgba(139,92,246,.22);border-radius:var(--r-xl);width:100%;max-width:600px;box-shadow:var(--sh-lg);animation:mIn .3s ease both;margin:auto;}
.m-box.wide{max-width:820px;}
@keyframes mIn{from{opacity:0;transform:scale(.95)translateY(14px)}to{opacity:1;transform:none}}
.m-hd{display:flex;align-items:center;justify-content:space-between;padding:17px 22px;border-bottom:1px solid rgba(255,255,255,.07);}
.m-ttl{font-family:var(--font-d);font-size:.84rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
.m-close{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
.m-close:hover{background:var(--red-dim);color:#f87171;}
.m-body{padding:18px 22px;}
.m-foot{padding:14px 22px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:8px;justify-content:flex-end;}
.fg{margin-bottom:13px;}
.fl{display:block;font-size:.67rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:5px;}
.fi{width:100%;padding:9px 13px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.86rem;transition:all .2s;outline:none;}
.fi:focus{border-color:var(--purple);background:rgba(139,92,246,.05);}
textarea.fi{resize:vertical;min-height:75px;line-height:1.6;}
select.fi option{background:var(--n700);}
.fg-2{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.em-btn{padding:9px 20px;border-radius:var(--r-md);font-weight:700;font-size:.82rem;transition:all .2s;cursor:pointer;}
.em-btn-purple{background:var(--purple);color:#fff;}
.em-btn-purple:hover{background:var(--purple-lt);}
.em-btn-cancel{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
.em-btn-cancel:hover{background:rgba(255,255,255,.1);color:var(--txt);}

/* Toggle */
.tg{position:relative;width:38px;height:20px;flex-shrink:0;display:inline-block;}
.tg input{display:none;}
.tg-sl{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:.3s;}
.tg-sl::before{content:'';position:absolute;width:14px;height:14px;background:#fff;border-radius:50%;top:3px;left:3px;transition:.3s;}
.tg input:checked + .tg-sl{background:var(--purple);}
.tg input:checked + .tg-sl::before{transform:translateX(18px);}

/* ════ TOAST ════ */
.toast-w{position:fixed;bottom:22px;right:22px;z-index:10000;display:flex;flex-direction:column;gap:7px;}
.tst{display:flex;align-items:center;gap:9px;padding:10px 16px;border-radius:var(--r-md);font-size:.8rem;font-weight:600;animation:tstIn .3s ease both;max-width:310px;box-shadow:var(--sh-md);}
@keyframes tstIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:none}}
.t-ok{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
.t-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
.t-info{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);color:var(--purple-lt);}

/* Curso card */
.curso-mini{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:14px;display:flex;align-items:center;gap:12px;transition:all .2s;cursor:pointer;margin-bottom:10px;}
.curso-mini:hover{border-color:rgba(139,92,246,.3);transform:translateX(4px);}
.cm-ico{font-size:1.6rem;flex-shrink:0;}
.cm-info{flex:1;}
.cm-title{font-size:.84rem;font-weight:700;color:var(--txt);}
.cm-meta{font-size:.68rem;color:var(--muted);margin-top:2px;}
.cm-inscritos{font-family:var(--font-d);font-size:.9rem;font-weight:900;color:var(--gold);}

/* Empty */
.empty-state{text-align:center;padding:40px 20px;color:var(--dim);}
.es-ico{font-size:3rem;opacity:.25;margin-bottom:12px;}
.es-txt{font-size:.88rem;}

/* ════ RESPONSIVE ════ */
@media(max-width:1024px){.sh-stats{display:none;}}
@media(max-width:820px){
  .cr-wrap{grid-template-columns:1fr;grid-template-areas:"tb""main";}
  .cr-sb{transform:translateX(-100%);}
  .cr-sb.open{transform:translateX(0);width:var(--sw-exp);}
  .tb-burger{display:flex;}
  .cr-main{padding:16px;}
  .stats-grid{grid-template-columns:repeat(2,1fr);}
  .tools-mosaic{grid-template-columns:repeat(2,1fr);}
}
@media(max-width:480px){
  .stats-grid{grid-template-columns:repeat(2,1fr);}
  .qa-grid{grid-template-columns:repeat(2,1fr);}
  .fg-2{grid-template-columns:1fr;}
}
</style>
</head>
<body>
<div class="cr-wrap" id="crWrap">

<!-- ════════════ SIDEBAR ════════════ -->
<aside class="cr-sb" id="crSb">
  <div class="sb-logo">
    <div class="sb-logo-ico">🎬</div>
    <span class="sb-logo-txt">VIROX STUDIO</span>
  </div>
  <div class="sb-profile">
    <img src="<?= $avatar ?>" alt="av" class="sb-av" onerror="this.src='../assets/avatar-default.png'">
    <div class="sb-uinfo">
      <div class="sb-uname"><?= $nombre ?></div>
      <div class="sb-urole">Creador de Contenido</div>
    </div>
  </div>
  <nav class="sb-nav">
    <div class="sb-slbl">Studio</div>
    <div class="sb-item on" onclick="showSec('dashboard',this)"><div class="sb-item-ico"><i class="fa fa-gauge-high"></i></div><span class="sb-item-lbl">Dashboard</span></div>
    <div class="sb-item" onclick="showSec('contenidos',this)">
      <div class="sb-item-ico"><i class="fa fa-photo-film"></i></div>
      <span class="sb-item-lbl">Mis Contenidos</span>
      <?php if(count($borradores)>0):?><span class="sb-badge"><?= count($borradores) ?></span><?php endif;?>
    </div>
    <div class="sb-item" onclick="showSec('subir',this)"><div class="sb-item-ico"><i class="fa fa-cloud-arrow-up"></i></div><span class="sb-item-lbl">Subir Contenido</span></div>
    <div class="sb-item" onclick="showSec('playlists',this)"><div class="sb-item-ico"><i class="fa fa-list-ul"></i></div><span class="sb-item-lbl">Playlists</span></div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Herramientas</div>
    <div class="sb-item" onclick="showSec('editor',this)"><div class="sb-item-ico"><i class="fa fa-wand-magic-sparkles"></i></div><span class="sb-item-lbl">Edición & Diseño</span></div>
    <div class="sb-item" onclick="showSec('notas',this)"><div class="sb-item-ico"><i class="fa fa-note-sticky"></i></div><span class="sb-item-lbl">Scripts & Notas</span></div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Canal</div>
    <div class="sb-item" onclick="showSec('canal',this)"><div class="sb-item-ico"><i class="fa fa-tower-broadcast"></i></div><span class="sb-item-lbl">Mi Canal</span></div>
    <div class="sb-item" onclick="showSec('analiticas',this)"><div class="sb-item-ico"><i class="fa fa-chart-line"></i></div><span class="sb-item-lbl">Analíticas</span></div>
    <div class="sb-item" onclick="showSec('comunidad',this)">
      <div class="sb-item-ico"><i class="fa fa-comments"></i></div>
      <span class="sb-item-lbl">Comunidad</span>
      <?php if(count($comentarios)>0):?><span class="sb-badge gold"><?= count($comentarios) ?></span><?php endif;?>
    </div>
    <div class="sb-sep"></div>
    <div class="sb-slbl">Aprendizaje</div>
    <div class="sb-item" onclick="showSec('cursos',this)"><div class="sb-item-ico"><i class="fa fa-graduation-cap"></i></div><span class="sb-item-lbl">Mis Cursos</span></div>
    <div class="sb-item" onclick="window.location.href='../AD.php'"><div class="sb-item-ico"><i class="fa fa-play-circle"></i></div><span class="sb-item-lbl">Aprendizaje Digital</span></div>
    <div class="sb-item" onclick="window.location.href='../IA.php'"><div class="sb-item-ico"><i class="fa fa-robot"></i></div><span class="sb-item-lbl">Asistente IA</span></div>
    <div class="sb-sep"></div>
    <div class="sb-item" onclick="window.location.href='../index.php'"><div class="sb-item-ico"><i class="fa fa-house"></i></div><span class="sb-item-lbl">Inicio VIROX</span></div>
    <div class="sb-item" onclick="window.location.href='../perfil.php'"><div class="sb-item-ico"><i class="fa fa-id-card"></i></div><span class="sb-item-lbl">Mi Perfil</span></div>
  </nav>
  <div class="sb-foot">
    <a href="../AD.php" class="sf-btn sfb-home"><i class="fa fa-play"></i> AD</a>
    <a href="../logout.php" class="sf-btn sfb-out"><i class="fa fa-right-from-bracket"></i> Salir</a>
  </div>
</aside>


<!-- ════════════ TOPBAR ════════════ -->
<header class="cr-tb">
  <button class="tb-burger" id="tbBurger" onclick="toggleSb()"><i class="fa fa-bars"></i></button>
  <div>
    <div class="tb-ttl">VIROX Studio</div>
    <div class="tb-sub" id="tbSub">Dashboard</div>
  </div>
  <div class="tb-search">
    <i class="fa fa-search" style="color:var(--dim);font-size:.78rem;"></i>
    <input type="text" placeholder="Buscar en tus contenidos..." id="gSearch">
  </div>
  <div class="tb-acts">
    <button class="tb-act-btn primary" onclick="showSec('subir')" title="Subir contenido"><i class="fa fa-plus"></i></button>
    <button class="tb-act-btn" onclick="showSec('comunidad')" title="Comentarios">
      <i class="fa fa-bell"></i>
      <?php if(count($comentarios)>0):?><span class="tb-notif-dot"></span><?php endif;?>
    </button>
    <img src="<?= $avatar ?>" alt="av" class="tb-av" onclick="window.location.href='../perfil.php'" onerror="this.src='../assets/avatar-default.png'">
  </div>
</header>


<!-- ════════════ MAIN ════════════ -->
<main class="cr-main">


<!-- █████████ DASHBOARD █████████ -->
<div class="cr-sec on" id="sec-dashboard">

  <!-- Hero -->
  <div class="studio-hero">
    <div class="sh-grid"></div><div class="sh-orb sho1"></div><div class="sh-orb sho2"></div><div class="sh-orb sho3"></div>
    <div class="sh-cnt">
      <img src="<?= $avatar ?>" alt="av" class="sh-av" onerror="this.src='../assets/avatar-default.png'">
      <div>
        <div class="sh-badge"><i class="fa fa-star fa-xs"></i> Creador de Contenido</div>
        <div class="sh-name"><?= $nombre ?></div>
        <div class="sh-canal">📡 <?= htmlspecialchars($mi_canal['nombre'] ?? 'Sin canal aún') ?></div>
        <div class="sh-chips">
          <span class="sh-chip"><?= count($mis_contenidos) ?> contenidos</span>
          <span class="sh-chip"><?= number_format($total_vistas) ?> vistas</span>
          <span class="sh-chip"><?= number_format($mi_canal['suscriptores'] ?? 0) ?> suscriptores</span>
          <?php if($mi_canal['verificado']??0):?><span class="sh-chip">✅ Verificado</span><?php endif;?>
        </div>
      </div>
      <div class="sh-stats">
        <div class="shs"><div class="shs-n"><?= count($mis_contenidos) ?></div><div class="shs-l">Contenidos</div></div>
        <div class="shs"><div class="shs-n"><?= number_format($total_vistas/1000,1) ?>K</div><div class="shs-l">Vistas</div></div>
        <div class="shs"><div class="shs-n"><?= number_format($mi_canal['suscriptores'] ?? 0) ?></div><div class="shs-l">Suscriptores</div></div>
        <div class="shs"><div class="shs-n">$<?= number_format($ing_mes,0,',','.') ?></div><div class="shs-l">Ingresos/mes</div></div>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card" onclick="showSec('contenidos')"><div class="sc-ico sci-purple"><i class="fa fa-photo-film"></i></div><div><div class="sc-num"><?= count($mis_contenidos) ?></div><div class="sc-lbl">Contenidos</div></div></div>
    <div class="stat-card" onclick="showSec('analiticas')"><div class="sc-ico sci-blue"><i class="fa fa-eye"></i></div><div><div class="sc-num"><?= number_format($total_vistas) ?></div><div class="sc-lbl">Vistas totales</div></div></div>
    <div class="stat-card" onclick="showSec('canal')"><div class="sc-ico sci-green"><i class="fa fa-bell"></i></div><div><div class="sc-num"><?= number_format($mi_canal['suscriptores'] ?? 0) ?></div><div class="sc-lbl">Suscriptores</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-gold"><i class="fa fa-heart"></i></div><div><div class="sc-num"><?= number_format($total_likes) ?></div><div class="sc-lbl">Likes totales</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-teal"><i class="fa fa-sack-dollar"></i></div><div><div class="sc-num">$<?= number_format($ing_mes,0,',','.') ?></div><div class="sc-lbl">Ingresos mes</div></div></div>
    <div class="stat-card" onclick="showSec('contenidos')"><div class="sc-ico sci-red"><i class="fa fa-clock-rotate-left"></i></div><div><div class="sc-num"><?= count($borradores) ?></div><div class="sc-lbl">Borradores</div></div></div>
  </div>

  <!-- Quick Actions -->
  <div class="sec-hd"><h2>⚡ Acciones Rápidas</h2><div class="sec-hd-line"></div></div>
  <div class="qa-grid">
    <div class="qa" onclick="showSec('subir')"><div class="qa-ico">📤</div><div class="qa-lbl">Subir Video</div></div>
    <div class="qa" onclick="showSec('subir');document.getElementById('ft_tipo').value='podcast'"><div class="qa-ico">🎙</div><div class="qa-lbl">Nuevo Podcast</div></div>
    <div class="qa" onclick="showSec('subir');document.getElementById('ft_tipo').value='infografia'"><div class="qa-ico">📊</div><div class="qa-lbl">Infografía</div></div>
    <div class="qa" onclick="showSec('notas')"><div class="qa-ico">📝</div><div class="qa-lbl">Script / Nota</div></div>
    <div class="qa" onclick="showSec('editor')"><div class="qa-ico">🎨</div><div class="qa-lbl">Herramientas</div></div>
    <div class="qa" onclick="showSec('playlists')"><div class="qa-ico">▶</div><div class="qa-lbl">Nueva Playlist</div></div>
    <div class="qa" onclick="showSec('analiticas')"><div class="qa-ico">📈</div><div class="qa-lbl">Ver Analytics</div></div>
    <div class="qa" onclick="window.location.href='../IA.php'"><div class="qa-ico">🤖</div><div class="qa-lbl">Asistente IA</div></div>
    <div class="qa" onclick="showSec('canal')"><div class="qa-ico">⚙️</div><div class="qa-lbl">Config. Canal</div></div>
    <div class="qa" onclick="showSec('comunidad')"><div class="qa-ico">💬</div><div class="qa-lbl">Comentarios</div></div>
  </div>

  <!-- Dos columnas: reciente + top contenidos -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
    <!-- Últimos subidos -->
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:12px;">
        <h2>🆕 Recién subidos</h2><div class="sec-hd-line"></div>
        <button class="btn btn-ghost btn-sm" onclick="showSec('contenidos')">Ver todos</button>
      </div>
      <?php if(empty($mis_contenidos)):?>
      <div class="empty-state"><div class="es-ico">📁</div><p class="es-txt">Aún no has subido contenido.</p></div>
      <?php else: foreach(array_slice($mis_contenidos,0,4) as $c): ?>
      <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div class="cont-thumb"><?= htmlspecialchars($c['icono']??'🎬') ?></div>
        <div style="flex:1;min-width:0;">
          <p style="font-size:.8rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($c['titulo']) ?></p>
          <p style="font-size:.62rem;color:var(--dim);"><?= number_format($c['vistas']??0) ?> vistas · <?= ucfirst($c['tipo']) ?></p>
        </div>
        <span class="badge <?= $c['publicado']?'b-pub':'b-borr' ?>"><?= $c['publicado']?'Público':'Borrador' ?></span>
      </div>
      <?php endforeach;endif;?>
    </div>

    <!-- Top contenidos -->
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:12px;"><h2>🏆 Más vistos</h2><div class="sec-hd-line"></div></div>
      <?php if(empty($top_contenidos)):?>
      <div class="empty-state"><div class="es-ico">📊</div><p class="es-txt">Sin datos aún.</p></div>
      <?php else: foreach($top_contenidos as $idx=>$c): ?>
      <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <span style="font-family:var(--font-d);font-size:.9rem;font-weight:900;color:var(--<?= $idx===0?'gold':'dim' ?>);width:20px;flex-shrink:0;">#<?= $idx+1 ?></span>
        <div class="cont-thumb"><?= htmlspecialchars($c['icono']??'🎬') ?></div>
        <div style="flex:1;min-width:0;">
          <p style="font-size:.8rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($c['titulo']) ?></p>
          <p style="font-size:.62rem;color:var(--dim);"><?= number_format($c['vistas']??0) ?> vistas</p>
        </div>
        <span style="font-family:var(--font-d);font-size:.75rem;color:var(--gold);"><?= number_format($c['likes']??0) ?> ❤</span>
      </div>
      <?php endforeach;endif;?>
    </div>
  </div>

  <!-- Barra de vistas 7 días en dashboard -->
  <div class="chart-box">
    <div class="chart-ttl"><i class="fa fa-chart-bar" style="color:var(--purple-lt);"></i> Actividad de vistas — últimos 7 días</div>
    <div class="bars">
      <?php foreach($barras_raw as $b):
        $h=max(4,round($b['val']/$max_bar*80));
      ?>
      <div class="bar-col">
        <div class="bar-v"><?= $b['val']>0?$b['val']:'' ?></div>
        <div class="bar" style="height:<?= $h ?>px;background:linear-gradient(to top,var(--purple),rgba(139,92,246,.25));"></div>
        <div class="bar-l"><?= $b['dia'] ?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>

</div><!-- /dashboard -->


<!-- █████████ MIS CONTENIDOS █████████ -->
<div class="cr-sec" id="sec-contenidos">
  <div class="sec-hd">
    <h2>📁 Mis Contenidos</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:7px;">
      <button class="btn btn-ghost btn-sm" onclick="filtrarContenido('',this)">Todos</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarContenido('publicado',this)">✅ Publicados</button>
      <button class="btn btn-ghost btn-sm" onclick="filtrarContenido('borrador',this)">📝 Borradores</button>
      <button class="btn btn-purple" onclick="showSec('subir')"><i class="fa fa-plus"></i> Subir</button>
    </div>
  </div>
  <div class="card" style="overflow:hidden;">
    <div class="cont-table-wrap">
      <table class="cont-table" id="contTable">
        <thead><tr><th></th><th>Título</th><th>Tipo</th><th>Vistas</th><th>Likes</th><th>Estado</th><th>Fecha</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php if(empty($mis_contenidos)):?>
        <tr><td colspan="8"><div class="empty-state"><div class="es-ico">📁</div><p class="es-txt">Aún no has subido contenido. ¡Empieza ahora!</p><br><button class="btn btn-purple" onclick="showSec('subir')"><i class="fa fa-plus"></i> Subir primer contenido</button></div></td></tr>
        <?php else: foreach($mis_contenidos as $c):
          $tipo_badge_map=['video'=>'b-video','podcast'=>'b-podcast','infografia'=>'b-info','audio'=>'b-audio','presentacion'=>'b-doc','documento'=>'b-doc'];
          $tbadge=$tipo_badge_map[$c['tipo']??'video']??'b-doc';
        ?>
        <tr data-estado="<?= $c['publicado']?'publicado':'borrador' ?>">
          <td><div class="cont-thumb"><?= htmlspecialchars($c['icono']??'🎬') ?></div></td>
          <td>
            <div class="cont-info-name"><?= htmlspecialchars($c['titulo']) ?></div>
            <div class="cont-info-meta"><?= htmlspecialchars($c['canal_nombre']??'') ?> · <?= htmlspecialchars($c['categoria']??'') ?></div>
          </td>
          <td><span class="badge <?= $tbadge ?>"><?= ucfirst($c['tipo']??'video') ?></span></td>
          <td style="font-family:var(--font-d);font-size:.78rem;color:var(--blue-lt);"><?= number_format($c['vistas']??0) ?></td>
          <td style="font-family:var(--font-d);font-size:.78rem;color:var(--red-lt);"><?= number_format($c['likes']??0) ?> ❤</td>
          <td>
            <button onclick="togglePublicado(<?= $c['id'] ?>,<?= $c['publicado']?0:1 ?>,this)"
                    class="badge <?= $c['publicado']?'b-pub':'b-borr' ?>" style="cursor:pointer;">
              <?= $c['publicado']?'✅ Publicado':'📝 Borrador' ?>
            </button>
          </td>
          <td style="font-size:.68rem;color:var(--dim);"><?= !empty($c['fecha_publicacion'])?date('d M Y',strtotime($c['fecha_publicacion'])):'—' ?></td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="ab ab-purple" onclick="abrirEditContenido(<?= htmlspecialchars(json_encode($c),ENT_QUOTES) ?>)"><i class="fa fa-pen"></i></button>
              <button class="ab ab-ghost" title="Ver estadísticas" onclick="showSec('analiticas')"><i class="fa fa-chart-bar"></i></button>
              <button class="ab ab-red" onclick="eliminarContenido(<?= $c['id'] ?>,'<?= htmlspecialchars($c['titulo'],ENT_QUOTES) ?>')"><i class="fa fa-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach;endif;?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- █████████ SUBIR CONTENIDO █████████ -->
<div class="cr-sec" id="sec-subir">
  <div class="sec-hd"><h2>📤 Subir / Crear Contenido</h2><div class="sec-hd-line"></div></div>

  <!-- Tipo de contenido -->
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:24px;">
    <?php
    $tipos_subir=[['🎬','Video','video'],['🎙','Podcast','podcast'],['📊','Infografía','infografia'],['📑','Presentación','presentacion'],['🎧','Audio','audio'],['📄','Documento','documento']];
    foreach($tipos_subir as [$ic,$nm,$val]):
    ?>
    <div class="qa" onclick="document.getElementById('ft_tipo').value='<?= $val ?>';this.closest('.cr-sec').querySelectorAll('.qa').forEach(q=>q.style.border='1.5px dashed rgba(255,255,255,.1)');this.style.border='1.5px solid var(--purple)';">
      <div class="qa-ico"><?= $ic ?></div>
      <div class="qa-lbl"><?= $nm ?></div>
    </div>
    <?php endforeach;?>
  </div>

  <!-- Formulario -->
  <div class="card cp">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">
      <!-- Izquierda -->
      <div>
        <div class="fg">
          <label class="fl">Título *</label>
          <input type="text" class="fi" id="ft_titulo" placeholder="Título atractivo para tu contenido">
        </div>
        <div class="fg">
          <label class="fl">Descripción</label>
          <textarea class="fi" id="ft_desc" rows="4" placeholder="Describe de qué trata este contenido..."></textarea>
        </div>
        <div class="fg-2">
          <div class="fg">
            <label class="fl">Tipo de contenido</label>
            <select class="fi" id="ft_tipo">
              <option value="video">🎬 Video</option>
              <option value="podcast">🎙 Podcast</option>
              <option value="infografia">📊 Infografía</option>
              <option value="presentacion">📑 Presentación</option>
              <option value="audio">🎧 Audio</option>
              <option value="documento">📄 Documento</option>
            </select>
          </div>
          <div class="fg">
            <label class="fl">Categoría</label>
            <input type="text" class="fi" id="ft_cat" placeholder="Ej: Programación, IA...">
          </div>
        </div>
        <div class="fg-2">
          <div class="fg">
            <label class="fl">Duración</label>
            <input type="text" class="fi" id="ft_dur" placeholder="Ej: 15:30">
          </div>
          <div class="fg">
            <label class="fl">Tags (separados por coma)</label>
            <input type="text" class="fi" id="ft_tags" placeholder="python, tutorial, básico">
          </div>
        </div>
        <div class="fg">
          <label class="fl">Canal</label>
          <select class="fi" id="ft_canal">
            <?php if($mi_canal):?>
            <option value="<?= $mi_canal['id'] ?>"><?= htmlspecialchars($mi_canal['nombre']) ?></option>
            <?php else:?>
            <option value="">— Primero crea tu canal —</option>
            <?php endif;?>
          </select>
        </div>
      </div>
      <!-- Derecha: zona de carga -->
      <div>
        <div style="border:2px dashed rgba(139,92,246,.3);border-radius:var(--r-xl);padding:40px 24px;text-align:center;background:rgba(139,92,246,.04);cursor:pointer;transition:all .25s;margin-bottom:14px;" id="dropZone" onclick="document.getElementById('ft_file').click()" ondragover="this.style.background='rgba(139,92,246,.1)'" ondragleave="this.style.background='rgba(139,92,246,.04)'">
          <i class="fa fa-cloud-arrow-up" style="font-size:3rem;color:var(--purple-lt);margin-bottom:12px;display:block;"></i>
          <p style="font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:4px;">Arrastra el archivo aquí</p>
          <p style="font-size:.78rem;color:var(--muted);">o haz clic para seleccionar</p>
          <p style="font-size:.68rem;color:var(--dim);margin-top:8px;">MP4, MP3, PDF, PPT, PNG — máx. 500 MB</p>
          <input type="file" id="ft_file" style="display:none;" onchange="previewFile(this)">
        </div>
        <div id="ft_preview" style="display:none;background:rgba(139,92,246,.06);border:1px solid rgba(139,92,246,.3);border-radius:var(--r-md);padding:12px 16px;margin-bottom:14px;">
          <p style="font-size:.8rem;font-weight:700;color:var(--purple-lt);" id="ft_prev_name"></p>
          <p style="font-size:.68rem;color:var(--muted);" id="ft_prev_size"></p>
        </div>
        <div class="fg">
          <label class="fl">URL del archivo (alternativa a subir)</label>
          <input type="text" class="fi" id="ft_url" placeholder="https://youtube.com/watch?v=...">
        </div>
        <div class="fg">
          <label class="fl">Miniatura URL</label>
          <input type="text" class="fi" id="ft_thumb" placeholder="https://...imagen.jpg">
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-top:1px solid rgba(255,255,255,.07);">
          <span style="font-size:.82rem;color:var(--txt);font-weight:600;">Publicar inmediatamente</span>
          <label class="tg"><input type="checkbox" id="ft_pub" checked><span class="tg-sl"></span></label>
        </div>
        <div style="display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.07);margin-bottom:16px;">
          <span style="font-size:.82rem;color:var(--txt);font-weight:600;">Marcar como destacado</span>
          <label class="tg"><input type="checkbox" id="ft_dest"><span class="tg-sl"></span></label>
        </div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-ghost" style="flex:1;justify-content:center;" onclick="guardarContenido(false)"><i class="fa fa-save"></i> Guardar borrador</button>
          <button class="btn btn-purple" style="flex:1;justify-content:center;" onclick="guardarContenido(true)"><i class="fa fa-upload"></i> Publicar ahora</button>
        </div>
      </div>
    </div>
  </div>
</div>


<!-- █████████ PLAYLISTS █████████ -->
<div class="cr-sec" id="sec-playlists">
  <div class="sec-hd">
    <h2>▶ Mis Playlists</h2><div class="sec-hd-line"></div>
    <button class="btn btn-purple" onclick="abrirModal('mNuevoPlaylist')"><i class="fa fa-plus"></i> Nueva playlist</button>
  </div>
  <?php if(empty($playlists)):?>
  <div class="empty-state"><div class="es-ico">▶</div><p class="es-txt">Aún no tienes playlists. ¡Crea la primera para organizar tu contenido!</p></div>
  <?php else:?>
  <div class="pl-list">
    <?php foreach($playlists as $pl):?>
    <div class="pl-item">
      <div class="pl-ico">▶</div>
      <div style="flex:1;">
        <div class="pl-title"><?= htmlspecialchars($pl['titulo']) ?></div>
        <div class="pl-meta"><?= $pl['total'] ?> videos · <?= $pl['publica']?'Pública':'Privada' ?></div>
      </div>
      <span class="badge <?= $pl['publica']?'b-pub':'b-borr' ?>"><?= $pl['publica']?'Pública':'Privada' ?></span>
      <div style="display:flex;gap:5px;">
        <button class="ab ab-purple"><i class="fa fa-pen"></i></button>
        <button class="ab ab-ghost"><i class="fa fa-eye"></i></button>
      </div>
    </div>
    <?php endforeach;?>
  </div>
  <?php endif;?>
</div>


<!-- █████████ EDITOR & HERRAMIENTAS █████████ -->
<div class="cr-sec" id="sec-editor">
  <div class="sec-hd"><h2>🎨 Herramientas de Edición & Diseño</h2><div class="sec-hd-line"></div></div>

  <?php
  $tool_sections_editor = [
    ['🎬 Edición de Video',  [
      ['DaVinci Resolve','🎬','Edición profesional gratuita','Gratis','https://www.blackmagicdesign.com/products/davinciresolve'],
      ['CapCut Web','✂️','Editor ágil para redes sociales','Gratis','https://www.capcut.com'],
      ['Kdenlive','🖊','Editor open source multiplataforma','Open','https://kdenlive.org'],
      ['Adobe Premiere','🎥','Suite profesional de Adobe','Pro','https://www.adobe.com/premiere'],
      ['Clipchamp','📱','Editor nativo de Windows','Gratis','https://clipchamp.com'],
      ['OpenShot','🎞','Editor de video open source','Open','https://www.openshot.org'],
    ]],
    ['🎙 Grabación & Audio',  [
      ['Audacity','🎙','Editor de audio open source','Open','https://www.audacityteam.org'],
      ['OBS Studio','📡','Grabación y streaming profesional','Gratis','https://obsproject.com'],
      ['GarageBand','🎸','Producción musical iOS/macOS','Gratis','https://www.apple.com/garageband/'],
      ['Adobe Audition','🎚','Post-producción de audio','Pro','https://www.adobe.com/audition'],
      ['Descript','🎤','Edita audio editando el texto','Freemium','https://www.descript.com'],
      ['Riverside.fm','🎧','Grabación remota HD','Freemium','https://riverside.fm'],
    ]],
    ['🖼 Diseño & Gráficos',  [
      ['Canva','🎨','Diseño gráfico en línea fácil','Freemium','https://www.canva.com'],
      ['Adobe Express','✨','Plantillas y diseño rápido','Freemium','https://www.adobe.com/express'],
      ['Figma','🖌','Diseño UI/UX colaborativo','Freemium','https://www.figma.com'],
      ['GIMP','🖼','Editor de imágenes open source','Open','https://www.gimp.org'],
      ['Photopea','🌐','Photoshop online gratuito','Gratis','https://www.photopea.com'],
      ['Remove.bg','🪄','Eliminar fondo con IA','Freemium','https://www.remove.bg'],
    ]],
    ['📊 Presentaciones & Infografías',  [
      ['Google Slides','📑','Presentaciones colaborativas','Gratis','https://slides.google.com'],
      ['Canva Presentations','📊','Presentaciones con diseño','Freemium','https://www.canva.com'],
      ['Piktochart','📈','Infografías y reportes visuales','Freemium','https://piktochart.com'],
      ['Visme','📉','Presentaciones e infografías','Freemium','https://www.visme.co'],
      ['Miro','🗺','Pizarras colaborativas','Freemium','https://miro.com'],
      ['Prezi','🌀','Presentaciones dinámicas no lineales','Freemium','https://prezi.com'],
    ]],
    ['🤖 IA para Creadores',  [
      ['Eleven Labs','🔊','Voz IA realista en español','Freemium','https://elevenlabs.io'],
      ['Runway ML','🎬','Video IA generativo','Freemium','https://runwayml.com'],
      ['Midjourney','🖼','Imágenes IA fotorrealistas','Pro','https://www.midjourney.com'],
      ['ChatGPT','💬','Guiones, ideas, scripts con IA','Freemium','https://chat.openai.com'],
      ['Claude IA','🤖','Asistente IA de Anthropic','Freemium','../IA.php'],
      ['Descript AI','✂️','Edición de video por transcripción','Freemium','https://www.descript.com'],
    ]],
    ['📡 Distribución & SEO',  [
      ['TubeBuddy','📈','SEO y optimización para YouTube','Freemium','https://www.tubebuddy.com'],
      ['VidIQ','🔍','Analytics y palabras clave','Freemium','https://vidiq.com'],
      ['Hootsuite','📣','Programación en redes sociales','Freemium','https://hootsuite.com'],
      ['Buffer','📱','Planificador de publicaciones','Freemium','https://buffer.com'],
      ['Notion','📔','Calendario editorial y notas','Freemium','https://www.notion.so'],
      ['Later','🗓','Planificador visual para IG/TikTok','Freemium','https://later.com'],
    ]],
  ];

  $badge_color=['Gratis'=>'tc-free','Open'=>'tc-free','Freemium'=>'tc-online','Pro'=>'tc-paid'];

  foreach($tool_sections_editor as [$seccion_lbl, $tools]):
  ?>
  <div style="margin-bottom:28px;">
    <p style="font-size:.72rem;font-weight:800;color:var(--purple-lt);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;"><?= $seccion_lbl ?></p>
    <div class="tools-mosaic">
      <?php foreach($tools as [$nm,$ico,$desc,$tier,$url]):
        $tcss=$badge_color[$tier]??'tc-online';
      ?>
      <div class="tool-card" onclick="window.open('<?= $url ?>','_blank')">
        <div class="tc-ico"><?= $ico ?></div>
        <div class="tc-name"><?= htmlspecialchars($nm) ?></div>
        <div class="tc-desc"><?= htmlspecialchars($desc) ?></div>
        <span class="tc-tag <?= $tcss ?>"><?= $tier ?></span>
        <div class="tc-open"><i class="fa fa-external-link-alt fa-xs"></i> Abrir</div>
      </div>
      <?php endforeach;?>
    </div>
  </div>
  <?php endforeach;?>
</div>


<!-- █████████ SCRIPTS & NOTAS █████████ -->
<div class="cr-sec" id="sec-notas">
  <div class="sec-hd"><h2>📝 Scripts, Notas & Ideas</h2><div class="sec-hd-line"></div>
    <button class="btn btn-purple" onclick="guardarNota()"><i class="fa fa-save"></i> Guardar</button>
  </div>

  <div style="display:grid;grid-template-columns:1fr 320px;gap:18px;">
    <div>
      <div style="background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);overflow:hidden;">
        <!-- Toolbar del editor -->
        <div style="display:flex;gap:4px;padding:10px 14px;border-bottom:1px solid rgba(255,255,255,.07);flex-wrap:wrap;background:rgba(255,255,255,.02);">
          <?php
          $tb_buttons=[
            ['fa-bold','negrita'],['fa-italic','cursiva'],['fa-underline','subrayado'],
            ['fa-heading','título'],['fa-list-ul','lista'],['fa-list-ol','lista num.'],
            ['fa-link','enlace'],['fa-image','imagen'],['fa-code','código'],
          ];
          foreach($tb_buttons as [$icon,$lbl]):
          ?>
          <button title="<?= $lbl ?>" style="width:28px;height:28px;border-radius:var(--r-sm);background:rgba(255,255,255,.05);color:var(--muted);font-size:.72rem;display:flex;align-items:center;justify-content:center;transition:all .2s;" onmouseover="this.style.background='rgba(139,92,246,.2)';this.style.color='var(--purple-lt)'" onmouseout="this.style.background='rgba(255,255,255,.05)';this.style.color='var(--muted)'">
            <i class="fa <?= $icon ?>"></i>
          </button>
          <?php endforeach;?>
          <div style="flex:1;"></div>
          <span style="font-size:.65rem;color:var(--dim);align-self:center;" id="nota_chars">0 caracteres</span>
        </div>
        <!-- Editor -->
        <div class="note-pad">
          <textarea id="nota_content" placeholder="Escribe aquí tu script, ideas para el próximo video, estructura del episodio...

Ejemplo:
🎬 VIDEO: Tutorial PHP desde cero
⏱ Duración estimada: 20 min
📌 Intro: ¿Qué es PHP y por qué aprenderlo?
📌 Sección 1: Variables y tipos de datos
📌 Sección 2: Estructuras de control
📌 Sección 3: Funciones
📌 Outro: Próximo video + CTA suscripción
🔑 Tags: php, programacion, tutorial, web
" oninput="document.getElementById('nota_chars').textContent=this.value.length+' caracteres'"><?= htmlspecialchars($mi_nota) ?></textarea>
        </div>
        <div style="padding:10px 14px;border-top:1px solid rgba(255,255,255,.07);display:flex;justify-content:flex-end;gap:8px;">
          <button class="btn btn-ghost btn-sm" onclick="document.getElementById('nota_content').value=''">🗑 Limpiar</button>
          <button class="btn btn-purple btn-sm" onclick="guardarNota()"><i class="fa fa-save"></i> Guardar nota</button>
        </div>
      </div>
    </div>

    <!-- Panel derecho: plantillas -->
    <div>
      <p style="font-size:.72rem;font-weight:800;color:var(--purple-lt);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">📋 Plantillas rápidas</p>
      <?php
      $plantillas=[
        ['🎬','Script de Video','Intro + 3 puntos + CTA','// Script Video\n\nINTRO (0:00-0:30):\nHook: [Pregunta o dato impactante]\nPresentación: Mi nombre es...\n\nSECCIÓN 1 (0:30-5:00):\n[Tema 1]\n\nSECCIÓN 2 (5:00-10:00):\n[Tema 2]\n\nSECCIÓN 3 (10:00-15:00):\n[Tema 3]\n\nOUTRO (15:00-15:30):\nResumen: ...\nCTA: Suscríbete y activa 🔔\nPróximo video: ...'],
        ['🎙','Estructura Podcast','Intro + entrevista + cierre','// Podcast Episode\n\n🎙 TÍTULO: \n⏱ DURACIÓN: \n\nINTRO (0:00-2:00):\n- Bienvenida\n- Presentación del invitado\n- Tema del episodio\n\nCUERPO (2:00-45:00):\n- Pregunta 1:\n- Pregunta 2:\n- Pregunta 3:\n\nCIERRE (45:00-50:00):\n- Reflexión final\n- Contacto del invitado\n- CTA'],
        ['📊','Infografía','Estructura visual','// INFOGRAFÍA\n\nTÍTULO: [Impactante y claro]\n\n📌 PUNTO 1:\n- Dato: \n- Fuente: \n\n📌 PUNTO 2:\n- Dato: \n- Fuente: \n\n📌 PUNTO 3:\n- Dato: \n- Fuente: \n\n🎨 COLORES: \n🖼 ESTILO: \n📐 TAMAÑO: '],
        ['📅','Calendario Editorial','Planificación semanal','// CALENDARIO SEMANAL\n\n📅 SEMANA: \n\nLUNES:\n- [ ] Grabar: \n\nMIÉRCOLES:\n- [ ] Editar: \n\nVIERNES:\n- [ ] Publicar: \n\nTEMAS PENDIENTES:\n- \n\nIDEAS FUTURAS:\n- '],
      ];
      foreach($plantillas as [$ico,$titulo,$desc,$tmpl]):
      ?>
      <div class="card" style="padding:12px 14px;margin-bottom:8px;cursor:pointer;transition:all .2s;" onclick="cargarPlantilla(<?= json_encode($tmpl) ?>)" onmouseover="this.style.borderColor='rgba(139,92,246,.3)'" onmouseout="this.style.borderColor='rgba(255,255,255,.07)'">
        <div style="display:flex;align-items:center;gap:10px;">
          <span style="font-size:1.4rem;"><?= $ico ?></span>
          <div>
            <div style="font-size:.82rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($titulo) ?></div>
            <div style="font-size:.68rem;color:var(--muted);"><?= htmlspecialchars($desc) ?></div>
          </div>
          <i class="fa fa-arrow-right" style="color:var(--dim);margin-left:auto;font-size:.75rem;"></i>
        </div>
      </div>
      <?php endforeach;?>

      <!-- Generador IA -->
      <div style="background:var(--accent-dim);border:1px solid rgba(139,92,246,.3);border-radius:var(--r-lg);padding:14px;margin-top:14px;">
        <p style="font-size:.75rem;font-weight:700;color:var(--purple-lt);margin-bottom:8px;">🤖 Generar con IA</p>
        <p style="font-size:.72rem;color:var(--muted);margin-bottom:10px;">Describe el tema y deja que la IA genere un script completo.</p>
        <textarea class="fi" id="ia_prompt" rows="2" placeholder="Ej: Tutorial de Python para principiantes, 15 min..." style="margin-bottom:8px;"></textarea>
        <button class="btn btn-purple" style="width:100%;justify-content:center;" onclick="generarConIA()">
          <i class="fa fa-robot"></i> Generar script con IA
        </button>
      </div>
    </div>
  </div>
</div>


<!-- █████████ MI CANAL █████████ -->
<div class="cr-sec" id="sec-canal">
  <div class="sec-hd"><h2>📡 Mi Canal</h2><div class="sec-hd-line"></div>
    <?php if($mi_canal):?>
    <button class="btn btn-purple" onclick="abrirEditCanal()"><i class="fa fa-pen"></i> Editar canal</button>
    <?php else:?>
    <button class="btn btn-purple" onclick="abrirModal('mCrearCanal')"><i class="fa fa-plus"></i> Crear canal</button>
    <?php endif;?>
  </div>

  <?php if(!$mi_canal):?>
  <div class="empty-state">
    <div class="es-ico">📡</div>
    <p class="es-txt" style="margin-bottom:16px;">Aún no tienes un canal creado.</p>
    <button class="btn btn-purple" onclick="abrirModal('mCrearCanal')"><i class="fa fa-plus"></i> Crear mi canal ahora</button>
  </div>
  <?php else:?>

  <!-- Info del canal -->
  <div class="card cp" style="margin-bottom:16px;">
    <div style="display:flex;align-items:center;gap:18px;padding-bottom:18px;border-bottom:1px solid rgba(255,255,255,.07);margin-bottom:18px;">
      <div style="width:72px;height:72px;border-radius:50%;background:var(--purple-dim);border:3px solid var(--purple);display:flex;align-items:center;justify-content:center;font-size:1.8rem;box-shadow:0 0 24px rgba(139,92,246,.4);">
        <?= htmlspecialchars($mi_canal['avatar']??'📺') ?>
      </div>
      <div>
        <h3 style="font-family:var(--font-d);font-size:1rem;font-weight:700;color:var(--txt);margin-bottom:4px;"><?= htmlspecialchars($mi_canal['nombre']) ?></h3>
        <p style="font-size:.78rem;color:var(--muted);margin-bottom:6px;"><?= htmlspecialchars($mi_canal['descripcion']??'') ?></p>
        <div style="display:flex;gap:10px;">
          <span class="badge b-pub"><?= number_format($mi_canal['suscriptores']??0) ?> suscriptores</span>
          <span class="badge b-doc"><?= $mi_canal['total_videos']??0 ?> videos</span>
          <?php if($mi_canal['verificado']??0):?><span class="badge b-pub">✅ Verificado</span><?php endif;?>
        </div>
      </div>
      <div style="margin-left:auto;display:flex;gap:8px;">
        <button class="btn btn-ghost" onclick="window.location.href='../AD.php?canal=<?= $mi_canal['id'] ?>'"><i class="fa fa-eye"></i> Ver canal público</button>
        <button class="btn btn-purple" onclick="showSec('subir')"><i class="fa fa-plus"></i> Subir contenido</button>
      </div>
    </div>
    <!-- Stats del canal -->
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;">
      <?php
      $cs=[
        ['👁','Total vistas',number_format($total_vistas)],
        ['❤','Total likes',number_format($total_likes)],
        ['🔔','Suscriptores',number_format($mi_canal['suscriptores']??0)],
        ['💰','Ingresos mes','$'.number_format($ing_mes,0,',','.')],
        ['💵','Ingresos total','$'.number_format($ing_total,0,',','.')],
        ['🎬','Videos publicados',$stats_pub],
      ];
      foreach($cs as [$ico,$lbl,$val]):
      ?>
      <div style="background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:14px;text-align:center;">
        <div style="font-size:1.4rem;margin-bottom:4px;"><?= $ico ?></div>
        <div style="font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);"><?= $val ?></div>
        <div style="font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;"><?= $lbl ?></div>
      </div>
      <?php endforeach;?>
    </div>
  </div>

  <!-- Suscriptores recientes -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:12px;"><h2>🔔 Nuevos suscriptores</h2><div class="sec-hd-line"></div></div>
      <?php if(empty($nuevos_subs)):?>
      <div class="empty-state" style="padding:20px;"><div class="es-ico" style="font-size:2rem;">🔔</div><p class="es-txt">Sin suscriptores aún.</p></div>
      <?php else: foreach($nuevos_subs as $s):
        $sav=$s['avatar']??'';$sini=mb_substr($s['nombre']??'U',0,1);
      ?>
      <div class="sub-item">
        <?php if($sav):?><img src="<?= htmlspecialchars($sav) ?>" class="sub-av" alt=""><?php else:?><div class="sub-av-ph"><?= $sini ?></div><?php endif;?>
        <div style="flex:1;"><div class="sub-name"><?= htmlspecialchars($s['nombre'].' '.($s['apellido']??'')) ?></div></div>
        <div class="sub-fecha"><?= !empty($s['fecha'])?date('d M',strtotime($s['fecha'])):'—' ?></div>
      </div>
      <?php endforeach;endif;?>
    </div>
    <div class="card cp">
      <div class="sec-hd" style="margin-bottom:12px;"><h2>⚙️ Configuración</h2><div class="sec-hd-line"></div></div>
      <?php
      $cfg_canal=[
        ['Canal público','Cualquier usuario puede ver tu contenido',true],
        ['Permitir comentarios','Usuarios pueden comentar en tus videos',true],
        ['Mostrar suscriptores','Número de suscriptores visible para todos',false],
        ['Notificaciones','Recibe alertas cuando interactúen contigo',true],
        ['Monetización','Habilitar ingresos a través del canal',false],
      ];
      foreach($cfg_canal as [$n,$d,$ch]):
      ?>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <div>
          <div style="font-size:.82rem;font-weight:600;color:var(--txt);"><?= htmlspecialchars($n) ?></div>
          <div style="font-size:.68rem;color:var(--muted);"><?= htmlspecialchars($d) ?></div>
        </div>
        <label class="tg"><input type="checkbox" <?= $ch?'checked':'' ?>><span class="tg-sl"></span></label>
      </div>
      <?php endforeach;?>
    </div>
  </div>
  <?php endif;?>
</div>


<!-- █████████ ANALÍTICAS █████████ -->
<div class="cr-sec" id="sec-analiticas">
  <div class="sec-hd"><h2>📈 Analíticas del Canal</h2><div class="sec-hd-line"></div>
    <button class="btn btn-ghost btn-sm" onclick="exportarCSV()"><i class="fa fa-file-csv"></i> Exportar</button>
  </div>

  <!-- KPIs analíticas -->
  <div class="stats-grid" style="margin-bottom:20px;">
    <div class="stat-card"><div class="sc-ico sci-blue"><i class="fa fa-eye"></i></div><div><div class="sc-num"><?= number_format($total_vistas) ?></div><div class="sc-lbl">Vistas totales</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-red"><i class="fa fa-heart"></i></div><div><div class="sc-num"><?= number_format($total_likes) ?></div><div class="sc-lbl">Likes totales</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-purple"><i class="fa fa-photo-film"></i></div><div><div class="sc-num"><?= count($mis_contenidos) ?></div><div class="sc-lbl">Contenidos</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-green"><i class="fa fa-bell"></i></div><div><div class="sc-num"><?= number_format($mi_canal['suscriptores']??0) ?></div><div class="sc-lbl">Suscriptores</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-gold"><i class="fa fa-sack-dollar"></i></div><div><div class="sc-num">$<?= number_format($ing_total,0,',','.') ?></div><div class="sc-lbl">Ingresos totales</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-teal"><i class="fa fa-percent"></i></div><div><div class="sc-num"><?= $total_vistas>0&&$total_likes>0?round($total_likes/$total_vistas*100,1):0 ?>%</div><div class="sc-lbl">Tasa engagement</div></div></div>
  </div>

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;">
    <!-- Gráfico vistas -->
    <div class="chart-box">
      <div class="chart-ttl"><i class="fa fa-chart-area" style="color:var(--purple-lt);"></i> Vistas por día — últimos 7 días</div>
      <div class="bars">
        <?php foreach($barras_raw as $b): $h=max(4,round($b['val']/$max_bar*80));?>
        <div class="bar-col">
          <div class="bar-v"><?= $b['val']>0?$b['val']:'' ?></div>
          <div class="bar" style="height:<?= $h ?>px;background:linear-gradient(to top,var(--purple),rgba(139,92,246,.2));"></div>
          <div class="bar-l"><?= $b['dia'] ?></div>
        </div>
        <?php endforeach;?>
      </div>
    </div>

    <!-- Top contenidos -->
    <div class="chart-box">
      <div class="chart-ttl"><i class="fa fa-trophy" style="color:var(--gold);"></i> Top 5 por vistas</div>
      <?php foreach(array_slice($top_contenidos,0,5) as $i=>$c):?>
      <div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05);">
        <span style="font-family:var(--font-d);font-size:.78rem;font-weight:900;color:var(--<?= $i===0?'gold':'dim' ?>);width:18px;"><?= $i+1 ?></span>
        <div style="flex:1;min-width:0;"><p style="font-size:.76rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($c['titulo']) ?></p></div>
        <span style="font-size:.7rem;color:var(--blue-lt);"><?= number_format($c['vistas']??0) ?></span>
      </div>
      <?php endforeach;?>
    </div>
  </div>

  <!-- Distribución por tipo -->
  <div style="margin-top:16px;display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;">
    <?php
    $tipos_data=[
      ['🎬','Videos',$stats_videos,'purple'],
      ['🎙','Podcasts',$stats_podcasts,'blue'],
      ['📊','Infografías',$stats_infos,'gold'],
      ['✅','Publicados',$stats_pub,'green'],
      ['📝','Borradores',count($borradores),'orange'],
    ];
    $total_c=max(1,count($mis_contenidos));
    foreach($tipos_data as [$ico,$lbl,$cnt,$clr]):
      $pct=round($cnt/$total_c*100);
    ?>
    <div class="card cp" style="text-align:center;">
      <div style="font-size:1.6rem;margin-bottom:6px;"><?= $ico ?></div>
      <div style="font-family:var(--font-d);font-size:1.2rem;font-weight:900;color:var(--<?= $clr ?>-lt,var(--muted));"><?= $cnt ?></div>
      <div style="font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;"><?= $lbl ?></div>
      <div style="height:3px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden;margin-top:8px;">
        <div style="height:100%;width:<?= $pct ?>%;background:var(--<?= $clr ?>-lt,var(--green));border-radius:99px;transition:width 1s;"></div>
      </div>
    </div>
    <?php endforeach;?>
  </div>
</div>


<!-- █████████ COMUNIDAD / COMENTARIOS █████████ -->
<div class="cr-sec" id="sec-comunidad">
  <div class="sec-hd">
    <h2>💬 Comunidad & Comentarios</h2><div class="sec-hd-line"></div>
    <span style="font-size:.75rem;color:var(--muted);"><?= count($comentarios) ?> comentarios recientes</span>
  </div>
  <?php if(empty($comentarios)):?>
  <div class="empty-state"><div class="es-ico">💬</div><p class="es-txt">Aún no tienes comentarios en tus contenidos.</p></div>
  <?php else: foreach($comentarios as $cm):
    $cav=$cm['autor_avatar']??'';$cini=mb_substr($cm['autor_nombre']??'A',0,1);
  ?>
  <div class="comment-item">
    <?php if($cav):?><img src="<?= htmlspecialchars($cav) ?>" class="cm-av" alt=""><?php else:?><div class="cm-av-ph"><?= $cini ?></div><?php endif;?>
    <div class="cm-body">
      <div class="cm-autor"><?= htmlspecialchars($cm['autor_nombre']??'Anónimo') ?></div>
      <div class="cm-contenido">en "<?= htmlspecialchars(mb_substr($cm['contenido_titulo']??'',0,40)) ?>..."</div>
      <div class="cm-texto"><?= htmlspecialchars($cm['comentario']??$cm['texto']??'') ?></div>
      <div class="cm-fecha"><?= !empty($cm['fecha'])?date('d M Y H:i',strtotime($cm['fecha'])):'—' ?></div>
    </div>
    <div style="display:flex;gap:5px;flex-shrink:0;">
      <button class="ab ab-purple btn-sm"><i class="fa fa-reply"></i></button>
      <button class="ab ab-red btn-sm"><i class="fa fa-trash"></i></button>
    </div>
  </div>
  <?php endforeach;endif;?>
</div>


<!-- █████████ MIS CURSOS (como instructor) █████████ -->
<div class="cr-sec" id="sec-cursos">
  <div class="sec-hd">
    <h2>🎓 Mis Cursos</h2><div class="sec-hd-line"></div>
    <button class="btn btn-purple" onclick="showSec('subir');document.getElementById('ft_tipo').value='documento'"><i class="fa fa-plus"></i> Nuevo curso</button>
  </div>
  <?php if(empty($mis_cursos)):?>
  <div class="empty-state"><div class="es-ico">🎓</div><p class="es-txt">Aún no eres instructor de ningún curso. Contacta con el administrador para habilitar esta función.</p></div>
  <?php else: foreach($mis_cursos as $c): $prog=round(($c['inscritos']/max(1,$c['total_subs']??100))*100); ?>
  <div class="curso-mini">
    <div class="cm-ico"><?= htmlspecialchars($c['icono']??'📚') ?></div>
    <div class="cm-info">
      <div class="cm-title"><?= htmlspecialchars($c['titulo']) ?></div>
      <div class="cm-meta"><?= ucfirst($c['nivel']??'') ?> · <?= htmlspecialchars($c['duracion']??'') ?></div>
    </div>
    <div style="text-align:center;">
      <div class="cm-inscritos"><?= $c['inscritos'] ?></div>
      <div style="font-size:.62rem;color:var(--dim);">inscritos</div>
    </div>
    <button class="ab ab-purple"><i class="fa fa-pen"></i></button>
  </div>
  <?php endforeach;endif;?>
</div>


</main>
</div><!-- /cr-wrap -->


<!-- ════════════ MODALES ════════════ -->

<!-- Modal: Editar contenido -->
<div class="cr-modal" id="mEditContenido">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">✏️ Editar Contenido</span><button class="m-close" onclick="cerrarModal('mEditContenido')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <input type="hidden" id="ec_id">
      <div class="fg"><label class="fl">Título *</label><input type="text" class="fi" id="ec_titulo"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="ec_desc" rows="3"></textarea></div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Tipo</label>
          <select class="fi" id="ec_tipo">
            <option value="video">🎬 Video</option><option value="podcast">🎙 Podcast</option>
            <option value="infografia">📊 Infografía</option><option value="presentacion">📑 Presentación</option>
            <option value="audio">🎧 Audio</option><option value="documento">📄 Documento</option>
          </select>
        </div>
        <div class="fg"><label class="fl">Categoría</label><input type="text" class="fi" id="ec_cat"></div>
      </div>
      <div class="fg-2">
        <div class="fg"><label class="fl">Tags</label><input type="text" class="fi" id="ec_tags"></div>
        <div class="fg"><label class="fl">Duración</label><input type="text" class="fi" id="ec_dur"></div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">
        <span style="font-size:.82rem;color:var(--txt);">Publicado</span>
        <label class="tg"><input type="checkbox" id="ec_pub"><span class="tg-sl"></span></label>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">
        <span style="font-size:.82rem;color:var(--txt);">Destacado</span>
        <label class="tg"><input type="checkbox" id="ec_dest"><span class="tg-sl"></span></label>
      </div>
    </div>
    <div class="m-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mEditContenido')">Cancelar</button>
      <button class="em-btn em-btn-purple" onclick="guardarEditContenido()"><i class="fa fa-save"></i> Guardar cambios</button>
    </div>
  </div>
</div>

<!-- Modal: Crear canal -->
<div class="cr-modal" id="mCrearCanal">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">📡 Crear Canal</span><button class="m-close" onclick="cerrarModal('mCrearCanal')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <div class="fg"><label class="fl">Nombre del canal *</label><input type="text" class="fi" id="cc_nombre" placeholder="Ej: VIROX Tech"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="cc_desc" rows="3" placeholder="¿De qué trata tu canal?"></textarea></div>
      <div class="fg"><label class="fl">Avatar (emoji o URL)</label><input type="text" class="fi" id="cc_avatar" value="📺" placeholder="📺 o https://...imagen.jpg"></div>
    </div>
    <div class="m-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mCrearCanal')">Cancelar</button>
      <button class="em-btn em-btn-purple" onclick="crearCanal()"><i class="fa fa-plus"></i> Crear canal</button>
    </div>
  </div>
</div>

<!-- Modal: Editar canal -->
<div class="cr-modal" id="mEditCanal">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">✏️ Editar Canal</span><button class="m-close" onclick="cerrarModal('mEditCanal')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <input type="hidden" id="ecca_id" value="<?= $mi_canal['id']??0 ?>">
      <div class="fg"><label class="fl">Nombre del canal *</label><input type="text" class="fi" id="ecca_nombre" value="<?= htmlspecialchars($mi_canal['nombre']??'') ?>"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="ecca_desc" rows="3"><?= htmlspecialchars($mi_canal['descripcion']??'') ?></textarea></div>
      <div class="fg"><label class="fl">Avatar (emoji o URL)</label><input type="text" class="fi" id="ecca_avatar" value="<?= htmlspecialchars($mi_canal['avatar']??'📺') ?>"></div>
    </div>
    <div class="m-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mEditCanal')">Cancelar</button>
      <button class="em-btn em-btn-purple" onclick="guardarCanal()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>

<!-- Modal: Nueva Playlist -->
<div class="cr-modal" id="mNuevoPlaylist">
  <div class="m-box">
    <div class="m-hd"><span class="m-ttl">▶ Nueva Playlist</span><button class="m-close" onclick="cerrarModal('mNuevoPlaylist')"><i class="fa fa-times"></i></button></div>
    <div class="m-body">
      <div class="fg"><label class="fl">Título *</label><input type="text" class="fi" id="pl_titulo" placeholder="Ej: 📚 Fundamentos de Programación"></div>
      <div class="fg"><label class="fl">Descripción</label><textarea class="fi" id="pl_desc" rows="2"></textarea></div>
      <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">
        <span style="font-size:.82rem;color:var(--txt);">Playlist pública</span>
        <label class="tg"><input type="checkbox" id="pl_publica" checked><span class="tg-sl"></span></label>
      </div>
    </div>
    <div class="m-foot">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('mNuevoPlaylist')">Cancelar</button>
      <button class="em-btn em-btn-purple" onclick="crearPlaylist()"><i class="fa fa-plus"></i> Crear playlist</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast-w" id="toastW"></div>


<!-- ════════════ JAVASCRIPT ════════════ -->
<script>
/* ══ NAV ══ */
const SEC_NAMES={dashboard:'Dashboard',contenidos:'Mis Contenidos',subir:'Subir Contenido',playlists:'Playlists',editor:'Edición & Diseño',notas:'Scripts & Notas',canal:'Mi Canal',analiticas:'Analíticas',comunidad:'Comunidad',cursos:'Mis Cursos'};
function showSec(id,el){
  document.querySelectorAll('.cr-sec').forEach(s=>s.classList.remove('on'));
  document.querySelectorAll('.sb-item').forEach(i=>i.classList.remove('on'));
  document.getElementById('sec-'+id)?.classList.add('on');
  if(el)el.classList.add('on');
  else document.querySelector(`.sb-item[onclick*="'${id}'"]`)?.classList.add('on');
  document.getElementById('tbSub').textContent=SEC_NAMES[id]||id;
  document.querySelector('.cr-main')?.scrollTo({top:0,behavior:'smooth'});
  if(window.innerWidth<820)closeSb();
}

/* ══ SIDEBAR ══ */
function toggleSb(){document.getElementById('crSb').classList.toggle('open');}
function closeSb(){document.getElementById('crSb').classList.remove('open');}

/* ══ MODALES ══ */
function abrirModal(id){document.getElementById(id).classList.add('on');document.body.style.overflow='hidden';}
function cerrarModal(id){document.getElementById(id).classList.remove('on');document.body.style.overflow='';}
document.querySelectorAll('.cr-modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m){m.classList.remove('on');document.body.style.overflow=''}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.cr-modal.on').forEach(m=>m.classList.remove('on'));document.body.style.overflow=''}});

/* ══ TOAST ══ */
function toast(msg,tipo='ok',dur=3500){
  const w=document.getElementById('toastW'),t=document.createElement('div');
  const icons={ok:'fa-circle-check',err:'fa-triangle-exclamation',info:'fa-circle-info'};
  t.className=`tst t-${tipo}`;
  t.innerHTML=`<i class="fa ${icons[tipo]}"></i>${msg}`;
  w.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(14px)';t.style.transition='all .3s';setTimeout(()=>t.remove(),300);},dur);
}

/* ══ FETCH ══ */
async function postAction(data){
  const fd=new FormData();
  Object.entries(data).forEach(([k,v])=>fd.append(k,v));
  try{const r=await fetch('',{method:'POST',body:fd});return await r.json();}
  catch(e){return{ok:false,error:'Error de conexión'};}
}

/* ══ SUBIR CONTENIDO ══ */
function previewFile(inp){
  const f=inp.files[0]; if(!f)return;
  const pv=document.getElementById('ft_preview');
  document.getElementById('ft_prev_name').textContent=f.name;
  document.getElementById('ft_prev_size').textContent=(f.size/1024/1024).toFixed(2)+' MB';
  pv.style.display='block';
}

async function guardarContenido(publicar){
  const titulo=document.getElementById('ft_titulo').value.trim();
  if(!titulo){toast('El título es obligatorio','err');return;}
  const r=await postAction({
    accion:'upsert_contenido',id:0,
    titulo,
    descripcion:document.getElementById('ft_desc').value,
    tipo:document.getElementById('ft_tipo').value,
    categoria:document.getElementById('ft_cat').value,
    duracion:document.getElementById('ft_dur').value,
    tags:document.getElementById('ft_tags').value,
    canal_id:document.getElementById('ft_canal').value||0,
    publicado:publicar||(document.getElementById('ft_pub').checked)?1:0,
    destacado:document.getElementById('ft_dest').checked?1:0,
  });
  if(r.ok){
    toast(publicar?'✅ Contenido publicado correctamente':'📝 Guardado como borrador','ok');
    // Limpiar form
    ['ft_titulo','ft_desc','ft_cat','ft_dur','ft_tags','ft_url','ft_thumb'].forEach(id=>document.getElementById(id).value='');
    document.getElementById('ft_preview').style.display='none';
    setTimeout(()=>{ showSec('contenidos'); location.reload(); },1500);
  }else toast('Error: '+r.error,'err');
}

/* ══ TOGGLE PUBLICADO ══ */
async function togglePublicado(id,val,btn){
  const r=await postAction({accion:'toggle_publicado',id,valor:val});
  if(r.ok){
    btn.textContent=val?'✅ Publicado':'📝 Borrador';
    btn.className='badge '+(val?'b-pub':'b-borr');
    btn.setAttribute('onclick',`togglePublicado(${id},${val?0:1},this)`);
    toast(val?'✅ Contenido publicado':'📝 Movido a borradores','ok');
  }else toast('Error: '+r.error,'err');
}

/* ══ EDITAR CONTENIDO ══ */
function abrirEditContenido(c){
  if(typeof c === 'string') c=JSON.parse(c);
  document.getElementById('ec_id').value=c.id;
  document.getElementById('ec_titulo').value=c.titulo||'';
  document.getElementById('ec_desc').value=c.descripcion||'';
  document.getElementById('ec_tipo').value=c.tipo||'video';
  document.getElementById('ec_cat').value=c.categoria||'';
  document.getElementById('ec_tags').value=c.tags||'';
  document.getElementById('ec_dur').value=c.duracion||'';
  document.getElementById('ec_pub').checked=c.publicado==1;
  document.getElementById('ec_dest').checked=c.destacado==1;
  abrirModal('mEditContenido');
}
async function guardarEditContenido(){
  const id=document.getElementById('ec_id').value;
  const r=await postAction({
    accion:'upsert_contenido',id,
    titulo:document.getElementById('ec_titulo').value,
    descripcion:document.getElementById('ec_desc').value,
    tipo:document.getElementById('ec_tipo').value,
    categoria:document.getElementById('ec_cat').value,
    tags:document.getElementById('ec_tags').value,
    duracion:document.getElementById('ec_dur').value,
    publicado:document.getElementById('ec_pub').checked?1:0,
    destacado:document.getElementById('ec_dest').checked?1:0,
    canal_id:0,
  });
  if(r.ok){toast('✅ Contenido actualizado','ok');cerrarModal('mEditContenido');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ ELIMINAR CONTENIDO ══ */
async function eliminarContenido(id,titulo){
  if(!confirm(`¿Eliminar "${titulo}"? Esta acción no se puede deshacer.`))return;
  const r=await postAction({accion:'delete_contenido',id});
  if(r.ok){toast('🗑 Contenido eliminado','info');setTimeout(()=>location.reload(),1000);}
  else toast('Error: '+r.error,'err');
}

/* ══ CANAL ══ */
function abrirEditCanal(){abrirModal('mEditCanal');}
async function crearCanal(){
  const nombre=document.getElementById('cc_nombre').value.trim();
  if(!nombre){toast('El nombre es obligatorio','err');return;}
  const r=await postAction({accion:'crear_canal',nombre,descripcion:document.getElementById('cc_desc').value,avatar:document.getElementById('cc_avatar').value||'📺'});
  if(r.ok){toast('📡 Canal creado exitosamente','ok');cerrarModal('mCrearCanal');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
async function guardarCanal(){
  const r=await postAction({
    accion:'update_canal',
    canal_id:document.getElementById('ecca_id').value,
    nombre:document.getElementById('ecca_nombre').value,
    descripcion:document.getElementById('ecca_desc').value,
    avatar:document.getElementById('ecca_avatar').value,
  });
  if(r.ok){toast('✅ Canal actualizado','ok');cerrarModal('mEditCanal');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ PLAYLIST ══ */
async function crearPlaylist(){
  const titulo=document.getElementById('pl_titulo').value.trim();
  const canalId=<?= (int)($mi_canal['id']??0) ?>;
  if(!titulo){toast('El título es obligatorio','err');return;}
  if(!canalId){toast('Primero crea tu canal','err');return;}
  const r=await postAction({accion:'crear_playlist',canal_id:canalId,titulo,descripcion:document.getElementById('pl_desc').value,publica:document.getElementById('pl_publica').checked?1:0});
  if(r.ok){toast('✅ Playlist creada','ok');cerrarModal('mNuevoPlaylist');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ NOTAS ══ */
async function guardarNota(){
  const cont=document.getElementById('nota_content').value;
  const r=await postAction({accion:'guardar_nota',contenido:cont});
  if(r.ok)toast('📝 Nota guardada correctamente','ok');
  else toast('Error al guardar','err');
}
function cargarPlantilla(tmpl){
  if(confirm('¿Cargar esta plantilla? Se reemplazará el contenido actual.'))
    document.getElementById('nota_content').value=tmpl.replace(/\\n/g,'\n');
}

/* ══ GENERAR CON IA ══ */
function generarConIA(){
  const prompt=document.getElementById('ia_prompt').value.trim();
  if(!prompt){toast('Describe el tema primero','err');return;}
  // Redirigir a IA.php con el prompt precargado
  window.open(`../IA.php?prompt=${encodeURIComponent('Genera un script completo para un video/podcast sobre: '+prompt+'. Incluye intro, puntos principales, ejemplos y CTA.')}`, '_blank');
}

/* ══ FILTRAR CONTENIDOS ══ */
function filtrarContenido(estado, btn){
  document.querySelectorAll('#sec-contenidos .btn').forEach(b=>{
    if(['Todos','✅ Publicados','📝 Borradores'].some(t=>b.textContent.includes(t.trim())))
      b.className=b.className.replace('btn-purple','btn-ghost');
  });
  if(btn){btn.className=btn.className.replace('btn-ghost','btn-purple');}
  document.querySelectorAll('#contTable tbody tr').forEach(tr=>{
    tr.style.display=(!estado||tr.dataset.estado===estado)?'':'none';
  });
}

/* ══ BÚSQUEDA ══ */
document.getElementById('gSearch').addEventListener('keydown',e=>{
  if(e.key!=='Enter')return;
  const q=e.target.value.toLowerCase();if(!q)return;
  document.querySelectorAll('#contTable tbody tr').forEach(tr=>{
    tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none';
  });
  toast(`🔍 Filtrando: "${q}"`, 'info');
});

/* ══ EXPORTAR CSV ══ */
function exportarCSV(){
  const rows=[['Título','Tipo','Vistas','Likes','Estado','Fecha']];
  document.querySelectorAll('#contTable tbody tr').forEach(tr=>{
    const tds=[...tr.querySelectorAll('td')];
    if(tds.length>3)rows.push([tds[1]?.querySelector('.cont-info-name')?.textContent||'',tds[2]?.textContent?.trim()||'',tds[3]?.textContent?.trim()||'',tds[4]?.textContent?.trim()||'',tds[5]?.textContent?.trim()||'',tds[6]?.textContent?.trim()||'']);
  });
  const csv=rows.map(r=>r.join(',')).join('\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const url=URL.createObjectURL(blob);
  const a=document.createElement('a');a.href=url;a.download='contenidos_virox_'+new Date().toISOString().slice(0,10)+'.csv';a.click();
  URL.revokeObjectURL(url);
  toast('📊 CSV exportado','ok');
}

/* ══ ANIMACIONES REVEAL ══ */
const ro=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';}}),{threshold:.04});
document.querySelectorAll('.stat-card,.tool-card,.pl-item,.comment-item,.curso-mini,.qa').forEach((el,i)=>{
  el.style.opacity='0';el.style.transform='translateY(12px)';
  el.style.transition=`opacity .4s ease ${i*.03}s,transform .4s ease ${i*.03}s`;
  ro.observe(el);
});

/* ══ INIT ══ */
const urlSec=new URLSearchParams(location.search).get('sec');
if(urlSec&&SEC_NAMES[urlSec])showSec(urlSec);
</script>
</body>
</html>