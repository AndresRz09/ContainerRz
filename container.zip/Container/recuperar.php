<?php
include 'conexion.php';
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Configuración desde BD
$nombre_sistema = 'ContainerRz';
$correo_sistema = 'contacto@teamvirox.com';
if (isset($conexion)) {
    $qc = $conexion->query("SELECT clave, valor FROM configuracion WHERE clave IN ('nombre_sistema','email') LIMIT 2");
    if ($qc) while ($r = $qc->fetch_assoc()) {
        if ($r['clave'] === 'nombre_sistema') $nombre_sistema = $r['valor'];
        if ($r['clave'] === 'email') $correo_sistema = $r['valor'];
    }
}

$msg      = '';
$msg_type = ''; // 'success' | 'error' | 'warn'
$sent     = false;

// ── PROCESAR SOLICITUD ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recuperar'])) {
    $input  = trim($_POST['input'] ?? '');
    $metodo = $_POST['metodo'] ?? 'correo'; // correo | sms

    if ($input === '') {
        $msg = 'Por favor ingresa tu correo, teléfono o nombre de usuario.';
        $msg_type = 'error';
    } else {
        // Buscar usuario por correo, teléfono o username
        $sql = "SELECT us.id AS seg_id, us.correo, us.telefono,
                       u.id AS user_id, u.nombre, u.apellido
                FROM usuarios_seguridad us
                INNER JOIN usuarios u ON us.usuario_id = u.id
                WHERE us.correo = ?
                   OR us.telefono = ?
                   OR u.username = ?
                   AND u.activo = 1
                LIMIT 1";
        $stmt = $conexion->prepare($sql);
        $stmt->bind_param("sss", $input, $input, $input);
        $stmt->execute();
        $result = $stmt->get_result();
        $stmt->close();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();

            // Generar token seguro
            $token   = bin2hex(random_bytes(32)); // 64 chars
            $expiry  = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $seg_id  = $row['seg_id'];
            $correo  = $row['correo'];
            $telefono= $row['telefono'];
            $nombre  = $row['nombre'];

            // Guardar token en BD
            $upd = $conexion->prepare(
                "UPDATE usuarios_seguridad
                 SET token_reset = ?, token_reset_expiry = ?
                 WHERE id = ?"
            );
            $upd->bind_param("ssi", $token, $expiry, $seg_id);
            $upd->execute();
            $upd->close();

            // URL de recuperación
            $base_url = (isset($_SERVER['HTTPS']) ? 'https' : 'http')
                . '://' . $_SERVER['HTTP_HOST']
                . dirname($_SERVER['PHP_SELF']);
            $reset_url = rtrim($base_url, '/') . '/nueva-contrasena.php?token=' . $token;

            $ok_envio = false;

            // ── MÉTODO CORREO ──────────────────────────────────
            if ($metodo === 'correo' && !empty($correo)) {
                $asunto  = "Recupera tu cuenta — {$nombre_sistema}";
                $cuerpo  = buildEmailHTML($nombre, $reset_url, $nombre_sistema, $expiry);
                $headers = implode("\r\n", [
                    "MIME-Version: 1.0",
                    "Content-type: text/html; charset=UTF-8",
                    "From: {$nombre_sistema} <{$correo_sistema}>",
                    "Reply-To: {$correo_sistema}",
                    "X-Mailer: PHP/" . PHP_VERSION,
                ]);
                $ok_envio = mail($correo, $asunto, $cuerpo, $headers);

                if ($ok_envio) {
                    // Enmascarar correo: a***@dominio.com
                    $partes    = explode('@', $correo);
                    $masked    = substr($partes[0], 0, 2) . str_repeat('*', max(3, strlen($partes[0]) - 2)) . '@' . $partes[1];
                    $msg       = "¡Enviado! Revisa tu correo <strong>{$masked}</strong>. El enlace expira en 1 hora.";
                    $msg_type  = 'success';
                    $sent      = true;
                } else {
                    // Si mail() falla (XAMPP local) mostramos el enlace directo para pruebas
                    $msg      = "No se pudo enviar el correo automáticamente. En entorno local usa este enlace: <a href='{$reset_url}' style='color:var(--gold-lt);text-decoration:underline;'>Restablecer contraseña</a>";
                    $msg_type = 'warn';
                    $sent     = true;
                }

            // ── MÉTODO SMS / WHATSAPP ──────────────────────────
            } elseif ($metodo === 'sms' && !empty($telefono)) {
                // En XAMPP no hay gateway SMS — mostramos enlace + instrucción
                // Para producción: integrar Twilio, AWS SNS o similar
                $msg_sms  = urlencode("Tu enlace de recuperación {$nombre_sistema}: {$reset_url} (válido 1 hora)");
                $wa_url   = "https://wa.me/" . preg_replace('/[^0-9]/', '', $telefono) . "?text={$msg_sms}";

                // Enmascarar teléfono
                $tel_mask = substr($telefono, 0, 4) . str_repeat('*', max(4, strlen($telefono) - 7)) . substr($telefono, -3);

                $msg      = "No hay gateway SMS configurado. <a href='{$wa_url}' target='_blank' style='color:var(--gold-lt);text-decoration:underline;'>Enviar por WhatsApp</a> al número {$tel_mask} o usa el método de correo.";
                $msg_type = 'warn';
                $sent     = true;

            } else {
                $msg      = "No se encontró " . ($metodo === 'sms' ? "teléfono" : "correo") . " asociado a esa cuenta. Intenta con otro método.";
                $msg_type = 'error';
            }

        } else {
            // No revelar si existe o no la cuenta (seguridad)
            $msg      = "Si esa cuenta existe en nuestro sistema, recibirás las instrucciones en breve.";
            $msg_type = 'success';
            $sent     = true;
        }
    }
}

// ── Helper: HTML del correo ───────────────────────────────────
function buildEmailHTML(string $nombre, string $url, string $sistema, string $expiry): string {
    $exp_fmt = date('d/m/Y H:i', strtotime($expiry));
    return <<<HTML
<!DOCTYPE html>
<html lang="es">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#020817;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#020817;padding:40px 20px;">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#0c1526;border-radius:16px;overflow:hidden;border:1px solid rgba(40,166,128,.2);">
        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#0a1f3d,#020817);padding:32px;text-align:center;border-bottom:1px solid rgba(40,166,128,.2);">
          <div style="font-size:2rem;margin-bottom:8px;">⬡</div>
          <div style="font-family:monospace;font-size:1.4rem;font-weight:900;color:#DAA520;letter-spacing:4px;">{$sistema}</div>
          <div style="font-size:.82rem;color:#8da0b8;margin-top:4px;text-transform:uppercase;letter-spacing:2px;">Recuperación de cuenta</div>
        </td></tr>
        <!-- Cuerpo -->
        <tr><td style="padding:32px;">
          <p style="color:#f0f4f8;font-size:1rem;margin-bottom:8px;">Hola, <strong style="color:#35d4a8;">{$nombre}</strong> 👋</p>
          <p style="color:#8da0b8;font-size:.9rem;line-height:1.7;margin-bottom:28px;">
            Recibimos una solicitud para restablecer la contraseña de tu cuenta en <strong style="color:#f0f4f8;">{$sistema}</strong>. Si no fuiste tú, ignora este correo.
          </p>
          <div style="text-align:center;margin-bottom:28px;">
            <a href="{$url}" style="display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#28A680,#1d8f6e);color:#fff;font-weight:800;font-size:.95rem;border-radius:12px;text-decoration:none;letter-spacing:.5px;">
              🔑 Restablecer contraseña
            </a>
          </div>
          <div style="background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.25);border-radius:10px;padding:14px 18px;margin-bottom:20px;">
            <p style="color:#35d4a8;font-size:.8rem;margin:0;">⏰ <strong>Este enlace expira el {$exp_fmt}</strong> (1 hora desde ahora).</p>
          </div>
          <p style="color:#526278;font-size:.75rem;line-height:1.6;">
            Si el botón no funciona, copia y pega este enlace en tu navegador:<br>
            <span style="color:#DAA520;word-break:break-all;">{$url}</span>
          </p>
        </td></tr>
        <!-- Footer -->
        <tr><td style="padding:20px 32px;border-top:1px solid rgba(255,255,255,.06);text-align:center;">
          <p style="color:#526278;font-size:.72rem;margin:0;">© 2025 {$sistema} — No responder a este correo.</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Recuperar cuenta — <?= htmlspecialchars($nombre_sistema) ?></title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --red:#ef4444;--red-dim:rgba(239,68,68,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --r-md:14px;--r-lg:22px;--font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html,body{height:100%;font-family:var(--font-b);background:var(--n900);color:var(--txt);}
    a{text-decoration:none;color:inherit;}
    button{cursor:pointer;border:none;font-family:inherit;}

    .page{min-height:100vh;display:grid;grid-template-columns:1fr 460px;}

    /* ── Panel izquierdo decorativo ── */
    .left-panel{
      position:relative;overflow:hidden;
      background:radial-gradient(ellipse 90% 80% at 30% 40%,#0a1a38 0%,var(--n900) 70%);
      display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 48px;
    }
    .lp-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.05) 1px,transparent 1px);background-size:52px 52px;}
    .lp-orb{position:absolute;border-radius:50%;filter:blur(90px);}
    .lporb1{width:450px;height:450px;background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-100px;left:-100px;animation:orbf 9s ease-in-out infinite;}
    .lporb2{width:350px;height:350px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-80px;right:-60px;animation:orbf 11s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}
    .lp-content{position:relative;z-index:1;text-align:center;max-width:500px;}
    .lp-ico{font-size:4rem;margin-bottom:20px;animation:float 3s ease-in-out infinite;}
    @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
    .lp-title{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);letter-spacing:2px;margin-bottom:12px;}
    .lp-sub{font-size:.9rem;color:var(--muted);line-height:1.75;margin-bottom:36px;}
    .lp-steps{display:flex;flex-direction:column;gap:14px;text-align:left;}
    .lp-step{display:flex;align-items:flex-start;gap:14px;padding:14px 16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);}
    .lp-step-n{width:28px;height:28px;border-radius:50%;background:var(--green-dim);border:1px solid rgba(40,166,128,.4);display:flex;align-items:center;justify-content:center;font-family:var(--font-d);font-size:.65rem;font-weight:700;color:var(--green-lt);flex-shrink:0;}
    .lp-step-body strong{display:block;font-size:.85rem;color:var(--txt);margin-bottom:2px;}
    .lp-step-body span{font-size:.75rem;color:var(--muted);}

    /* ── Panel derecho (formulario) ── */
    .right-panel{
      background:var(--n800);border-left:1px solid rgba(255,255,255,.06);
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      padding:40px 40px;
    }
    .form-wrap{width:100%;max-width:360px;}

    /* Logo */
    .form-logo{display:flex;align-items:center;gap:8px;margin-bottom:28px;}
    .fl-hex{font-size:1.4rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green));}
    .fl-name{font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);letter-spacing:3px;}

    .form-title{font-family:var(--font-d);font-size:1.3rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .form-sub{font-size:.82rem;color:var(--muted);margin-bottom:24px;line-height:1.5;}

    /* Alertas */
    .alert{border-radius:var(--r-md);padding:12px 16px;margin-bottom:20px;font-size:.82rem;display:flex;align-items:flex-start;gap:10px;line-height:1.5;}
    .alert-success{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
    .alert-error{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#fca5a5;}
    .alert-warn{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
    .alert i{margin-top:2px;flex-shrink:0;}

    /* Tabs de método */
    .method-tabs{display:flex;gap:4px;background:rgba(255,255,255,.04);padding:3px;border-radius:var(--r-md);margin-bottom:20px;}
    .mtab{flex:1;padding:9px;border-radius:10px;font-size:.75rem;font-weight:700;color:var(--muted);transition:all .2s;text-align:center;cursor:pointer;background:none;}
    .mtab.active{background:var(--green);color:#fff;box-shadow:0 2px 8px rgba(40,166,128,.3);}

    /* Input */
    .input-group{position:relative;margin-bottom:16px;}
    .input-group label{display:block;font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
    .input-icon{position:absolute;left:13px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.88rem;pointer-events:none;margin-top:10px;}
    .linput{width:100%;padding:12px 13px 12px 38px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.9rem;transition:all .2s;}
    .linput:focus{outline:none;border-color:var(--green);background:rgba(40,166,128,.06);box-shadow:0 0 0 3px rgba(40,166,128,.12);}

    /* Hint bajo el input */
    .input-hint{font-size:.7rem;color:var(--dim);margin-top:4px;margin-bottom:0;}

    /* Botón */
    .btn-primary{width:100%;padding:13px;background:linear-gradient(135deg,var(--green),#1d8f6e);color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.92rem;transition:all .2s;box-shadow:0 4px 18px rgba(40,166,128,.35);}
    .btn-primary:hover{background:linear-gradient(135deg,var(--green-lt),var(--green));transform:translateY(-2px);}

    /* Estado enviado */
    .sent-state{text-align:center;padding:20px 0;}
    .sent-ico{font-size:4rem;margin-bottom:16px;animation:float 2.5s ease-in-out infinite;}
    .sent-title{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--green-lt);margin-bottom:8px;}
    .sent-sub{font-size:.82rem;color:var(--muted);line-height:1.65;margin-bottom:20px;}

    /* Footer */
    .form-footer{margin-top:20px;text-align:center;font-size:.78rem;color:var(--muted);display:flex;flex-direction:column;gap:8px;}
    .form-footer a{color:var(--gold);font-weight:700;}
    .form-footer a:hover{color:var(--gold-lt);}

    /* Divisor */
    .divider{display:flex;align-items:center;gap:10px;margin:14px 0;}
    .divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.08);}
    .divider span{font-size:.7rem;color:var(--dim);}

    @media(max-width:900px){
      .page{grid-template-columns:1fr;}
      .left-panel{display:none;}
      .right-panel{padding:32px 24px;}
    }
  </style>
</head>
<body>
<div class="page">

  <!-- ── Panel izquierdo ──────────────────────────────────────── -->
  <div class="left-panel">
    <div class="lp-grid"></div>
    <div class="lp-orb lporb1"></div>
    <div class="lp-orb lporb2"></div>
    <div class="lp-content">
      <div class="lp-ico">🔓</div>
      <div class="lp-title">Recupera tu acceso</div>
      <p class="lp-sub">Sin importar cómo iniciabas sesión, puedes recuperar tu cuenta en tres simples pasos.</p>
      <div class="lp-steps">
        <div class="lp-step">
          <div class="lp-step-n">1</div>
          <div class="lp-step-body">
            <strong>Ingresa tu dato de registro</strong>
            <span>Correo electrónico, teléfono o nombre de usuario</span>
          </div>
        </div>
        <div class="lp-step">
          <div class="lp-step-n">2</div>
          <div class="lp-step-body">
            <strong>Recibe el enlace seguro</strong>
            <span>Te enviamos un enlace de un solo uso válido por 1 hora</span>
          </div>
        </div>
        <div class="lp-step">
          <div class="lp-step-n">3</div>
          <div class="lp-step-body">
            <strong>Crea tu nueva contraseña</strong>
            <span>Establece una contraseña segura y vuelve a ingresar</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── Panel formulario ─────────────────────────────────────── -->
  <div class="right-panel">
    <div class="form-wrap">

      <div class="form-logo">
        <span class="fl-hex">⬡</span>
        <span class="fl-name"><?= htmlspecialchars($nombre_sistema) ?></span>
      </div>

      <?php if ($sent): ?>
        <!-- Estado: enviado -->
        <div class="sent-state">
          <div class="sent-ico">📬</div>
          <div class="sent-title">¡Instrucciones enviadas!</div>
          <p class="sent-sub">
            <?php if ($msg_type === 'success'): ?>
              Revisa tu bandeja de entrada (y la carpeta de spam). El enlace de recuperación expira en <strong style="color:var(--gold-lt);">1 hora</strong>.
            <?php else: ?>
              Revisa el mensaje a continuación.
            <?php endif; ?>
          </p>
          <?php if ($msg): ?>
          <div class="alert alert-<?= $msg_type ?>">
            <i class="fa <?= $msg_type === 'success' ? 'fa-check-circle' : ($msg_type === 'warn' ? 'fa-triangle-exclamation' : 'fa-circle-xmark') ?>"></i>
            <span><?= $msg ?></span>
          </div>
          <?php endif; ?>
          <div class="form-footer">
            <span>¿No llegó el correo? <a href="recuperar.php">Intentar de nuevo</a></span>
            <a href="login.php">← Volver al login</a>
          </div>
        </div>

      <?php else: ?>
        <!-- Formulario -->
        <div class="form-title">Recuperar cuenta</div>
        <p class="form-sub">Ingresa el dato con el que te registraste y te enviamos el enlace para restablecer tu contraseña.</p>

        <?php if ($msg): ?>
        <div class="alert alert-<?= $msg_type ?>">
          <i class="fa <?= $msg_type === 'error' ? 'fa-circle-xmark' : 'fa-triangle-exclamation' ?>"></i>
          <span><?= $msg ?></span>
        </div>
        <?php endif; ?>

        <!-- Tabs de método de envío -->
        <div class="method-tabs">
          <button type="button" class="mtab active" id="tab-correo" onclick="setTab('correo',this)">
            📧 Correo
          </button>
          <button type="button" class="mtab" id="tab-sms" onclick="setTab('sms',this)">
            📱 SMS / WhatsApp
          </button>
        </div>

        <form method="POST" id="recForm">
          <input type="hidden" name="metodo" id="metodoInput" value="correo">

          <div class="input-group">
            <label id="inputLbl">Correo electrónico / Usuario</label>
            <i class="fa fa-envelope input-icon" id="inputIco"></i>
            <input class="linput" type="text" name="input" id="mainInput"
                   placeholder="correo@ejemplo.com o nombre_usuario"
                   required autocomplete="off"
                   value="<?= htmlspecialchars($_POST['input'] ?? '') ?>">
            <p class="input-hint" id="inputHint">Ingresa el correo con el que te registraste o tu nombre de usuario.</p>
          </div>

          <button type="submit" name="recuperar" class="btn-primary" id="submitBtn">
            <i class="fa fa-paper-plane"></i> Enviar instrucciones
          </button>
        </form>

        <div class="divider"><span>recordé mi contraseña</span></div>

        <div class="form-footer">
          <a href="login.php">← Volver al login</a>
          <span>¿No tienes cuenta? <a href="register.php">Regístrate gratis</a></span>
        </div>
      <?php endif; ?>

    </div>
  </div>
</div>

<script>
const tabConfig = {
  correo: {
    label:   'Correo electrónico / Usuario',
    placeholder: 'correo@ejemplo.com o nombre_usuario',
    icon:    'fa-envelope',
    hint:    'Ingresa el correo registrado o tu nombre de usuario.',
    btnTxt:  'Enviar enlace por correo',
  },
  sms: {
    label:   'Número de teléfono',
    placeholder: '+57 300 000 0000',
    icon:    'fa-mobile-alt',
    hint:    'Ingresa el teléfono registrado con prefijo internacional (+57 para Colombia).',
    btnTxt:  'Enviar enlace por WhatsApp / SMS',
  },
};

function setTab(tab, btn) {
  document.querySelectorAll('.mtab').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('metodoInput').value = tab;

  const cfg = tabConfig[tab];
  document.getElementById('inputLbl').textContent     = cfg.label;
  document.getElementById('mainInput').placeholder    = cfg.placeholder;
  document.getElementById('mainInput').type           = tab === 'sms' ? 'tel' : 'text';
  document.getElementById('inputIco').className       = 'fa ' + cfg.icon + ' input-icon';
  document.getElementById('inputHint').textContent    = cfg.hint;
  document.getElementById('submitBtn').innerHTML      = '<i class="fa fa-paper-plane"></i> ' + cfg.btnTxt;
  document.getElementById('mainInput').value          = '';
  document.getElementById('mainInput').focus();
}
</script>
</body>
</html>