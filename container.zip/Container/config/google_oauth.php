<?php


define('GOOGLE_CLIENT_ID',
    '517026423711-19gstckkos05rahtcbumuqflfi8df8vh.apps.googleusercontent.com'
);

define('GOOGLE_CLIENT_SECRET',
    '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'
);

// URI de callback — debe coincidir EXACTAMENTE con la configurada en Google Console
define('GOOGLE_REDIRECT_URI',
    'http://localhost/containerrz/auth/google_callback.php'
);

// Scopes que pedimos a Google
define('GOOGLE_SCOPES', implode(' ', [
    'openid',
    'https://www.googleapis.com/auth/userinfo.email',
    'https://www.googleapis.com/auth/userinfo.profile',
]));

// Endpoints de Google OAuth2
define('GOOGLE_AUTH_URL',  'https://accounts.google.com/o/oauth2/v2/auth');
define('GOOGLE_TOKEN_URL', 'https://oauth2.googleapis.com/token');
define('GOOGLE_USER_URL',  'https://www.googleapis.com/oauth2/v3/userinfo');