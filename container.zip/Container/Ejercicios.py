def fizz_buzz(n):
    for i in range(1, n + 1):
        if i % 3 == 0 and i % 5 == 0:
            print("FizzBuzz")
        elif i % 3 == 0:
            print("Fizz")
        elif i % 5 == 0:
            print("Buzz")
        else:
            print(i)
fizz_buzz(15)


#10
import random

opciones = ["Piedra", "Papel", "Tijera"]

computadora = random.choice(opciones)

jugador = input("Elige: Piedra, Papel o Tijera: ").capitalize()

print(f"La computadora eligió: {computadora}")

if jugador == computadora:
    print("¡Empate!")
elif (jugador == "Piedra" and computadora == "Tijera") or \
     (jugador == "Papel" and computadora == "Piedra") or \
     (jugador == "Tijera" and computadora == "Papel"):
    print("¡Ganaste!")
else:
    print("¡Perdiste!")
