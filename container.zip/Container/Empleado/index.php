<?php

include '../conexion.php';
session_start();

// ── Seguridad: solo empleados ────────────────────────────────────────────
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit(); }
$roles_validos = ['empleado', 'admin', 'superadmin'];
if (!in_array($_SESSION['rol'] ?? '', $roles_validos)) {
    header('Location: ../index.php'); exit();
}

$uid    = (int)$_SESSION['user_id'];
$rol    = $_SESSION['rol']       ?? 'empleado';
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'Empleado');
$avatar = htmlspecialchars($_SESSION['avatar']    ?? '../assets/Emma.png');

// ── Helper query ─────────────────────────────────────────────────────────
function qrow(mysqli $db, string $sql, string $t = '', ...$p): ?array {
    $s = $db->prepare($sql); if (!$s) return null;
    if ($t) $s->bind_param($t, ...$p);
    $s->execute(); $r = $s->get_result()->fetch_assoc(); $s->close(); return $r;
}
function qall(mysqli $db, string $sql, string $t = '', ...$p): array {
    $s = $db->prepare($sql); if (!$s) return [];
    if ($t) $s->bind_param($t, ...$p);
    $s->execute(); $rows = $s->get_result()->fetch_all(MYSQLI_ASSOC); $s->close(); return $rows;
}

// ══════════════════════════════════════════════════════════════════════════
//  PROCESAR ACCIONES POST (AJAX / Form)
// ══════════════════════════════════════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';
    header('Content-Type: application/json');

    // ── Aceptar / Rechazar adquisición ──────────────────────────────────
    if ($accion === 'gestionar_adquisicion') {
        $adq_id = (int)($_POST['adq_id'] ?? 0);
        $estado = in_array($_POST['estado'], ['pagado','cancelado']) ? $_POST['estado'] : '';
        $notas  = htmlspecialchars(trim($_POST['notas'] ?? ''), ENT_QUOTES);
        if ($adq_id && $estado) {
            $u = $conexion->prepare(
                "UPDATE servicio_adquisiciones SET estado=?, notas=?, empleado_id=?, fecha_gestion=NOW() WHERE id=?"
            );
            // notas y empleado_id pueden no existir en la tabla original — usamos try
            if ($u) {
                // Intentamos con columnas extra primero, si falla, simple
                $u->bind_param("ssii", $estado, $notas, $uid, $adq_id);
                if (!$u->execute()) {
                    $u->close();
                    $u2 = $conexion->prepare("UPDATE servicio_adquisiciones SET estado=? WHERE id=?");
                    if ($u2) { $u2->bind_param("si", $estado, $adq_id); $u2->execute(); $u2->close(); }
                } else { $u->close(); }
            }
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Datos inválidos']);
        }
        exit();
    }

    // ── Actualizar progreso de proyecto ─────────────────────────────────
    if ($accion === 'actualizar_progreso') {
        $proy_id  = (int)($_POST['proyecto_id'] ?? 0);
        $progreso = min(100, max(0, (int)($_POST['progreso'] ?? 0)));
        $estado   = htmlspecialchars($_POST['estado'] ?? '', ENT_QUOTES);
        // Verificar que el empleado pertenece al proyecto
        $check = qrow($conexion,
            "SELECT id FROM proyecto_usuarios WHERE proyecto_id=? AND usuario_id=?",
            "ii", $proy_id, $uid
        );
        if ($check) {
            $u = $conexion->prepare("UPDATE proyectos SET progreso=?, estado=? WHERE id=?");
            if ($u) { $u->bind_param("isi", $progreso, $estado, $proy_id); $u->execute(); $u->close(); }
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Sin permiso sobre este proyecto']);
        }
        exit();
    }

    // ── Agregar avance al proyecto ───────────────────────────────────────
    if ($accion === 'agregar_avance') {
        $proy_id = (int)($_POST['proyecto_id'] ?? 0);
        $titulo  = htmlspecialchars(trim($_POST['titulo']  ?? ''), ENT_QUOTES);
        $desc    = htmlspecialchars(trim($_POST['desc']    ?? ''), ENT_QUOTES);
        if ($proy_id && $titulo) {
            $ins = $conexion->prepare(
                "INSERT INTO proyecto_avances (proyecto_id, titulo, descripcion, fecha, autor_id) VALUES (?,?,?,CURDATE(),?)"
            );
            if ($ins) { $ins->bind_param("issi", $proy_id, $titulo, $desc, $uid); $ins->execute(); $ins->close(); }
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Datos incompletos']);
        }
        exit();
    }

    // ── Enviar mensaje interno ───────────────────────────────────────────
    if ($accion === 'enviar_mensaje') {
        $dest_id = (int)($_POST['destinatario_id'] ?? 0);
        $asunto  = htmlspecialchars(trim($_POST['asunto']  ?? ''), ENT_QUOTES);
        $mensaje = htmlspecialchars(trim($_POST['mensaje'] ?? ''), ENT_QUOTES);
        if ($dest_id && $asunto && $mensaje) {
            $ins = $conexion->prepare(
                "INSERT INTO mensajes_internos (remitente_id, destinatario_id, asunto, mensaje, fecha) VALUES (?,?,?,?,NOW())"
            );
            if ($ins) { $ins->bind_param("iiss", $uid, $dest_id, $asunto, $mensaje); $ins->execute(); $ins->close(); }
            echo json_encode(['ok' => true]);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Completa todos los campos']);
        }
        exit();
    }

    // ── Marcar mensaje como leído ────────────────────────────────────────
    if ($accion === 'marcar_leido') {
        $msg_id = (int)($_POST['msg_id'] ?? 0);
        $u = $conexion->prepare("UPDATE mensajes_internos SET leido=1 WHERE id=? AND destinatario_id=?");
        if ($u) { $u->bind_param("ii", $msg_id, $uid); $u->execute(); $u->close(); }
        echo json_encode(['ok' => true]);
        exit();
    }

    echo json_encode(['ok' => false, 'error' => 'Acción no reconocida']);
    exit();
}

// ══════════════════════════════════════════════════════════════════════════
//  CARGAR DATOS DEL DASHBOARD
// ══════════════════════════════════════════════════════════════════════════

// ── Perfil del empleado ──────────────────────────────────────────────────
$perfil = qrow($conexion,
    "SELECT u.*, e.area_tecnologica, e.cargo_equipo, e.tipo_equipo, e.calificacion,
            e.habilidades, e.disponible, e.descripcion_equipo
     FROM usuarios u LEFT JOIN equipo e ON e.usuario_id = u.id
     WHERE u.id = ? LIMIT 1",
    "i", $uid
);

// ── Servicios adquiridos pendientes de gestión ───────────────────────────
$servicios_pendientes = qall($conexion,
    "SELECT sa.id, sa.estado, sa.monto, sa.metodo_pago, sa.fecha,
            s.titulo, s.icono, s.categoria,
            u.nombre AS cliente_nombre, u.apellido AS cliente_apellido,
            u.avatar AS cliente_avatar, u.correo AS cliente_correo
     FROM servicio_adquisiciones sa
     JOIN servicios s ON s.id = sa.servicio_id
     JOIN usuarios u ON u.id = sa.usuario_id
     WHERE sa.estado = 'pendiente'
     ORDER BY sa.fecha DESC LIMIT 20"
);

// ── Todos los servicios para gestión ────────────────────────────────────
$servicios_todos = qall($conexion,
    "SELECT sa.id, sa.estado, sa.monto, sa.fecha,
            s.titulo, s.icono, s.categoria,
            u.nombre AS cliente_nombre, u.apellido AS cliente_apellido
     FROM servicio_adquisiciones sa
     JOIN servicios s ON s.id = sa.servicio_id
     JOIN usuarios u ON u.id = sa.usuario_id
     ORDER BY sa.fecha DESC LIMIT 50"
);

// ── Proyectos asignados al empleado ──────────────────────────────────────
$mis_proyectos = qall($conexion,
    "SELECT p.*, pu.rol_proyecto, pu.permisos,
            (SELECT COUNT(*) FROM proyecto_usuarios pu2 WHERE pu2.proyecto_id = p.id) AS total_miembros,
            (SELECT COUNT(*) FROM proyecto_avances pa WHERE pa.proyecto_id = p.id) AS total_avances
     FROM proyectos p
     JOIN proyecto_usuarios pu ON pu.proyecto_id = p.id AND pu.usuario_id = ?
     ORDER BY p.estado = 'activo' DESC, p.fecha_update DESC LIMIT 20",
    "i", $uid
);

// ── Todos los proyectos activos (para postularse) ────────────────────────
$proyectos_disponibles = qall($conexion,
    "SELECT p.id, p.titulo, p.descripcion, p.icono, p.estado, p.progreso,
            p.areas, p.tecnologias, p.fecha_inicio,
            (SELECT COUNT(*) FROM proyecto_usuarios WHERE proyecto_id=p.id) AS miembros
     FROM proyectos p
     WHERE p.estado IN ('planeado','activo') AND p.privado = 0
       AND p.id NOT IN (SELECT proyecto_id FROM proyecto_usuarios WHERE usuario_id = ?)
     ORDER BY p.estado = 'activo' DESC, p.fecha_inicio DESC LIMIT 12",
    "i", $uid
);

// ── Avances recientes de mis proyectos ───────────────────────────────────
$avances_recientes = qall($conexion,
    "SELECT pa.*, p.titulo AS proyecto_titulo, p.icono AS proyecto_icono,
             u.nombre AS autor_nombre
     FROM proyecto_avances pa
     JOIN proyectos p ON p.id = pa.proyecto_id
     LEFT JOIN usuarios u ON u.id = pa.autor_id
     WHERE pa.proyecto_id IN (
         SELECT proyecto_id FROM proyecto_usuarios WHERE usuario_id = ?
     )
     ORDER BY pa.fecha DESC LIMIT 10",
    "i", $uid
);

// ── Mensajes no leídos ───────────────────────────────────────────────────
$mensajes_nuevos = qall($conexion,
    "SELECT mi.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido,
             u.avatar AS remitente_avatar
     FROM mensajes_internos mi
     JOIN usuarios u ON u.id = mi.remitente_id
     WHERE mi.destinatario_id = ? AND mi.leido = 0
     ORDER BY mi.fecha DESC LIMIT 10",
    "i", $uid
);

// ── Todos los mensajes ───────────────────────────────────────────────────
$mensajes_todos = qall($conexion,
    "SELECT mi.*, u.nombre AS remitente_nombre, u.apellido AS remitente_apellido
     FROM mensajes_internos mi
     JOIN usuarios u ON u.id = mi.remitente_id
     WHERE mi.destinatario_id = ?
     ORDER BY mi.fecha DESC LIMIT 30",
    "i", $uid
);

// ── Compañeros del equipo ────────────────────────────────────────────────
$companneros = qall($conexion,
    "SELECT u.id, u.nombre, u.apellido, u.avatar, u.rol,
             e.cargo_equipo, e.area_tecnologica, e.disponible
     FROM usuarios u
     LEFT JOIN equipo e ON e.usuario_id = u.id
     WHERE u.activo = 1 AND u.id != ? AND u.rol IN ('empleado','admin','superadmin','creador')
     ORDER BY e.area_tecnologica, u.nombre LIMIT 20",
    "i", $uid
);

// ── Mis inscripciones en cursos ──────────────────────────────────────────
$mis_cursos = qall($conexion,
    "SELECT i.progreso, i.fecha_inscripcion, c.titulo, c.icono, c.nivel, c.duracion
     FROM inscripciones i
     JOIN cursos c ON c.id = i.curso_id
     WHERE i.usuario_id = ? ORDER BY i.fecha_inscripcion DESC LIMIT 8",
    "i", $uid
);

// ── Certificados obtenidos ───────────────────────────────────────────────
$mis_certificados = qall($conexion,
    "SELECT cert.*, c.titulo AS curso_titulo
     FROM certificados cert
     LEFT JOIN cursos c ON c.id = cert.curso_id
     WHERE cert.usuario_id = ? ORDER BY cert.fecha_emision DESC LIMIT 6",
    "i", $uid
);

// ── Estadísticas rápidas ─────────────────────────────────────────────────
$stats = [
    'proyectos_activos'  => count(array_filter($mis_proyectos, fn($p) => $p['estado'] === 'activo')),
    'servicios_gestion'  => count($servicios_pendientes),
    'mensajes_nuevos'    => count($mensajes_nuevos),
    'cursos_en_curso'    => count(array_filter($mis_cursos, fn($c) => $c['progreso'] < 100)),
    'certificados'       => count($mis_certificados),
    'proyectos_total'    => count($mis_proyectos),
];

// ── KPIs del empleado ────────────────────────────────────────────────────
$kpi_completados = count(array_filter($mis_proyectos, fn($p) => $p['estado'] === 'completado'));
$kpi_calif       = $perfil['calificacion'] ?? 0;
$kpi_habilidades = array_filter(explode(',', $perfil['habilidades'] ?? ''));
$kpi_area        = $perfil['area_tecnologica'] ?? 'Sin área asignada';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Dashboard Empleado — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
  /* ══════════════════════════════════════════════════════════════
     VARIABLES & RESET
  ══════════════════════════════════════════════════════════════ */
  :root{
    --n950:#010610;--n900:#020817;--n800:#0c1526;
    --n700:#111827;--n600:#182035;--n500:#1e2d47;--n400:#243450;
    --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.13);
    --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.13);
    --blue:#3b82f6;--blue-lt:#93c5fd;--blue-dim:rgba(59,130,246,.13);
    --purple:#8b5cf6;--purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
    --red:#ef4444;--red-lt:#fca5a5;--red-dim:rgba(239,68,68,.12);
    --orange:#f97316;--orange-dim:rgba(249,115,22,.13);
    --teal:#14b8a6;--teal-dim:rgba(20,184,166,.13);
    --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
    --sh-sm:0 4px 18px rgba(0,0,0,.4);
    --sh-md:0 10px 36px rgba(0,0,0,.5);
    --sh-lg:0 24px 60px rgba(0,0,0,.65);
    --r-sm:8px;--r-md:14px;--r-lg:20px;--r-xl:28px;
    --font-d:'Orbitron',monospace;
    --font-b:'Syne',sans-serif;
    --sidebar-w:260px;
    --topbar-h:64px;
  }
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
  html{scroll-behavior:smooth;}
  body{font-family:var(--font-b);background:var(--n950);color:var(--txt);min-height:100vh;overflow-x:hidden;}
  ::-webkit-scrollbar{width:5px;height:5px;}
  ::-webkit-scrollbar-track{background:var(--n800);}
  ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
  a{text-decoration:none;color:inherit;}
  button{cursor:pointer;border:none;font-family:var(--font-b);background:none;}
  img{display:block;max-width:100%;}

  /* ══ LAYOUT ══ */
  .emp-wrap{display:grid;grid-template-columns:var(--sidebar-w) 1fr;grid-template-rows:var(--topbar-h) 1fr;grid-template-areas:"sidebar topbar""sidebar main";min-height:100vh;}

  /* ══ SIDEBAR ══ */
  .emp-sidebar{
    grid-area:sidebar;position:fixed;top:0;left:0;bottom:0;
    width:var(--sidebar-w);z-index:300;
    background:var(--n900);border-right:1px solid rgba(40,166,128,.15);
    display:flex;flex-direction:column;
    transition:transform .3s cubic-bezier(.4,0,.2,1);
  }
  .sb-brand{
    display:flex;align-items:center;gap:10px;
    padding:0 20px;height:var(--topbar-h);
    border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;
  }
  .sb-brand-ico{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--green),#1a7a5e);display:flex;align-items:center;justify-content:center;font-size:.9rem;color:#fff;font-family:var(--font-d);font-weight:900;box-shadow:0 0 12px rgba(40,166,128,.35);}
  .sb-brand-name{font-family:var(--font-d);font-size:.9rem;font-weight:900;color:var(--gold);letter-spacing:3px;}
  .sb-brand-badge{margin-left:auto;padding:2px 8px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;font-size:.6rem;font-weight:700;color:var(--green-lt);letter-spacing:1px;}

  /* Perfil mini sidebar */
  .sb-profile{
    display:flex;align-items:center;gap:12px;
    padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;
  }
  .sb-av{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--green);box-shadow:0 0 12px rgba(40,166,128,.3);flex-shrink:0;}
  .sb-uname{font-size:.82rem;font-weight:700;color:var(--txt);}
  .sb-urole{font-size:.65rem;color:var(--green-lt);text-transform:uppercase;letter-spacing:1px;}
  .sb-status{display:flex;align-items:center;gap:4px;margin-top:2px;}
  .sb-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:sbdot 2s ease-in-out infinite;}
  @keyframes sbdot{0%,100%{opacity:1}50%{opacity:.4}}
  .sb-status-txt{font-size:.62rem;color:var(--muted);}

  /* Nav */
  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;}
  .sb-nav::-webkit-scrollbar{width:2px;}
  .sb-section-lbl{font-size:.58rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 10px 4px;}
  .sb-item{
    display:flex;align-items:center;gap:11px;
    padding:10px 12px;border-radius:var(--r-md);
    color:var(--muted);font-size:.84rem;font-weight:600;
    cursor:pointer;transition:all .2s;
    border-left:3px solid transparent;margin-bottom:2px;
    position:relative;
  }
  .sb-item:hover{background:rgba(255,255,255,.05);color:var(--txt);}
  .sb-item.active{background:var(--green-dim);color:var(--green-lt);border-left-color:var(--green);}
  .sb-item .sb-ico{width:18px;text-align:center;flex-shrink:0;}
  .sb-item .sb-badge{margin-left:auto;padding:1px 6px;background:var(--red);color:#fff;border-radius:99px;font-size:.58rem;font-weight:800;}
  .sb-item .sb-badge.gold{background:var(--gold);color:#000;}
  .sb-sep{height:1px;background:rgba(255,255,255,.06);margin:8px 10px;}

  /* Footer sidebar */
  .sb-footer{padding:12px 10px;border-top:1px solid rgba(255,255,255,.06);display:flex;gap:6px;flex-shrink:0;}
  .sb-foot-btn{
    flex:1;display:flex;align-items:center;justify-content:center;gap:6px;
    padding:8px;border-radius:var(--r-md);font-size:.75rem;font-weight:600;
    transition:all .2s;
  }
  .sfb-profile{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);color:var(--muted);}
  .sfb-profile:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .sfb-logout{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;}
  .sfb-logout:hover{background:rgba(239,68,68,.2);}

  /* ══ TOPBAR ══ */
  .emp-topbar{
    grid-area:topbar;position:sticky;top:0;z-index:200;
    height:var(--topbar-h);
    background:rgba(2,8,23,.92);backdrop-filter:blur(20px);
    border-bottom:1px solid rgba(40,166,128,.12);
    display:flex;align-items:center;gap:14px;
    padding:0 24px;
  }
  .tb-burger{
    display:none;width:36px;height:36px;border-radius:var(--r-sm);
    background:rgba(255,255,255,.05);color:var(--muted);
    align-items:center;justify-content:center;font-size:.9rem;
  }
  .tb-title{font-family:var(--font-d);font-size:.85rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .tb-section-name{font-size:.78rem;color:var(--muted);}
  .tb-search{
    flex:1;max-width:360px;display:flex;align-items:center;gap:8px;
    background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);
    border-radius:99px;padding:7px 16px;transition:all .2s;
  }
  .tb-search:focus-within{border-color:var(--green);box-shadow:0 0 0 3px rgba(40,166,128,.1);}
  .tb-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:100%;}
  .tb-search input::placeholder{color:var(--dim);}
  .tb-actions{margin-left:auto;display:flex;align-items:center;gap:8px;}
  .tb-action-btn{
    width:34px;height:34px;border-radius:50%;
    background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);
    color:var(--muted);display:flex;align-items:center;justify-content:center;
    font-size:.8rem;transition:all .2s;position:relative;cursor:pointer;
  }
  .tb-action-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .tb-notif-dot{position:absolute;top:5px;right:5px;width:8px;height:8px;border-radius:50%;background:var(--red);border:2px solid var(--n900);}
  .tb-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid var(--green);cursor:pointer;}

  /* ══ MAIN CONTENT ══ */
  .emp-main{
    grid-area:main;padding:28px;
    min-width:0;overflow-x:hidden;
  }
  .emp-section{display:none;animation:secIn .35s ease both;}
  .emp-section.active{display:block;}
  @keyframes secIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

  /* ══ HERO BANNER ══ */
  .emp-hero{
    position:relative;overflow:hidden;
    border-radius:var(--r-xl);padding:32px 36px;
    background:linear-gradient(135deg,#0a1f3d,#081528,#0d2a1a);
    margin-bottom:28px;border:1px solid rgba(40,166,128,.2);
  }
  .eh-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:40px 40px;}
  .eh-orb{position:absolute;border-radius:50%;filter:blur(80px);}
  .eho1{width:300px;height:300px;background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-80px;right:-60px;animation:eho 9s ease-in-out infinite;}
  .eho2{width:250px;height:250px;background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-60px;left:-40px;animation:eho 11s ease-in-out infinite reverse;}
  @keyframes eho{0%,100%{transform:translate(0,0)}50%{transform:translate(15px,-15px)}}
  .eh-content{position:relative;z-index:1;display:flex;align-items:center;gap:24px;}
  .eh-av{width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 24px rgba(40,166,128,.4);flex-shrink:0;}
  .eh-text{}
  .eh-greeting{font-size:.8rem;color:var(--muted);margin-bottom:2px;}
  .eh-name{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--txt);letter-spacing:1px;margin-bottom:4px;}
  .eh-area{font-size:.78rem;color:var(--green-lt);font-weight:700;letter-spacing:1px;margin-bottom:12px;}
  .eh-skills{display:flex;flex-wrap:wrap;gap:6px;}
  .eh-skill{padding:3px 10px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.65rem;color:var(--muted);}
  .eh-stats{margin-left:auto;display:flex;gap:20px;flex-shrink:0;}
  .eh-stat{text-align:center;}
  .eh-stat-n{font-family:var(--font-d);font-size:1.6rem;font-weight:900;color:var(--gold);}
  .eh-stat-l{font-size:.6rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

  /* ══ STATS CARDS ══ */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:28px;}
  .stat-card{
    background:var(--n800);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-lg);padding:18px 20px;
    display:flex;align-items:center;gap:14px;
    transition:transform .25s,border-color .25s;cursor:pointer;
  }
  .stat-card:hover{transform:translateY(-4px);}
  .stat-card-ico{width:44px;height:44px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
  .sci-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);}
  .sci-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);}
  .sci-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);}
  .sci-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);}
  .sci-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);}
  .sci-teal{background:var(--teal-dim);border:1px solid rgba(20,184,166,.3);}
  .stat-card-info{}
  .sc-num{font-family:var(--font-d);font-size:1.6rem;font-weight:900;color:var(--gold);line-height:1;}
  .sc-lbl{font-size:.68rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

  /* ══ SECTION HEADERS ══ */
  .sec-hd{display:flex;align-items:center;gap:12px;margin-bottom:18px;}
  .sec-hd h2{font-family:var(--font-d);font-size:.9rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .sec-hd-line{flex:1;height:1px;background:linear-gradient(to right,rgba(40,166,128,.3),transparent);}
  .sec-hd-btn{
    display:flex;align-items:center;gap:6px;
    padding:6px 14px;border-radius:99px;font-size:.75rem;font-weight:700;
    transition:all .2s;cursor:pointer;
  }
  .shb-green{background:var(--green);color:#fff;}
  .shb-green:hover{background:var(--green-lt);}
  .shb-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .shb-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt);}

  /* ══ CARDS GENERALES ══ */
  .card-base{
    background:var(--n800);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-lg);transition:border-color .2s;
  }
  .card-base:hover{border-color:rgba(40,166,128,.25);}

  /* ══ TABLA SERVICIOS ══ */
  .srv-table-wrap{overflow-x:auto;}
  .srv-table{width:100%;border-collapse:collapse;}
  .srv-table th{
    padding:10px 14px;text-align:left;
    font-size:.62rem;font-weight:800;color:var(--dim);
    text-transform:uppercase;letter-spacing:1.5px;
    border-bottom:1px solid rgba(255,255,255,.07);
    background:rgba(255,255,255,.02);
  }
  .srv-table td{
    padding:12px 14px;font-size:.82rem;color:var(--muted);
    border-bottom:1px solid rgba(255,255,255,.04);
    vertical-align:middle;
  }
  .srv-table tr:hover td{background:rgba(255,255,255,.03);}
  .srv-table tr:last-child td{border-bottom:none;}

  /* Badges estado */
  .badge{padding:3px 10px;border-radius:99px;font-size:.65rem;font-weight:700;display:inline-block;}
  .b-pendiente{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-pagado{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-cancelado{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
  .b-activo{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-planeado{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-pausado{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-completado{background:var(--teal-dim);color:#5eead4;border:1px solid rgba(20,184,166,.3);}

  /* Cliente mini */
  .cliente-mini{display:flex;align-items:center;gap:8px;}
  .cli-av{width:28px;height:28px;border-radius:50%;object-fit:cover;border:1.5px solid var(--green-dim);}
  .cli-av-ph{width:28px;height:28px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;color:var(--green-lt);}
  .cli-name{font-size:.78rem;font-weight:600;color:var(--txt);}

  /* Botones de acción en tabla */
  .act-btn{
    display:inline-flex;align-items:center;gap:4px;
    padding:5px 10px;border-radius:var(--r-sm);font-size:.72rem;font-weight:700;
    transition:all .2s;cursor:pointer;
  }
  .ab-accept{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
  .ab-accept:hover{background:var(--green);color:#fff;}
  .ab-reject{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .ab-reject:hover{background:var(--red);color:#fff;}
  .ab-view{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .ab-view:hover{background:rgba(255,255,255,.12);color:var(--txt);}

  /* ══ PROYECTOS GRID ══ */
  .proyectos-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;}
  .proy-card{
    background:var(--n800);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-xl);overflow:hidden;
    transition:transform .25s,border-color .25s,box-shadow .25s;cursor:pointer;
  }
  .proy-card:hover{transform:translateY(-5px);border-color:rgba(40,166,128,.3);box-shadow:var(--sh-md);}
  .proy-card-band{height:5px;}
  .proy-card-body{padding:18px 20px;}
  .proy-card-top{display:flex;align-items:flex-start;gap:12px;margin-bottom:12px;}
  .proy-ico-wrap{width:44px;height:44px;border-radius:var(--r-md);background:var(--n600);display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0;}
  .proy-title{font-size:.92rem;font-weight:800;color:var(--txt);margin-bottom:4px;line-height:1.3;}
  .proy-rol{font-size:.65rem;color:var(--green-lt);font-weight:700;text-transform:uppercase;letter-spacing:1px;}
  .proy-desc{font-size:.78rem;color:var(--muted);line-height:1.55;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
  .proy-tags{display:flex;flex-wrap:wrap;gap:5px;margin-bottom:12px;}
  .proy-tag{padding:2px 8px;background:rgba(255,255,255,.05);border-radius:99px;font-size:.62rem;color:var(--dim);}
  .proy-prog{margin-bottom:12px;}
  .proy-prog-hd{display:flex;justify-content:space-between;font-size:.68rem;color:var(--muted);margin-bottom:5px;}
  .proy-prog-bar{height:5px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
  .proy-prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}
  .proy-footer{display:flex;align-items:center;justify-content:space-between;padding-top:10px;border-top:1px solid rgba(255,255,255,.06);}
  .proy-meta{font-size:.65rem;color:var(--dim);display:flex;align-items:center;gap:5px;}
  .proy-actions{display:flex;gap:6px;}

  /* ══ TIMELINE AVANCES ══ */
  .timeline{display:flex;flex-direction:column;gap:0;}
  .tl-item{display:flex;gap:14px;padding-bottom:18px;position:relative;}
  .tl-item:not(:last-child)::before{content:'';position:absolute;left:13px;top:28px;width:2px;height:calc(100% - 18px);background:rgba(255,255,255,.07);}
  .tl-dot{width:28px;height:28px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.75rem;z-index:1;}
  .tld-green{background:var(--green-dim);border:2px solid var(--green);color:var(--green);}
  .tld-gold{background:var(--gold-dim);border:2px solid var(--gold);color:var(--gold);}
  .tl-content{flex:1;}
  .tl-proy{font-size:.65rem;color:var(--green-lt);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:2px;}
  .tl-title{font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:3px;}
  .tl-desc{font-size:.78rem;color:var(--muted);line-height:1.5;}
  .tl-date{font-size:.65rem;color:var(--dim);margin-top:4px;}

  /* ══ MENSAJES ══ */
  .msg-list{display:flex;flex-direction:column;gap:8px;}
  .msg-item{
    display:flex;align-items:flex-start;gap:12px;
    padding:14px 16px;border-radius:var(--r-md);
    background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
    cursor:pointer;transition:all .2s;
  }
  .msg-item:hover{background:rgba(255,255,255,.06);border-color:rgba(40,166,128,.2);}
  .msg-item.unread{border-left:3px solid var(--green);background:rgba(40,166,128,.04);}
  .msg-av{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--green-dim);flex-shrink:0;}
  .msg-av-ph{width:36px;height:36px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:var(--green-lt);flex-shrink:0;}
  .msg-body{flex:1;min-width:0;}
  .msg-sender{font-size:.82rem;font-weight:700;color:var(--txt);}
  .msg-asunto{font-size:.78rem;color:var(--muted);margin-bottom:2px;}
  .msg-preview{font-size:.72rem;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .msg-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}
  .msg-date{font-size:.62rem;color:var(--dim);}
  .msg-unread-dot{width:8px;height:8px;border-radius:50%;background:var(--green);}

  /* ══ COMPAÑEROS GRID ══ */
  .team-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;}
  .team-card{
    background:var(--n800);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-lg);padding:16px;text-align:center;
    transition:all .25s;cursor:pointer;
  }
  .team-card:hover{transform:translateY(-4px);border-color:rgba(40,166,128,.3);box-shadow:var(--sh-sm);}
  .tc-av{width:56px;height:56px;border-radius:50%;object-fit:cover;border:2px solid var(--green);margin:0 auto 10px;box-shadow:0 0 14px rgba(40,166,128,.25);}
  .tc-av-ph{width:56px;height:56px;border-radius:50%;background:var(--green-dim);border:2px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:1.2rem;margin:0 auto 10px;}
  .tc-name{font-size:.84rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
  .tc-cargo{font-size:.68rem;color:var(--green-lt);font-weight:600;margin-bottom:4px;}
  .tc-area{font-size:.65rem;color:var(--dim);}
  .tc-disp{display:flex;align-items:center;justify-content:center;gap:4px;margin-top:8px;font-size:.65rem;}
  .tc-disp-dot{width:6px;height:6px;border-radius:50%;}
  .tc-contact-btn{
    margin-top:10px;width:100%;padding:6px;
    background:var(--green-dim);border:1px solid rgba(40,166,128,.3);
    border-radius:var(--r-sm);font-size:.72rem;font-weight:700;color:var(--green-lt);
    transition:all .2s;
  }
  .tc-contact-btn:hover{background:var(--green);color:#fff;}

  /* ══ CURSOS ══ */
  .curso-mini{
    display:flex;align-items:center;gap:12px;
    padding:12px 16px;border-radius:var(--r-md);
    background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);
    margin-bottom:8px;cursor:pointer;transition:all .2s;
  }
  .curso-mini:hover{background:rgba(255,255,255,.06);border-color:rgba(40,166,128,.2);}
  .curso-ico{font-size:1.4rem;flex-shrink:0;}
  .curso-info{flex:1;min-width:0;}
  .curso-title{font-size:.84rem;font-weight:700;color:var(--txt);}
  .curso-meta{font-size:.68rem;color:var(--muted);margin-top:2px;}
  .curso-prog-mini{width:80px;flex-shrink:0;}
  .cpm-pct{font-size:.7rem;font-weight:700;color:var(--gold);text-align:right;margin-bottom:3px;}
  .cpm-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
  .cpm-fill{height:100%;background:var(--green);border-radius:99px;}

  /* ══ KANBAN BOARD ══ */
  .kanban-wrap{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;}
  .kanban-col{background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);padding:14px;min-height:300px;}
  .kanban-col-hd{display:flex;align-items:center;gap:8px;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid rgba(255,255,255,.07);}
  .kanban-col-ico{width:8px;height:8px;border-radius:50%;flex-shrink:0;}
  .kanban-col-title{font-size:.72rem;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:1.5px;flex:1;}
  .kanban-col-cnt{font-size:.65rem;color:var(--dim);background:rgba(255,255,255,.07);padding:1px 6px;border-radius:99px;}
  .kanban-card{
    background:var(--n700);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-md);padding:12px;margin-bottom:8px;
    cursor:pointer;transition:all .2s;
  }
  .kanban-card:hover{border-color:rgba(40,166,128,.3);transform:translateX(3px);}
  .kc-title{font-size:.8rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
  .kc-proy{font-size:.65rem;color:var(--green-lt);}
  .kc-date{font-size:.62rem;color:var(--dim);margin-top:5px;}

  /* ══ MODAL ══ */
  .emp-modal{
    position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:9999;
    display:none;align-items:center;justify-content:center;padding:20px;
  }
  .emp-modal.open{display:flex;}
  .em-box{
    background:var(--n800);border:1px solid rgba(40,166,128,.25);
    border-radius:var(--r-xl);width:100%;max-width:560px;
    box-shadow:var(--sh-lg);animation:eminIn .3s ease both;
  }
  @keyframes eminIn{from{opacity:0;transform:scale(.95) translateY(16px)}to{opacity:1;transform:none}}
  .em-header{
    display:flex;align-items:center;justify-content:space-between;
    padding:20px 24px;border-bottom:1px solid rgba(255,255,255,.07);
  }
  .em-title{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .em-close{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
  .em-close:hover{background:rgba(239,68,68,.2);color:#f87171;}
  .em-body{padding:20px 24px;}
  .em-footer{padding:16px 24px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:10px;justify-content:flex-end;}

  /* Inputs del modal */
  .em-group{margin-bottom:14px;}
  .em-label{font-size:.7rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;display:block;margin-bottom:5px;}
  .em-input{
    width:100%;padding:10px 14px;
    background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
    border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.88rem;
    transition:all .2s;outline:none;
  }
  .em-input:focus{border-color:var(--green);background:rgba(40,166,128,.05);}
  textarea.em-input{resize:vertical;min-height:80px;line-height:1.6;}
  select.em-input option{background:var(--n700);}

  .em-btn{
    padding:9px 20px;border-radius:var(--r-md);font-weight:700;font-size:.82rem;
    transition:all .2s;cursor:pointer;
  }
  .em-btn-primary{background:var(--green);color:#fff;}
  .em-btn-primary:hover{background:var(--green-lt);}
  .em-btn-cancel{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .em-btn-cancel:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .em-btn-danger{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .em-btn-danger:hover{background:var(--red);color:#fff;}

  /* ══ ALERTAS / TOAST ══ */
  .toast-wrap{position:fixed;bottom:24px;right:24px;z-index:10000;display:flex;flex-direction:column;gap:8px;}
  .toast{
    display:flex;align-items:center;gap:10px;
    padding:12px 18px;border-radius:var(--r-md);
    font-size:.82rem;font-weight:600;
    animation:toastIn .3s ease both;
    max-width:320px;box-shadow:var(--sh-md);
  }
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
  .toast-ok{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
  .toast-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .toast-info{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);color:var(--blue-lt);}

  /* ══ EMPTY STATE ══ */
  .empty-state{text-align:center;padding:48px 24px;color:var(--dim);}
  .empty-state-ico{font-size:3rem;margin-bottom:12px;opacity:.3;}
  .empty-state p{font-size:.88rem;margin-bottom:14px;}

  /* ══ KPI ROW ══ */
  .kpi-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin-bottom:24px;}
  .kpi-card{
    background:var(--n800);border:1px solid rgba(255,255,255,.07);
    border-radius:var(--r-lg);padding:16px 18px;
    display:flex;flex-direction:column;gap:8px;
  }
  .kpi-label{font-size:.62rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;}
  .kpi-value{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);line-height:1;}
  .kpi-sub{font-size:.72rem;color:var(--muted);}
  .kpi-bar{height:4px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden;}
  .kpi-bar-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;}

  /* ══ QUICK ACTIONS ══ */
  .quick-actions{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:24px;}
  .qa-card{
    display:flex;flex-direction:column;align-items:center;gap:8px;
    padding:18px 12px;
    background:var(--n800);border:1.5px dashed rgba(255,255,255,.1);
    border-radius:var(--r-lg);cursor:pointer;transition:all .25s;text-align:center;
  }
  .qa-card:hover{background:var(--green-dim);border-color:var(--green);transform:translateY(-4px);}
  .qa-ico{font-size:1.8rem;}
  .qa-lbl{font-size:.75rem;font-weight:700;color:var(--muted);}
  .qa-card:hover .qa-lbl{color:var(--green-lt);}

  /* ══ NOTIFICACIONES ══ */
  .notif-list{display:flex;flex-direction:column;gap:6px;}
  .notif-item{
    display:flex;align-items:flex-start;gap:10px;
    padding:10px 14px;border-radius:var(--r-md);
    background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);
    font-size:.78rem;
  }
  .notif-item.new{border-left:3px solid var(--green);}
  .notif-ico{font-size:1rem;flex-shrink:0;margin-top:1px;}
  .notif-txt{flex:1;color:var(--muted);line-height:1.5;}
  .notif-txt strong{color:var(--txt);}
  .notif-time{font-size:.62rem;color:var(--dim);flex-shrink:0;}

  /* ══ RESPONSIVE ══ */
  @media(max-width:1024px){.proyectos-grid{grid-template-columns:1fr 1fr;}}
  @media(max-width:820px){
    .emp-wrap{grid-template-columns:1fr;grid-template-areas:"topbar""main";}
    .emp-sidebar{transform:translateX(-100%);}
    .emp-sidebar.open{transform:translateX(0);}
    .emp-main{padding:16px;}
    .tb-burger{display:flex;}
    .eh-stats{display:none;}
    .proyectos-grid{grid-template-columns:1fr;}
    .kanban-wrap{grid-template-columns:1fr;}
    .stats-grid{grid-template-columns:repeat(2,1fr);}
  }
  @media(max-width:480px){
    .stats-grid{grid-template-columns:1fr 1fr;}
    .quick-actions{grid-template-columns:repeat(2,1fr);}
    .team-grid{grid-template-columns:1fr 1fr;}
  }
  </style>
</head>
<body>
<div class="emp-wrap" id="empWrap">

<!-- ═══════════════════════════════════════════════════════════
     SIDEBAR
════════════════════════════════════════════════════════════ -->
<aside class="emp-sidebar" id="empSidebar">

  <!-- Brand -->
  <div class="sb-brand">
    <div class="sb-brand-ico">VX</div>
    <span class="sb-brand-name">Virox</span>
    <span class="sb-brand-badge">EMPLEADO</span>
  </div>

  <!-- Perfil mini -->
  <div class="sb-profile">
    <img src="<?= $avatar ?>" alt="Avatar" class="sb-av" onerror="this.src='../assets/Emma.png'">
    <div>
      <div class="sb-uname"><?= $nombre ?></div>
      <div class="sb-urole"><?= htmlspecialchars($perfil['cargo_equipo'] ?? 'Empleado') ?></div>
      <div class="sb-status">
        <div class="sb-dot"></div>
        <span class="sb-status-txt">En línea</span>
      </div>
    </div>
  </div>

  <!-- Navegación -->
  <nav class="sb-nav">
    <div class="sb-section-lbl">Principal</div>
    <div class="sb-item active" onclick="showSec('dashboard',this)">
      <span class="sb-ico"><i class="fa fa-gauge-high"></i></span>
      Dashboard
    </div>
    <div class="sb-item" onclick="showSec('servicios',this)">
      <span class="sb-ico"><i class="fa fa-store"></i></span>
      Gestión de Servicios
      <?php if ($stats['servicios_gestion'] > 0): ?>
      <span class="sb-badge"><?= $stats['servicios_gestion'] ?></span>
      <?php endif; ?>
    </div>
    <div class="sb-item" onclick="showSec('proyectos',this)">
      <span class="sb-ico"><i class="fa fa-diagram-project"></i></span>
      Mis Proyectos
    </div>
    <div class="sb-item" onclick="showSec('explorar',this)">
      <span class="sb-ico"><i class="fa fa-compass"></i></span>
      Explorar Proyectos
    </div>
    <div class="sb-item" onclick="showSec('avances',this)">
      <span class="sb-ico"><i class="fa fa-chart-line"></i></span>
      Avances & Bitácora
    </div>
    <div class="sb-sep"></div>
    <div class="sb-section-lbl">Comunicación</div>
    <div class="sb-item" onclick="showSec('mensajes',this)">
      <span class="sb-ico"><i class="fa fa-envelope"></i></span>
      Mensajes
      <?php if ($stats['mensajes_nuevos'] > 0): ?>
      <span class="sb-badge"><?= $stats['mensajes_nuevos'] ?></span>
      <?php endif; ?>
    </div>
    <div class="sb-item" onclick="showSec('equipo',this)">
      <span class="sb-ico"><i class="fa fa-users"></i></span>
      Mi Equipo
    </div>
    <div class="sb-sep"></div>
    <div class="sb-section-lbl">Aprendizaje</div>
    <div class="sb-item" onclick="showSec('cursos',this)">
      <span class="sb-ico"><i class="fa fa-graduation-cap"></i></span>
      Mis Cursos
      <?php if ($stats['cursos_en_curso'] > 0): ?>
      <span class="sb-badge gold"><?= $stats['cursos_en_curso'] ?></span>
      <?php endif; ?>
    </div>
    <div class="sb-item" onclick="window.location.href='../AD.php'">
      <span class="sb-ico"><i class="fa fa-play-circle"></i></span>
      Aprendizaje Digital
    </div>
    <div class="sb-item" onclick="window.location.href='../IA.php'">
      <span class="sb-ico"><i class="fa fa-robot"></i></span>
      Asistente IA
    </div>
    <div class="sb-sep"></div>
    <div class="sb-section-lbl">Cuenta</div>
    <div class="sb-item" onclick="window.location.href='../perfil.php'">
      <span class="sb-ico"><i class="fa fa-id-card"></i></span>
      Mi Perfil
    </div>
    <div class="sb-item" onclick="window.location.href='../index.php'">
      <span class="sb-ico"><i class="fa fa-house"></i></span>
      Inicio VIROX
    </div>
  </nav>

  <!-- Footer -->
  <div class="sb-footer">
    <a href="../perfil.php" class="sb-foot-btn sfb-profile">
      <i class="fa fa-user-gear"></i> Perfil
    </a>
    <a href="../logout.php" class="sb-foot-btn sfb-logout">
      <i class="fa fa-right-from-bracket"></i> Salir
    </a>
  </div>
</aside>


<!-- ═══════════════════════════════════════════════════════════
     TOPBAR
════════════════════════════════════════════════════════════ -->
<header class="emp-topbar">
  <button class="tb-burger" id="tbBurger" onclick="toggleSidebar()">
    <i class="fa fa-bars"></i>
  </button>
  <div>
    <div class="tb-title">Panel de Empleado</div>
    <div class="tb-section-name" id="tbSectionName">Dashboard</div>
  </div>
  <div class="tb-search">
    <i class="fa fa-search" style="color:var(--dim);font-size:.8rem;"></i>
    <input type="text" placeholder="Buscar proyectos, servicios..." id="globalSearch">
  </div>
  <div class="tb-actions">
    <button class="tb-action-btn" onclick="showSec('mensajes')" title="Mensajes">
      <i class="fa fa-envelope"></i>
      <?php if ($stats['mensajes_nuevos'] > 0): ?>
      <span class="tb-notif-dot"></span>
      <?php endif; ?>
    </button>
    <button class="tb-action-btn" onclick="showSec('servicios')" title="Servicios pendientes">
      <i class="fa fa-bell"></i>
      <?php if ($stats['servicios_gestion'] > 0): ?>
      <span class="tb-notif-dot"></span>
      <?php endif; ?>
    </button>
    <img src="<?= $avatar ?>" alt="Avatar" class="tb-av"
         onclick="window.location.href='../perfil.php'"
         onerror="this.src='../assets/Emma.png'">
  </div>
</header>


<!-- ═══════════════════════════════════════════════════════════
     MAIN CONTENT
════════════════════════════════════════════════════════════ -->
<main class="emp-main">


<!-- ██████████████████████████ DASHBOARD ████████████████████████████ -->
<div class="emp-section active" id="sec-dashboard">

  <!-- Hero Banner -->
  <div class="emp-hero">
    <div class="eh-grid"></div>
    <div class="eh-orb eho1"></div>
    <div class="eh-orb eho2"></div>
    <div class="eh-content">
      <img src="<?= $avatar ?>" alt="Avatar" class="eh-av"
           onerror="this.src='../assets/Emma.png'">
      <div class="eh-text">
        <div class="eh-greeting">👋 Bienvenido de vuelta,</div>
        <div class="eh-name"><?= $nombre ?></div>
        <div class="eh-area">
          <?= htmlspecialchars($perfil['area_tecnologica'] ?? 'Sin área') ?>
          <?php if (!empty($perfil['cargo_equipo'])): ?>
          · <?= htmlspecialchars($perfil['cargo_equipo']) ?>
          <?php endif; ?>
        </div>
        <?php if (!empty($kpi_habilidades)): ?>
        <div class="eh-skills">
          <?php foreach (array_slice($kpi_habilidades, 0, 5) as $sk): ?>
          <span class="eh-skill"><?= htmlspecialchars(trim($sk)) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </div>
      <div class="eh-stats">
        <div class="eh-stat">
          <div class="eh-stat-n"><?= $stats['proyectos_activos'] ?></div>
          <div class="eh-stat-l">Proyectos activos</div>
        </div>
        <div class="eh-stat">
          <div class="eh-stat-n"><?= $stats['servicios_gestion'] ?></div>
          <div class="eh-stat-l">Servicios pendientes</div>
        </div>
        <div class="eh-stat">
          <div class="eh-stat-n"><?= number_format((float)($kpi_calif), 1) ?></div>
          <div class="eh-stat-l">Calificación</div>
        </div>
        <div class="eh-stat">
          <div class="eh-stat-n"><?= $kpi_completados ?></div>
          <div class="eh-stat-l">Completados</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Stats cards -->
  <div class="stats-grid">
    <div class="stat-card" onclick="showSec('proyectos')">
      <div class="stat-card-ico sci-green"><i class="fa fa-diagram-project"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['proyectos_activos'] ?></div>
        <div class="sc-lbl">Proyectos Activos</div>
      </div>
    </div>
    <div class="stat-card" onclick="showSec('servicios')">
      <div class="stat-card-ico sci-gold"><i class="fa fa-store"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['servicios_gestion'] ?></div>
        <div class="sc-lbl">Servicios Pendientes</div>
      </div>
    </div>
    <div class="stat-card" onclick="showSec('mensajes')">
      <div class="stat-card-ico sci-blue"><i class="fa fa-envelope"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['mensajes_nuevos'] ?></div>
        <div class="sc-lbl">Mensajes Nuevos</div>
      </div>
    </div>
    <div class="stat-card" onclick="showSec('cursos')">
      <div class="stat-card-ico sci-purple"><i class="fa fa-graduation-cap"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['cursos_en_curso'] ?></div>
        <div class="sc-lbl">Cursos en Curso</div>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-card-ico sci-teal"><i class="fa fa-certificate"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['certificados'] ?></div>
        <div class="sc-lbl">Certificados</div>
      </div>
    </div>
    <div class="stat-card" onclick="showSec('proyectos')">
      <div class="stat-card-ico sci-red"><i class="fa fa-folder-open"></i></div>
      <div class="stat-card-info">
        <div class="sc-num"><?= $stats['proyectos_total'] ?></div>
        <div class="sc-lbl">Total Proyectos</div>
      </div>
    </div>
  </div>

  <!-- Acciones rápidas -->
  <div class="sec-hd">
    <h2>⚡ Acciones Rápidas</h2>
    <div class="sec-hd-line"></div>
  </div>
  <div class="quick-actions">
    <div class="qa-card" onclick="openModalAgregarAvance()">
      <div class="qa-ico">📝</div>
      <div class="qa-lbl">Registrar Avance</div>
    </div>
    <div class="qa-card" onclick="showSec('servicios')">
      <div class="qa-ico">✅</div>
      <div class="qa-lbl">Gestionar Servicio</div>
    </div>
    <div class="qa-card" onclick="openModalMensaje()">
      <div class="qa-ico">💬</div>
      <div class="qa-lbl">Enviar Mensaje</div>
    </div>
    <div class="qa-card" onclick="showSec('explorar')">
      <div class="qa-ico">🔍</div>
      <div class="qa-lbl">Explorar Proyectos</div>
    </div>
    <div class="qa-card" onclick="window.location.href='../IA.php'">
      <div class="qa-ico">🤖</div>
      <div class="qa-lbl">Asistente IA</div>
    </div>
    <div class="qa-card" onclick="window.location.href='../AD.php'">
      <div class="qa-ico">🎓</div>
      <div class="qa-lbl">Aprender Ahora</div>
    </div>
    <div class="qa-card" onclick="window.location.href='../perfil.php'">
      <div class="qa-ico">👤</div>
      <div class="qa-lbl">Mi Perfil</div>
    </div>
    <div class="qa-card" onclick="window.location.href='../contacto.php'">
      <div class="qa-ico">📞</div>
      <div class="qa-lbl">Contacto</div>
    </div>
  </div>

  <!-- Dos columnas: Servicios pendientes + Avances recientes -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">

    <!-- Servicios pendientes -->
    <div class="card-base" style="padding:18px;">
      <div class="sec-hd" style="margin-bottom:14px;">
        <h2>🛒 Servicios Pendientes</h2>
        <div class="sec-hd-line"></div>
        <span class="sec-hd-btn shb-ghost" onclick="showSec('servicios')">Ver todos</span>
      </div>
      <?php if (empty($servicios_pendientes)): ?>
        <div class="empty-state" style="padding:24px;">
          <div class="empty-state-ico">✅</div>
          <p>Sin servicios pendientes</p>
        </div>
      <?php else: ?>
        <?php foreach (array_slice($servicios_pendientes, 0, 4) as $srv): ?>
        <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.05);">
          <span style="font-size:1.3rem;"><?= htmlspecialchars($srv['icono'] ?? '🛠') ?></span>
          <div style="flex:1;min-width:0;">
            <p style="font-size:.82rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($srv['titulo']) ?></p>
            <p style="font-size:.68rem;color:var(--muted);"><?= htmlspecialchars($srv['cliente_nombre'].' '.$srv['cliente_apellido']) ?> · $<?= number_format($srv['monto'],0,',','.') ?></p>
          </div>
          <span class="badge b-pendiente">Pendiente</span>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- Avances recientes -->
    <div class="card-base" style="padding:18px;">
      <div class="sec-hd" style="margin-bottom:14px;">
        <h2>📋 Avances Recientes</h2>
        <div class="sec-hd-line"></div>
        <span class="sec-hd-btn shb-ghost" onclick="showSec('avances')">Ver todos</span>
      </div>
      <?php if (empty($avances_recientes)): ?>
        <div class="empty-state" style="padding:24px;">
          <div class="empty-state-ico">📋</div>
          <p>Sin avances registrados</p>
        </div>
      <?php else: ?>
        <div class="timeline">
          <?php foreach (array_slice($avances_recientes, 0, 4) as $av): ?>
          <div class="tl-item">
            <div class="tl-dot tld-green"><i class="fa fa-check fa-xs"></i></div>
            <div class="tl-content">
              <div class="tl-proy"><?= htmlspecialchars($av['proyecto_icono']??'🚀') ?> <?= htmlspecialchars($av['proyecto_titulo']) ?></div>
              <div class="tl-title"><?= htmlspecialchars($av['titulo']) ?></div>
              <div class="tl-date"><?= date('d M Y', strtotime($av['fecha'])) ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- KPIs -->
  <div class="sec-hd" style="margin-top:24px;">
    <h2>📊 Mis KPIs</h2>
    <div class="sec-hd-line"></div>
  </div>
  <div class="kpi-row">
    <div class="kpi-card">
      <div class="kpi-label">Proyectos completados</div>
      <div class="kpi-value"><?= $kpi_completados ?></div>
      <div class="kpi-sub">de <?= $stats['proyectos_total'] ?> totales</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= $stats['proyectos_total']>0 ? round($kpi_completados/$stats['proyectos_total']*100) : 0 ?>%"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Calificación</div>
      <div class="kpi-value"><?= number_format((float)$kpi_calif,1) ?>/5</div>
      <div class="kpi-sub">⭐ Promedio del equipo</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= ($kpi_calif/5)*100 ?>%"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Servicios gestionados</div>
      <div class="kpi-value"><?= count(array_filter($servicios_todos, fn($s) => $s['estado']==='pagado')) ?></div>
      <div class="kpi-sub">Aprobados exitosamente</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= count($servicios_todos)>0 ? round(count(array_filter($servicios_todos,fn($s)=>$s['estado']==='pagado'))/count($servicios_todos)*100) : 0 ?>%"></div></div>
    </div>
    <div class="kpi-card">
      <div class="kpi-label">Certificados</div>
      <div class="kpi-value"><?= $stats['certificados'] ?></div>
      <div class="kpi-sub">Obtenidos en la plataforma</div>
      <div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= min(100,$stats['certificados']*10) ?>%"></div></div>
    </div>
  </div>

</div><!-- /sec-dashboard -->


<!-- ██████████████████ GESTIÓN DE SERVICIOS ██████████████████████████ -->
<div class="emp-section" id="sec-servicios">
  <div class="sec-hd">
    <h2>🛒 Gestión de Servicios</h2>
    <div class="sec-hd-line"></div>
  </div>

  <!-- Filtros -->
  <div style="display:flex;gap:8px;margin-bottom:18px;flex-wrap:wrap;">
    <button class="sec-hd-btn shb-green" id="filt-todos" onclick="filtrarServicios('todos',this)">Todos</button>
    <button class="sec-hd-btn shb-ghost" id="filt-pendiente" onclick="filtrarServicios('pendiente',this)">
      ⏳ Pendientes <span style="background:var(--red);color:#fff;border-radius:99px;padding:1px 6px;font-size:.6rem;margin-left:4px;"><?= count($servicios_pendientes) ?></span>
    </button>
    <button class="sec-hd-btn shb-ghost" id="filt-pagado" onclick="filtrarServicios('pagado',this)">✅ Aprobados</button>
    <button class="sec-hd-btn shb-ghost" id="filt-cancelado" onclick="filtrarServicios('cancelado',this)">❌ Cancelados</button>
  </div>

  <div class="card-base" style="overflow:hidden;">
    <div class="srv-table-wrap">
      <table class="srv-table" id="srvTable">
        <thead>
          <tr>
            <th>#</th>
            <th>Servicio</th>
            <th>Cliente</th>
            <th>Monto</th>
            <th>Método pago</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($servicios_todos)): ?>
          <tr><td colspan="8" style="text-align:center;padding:32px;color:var(--dim);">No hay servicios registrados aún.</td></tr>
          <?php else: ?>
          <?php foreach ($servicios_todos as $srv): ?>
          <tr data-estado="<?= $srv['estado'] ?>">
            <td style="color:var(--dim);font-size:.72rem;">#<?= $srv['id'] ?></td>
            <td>
              <div style="display:flex;align-items:center;gap:8px;">
                <span style="font-size:1.1rem;"><?= htmlspecialchars($srv['icono'] ?? '🛠') ?></span>
                <div>
                  <p style="font-size:.82rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($srv['titulo']) ?></p>
                  <p style="font-size:.65rem;color:var(--dim);"><?= htmlspecialchars($srv['categoria'] ?? '') ?></p>
                </div>
              </div>
            </td>
            <td>
              <div class="cliente-mini">
                <div class="cli-av-ph"><?= mb_substr($srv['cliente_nombre'] ?? 'U', 0, 1) ?></div>
                <span class="cli-name"><?= htmlspecialchars($srv['cliente_nombre'].' '.($srv['cliente_apellido']??'')) ?></span>
              </div>
            </td>
            <td style="font-family:var(--font-d);color:var(--gold);font-size:.8rem;">$<?= number_format($srv['monto'],0,',','.') ?></td>
            <td style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($srv['metodo_pago'] ?? '—') ?></td>
            <td style="font-size:.72rem;color:var(--dim);"><?= date('d M Y', strtotime($srv['fecha'])) ?></td>
            <td><span class="badge b-<?= $srv['estado'] ?>"><?= ucfirst($srv['estado']) ?></span></td>
            <td>
              <div style="display:flex;gap:6px;">
                <?php if ($srv['estado'] === 'pendiente'): ?>
                <button class="act-btn ab-accept"
                        onclick="gestionarAdquisicion(<?= $srv['id'] ?>,'pagado','<?= htmlspecialchars($srv['titulo'],ENT_QUOTES) ?>')">
                  <i class="fa fa-check"></i> Aprobar
                </button>
                <button class="act-btn ab-reject"
                        onclick="gestionarAdquisicion(<?= $srv['id'] ?>,'cancelado','<?= htmlspecialchars($srv['titulo'],ENT_QUOTES) ?>')">
                  <i class="fa fa-xmark"></i> Rechazar
                </button>
                <?php else: ?>
                <button class="act-btn ab-view"><i class="fa fa-eye"></i> Ver</button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div><!-- /sec-servicios -->


<!-- ██████████████████ MIS PROYECTOS ██████████████████████████████████ -->
<div class="emp-section" id="sec-proyectos">
  <div class="sec-hd">
    <h2>🚀 Mis Proyectos</h2>
    <div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-ghost" onclick="showSec('explorar')">
      <i class="fa fa-compass"></i> Explorar más
    </button>
  </div>

  <?php if (empty($mis_proyectos)): ?>
  <div class="empty-state">
    <div class="empty-state-ico">🚀</div>
    <p>Aún no estás asignado a ningún proyecto.</p>
    <button class="sec-hd-btn shb-green" onclick="showSec('explorar')">
      <i class="fa fa-compass"></i> Explorar proyectos disponibles
    </button>
  </div>
  <?php else: ?>
  <div class="proyectos-grid">
    <?php
    $band_colors = [
      'activo'     => 'linear-gradient(to right,#28A680,rgba(40,166,128,.2))',
      'planeado'   => 'linear-gradient(to right,#3b82f6,rgba(59,130,246,.2))',
      'pausado'    => 'linear-gradient(to right,#DAA520,rgba(218,165,32,.2))',
      'completado' => 'linear-gradient(to right,#14b8a6,rgba(20,184,166,.2))',
      'cancelado'  => 'linear-gradient(to right,#ef4444,rgba(239,68,68,.2))',
    ];
    foreach ($mis_proyectos as $p):
      $band = $band_colors[$p['estado']] ?? $band_colors['planeado'];
      $techs = array_filter(explode(',', $p['tecnologias'] ?? ''));
      $areas = array_filter(explode(',', $p['areas'] ?? ''));
      $prog  = (int)$p['progreso'];
    ?>
    <div class="proy-card" onclick="openProyectoModal(<?= $p['id'] ?>,'<?= htmlspecialchars($p['titulo'],ENT_QUOTES) ?>',<?= $prog ?>,'<?= $p['estado'] ?>')">
      <div class="proy-card-band" style="background:<?= $band ?>"></div>
      <div class="proy-card-body">
        <div class="proy-card-top">
          <div class="proy-ico-wrap"><?= htmlspecialchars($p['icono'] ?? '🚀') ?></div>
          <div>
            <div class="proy-title"><?= htmlspecialchars($p['titulo']) ?></div>
            <div class="proy-rol">
              <?= htmlspecialchars($p['rol_proyecto'] ?? 'Colaborador') ?>
              <span class="badge b-<?= $p['estado'] ?>" style="margin-left:6px;"><?= ucfirst($p['estado']) ?></span>
            </div>
          </div>
        </div>
        <?php if (!empty($p['descripcion'])): ?>
        <p class="proy-desc"><?= htmlspecialchars($p['descripcion']) ?></p>
        <?php endif; ?>
        <?php if (!empty($techs)): ?>
        <div class="proy-tags">
          <?php foreach (array_slice($techs, 0, 4) as $t): ?>
          <span class="proy-tag"><?= htmlspecialchars(trim($t)) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="proy-prog">
          <div class="proy-prog-hd"><span>Progreso</span><span style="color:var(--green-lt);font-weight:700;"><?= $prog ?>%</span></div>
          <div class="proy-prog-bar"><div class="proy-prog-fill" style="width:<?= $prog ?>%"></div></div>
        </div>
        <div class="proy-footer">
          <div class="proy-meta">
            <i class="fa fa-users"></i> <?= $p['total_miembros'] ?> miembros
          </div>
          <div class="proy-meta">
            <i class="fa fa-list-check"></i> <?= $p['total_avances'] ?> avances
          </div>
          <div class="proy-actions">
            <button class="act-btn ab-view" onclick="event.stopPropagation();openModalAgregarAvance(<?= $p['id'] ?>,'<?= htmlspecialchars($p['titulo'],ENT_QUOTES) ?>')">
              <i class="fa fa-plus"></i> Avance
            </button>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div><!-- /sec-proyectos -->


<!-- ██████████████████ EXPLORAR PROYECTOS ███████████████████████████ -->
<div class="emp-section" id="sec-explorar">
  <div class="sec-hd">
    <h2>🔍 Proyectos Disponibles</h2>
    <div class="sec-hd-line"></div>
  </div>
  <p style="font-size:.82rem;color:var(--muted);margin-bottom:18px;">Proyectos abiertos a los que puedes unirte según tu área de especialización.</p>

  <?php if (empty($proyectos_disponibles)): ?>
  <div class="empty-state">
    <div class="empty-state-ico">🔍</div>
    <p>No hay proyectos disponibles en este momento.</p>
  </div>
  <?php else: ?>
  <div class="proyectos-grid">
    <?php foreach ($proyectos_disponibles as $p):
      $techs = array_filter(explode(',', $p['tecnologias'] ?? ''));
      $prog  = (int)$p['progreso'];
      $band  = $band_colors[$p['estado']] ?? $band_colors['planeado'];
    ?>
    <div class="proy-card">
      <div class="proy-card-band" style="background:<?= $band ?>"></div>
      <div class="proy-card-body">
        <div class="proy-card-top">
          <div class="proy-ico-wrap"><?= htmlspecialchars($p['icono'] ?? '🚀') ?></div>
          <div>
            <div class="proy-title"><?= htmlspecialchars($p['titulo']) ?></div>
            <span class="badge b-<?= $p['estado'] ?>"><?= ucfirst($p['estado']) ?></span>
          </div>
        </div>
        <?php if (!empty($p['descripcion'])): ?>
        <p class="proy-desc"><?= htmlspecialchars($p['descripcion']) ?></p>
        <?php endif; ?>
        <?php if (!empty($p['areas'])): ?>
        <div class="proy-tags">
          <?php foreach (array_slice(explode(',', $p['areas']), 0, 3) as $a): ?>
          <span class="proy-tag"><?= htmlspecialchars(trim($a)) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($techs)): ?>
        <div class="proy-tags" style="margin-top:4px;">
          <?php foreach (array_slice($techs, 0, 4) as $t): ?>
          <span class="proy-tag" style="background:var(--blue-dim);color:var(--blue-lt);"><?= htmlspecialchars(trim($t)) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="proy-footer" style="margin-top:10px;">
          <div class="proy-meta"><i class="fa fa-users"></i> <?= $p['miembros'] ?> miembros</div>
          <button class="act-btn ab-accept"
                  onclick="postularseProyecto(<?= $p['id'] ?>,'<?= htmlspecialchars($p['titulo'],ENT_QUOTES) ?>')">
            <i class="fa fa-paper-plane"></i> Postularme
          </button>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div><!-- /sec-explorar -->


<!-- ██████████████████ AVANCES & BITÁCORA ███████████████████████████ -->
<div class="emp-section" id="sec-avances">
  <div class="sec-hd">
    <h2>📋 Avances & Bitácora</h2>
    <div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-green" onclick="openModalAgregarAvance()">
      <i class="fa fa-plus"></i> Nuevo avance
    </button>
  </div>

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;">
    <!-- Timeline -->
    <div class="card-base" style="padding:20px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:18px;">Historial de actividad</p>
      <?php if (empty($avances_recientes)): ?>
        <div class="empty-state">
          <div class="empty-state-ico">📋</div>
          <p>Registra tu primer avance de proyecto.</p>
        </div>
      <?php else: ?>
      <div class="timeline">
        <?php foreach ($avances_recientes as $av): ?>
        <div class="tl-item">
          <div class="tl-dot <?= $av['completado'] ? 'tld-green' : 'tld-gold' ?>">
            <i class="fa fa-<?= $av['completado'] ? 'check' : 'clock' ?> fa-xs"></i>
          </div>
          <div class="tl-content">
            <div class="tl-proy">
              <?= htmlspecialchars($av['proyecto_icono'] ?? '🚀') ?>
              <?= htmlspecialchars($av['proyecto_titulo']) ?>
            </div>
            <div class="tl-title"><?= htmlspecialchars($av['titulo']) ?></div>
            <?php if (!empty($av['descripcion'])): ?>
            <div class="tl-desc"><?= htmlspecialchars($av['descripcion']) ?></div>
            <?php endif; ?>
            <div class="tl-date">
              <?= date('d M Y', strtotime($av['fecha'])) ?>
              <?php if (!empty($av['autor_nombre'])): ?>
              · por <?= htmlspecialchars($av['autor_nombre']) ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <!-- Mis proyectos con control de progreso -->
    <div class="card-base" style="padding:20px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">Actualizar Progreso</p>
      <?php foreach ($mis_proyectos as $p): ?>
      <?php if ($p['estado'] === 'activo' || $p['estado'] === 'planeado'): ?>
      <div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
          <span style="font-size:1rem;"><?= htmlspecialchars($p['icono']??'🚀') ?></span>
          <span style="font-size:.82rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($p['titulo']) ?></span>
        </div>
        <div class="proy-prog-bar" style="margin-bottom:6px;">
          <div class="proy-prog-fill" id="progBar_<?= $p['id'] ?>" style="width:<?= $p['progreso'] ?>%"></div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <input type="range" min="0" max="100" value="<?= $p['progreso'] ?>"
                 style="flex:1;accent-color:var(--green);"
                 oninput="document.getElementById('progVal_<?= $p['id'] ?>').textContent=this.value+'%';document.getElementById('progBar_<?= $p['id'] ?>').style.width=this.value+'%'"
                 onchange="actualizarProgreso(<?= $p['id'] ?>,this.value,'<?= $p['estado'] ?>')">
          <span id="progVal_<?= $p['id'] ?>" style="font-size:.75rem;font-weight:700;color:var(--gold);width:36px;"><?= $p['progreso'] ?>%</span>
        </div>
      </div>
      <?php endif; ?>
      <?php endforeach; ?>
      <?php if (empty($mis_proyectos)): ?>
      <p style="font-size:.78rem;color:var(--dim);">Sin proyectos activos.</p>
      <?php endif; ?>
    </div>
  </div>
</div><!-- /sec-avances -->


<!-- ██████████████████ MENSAJES ██████████████████████████████████████ -->
<div class="emp-section" id="sec-mensajes">
  <div class="sec-hd">
    <h2>💬 Mensajes</h2>
    <div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-green" onclick="openModalMensaje()">
      <i class="fa fa-pen"></i> Nuevo mensaje
    </button>
  </div>

  <?php if ($stats['mensajes_nuevos'] > 0): ?>
  <div style="background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);padding:10px 16px;margin-bottom:16px;font-size:.82rem;color:var(--green-lt);display:flex;align-items:center;gap:8px;">
    <i class="fa fa-envelope"></i>
    Tienes <strong><?= $stats['mensajes_nuevos'] ?></strong> mensaje<?= $stats['mensajes_nuevos']>1?'s':'' ?> sin leer.
  </div>
  <?php endif; ?>

  <div class="msg-list">
    <?php if (empty($mensajes_todos)): ?>
    <div class="empty-state">
      <div class="empty-state-ico">💬</div>
      <p>No tienes mensajes todavía.</p>
    </div>
    <?php else: ?>
    <?php foreach ($mensajes_todos as $msg):
      $esNuevo = !$msg['leido'];
      $av_rem  = !empty($msg['remitente_avatar']) ? htmlspecialchars($msg['remitente_avatar']) : '';
      $ini     = mb_substr($msg['remitente_nombre'] ?? 'U', 0, 1);
    ?>
    <div class="msg-item <?= $esNuevo ? 'unread' : '' ?>"
         onclick="abrirMensaje(<?= $msg['id'] ?>,'<?= htmlspecialchars($msg['asunto'],ENT_QUOTES) ?>','<?= htmlspecialchars($msg['mensaje'],ENT_QUOTES) ?>','<?= htmlspecialchars($msg['remitente_nombre'],ENT_QUOTES) ?>')">
      <?php if ($av_rem): ?>
        <img src="<?= $av_rem ?>" class="msg-av" alt="">
      <?php else: ?>
        <div class="msg-av-ph"><?= $ini ?></div>
      <?php endif; ?>
      <div class="msg-body">
        <div class="msg-sender"><?= htmlspecialchars($msg['remitente_nombre'].' '.($msg['remitente_apellido']??'')) ?></div>
        <div class="msg-asunto"><?= htmlspecialchars($msg['asunto']) ?></div>
        <div class="msg-preview"><?= htmlspecialchars($msg['mensaje']) ?></div>
      </div>
      <div class="msg-meta">
        <div class="msg-date"><?= date('d M', strtotime($msg['fecha'])) ?></div>
        <?php if ($esNuevo): ?><div class="msg-unread-dot"></div><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div><!-- /sec-mensajes -->


<!-- ██████████████████ EQUIPO ████████████████████████████████████████ -->
<div class="emp-section" id="sec-equipo">
  <div class="sec-hd">
    <h2>👥 Mi Equipo</h2>
    <div class="sec-hd-line"></div>
    <a href="../equipo.php" class="sec-hd-btn shb-ghost">Ver completo</a>
  </div>

  <?php if (empty($companneros)): ?>
  <div class="empty-state">
    <div class="empty-state-ico">👥</div>
    <p>No hay otros miembros del equipo registrados.</p>
  </div>
  <?php else: ?>
  <div class="team-grid">
    <?php foreach ($companneros as $c):
      $cav = !empty($c['avatar']) ? htmlspecialchars($c['avatar']) : '';
      $ini = mb_substr($c['nombre'] ?? 'U', 0, 1);
      $disp = $c['disponible'] ?? 1;
    ?>
    <div class="team-card">
      <?php if ($cav): ?>
        <img src="<?= $cav ?>" class="tc-av" alt="<?= htmlspecialchars($c['nombre']) ?>" onerror="this.style.display='none'">
      <?php else: ?>
        <div class="tc-av-ph"><?= $ini ?></div>
      <?php endif; ?>
      <div class="tc-name"><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></div>
      <div class="tc-cargo"><?= htmlspecialchars($c['cargo_equipo'] ?? ucfirst($c['rol'])) ?></div>
      <div class="tc-area"><?= htmlspecialchars($c['area_tecnologica'] ?? '') ?></div>
      <div class="tc-disp">
        <div class="tc-disp-dot" style="background:<?= $disp ? '#22c55e' : '#f59e0b' ?>"></div>
        <span style="font-size:.65rem;color:var(--muted);"><?= $disp ? 'Disponible' : 'Ocupado' ?></span>
      </div>
      <button class="tc-contact-btn"
              onclick="openModalMensaje(<?= $c['id'] ?>,'<?= htmlspecialchars($c['nombre'].' '.$c['apellido'],ENT_QUOTES) ?>')">
        <i class="fa fa-envelope"></i> Contactar
      </button>
    </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div><!-- /sec-equipo -->


<!-- ██████████████████ CURSOS ████████████████████████████████████████ -->
<div class="emp-section" id="sec-cursos">
  <div class="sec-hd">
    <h2>🎓 Mis Cursos</h2>
    <div class="sec-hd-line"></div>
    <a href="../AD.php" class="sec-hd-btn shb-green">
      <i class="fa fa-play"></i> Ver catálogo
    </a>
  </div>

  <?php if (empty($mis_cursos)): ?>
  <div class="empty-state">
    <div class="empty-state-ico">🎓</div>
    <p>Aún no te has inscrito en ningún curso.</p>
    <a href="../AD.php" class="sec-hd-btn shb-green" style="display:inline-flex;">
      <i class="fa fa-play"></i> Explorar cursos
    </a>
  </div>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
    <div>
      <p style="font-size:.72rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">En progreso</p>
      <?php foreach (array_filter($mis_cursos, fn($c) => $c['progreso'] < 100) as $c): ?>
      <div class="curso-mini">
        <div class="curso-ico"><?= htmlspecialchars($c['icono'] ?? '📚') ?></div>
        <div class="curso-info">
          <div class="curso-title"><?= htmlspecialchars($c['titulo']) ?></div>
          <div class="curso-meta"><?= ucfirst($c['nivel'] ?? '') ?> · <?= htmlspecialchars($c['duracion'] ?? '') ?></div>
        </div>
        <div class="curso-prog-mini">
          <div class="cpm-pct"><?= $c['progreso'] ?>%</div>
          <div class="cpm-bar"><div class="cpm-fill" style="width:<?= $c['progreso'] ?>%"></div></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div>
      <p style="font-size:.72rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">Completados</p>
      <?php $completados = array_filter($mis_cursos, fn($c) => $c['progreso'] >= 100); ?>
      <?php if (empty($completados)): ?>
        <p style="font-size:.78rem;color:var(--dim);">Sin cursos completados aún.</p>
      <?php else: ?>
        <?php foreach ($completados as $c): ?>
        <div class="curso-mini" style="border-color:rgba(40,166,128,.2);">
          <div class="curso-ico"><?= htmlspecialchars($c['icono'] ?? '📚') ?></div>
          <div class="curso-info">
            <div class="curso-title"><?= htmlspecialchars($c['titulo']) ?></div>
            <div class="curso-meta" style="color:var(--green-lt);">✅ Completado</div>
          </div>
          <div class="cpm-pct" style="color:var(--green-lt);">100%</div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Certificados -->
  <?php if (!empty($mis_certificados)): ?>
  <div style="margin-top:24px;">
    <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">🏆 Mis Certificados</p>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;">
      <?php foreach ($mis_certificados as $cert): ?>
      <div class="card-base" style="padding:16px;text-align:center;">
        <div style="font-size:2rem;margin-bottom:8px;">🏆</div>
        <div style="font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:4px;"><?= htmlspecialchars($cert['curso_titulo'] ?? 'Certificado') ?></div>
        <div style="font-size:.68rem;color:var(--dim);"><?= !empty($cert['fecha_emision']) ? date('d M Y', strtotime($cert['fecha_emision'])) : '—' ?></div>
        <?php if (!empty($cert['codigo'])): ?>
        <div style="font-size:.6rem;color:var(--muted);font-family:var(--font-d);margin-top:6px;"><?= htmlspecialchars($cert['codigo']) ?></div>
        <?php endif; ?>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div><!-- /sec-cursos -->


</main><!-- /emp-main -->
</div><!-- /emp-wrap -->


<!-- ═══════════════════════════════════════════════════════════
     MODALES
════════════════════════════════════════════════════════════ -->

<!-- Modal: Gestionar adquisición -->
<div class="emp-modal" id="modalGestion">
  <div class="em-box">
    <div class="em-header">
      <span class="em-title">⚙️ Gestionar Servicio</span>
      <button class="em-close" onclick="cerrarModal('modalGestion')"><i class="fa fa-times"></i></button>
    </div>
    <div class="em-body">
      <p style="font-size:.85rem;color:var(--muted);margin-bottom:16px;">Servicio: <strong id="gestion_titulo" style="color:var(--txt);"></strong></p>
      <div class="em-group">
        <label class="em-label">Notas internas (opcional)</label>
        <textarea class="em-input" id="gestion_notas" rows="3" placeholder="Motivo de aprobación o rechazo..."></textarea>
      </div>
      <input type="hidden" id="gestion_id">
      <input type="hidden" id="gestion_estado">
    </div>
    <div class="em-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalGestion')">Cancelar</button>
      <button class="em-btn em-btn-danger" onclick="confirmarGestion('cancelado')"><i class="fa fa-xmark"></i> Rechazar</button>
      <button class="em-btn em-btn-primary" onclick="confirmarGestion('pagado')"><i class="fa fa-check"></i> Aprobar</button>
    </div>
  </div>
</div>

<!-- Modal: Agregar avance -->
<div class="emp-modal" id="modalAvance">
  <div class="em-box">
    <div class="em-header">
      <span class="em-title">📝 Registrar Avance</span>
      <button class="em-close" onclick="cerrarModal('modalAvance')"><i class="fa fa-times"></i></button>
    </div>
    <div class="em-body">
      <div class="em-group">
        <label class="em-label">Proyecto</label>
        <select class="em-input" id="avance_proyecto_id">
          <option value="">Seleccionar proyecto...</option>
          <?php foreach ($mis_proyectos as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['icono']??'🚀') ?> <?= htmlspecialchars($p['titulo']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="em-group">
        <label class="em-label">Título del avance *</label>
        <input type="text" class="em-input" id="avance_titulo" placeholder="Ej: Implementación de módulo X completada">
      </div>
      <div class="em-group">
        <label class="em-label">Descripción</label>
        <textarea class="em-input" id="avance_desc" rows="3" placeholder="Detalles del avance logrado..."></textarea>
      </div>
    </div>
    <div class="em-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalAvance')">Cancelar</button>
      <button class="em-btn em-btn-primary" onclick="guardarAvance()"><i class="fa fa-save"></i> Guardar</button>
    </div>
  </div>
</div>

<!-- Modal: Enviar mensaje -->
<div class="emp-modal" id="modalMensaje">
  <div class="em-box">
    <div class="em-header">
      <span class="em-title">💬 Nuevo Mensaje</span>
      <button class="em-close" onclick="cerrarModal('modalMensaje')"><i class="fa fa-times"></i></button>
    </div>
    <div class="em-body">
      <div class="em-group">
        <label class="em-label">Destinatario</label>
        <select class="em-input" id="msg_destinatario">
          <option value="">Seleccionar compañero...</option>
          <?php foreach ($companneros as $c): ?>
          <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?> — <?= htmlspecialchars($c['area_tecnologica']??$c['rol']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="em-group">
        <label class="em-label">Asunto *</label>
        <input type="text" class="em-input" id="msg_asunto" placeholder="Asunto del mensaje">
      </div>
      <div class="em-group">
        <label class="em-label">Mensaje *</label>
        <textarea class="em-input" id="msg_texto" rows="4" placeholder="Escribe tu mensaje aquí..."></textarea>
      </div>
    </div>
    <div class="em-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalMensaje')">Cancelar</button>
      <button class="em-btn em-btn-primary" onclick="enviarMensaje()"><i class="fa fa-paper-plane"></i> Enviar</button>
    </div>
  </div>
</div>

<!-- Modal: Ver mensaje -->
<div class="emp-modal" id="modalVerMensaje">
  <div class="em-box">
    <div class="em-header">
      <span class="em-title">📨 Mensaje</span>
      <button class="em-close" onclick="cerrarModal('modalVerMensaje')"><i class="fa fa-times"></i></button>
    </div>
    <div class="em-body">
      <p style="font-size:.72rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">De:</p>
      <p id="ver_remitente" style="font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:12px;"></p>
      <p style="font-size:.72rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Asunto:</p>
      <p id="ver_asunto" style="font-size:.88rem;font-weight:700;color:var(--gold);margin-bottom:16px;"></p>
      <p style="font-size:.72rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;">Mensaje:</p>
      <div id="ver_texto" style="font-size:.85rem;color:var(--muted);line-height:1.7;background:rgba(255,255,255,.03);padding:14px;border-radius:var(--r-md);border:1px solid rgba(255,255,255,.07);"></div>
      <input type="hidden" id="ver_msg_id">
    </div>
    <div class="em-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalVerMensaje')">Cerrar</button>
      <button class="em-btn em-btn-primary" onclick="responderMensaje()"><i class="fa fa-reply"></i> Responder</button>
    </div>
  </div>
</div>

<!-- Modal: Proyecto detalle -->
<div class="emp-modal" id="modalProyecto">
  <div class="em-box" style="max-width:640px;">
    <div class="em-header">
      <span class="em-title" id="mpTitulo">📊 Proyecto</span>
      <button class="em-close" onclick="cerrarModal('modalProyecto')"><i class="fa fa-times"></i></button>
    </div>
    <div class="em-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;">
        <div>
          <p style="font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Estado</p>
          <span id="mpEstado" class="badge"></span>
        </div>
        <div>
          <p style="font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">Progreso</p>
          <span id="mpProgreso" style="font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);"></span>
        </div>
      </div>
      <div class="proy-prog-bar" style="margin-bottom:14px;">
        <div class="proy-prog-fill" id="mpProgBar" style="width:0%"></div>
      </div>
      <div class="em-group">
        <label class="em-label">Actualizar estado</label>
        <select class="em-input" id="mpEstadoSel">
          <option value="planeado">Planeado</option>
          <option value="activo">Activo</option>
          <option value="pausado">Pausado</option>
          <option value="completado">Completado</option>
        </select>
      </div>
      <div class="em-group">
        <label class="em-label">Actualizar progreso: <span id="mpProgVal"></span></label>
        <input type="range" id="mpProgSlider" min="0" max="100"
               style="width:100%;accent-color:var(--green);"
               oninput="document.getElementById('mpProgVal').textContent=this.value+'%';document.getElementById('mpProgBar').style.width=this.value+'%'">
      </div>
      <input type="hidden" id="mpId">
    </div>
    <div class="em-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalProyecto')">Cancelar</button>
      <button class="em-btn em-btn-primary" onclick="guardarProyecto()"><i class="fa fa-save"></i> Guardar cambios</button>
    </div>
  </div>
</div>

<!-- Toast notifications -->
<div class="toast-wrap" id="toastWrap"></div>


<!-- ═══════════════════════════════════════════════════════════
     JAVASCRIPT
════════════════════════════════════════════════════════════ -->
<script>
/* ══ NAVEGACIÓN ══ */
const SECTION_NAMES = {
  dashboard:'Dashboard', servicios:'Gestión de Servicios',
  proyectos:'Mis Proyectos', explorar:'Explorar Proyectos',
  avances:'Avances & Bitácora', mensajes:'Mensajes',
  equipo:'Mi Equipo', cursos:'Mis Cursos'
};

function showSec(id, el) {
  document.querySelectorAll('.emp-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('active'));
  const sec = document.getElementById('sec-'+id);
  if (sec) sec.classList.add('active');
  if (el) el.classList.add('active');
  else {
    const found = document.querySelector(`.sb-item[onclick*="${id}"]`);
    if (found) found.classList.add('active');
  }
  document.getElementById('tbSectionName').textContent = SECTION_NAMES[id] || id;
  document.querySelector('.emp-main')?.scrollTo({top:0,behavior:'smooth'});
  if (window.innerWidth < 820) closeSidebar();
}

/* ══ SIDEBAR MOBILE ══ */
function toggleSidebar() {
  document.getElementById('empSidebar').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('empSidebar').classList.remove('open');
}

/* ══ MODALES ══ */
function abrirModal(id) {
  document.getElementById(id).classList.add('open');
  document.body.style.overflow = 'hidden';
}
function cerrarModal(id) {
  document.getElementById(id).classList.remove('open');
  document.body.style.overflow = '';
}
document.querySelectorAll('.emp-modal').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) { m.classList.remove('open'); document.body.style.overflow = ''; } });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.emp-modal.open').forEach(m => { m.classList.remove('open'); });
    document.body.style.overflow = '';
  }
});

/* ══ TOAST ══ */
function toast(msg, tipo = 'ok', dur = 3500) {
  const wrap = document.getElementById('toastWrap');
  const t = document.createElement('div');
  t.className = `toast toast-${tipo}`;
  const icons = { ok:'fa-circle-check', err:'fa-triangle-exclamation', info:'fa-circle-info' };
  t.innerHTML = `<i class="fa ${icons[tipo]||'fa-info'}"></i> ${msg}`;
  wrap.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transform='translateX(20px)'; t.style.transition='all .3s'; setTimeout(() => t.remove(), 300); }, dur);
}

/* ══ FETCH HELPER ══ */
async function postAction(data) {
  try {
    const fd = new FormData();
    Object.entries(data).forEach(([k,v]) => fd.append(k, v));
    const r = await fetch('', { method:'POST', body: fd });
    return await r.json();
  } catch (e) {
    return { ok: false, error: 'Error de conexión' };
  }
}

/* ══ GESTIONAR ADQUISICIÓN ══ */
function gestionarAdquisicion(id, estado, titulo) {
  document.getElementById('gestion_id').value = id;
  document.getElementById('gestion_estado').value = estado;
  document.getElementById('gestion_titulo').textContent = titulo;
  document.getElementById('gestion_notas').value = '';
  abrirModal('modalGestion');
}
async function confirmarGestion(estado) {
  const id    = document.getElementById('gestion_id').value;
  const notas = document.getElementById('gestion_notas').value;
  const r = await postAction({ accion:'gestionar_adquisicion', adq_id:id, estado, notas });
  if (r.ok) {
    toast(estado==='pagado' ? '✅ Servicio aprobado exitosamente' : '❌ Servicio rechazado', estado==='pagado'?'ok':'err');
    cerrarModal('modalGestion');
    setTimeout(() => location.reload(), 1200);
  } else { toast('Error: '+r.error, 'err'); }
}

/* ══ FILTRAR SERVICIOS ══ */
function filtrarServicios(estado, btn) {
  document.querySelectorAll('[id^="filt-"]').forEach(b => {
    b.classList.remove('shb-green'); b.classList.add('shb-ghost');
  });
  btn.classList.remove('shb-ghost'); btn.classList.add('shb-green');
  document.querySelectorAll('#srvTable tbody tr').forEach(tr => {
    tr.style.display = (estado === 'todos' || tr.dataset.estado === estado) ? '' : 'none';
  });
}

/* ══ ACTUALIZAR PROGRESO ══ */
let progTimer = {};
async function actualizarProgreso(proyId, progreso, estado) {
  clearTimeout(progTimer[proyId]);
  progTimer[proyId] = setTimeout(async () => {
    const r = await postAction({ accion:'actualizar_progreso', proyecto_id:proyId, progreso, estado });
    if (r.ok) toast('📊 Progreso actualizado: '+progreso+'%', 'ok');
    else toast('Error al actualizar: '+r.error, 'err');
  }, 800);
}

/* ══ MODAL PROYECTO ══ */
function openProyectoModal(id, titulo, progreso, estado) {
  document.getElementById('mpId').value = id;
  document.getElementById('mpTitulo').textContent = '📊 ' + titulo;
  document.getElementById('mpProgreso').textContent = progreso + '%';
  document.getElementById('mpProgBar').style.width = progreso + '%';
  document.getElementById('mpProgSlider').value = progreso;
  document.getElementById('mpProgVal').textContent = progreso + '%';
  document.getElementById('mpEstado').textContent = estado.charAt(0).toUpperCase()+estado.slice(1);
  document.getElementById('mpEstado').className = 'badge b-' + estado;
  document.getElementById('mpEstadoSel').value = estado;
  abrirModal('modalProyecto');
}
async function guardarProyecto() {
  const id      = document.getElementById('mpId').value;
  const progreso = document.getElementById('mpProgSlider').value;
  const estado  = document.getElementById('mpEstadoSel').value;
  const r = await postAction({ accion:'actualizar_progreso', proyecto_id:id, progreso, estado });
  if (r.ok) { toast('✅ Proyecto actualizado correctamente', 'ok'); cerrarModal('modalProyecto'); setTimeout(()=>location.reload(),1200); }
  else toast('Error: '+r.error, 'err');
}

/* ══ AGREGAR AVANCE ══ */
function openModalAgregarAvance(proyId = null, proyTitulo = null) {
  if (proyId) document.getElementById('avance_proyecto_id').value = proyId;
  document.getElementById('avance_titulo').value = '';
  document.getElementById('avance_desc').value = '';
  abrirModal('modalAvance');
}
async function guardarAvance() {
  const proy_id = document.getElementById('avance_proyecto_id').value;
  const titulo  = document.getElementById('avance_titulo').value.trim();
  const desc    = document.getElementById('avance_desc').value.trim();
  if (!proy_id) { toast('Selecciona un proyecto', 'err'); return; }
  if (!titulo)  { toast('El título es obligatorio', 'err'); return; }
  const r = await postAction({ accion:'agregar_avance', proyecto_id:proy_id, titulo, desc });
  if (r.ok) { toast('📝 Avance registrado correctamente', 'ok'); cerrarModal('modalAvance'); setTimeout(()=>location.reload(),1200); }
  else toast('Error: '+r.error, 'err');
}

/* ══ MENSAJES ══ */
function openModalMensaje(destId = null, destNombre = null) {
  if (destId) document.getElementById('msg_destinatario').value = destId;
  else document.getElementById('msg_destinatario').value = '';
  document.getElementById('msg_asunto').value = '';
  document.getElementById('msg_texto').value = '';
  abrirModal('modalMensaje');
}
async function enviarMensaje() {
  const dest_id = document.getElementById('msg_destinatario').value;
  const asunto  = document.getElementById('msg_asunto').value.trim();
  const mensaje = document.getElementById('msg_texto').value.trim();
  if (!dest_id) { toast('Selecciona un destinatario', 'err'); return; }
  if (!asunto)  { toast('El asunto es obligatorio', 'err'); return; }
  if (!mensaje) { toast('Escribe el mensaje', 'err'); return; }
  const r = await postAction({ accion:'enviar_mensaje', destinatario_id:dest_id, asunto, mensaje });
  if (r.ok) { toast('📨 Mensaje enviado correctamente', 'ok'); cerrarModal('modalMensaje'); }
  else toast('Error: '+r.error, 'err');
}
function abrirMensaje(id, asunto, texto, remitente) {
  document.getElementById('ver_msg_id').value = id;
  document.getElementById('ver_remitente').textContent = remitente;
  document.getElementById('ver_asunto').textContent = asunto;
  document.getElementById('ver_texto').textContent = texto;
  abrirModal('modalVerMensaje');
  postAction({ accion:'marcar_leido', msg_id:id });
}
function responderMensaje() {
  cerrarModal('modalVerMensaje');
  openModalMensaje();
}

/* ══ POSTULARSE A PROYECTO ══ */
function postularseProyecto(id, titulo) {
  if (!confirm(`¿Deseas postularte al proyecto "${titulo}"?\n\nUn administrador revisará tu solicitud.`)) return;
  toast(`📤 Solicitud enviada para "${titulo}". Un administrador la revisará.`, 'info', 5000);
}

/* ══ BÚSQUEDA GLOBAL ══ */
document.getElementById('globalSearch').addEventListener('keydown', e => {
  if (e.key !== 'Enter') return;
  const q = e.target.value.toLowerCase();
  if (!q) return;
  // Buscar en proyectos
  let found = false;
  document.querySelectorAll('.proy-title').forEach(el => {
    if (el.textContent.toLowerCase().includes(q)) { found = true; showSec('proyectos'); }
  });
  if (!found) toast(`Sin resultados para "${q}"`, 'info');
});

/* ══ ANIMACIONES DE ENTRADA ══ */
const revObs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.05 });

document.querySelectorAll('.proy-card,.team-card,.stat-card,.kpi-card,.curso-mini,.msg-item').forEach((el, i) => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(16px)';
  el.style.transition = `opacity .4s ease ${i * 0.04}s, transform .4s ease ${i * 0.04}s`;
  revObs.observe(el);
});

/* ══ INIT ══ */
// Auto-mostrar sección por parámetro URL
const urlSec = new URLSearchParams(location.search).get('sec');
if (urlSec) showSec(urlSec);
</script>
</body>
</html>