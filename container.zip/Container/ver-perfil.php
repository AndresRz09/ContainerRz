<?php

include 'conexion.php';
session_start();

$perfil_id = 0;

if (!empty($_GET['id'])) {
    $perfil_id = (int)$_GET['id'];
} elseif (!empty($_GET['u'])) {
    $uname = preg_replace('/[^a-zA-Z0-9_\-]/', '', $_GET['u']);
    $sq = $conexion->prepare("SELECT id FROM usuarios WHERE username = ? LIMIT 1");
    if ($sq) {
        $sq->bind_param("s", $uname);
        $sq->execute();
        $row_sq = $sq->get_result()->fetch_assoc();
        $sq->close();
        $perfil_id = (int)($row_sq['id'] ?? 0);
    }
}

// Sin parámetro y hay sesión → redirigir al propio perfil
if ($perfil_id === 0) {
    if (isset($_SESSION['user_id'])) {
        header("Location: ver-perfil.php?id=" . (int)$_SESSION['user_id']);
    } else {
        header("Location: login.php");
    }
    exit();
}

// ── Cargar datos del PERFIL (no del visitante) ───────────────────────────
$stmt = $conexion->prepare(
    "SELECT u.*,
            COALESCE(u.avatar,'assets/avatar-default.png') AS avatar_url,
            e.area_tecnologica, e.tipo_equipo, e.cargo_equipo,
            e.disponible, e.calificacion AS cal_equipo,
            e.num_proyectos AS np_equipo, e.habilidades AS hab_equipo,
            e.descripcion_equipo
     FROM usuarios u
     LEFT JOIN equipo e ON e.usuario_id = u.id
     WHERE u.id = ? AND u.activo = 1
     LIMIT 1"
);
$stmt->bind_param("i", $perfil_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    // Usuario no encontrado
    http_response_code(404);
    ?><!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Perfil no encontrado</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;700&display=swap" rel="stylesheet">
    <style>body{font-family:'Syne',sans-serif;background:#020817;color:#f0f4f8;display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;gap:16px;}
    a{color:#28A680;}</style></head><body>
    <div style="font-size:4rem;">👤</div>
    <h2>Perfil no encontrado</h2>
    <p style="color:#8da0b8;">Este usuario no existe o su cuenta está desactivada.</p>
    <a href="equipo.php">← Volver al equipo</a>
    </body></html><?php
    exit();
}

// ── ¿El visitante es el dueño del perfil? ───────────────────────────────
$visitor_id  = (int)($_SESSION['user_id'] ?? 0);
$visitor_rol = $_SESSION['rol'] ?? '';
$es_dueno    = ($visitor_id > 0 && $visitor_id === $perfil_id);
$es_admin    = in_array($visitor_rol, ['admin', 'superadmin']);
$puede_editar= $es_dueno || $es_admin;

// ── Registrar visita al perfil (solo si no es el dueño) ──────────────────
if (!$es_dueno && $visitor_id > 0) {
    $rv = $conexion->prepare(
        "INSERT INTO actividad_usuario (usuario_id, tipo, descripcion, referencia_id, referencia_tipo)
         VALUES (?, 'vista_perfil', 'Visitó el perfil de un usuario', ?, 'usuario')"
    );
    if ($rv) { $rv->bind_param("ii", $visitor_id, $perfil_id); $rv->execute(); $rv->close(); }

    // Incrementar contador de visitas en CRM si existe
    $conexion->query("UPDATE usuario_crm SET visitas_perfil = visitas_perfil + 1 WHERE usuario_id = $perfil_id");
}

// ── Estadísticas del perfil ──────────────────────────────────────────────
$stats = ['cursos_total' => 0, 'cursos_comp' => 0, 'certs' => 0, 'pubs' => 0];

$qs = [
    'cursos_total' => "SELECT COUNT(*) c FROM inscripciones WHERE usuario_id=?",
    'cursos_comp'  => "SELECT COUNT(*) c FROM inscripciones WHERE usuario_id=? AND completado=1",
    'certs'        => "SELECT COUNT(*) c FROM certificados WHERE usuario_id=?",
    'pubs'         => "SELECT COUNT(*) c FROM publicaciones WHERE autor_id=?",
];
foreach ($qs as $key => $sql) {
    $q = $conexion->prepare($sql);
    if ($q) {
        $q->bind_param("i", $perfil_id);
        $q->execute();
        $stats[$key] = (int)($q->get_result()->fetch_assoc()['c'] ?? 0);
        $q->close();
    }
}

$nivel = min(100, ($stats['cursos_comp'] * 15) + ($stats['certs'] * 20) + ($stats['pubs'] * 10));

// ── Proyectos del perfil ─────────────────────────────────────────────────
$proyectos = [];
$qpry = $conexion->prepare(
    "SELECT p.id, p.titulo, p.estado, p.progreso, p.icono, pu.rol_proyecto
     FROM proyecto_usuarios pu
     JOIN proyectos p ON pu.proyecto_id = p.id
     WHERE pu.usuario_id = ?
     ORDER BY p.fecha_inicio DESC
     LIMIT 6"
);
if ($qpry) {
    $qpry->bind_param("i", $perfil_id);
    $qpry->execute();
    $rpry = $qpry->get_result();
    while ($r = $rpry->fetch_assoc()) $proyectos[] = $r;
    $qpry->close();
}

// ── Actividad reciente (solo visible al dueño o admin) ───────────────────
$actividad = [];
if ($puede_editar) {
    $qa = $conexion->prepare(
        "SELECT tipo, descripcion, fecha FROM actividad_usuario
         WHERE usuario_id = ? ORDER BY fecha DESC LIMIT 8"
    );
    if ($qa) {
        $qa->bind_param("i", $perfil_id);
        $qa->execute();
        $ra = $qa->get_result();
        while ($a = $ra->fetch_assoc()) $actividad[] = $a;
        $qa->close();
    }
}

// ── Cursos inscritos ─────────────────────────────────────────────────────
$cursos_rec = [];
$qcr = $conexion->prepare(
    "SELECT c.titulo, c.imagen, i.progreso, i.completado
     FROM inscripciones i
     JOIN cursos c ON i.curso_id = c.id
     WHERE i.usuario_id = ?
     ORDER BY i.fecha_inscripcion DESC
     LIMIT 4"
);
if ($qcr) {
    $qcr->bind_param("i", $perfil_id);
    $qcr->execute();
    $rcr = $qcr->get_result();
    while ($cr = $rcr->fetch_assoc()) $cursos_rec[] = $cr;
    $qcr->close();
}

// ── Intereses y datos ────────────────────────────────────────────────────
$intereses      = array_filter(array_map('trim', explode(',', $user['intereses'] ?? '')));
$habilidades    = array_filter(array_map('trim', explode(',', $user['hab_equipo'] ?? $user['habilidades'] ?? '')));
$nombre_completo= htmlspecialchars(trim(($user['nombre'] ?? '') . ' ' . ($user['apellido'] ?? '')));
$avatar_src     = htmlspecialchars($user['avatar_url'] ?? 'assets/avatar-default.png');

// Determinar qué tabs mostrar
$tabs_publicos   = ['overview', 'proyectos', 'info'];
$tabs_privados   = ['cursos', 'certificados', 'actividad'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= $nombre_completo ?> — Perfil · VIROX</title>

  <!-- Open Graph para compartir -->
  <meta property="og:title"       content="<?= $nombre_completo ?> — VIROX">
  <meta property="og:description" content="<?= htmlspecialchars(mb_substr($user['bio'] ?? 'Miembro de Team VIROX', 0, 120)) ?>">
  <meta property="og:image"       content="<?= $avatar_src ?>">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --r-sm:8px;--r-md:14px;--r-lg:22px;--r-xl:28px;
      --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
      --hh:68px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);}
    ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;} button{cursor:pointer;border:none;font-family:inherit;}

    /* ════════════════════════════════════════
       BANNER SUPERIOR
    ════════════════════════════════════════ */
    .prof-banner{
      position:relative;overflow:hidden;
      height:220px;
      background:linear-gradient(135deg,#071428 0%,#0e2240 40%,#071428 100%);
    }
    .banner-grid{position:absolute;inset:0;
      background-image:linear-gradient(rgba(40,166,128,.05) 1px,transparent 1px),
        linear-gradient(90deg,rgba(40,166,128,.05) 1px,transparent 1px);
      background-size:44px 44px;}
    .banner-orb{position:absolute;border-radius:50%;filter:blur(80px);}
    .bo1{width:400px;height:400px;background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-120px;left:-100px;}
    .bo2{width:320px;height:320px;background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-80px;right:-60px;}

    /* Indicador de "es tu perfil" / "perfil ajeno" */
    .banner-notice{
      position:absolute;top:16px;right:20px;
      display:flex;align-items:center;gap:7px;
      padding:6px 14px;border-radius:99px;font-size:.72rem;font-weight:700;letter-spacing:.5px;z-index:5;
    }
    .bn-own{background:rgba(40,166,128,.18);border:1px solid rgba(40,166,128,.35);color:var(--green-lt);}
    .bn-other{background:rgba(218,165,32,.12);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}

    /* ════════════════════════════════════════
       LAYOUT PRINCIPAL
    ════════════════════════════════════════ */
    .prof-layout{
      display:grid;
      grid-template-columns:280px 1fr;
      max-width:1280px;margin:0 auto;
      padding:0 28px 60px;
      gap:28px;
      align-items:start;
    }

    /* ════════════════════════════════════════
       SIDEBAR
    ════════════════════════════════════════ */
    .prof-sidebar{
      margin-top:-80px;
      position:sticky;top:calc(var(--hh)+16px);
      display:flex;flex-direction:column;gap:16px;
    }

    /* Tarjeta de identidad */
    .psb-id-card{
      background:var(--n800);border:1px solid rgba(40,166,128,.2);
      border-radius:var(--r-xl);padding:24px 20px;
      text-align:center;
      box-shadow:0 8px 32px rgba(0,0,0,.45);
    }
    .psb-av-wrap{position:relative;width:96px;height:96px;margin:0 auto 14px;}
    .psb-av-ring{
      position:absolute;inset:-4px;border-radius:50%;
      background:linear-gradient(135deg,var(--green),var(--gold));
      padding:2px;-webkit-mask:linear-gradient(#fff 0 0) content-box,linear-gradient(#fff 0 0);
      -webkit-mask-composite:destination-out;mask-composite:exclude;
      animation:ringR 6s linear infinite;
    }
    @keyframes ringR{to{transform:rotate(360deg)}}
    .psb-av{width:96px;height:96px;border-radius:50%;object-fit:cover;background:var(--n700);display:flex;align-items:center;justify-content:center;font-size:2.5rem;border:3px solid var(--n800);position:relative;z-index:1;}
    .psb-av img{width:100%;height:100%;border-radius:50%;object-fit:cover;}
    .psb-disp-dot{
      position:absolute;bottom:4px;right:4px;z-index:2;
      width:14px;height:14px;border-radius:50%;border:2.5px solid var(--n800);
    }
    .psb-disp-dot.on{background:#22c55e;box-shadow:0 0 8px #22c55e;}
    .psb-disp-dot.off{background:#f59e0b;}

    .psb-name{font-family:var(--font-d);font-size:.95rem;font-weight:700;color:var(--txt);letter-spacing:.5px;margin-bottom:4px;line-height:1.3;}
    .psb-cargo{font-size:.75rem;color:var(--green-lt);font-weight:700;letter-spacing:1px;margin-bottom:3px;}
    .psb-username{font-size:.75rem;color:var(--dim);margin-bottom:10px;}

    .psb-badges{display:flex;flex-wrap:wrap;justify-content:center;gap:6px;margin-bottom:14px;}
    .psb-badge{padding:3px 11px;border-radius:99px;font-size:.66rem;font-weight:700;letter-spacing:.5px;}
    .psb-badge-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.35);color:var(--green-lt);}
    .psb-badge-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
    .psb-badge-blue{background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.3);color:#93c5fd;}
    .psb-badge-purple{background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.3);color:#c4b5fd;}

    /* Stats rápidas */
    .psb-quickstats{
      display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px;
    }
    .qstat{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:10px;text-align:center;}
    .qstat-n{font-family:var(--font-d);font-size:1.2rem;font-weight:700;color:var(--gold);}
    .qstat-l{font-size:.62rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

    /* Rating */
    .psb-rating{display:flex;align-items:center;justify-content:center;gap:5px;margin-bottom:12px;}
    .pst-stars{display:flex;gap:2px;}
    .pst-star{font-size:.8rem;color:var(--gold);}
    .pst-star.e{color:rgba(255,255,255,.15);}
    .pst-n{font-size:.75rem;color:var(--dim);}

    /* Nivel barra */
    .psb-lvl{margin-bottom:16px;}
    .psb-lvl-top{display:flex;justify-content:space-between;font-size:.7rem;color:var(--muted);margin-bottom:6px;}
    .psb-lvl-bar{height:5px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
    .psb-lvl-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1.2s ease;}

    /* Botones de acción del sidebar */
    .psb-actions{display:flex;flex-direction:column;gap:8px;}
    .psb-btn{
      display:flex;align-items:center;justify-content:center;gap:8px;
      padding:11px;border-radius:var(--r-md);
      font-size:.85rem;font-weight:700;cursor:pointer;
      transition:all .2s;font-family:var(--font-b);
    }
    .psb-btn-primary{background:linear-gradient(135deg,var(--green),#1d8f6e);color:#fff;box-shadow:0 4px 16px rgba(40,166,128,.3);}
    .psb-btn-primary:hover{transform:translateY(-2px);box-shadow:0 6px 22px rgba(40,166,128,.4);}
    .psb-btn-gold{background:linear-gradient(135deg,var(--gold),#b8860b);color:#111;font-weight:800;}
    .psb-btn-gold:hover{transform:translateY(-2px);}
    .psb-btn-ghost{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
    .psb-btn-ghost:hover{background:rgba(255,255,255,.09);color:var(--txt);}
    .psb-btn-danger{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;}
    .psb-btn-danger:hover{background:rgba(239,68,68,.18);}

    /* Redes sociales sidebar */
    .psb-social{display:flex;justify-content:center;gap:8px;margin-top:4px;}
    .soc-ico-btn{
      width:34px;height:34px;border-radius:var(--r-sm);
      background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
      display:flex;align-items:center;justify-content:center;
      font-size:.9rem;color:var(--muted);transition:all .2s;
    }
    .soc-ico-btn:hover{background:rgba(40,166,128,.15);color:var(--green-lt);}

    /* ════════════════════════════════════════
       CONTENIDO PRINCIPAL
    ════════════════════════════════════════ */
    .prof-main{padding-top:20px;min-width:0;}

    /* Tabs */
    .prof-tabs{
      display:flex;gap:2px;background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-lg);padding:4px;
      margin-bottom:24px;overflow-x:auto;
      scrollbar-width:none;
    }
    .prof-tabs::-webkit-scrollbar{display:none;}
    .ptab{
      flex-shrink:0;padding:9px 20px;border-radius:12px;
      font-size:.82rem;font-weight:700;color:var(--muted);
      cursor:pointer;transition:all .2s;background:none;white-space:nowrap;
    }
    .ptab:hover{color:var(--txt);}
    .ptab.on{background:var(--green);color:#fff;box-shadow:0 2px 12px rgba(40,166,128,.35);}
    .ptab-icon{margin-right:5px;}
    .ptab-badge{
      display:inline-block;margin-left:5px;padding:1px 7px;
      background:rgba(255,255,255,.12);border-radius:99px;font-size:.62rem;
    }
    .ptab.on .ptab-badge{background:rgba(255,255,255,.2);}

    /* Contenido de tab */
    .ptab-content{display:none;animation:tabIn .3s ease both;}
    .ptab-content.on{display:block;}
    @keyframes tabIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

    /* ─── Tab: Overview ─── */
    .stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:24px;}
    .stat-card{
      background:var(--n700);border:1px solid rgba(255,255,255,.06);
      border-radius:var(--r-lg);padding:20px 16px;text-align:center;
      transition:transform .2s,border-color .2s;
    }
    .stat-card:hover{transform:translateY(-4px);border-color:rgba(40,166,128,.3);}
    .sc-ico{font-size:1.6rem;margin-bottom:7px;}
    .sc-num{font-family:var(--font-d);font-size:1.9rem;font-weight:900;color:var(--gold);line-height:1;}
    .sc-lbl{font-size:.68rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:4px;}

    /* Sección title */
    .sec-title{
      font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);
      letter-spacing:1px;margin-bottom:16px;margin-top:28px;
      display:flex;align-items:center;justify-content:space-between;
    }
    .sec-title:first-child{margin-top:0;}
    .sec-title a{font-family:var(--font-b);font-size:.75rem;color:var(--green);font-weight:600;}
    .sec-title-dot{
      width:6px;height:6px;border-radius:50%;background:var(--green);
      margin-right:10px;box-shadow:0 0 8px var(--green);display:inline-block;
    }

    /* Proyectos grid */
    .proy-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:12px;}
    .proy-card{
      background:var(--n700);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);padding:16px;transition:transform .2s,border-color .2s;
    }
    .proy-card:hover{transform:translateY(-3px);border-color:rgba(40,166,128,.3);}
    .proy-card-top{display:flex;align-items:center;gap:10px;margin-bottom:10px;}
    .proy-ico{width:40px;height:40px;border-radius:var(--r-sm);background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
    .proy-title{font-weight:700;font-size:.85rem;color:var(--txt);line-height:1.3;}
    .proy-rol{font-size:.7rem;color:var(--muted);}
    .proy-estado{display:inline-block;padding:2px 9px;border-radius:99px;font-size:.64rem;font-weight:700;margin-bottom:8px;}
    .proy-activo{background:rgba(40,166,128,.15);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
    .proy-completado{background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.3);color:#93c5fd;}
    .proy-pausado{background:rgba(218,165,32,.12);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
    .proy-planeado{background:rgba(139,92,246,.15);border:1px solid rgba(139,92,246,.3);color:#c4b5fd;}
    .proy-bar{height:3px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
    .proy-fill{height:100%;background:var(--green);border-radius:99px;}

    /* Cursos */
    .cursos-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px;}
    .curso-card{background:var(--n700);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);overflow:hidden;transition:transform .2s;}
    .curso-card:hover{transform:translateY(-3px);}
    .curso-img{width:100%;aspect-ratio:16/9;object-fit:cover;background:var(--n600);display:flex;align-items:center;justify-content:center;font-size:2rem;}
    .curso-body{padding:12px;}
    .curso-title{font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:8px;line-height:1.3;}
    .curso-prog{height:3px;background:rgba(255,255,255,.08);border-radius:99px;margin-bottom:4px;}
    .curso-prog-fill{height:100%;background:var(--green);border-radius:99px;}
    .curso-pct{font-size:.68rem;color:var(--muted);}

    /* Info grid */
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    .info-item{background:var(--n700);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);padding:14px;}
    .info-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:3px;}
    .info-val{font-size:.9rem;color:var(--txt);font-weight:600;}
    .info-private{font-size:.82rem;color:var(--dim);font-style:italic;}

    /* Tags/chips */
    .tags{display:flex;flex-wrap:wrap;gap:7px;margin-top:12px;}
    .tag{padding:4px 13px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;font-size:.73rem;color:var(--green-lt);font-weight:600;}

    /* Habilidades */
    .skills-wrap{display:flex;flex-wrap:wrap;gap:7px;}
    .skill-tag{padding:4px 12px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.73rem;color:var(--muted);font-weight:600;}

    /* Actividad */
    .act-list{display:flex;flex-direction:column;gap:8px;}
    .act-item{display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--n700);border:1px solid rgba(255,255,255,.05);border-radius:var(--r-md);}
    .act-ico{width:34px;height:34px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;}
    .act-desc{font-size:.83rem;color:var(--txt);flex:1;}
    .act-date{font-size:.7rem;color:var(--dim);}

    /* Bio card */
    .bio-card{background:var(--n700);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);padding:20px;margin-bottom:20px;}
    .bio-txt{font-size:.9rem;color:var(--muted);line-height:1.8;}

    /* Aviso de privacidad */
    .private-notice{
      display:flex;align-items:center;gap:12px;padding:16px 18px;
      background:rgba(218,165,32,.07);border:1px solid rgba(218,165,32,.2);
      border-radius:var(--r-md);font-size:.84rem;color:var(--gold-lt);
    }

    /* Social links */
    .social-row{display:flex;flex-wrap:wrap;gap:8px;}
    .soc-link{display:flex;align-items:center;gap:7px;padding:8px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:var(--r-md);font-size:.8rem;color:var(--muted);transition:all .2s;}
    .soc-link:hover{background:rgba(255,255,255,.09);color:var(--txt);}

    /* Modal contactar */
    .modal{position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:9999;display:none;align-items:center;justify-content:center;padding:24px;}
    .modal.open{display:flex;}
    .modal-box{background:var(--n800);border:1px solid rgba(40,166,128,.25);border-radius:var(--r-xl);width:min(520px,94vw);overflow:hidden;box-shadow:0 24px 60px rgba(0,0,0,.7);animation:mIn .3s ease both;}
    @keyframes mIn{from{opacity:0;transform:scale(.96) translateY(16px)}to{opacity:1;transform:none}}
    .mhd{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid rgba(255,255,255,.07);}
    .mhd h3{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
    .mcls{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.07);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;font-size:.8rem;}
    .mcls:hover{background:rgba(239,68,68,.2);color:#f87171;}
    .mbody{padding:22px 24px;}
    .minput{width:100%;padding:10px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.88rem;margin-bottom:12px;outline:none;transition:border-color .2s;}
    .minput:focus{border-color:var(--green);}
    .mtarea{resize:vertical;min-height:110px;line-height:1.6;}
    .mfoot{display:flex;gap:10px;justify-content:flex-end;padding:16px 24px;border-top:1px solid rgba(255,255,255,.06);}

    /* Responsive */
    @media(max-width:1024px){.prof-layout{grid-template-columns:240px 1fr;gap:20px;}}
    @media(max-width:768px){
      .prof-layout{grid-template-columns:1fr;padding:0 16px 40px;}
      .prof-sidebar{margin-top:-60px;position:static;}
      .info-grid{grid-template-columns:1fr;}
    }
    @media(max-width:480px){
      .prof-banner{height:160px;}
      .stats-row{grid-template-columns:1fr 1fr;}
    }
  </style>
</head>
<body>

<!-- ══ HEADER ══ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php"        class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php"        class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>

      <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill" onclick="toggleDrop(this)">
            <?php if (!empty($_SESSION['avatar'])): ?>
              <img src="<?= htmlspecialchars($_SESSION['avatar']) ?>" alt="" style="width:26px;height:26px;border-radius:50%;object-fit:cover;">
            <?php else: ?>
              <span class="user-av"><i class="fa fa-user"></i></span>
            <?php endif; ?>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span>
            <i class="fa fa-chevron-down" style="font-size:.6rem;opacity:.6;"></i>
          </button>
          <div class="user-drop" id="userDrop">
            <a href="ver-perfil.php?id=<?= $visitor_id ?>"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="editar-perfil.php"><i class="fa fa-pen"></i> Editar perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Cerrar sesión</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ══ BANNER ══ -->
<div class="prof-banner">
  <div class="banner-grid"></div>
  <div class="banner-orb bo1"></div>
  <div class="banner-orb bo2"></div>

  <!-- Indicador dueño vs visitante -->
  <?php if ($es_dueno): ?>
  <div class="banner-notice bn-own">
    <i class="fa fa-user-check"></i> Estás viendo tu propio perfil
  </div>
  <?php elseif ($es_admin): ?>
  <div class="banner-notice bn-other">
    <i class="fa fa-shield-halved"></i> Vista Admin · ID <?= $perfil_id ?>
  </div>
  <?php elseif ($visitor_id > 0): ?>
  <div class="banner-notice bn-other">
    <i class="fa fa-eye"></i> Viendo perfil de <?= htmlspecialchars($user['nombre'] ?? '') ?>
  </div>
  <?php endif; ?>
</div>


<!-- ══ LAYOUT ══ -->
<div class="prof-layout">

  <!-- ─── SIDEBAR ──────────────────────────────────────────────── -->
  <aside class="prof-sidebar">

    <!-- Tarjeta de identidad -->
    <div class="psb-id-card">

      <!-- Avatar -->
      <div class="psb-av-wrap" style="margin:0 auto 14px;">
        <div class="psb-av-ring"></div>
        <div class="psb-av">
          <img src="<?= $avatar_src ?>" alt="Avatar de <?= $nombre_completo ?>">
        </div>
        <div class="psb-disp-dot <?= ($user['disponible'] ?? 1) ? 'on' : 'off' ?>"
             title="<?= ($user['disponible'] ?? 1) ? 'Disponible' : 'Ocupado' ?>"></div>
      </div>

      <!-- Nombre y cargo -->
      <div class="psb-name"><?= $nombre_completo ?></div>
      <?php if (!empty($user['cargo_equipo']) || !empty($user['ocupacion'])): ?>
      <div class="psb-cargo"><?= htmlspecialchars($user['cargo_equipo'] ?? $user['ocupacion']) ?></div>
      <?php endif; ?>
      <div class="psb-username">@<?= htmlspecialchars($user['username'] ?? '') ?></div>

      <!-- Badges de rol y área -->
      <div class="psb-badges">
        <?php
          $rol_badge_class = match($user['rol'] ?? '') {
            'admin'      => 'psb-badge-blue',
            'superadmin' => 'psb-badge-purple',
            'empleado'   => 'psb-badge-green',
            'creador'    => 'psb-badge-gold',
            default      => 'psb-badge-green',
          };
          $rol_label = match($user['rol'] ?? '') {
            'admin'      => '⚙️ Admin',
            'superadmin' => '👑 SuperAdmin',
            'empleado'   => '👔 Empleado',
            'creador'    => '🎨 Creador',
            default      => '👤 Usuario',
          };
        ?>
        <span class="psb-badge <?= $rol_badge_class ?>"><?= $rol_label ?></span>
        <?php if (!empty($user['area_tecnologica'])): ?>
        <span class="psb-badge psb-badge-green"><?= htmlspecialchars($user['area_tecnologica']) ?></span>
        <?php endif; ?>
        <?php if (!empty($user['tipo_equipo'])): ?>
        <span class="psb-badge psb-badge-gold"><?= htmlspecialchars($user['tipo_equipo']) ?></span>
        <?php endif; ?>
      </div>

      <!-- Rating -->
      <?php $cal = (float)($user['cal_equipo'] ?? $user['calificacion'] ?? 0); if ($cal > 0): ?>
      <div class="psb-rating">
        <div class="pst-stars">
          <?php for ($s = 1; $s <= 5; $s++): ?>
          <span class="pst-star <?= $s <= round($cal) ? '' : 'e' ?>">★</span>
          <?php endfor; ?>
        </div>
        <span class="pst-n"><?= number_format($cal, 1) ?></span>
      </div>
      <?php endif; ?>

      <!-- Stats rápidas -->
      <div class="psb-quickstats">
        <div class="qstat">
          <div class="qstat-n"><?= $stats['cursos_comp'] ?></div>
          <div class="qstat-l">Cursos</div>
        </div>
        <div class="qstat">
          <div class="qstat-n"><?= count($proyectos) ?></div>
          <div class="qstat-l">Proyectos</div>
        </div>
        <div class="qstat">
          <div class="qstat-n"><?= $stats['certs'] ?></div>
          <div class="qstat-l">Certs</div>
        </div>
        <div class="qstat">
          <div class="qstat-n"><?= $nivel ?></div>
          <div class="qstat-l">Nivel</div>
        </div>
      </div>

      <!-- Barra de nivel -->
      <div class="psb-lvl">
        <div class="psb-lvl-top">
          <span>Nivel de progreso</span>
          <span style="color:var(--gold);font-weight:700;"><?= $nivel ?>/100</span>
        </div>
        <div class="psb-lvl-bar">
          <div class="psb-lvl-fill" data-w="<?= $nivel ?>" style="width:0;"></div>
        </div>
      </div>

      <!-- Redes sociales -->
      <?php
        $redes = [];
        if (!empty($user['linkedin'])) $redes[] = ['fab fa-linkedin', $user['linkedin'], '#0A66C2', 'LinkedIn'];
        if (!empty($user['github']))   $redes[] = ['fab fa-github',   $user['github'],   '#ccc',    'GitHub'];
        if (!empty($user['twitter']))  $redes[] = ['fab fa-twitter',  $user['twitter'],  '#1DA1F2', 'Twitter'];
        if (!empty($user['website']))  $redes[] = ['fa fa-globe',     $user['website'],  '#28A680', 'Web'];
      ?>
      <?php if (!empty($redes)): ?>
      <div class="psb-social" style="margin-bottom:12px;">
        <?php foreach ($redes as [$ico, $url, $clr, $lbl]): ?>
        <a href="<?= htmlspecialchars($url) ?>" target="_blank" class="soc-ico-btn" title="<?= $lbl ?>" style="color:<?= $clr ?>;">
          <i class="<?= $ico ?>"></i>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Botones de acción -->
      <div class="psb-actions">
        <?php if ($es_dueno): ?>
          <!-- Dueño del perfil: editar y logout -->
          <a href="editar-perfil.php" class="psb-btn psb-btn-primary">
            <i class="fa fa-pen"></i> Editar mi perfil
          </a>
          <?php if ($es_admin): ?>
          <a href="admin/index.php" class="psb-btn psb-btn-gold">
            <i class="fa fa-shield-halved"></i> Panel Admin
          </a>
          <?php endif; ?>
          <a href="logout.php" class="psb-btn psb-btn-danger">
            <i class="fa fa-sign-out-alt"></i> Cerrar sesión
          </a>

        <?php elseif ($visitor_id > 0): ?>
          <!-- Otro usuario logueado: contactar -->
          <button class="psb-btn psb-btn-primary" onclick="openContactModal()">
            <i class="fa fa-envelope"></i> Enviar mensaje
          </button>
          <?php if ($es_admin): ?>
          <a href="admin/usuarios.php?edit=<?= $perfil_id ?>" class="psb-btn psb-btn-gold">
            <i class="fa fa-pen"></i> Editar (Admin)
          </a>
          <?php endif; ?>
          <a href="equipo.php" class="psb-btn psb-btn-ghost">
            <i class="fa fa-arrow-left"></i> Volver al equipo
          </a>

        <?php else: ?>
          <!-- Visitante anónimo -->
          <a href="login.php" class="psb-btn psb-btn-primary">
            <i class="fa fa-sign-in-alt"></i> Ingresar para contactar
          </a>
          <a href="equipo.php" class="psb-btn psb-btn-ghost">
            <i class="fa fa-arrow-left"></i> Volver al equipo
          </a>
        <?php endif; ?>
      </div>

    </div><!-- /psb-id-card -->

    <!-- Miembro desde -->
    <div style="text-align:center;font-size:.72rem;color:var(--dim);padding:8px;">
      <i class="fa fa-calendar-check" style="color:var(--green);margin-right:5px;"></i>
      Miembro desde <?= !empty($user['fecha_registro']) ? date('M Y', strtotime($user['fecha_registro'])) : 'N/A' ?>
    </div>

  </aside>


  <!-- ─── CONTENIDO PRINCIPAL ──────────────────────────────────── -->
  <main class="prof-main">

    <!-- Tabs -->
    <div class="prof-tabs">
      <button class="ptab on" onclick="showTab('overview',this)">
        <span class="ptab-icon">📊</span>Resumen
      </button>
      <button class="ptab" onclick="showTab('proyectos',this)">
        <span class="ptab-icon">🚀</span>Proyectos
        <span class="ptab-badge"><?= count($proyectos) ?></span>
      </button>
      <button class="ptab" onclick="showTab('info',this)">
        <span class="ptab-icon">ℹ️</span>Información
      </button>
      <?php if (!empty($habilidades)): ?>
      <button class="ptab" onclick="showTab('habilidades',this)">
        <span class="ptab-icon">⚡</span>Habilidades
      </button>
      <?php endif; ?>
      <?php if ($puede_editar): ?>
      <button class="ptab" onclick="showTab('cursos',this)">
        <span class="ptab-icon">🎓</span>Cursos
        <span class="ptab-badge"><?= $stats['cursos_total'] ?></span>
      </button>
      <button class="ptab" onclick="showTab('actividad',this)">
        <span class="ptab-icon">⏱</span>Actividad
      </button>
      <?php endif; ?>
    </div>


    <!-- ══ TAB: RESUMEN ══════════════════════════════════════════ -->
    <div class="ptab-content on" id="tab-overview">

      <!-- Stats -->
      <div class="stats-row">
        <div class="stat-card"><div class="sc-ico">🎓</div><div class="sc-num"><?= $stats['cursos_total'] ?></div><div class="sc-lbl">Cursos</div></div>
        <div class="stat-card"><div class="sc-ico">✅</div><div class="sc-num"><?= $stats['cursos_comp'] ?></div><div class="sc-lbl">Completados</div></div>
        <div class="stat-card"><div class="sc-ico">🏆</div><div class="sc-num"><?= $stats['certs'] ?></div><div class="sc-lbl">Certificados</div></div>
        <div class="stat-card"><div class="sc-ico">🚀</div><div class="sc-num"><?= count($proyectos) ?></div><div class="sc-lbl">Proyectos</div></div>
      </div>

      <!-- Bio -->
      <?php if (!empty($user['bio'])): ?>
      <div class="sec-title"><span><span class="sec-title-dot"></span>Sobre <?= htmlspecialchars($user['nombre'] ?? '') ?></span></div>
      <div class="bio-card">
        <p class="bio-txt"><?= nl2br(htmlspecialchars($user['bio'])) ?></p>
      </div>
      <?php endif; ?>

      <!-- Habilidades preview -->
      <?php if (!empty($habilidades)): ?>
      <div class="sec-title"><span><span class="sec-title-dot"></span>Habilidades destacadas</span></div>
      <div class="skills-wrap" style="margin-bottom:20px;">
        <?php foreach (array_slice($habilidades, 0, 8) as $sk): ?>
        <span class="skill-tag"><?= htmlspecialchars($sk) ?></span>
        <?php endforeach; ?>
        <?php if (count($habilidades) > 8): ?>
        <span class="skill-tag" style="color:var(--green-lt);border-color:rgba(40,166,128,.3);">+<?= count($habilidades) - 8 ?> más</span>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <!-- Intereses -->
      <?php if (!empty($intereses)): ?>
      <div class="sec-title"><span><span class="sec-title-dot"></span>Áreas de interés</span></div>
      <div class="tags" style="margin-bottom:20px;">
        <?php foreach ($intereses as $int): if (!$int) continue; ?>
        <span class="tag"><?= htmlspecialchars($int) ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Proyectos preview (max 4) -->
      <?php if (!empty($proyectos)): ?>
      <div class="sec-title">
        <span><span class="sec-title-dot"></span>Proyectos recientes</span>
        <a onclick="showTab('proyectos', document.querySelectorAll('.ptab')[1])">Ver todos →</a>
      </div>
      <div class="proy-grid">
        <?php foreach (array_slice($proyectos, 0, 4) as $pr):
          $est_cls = match($pr['estado'] ?? ''){
            'activo'     => 'proy-activo',
            'completado' => 'proy-completado',
            'pausado'    => 'proy-pausado',
            default      => 'proy-planeado',
          };
          $est_lbl = match($pr['estado'] ?? ''){
            'activo'     => '● Activo',
            'completado' => '✔ Completado',
            'pausado'    => '⏸ En pausa',
            default      => '◌ Planeado',
          };
        ?>
        <div class="proy-card">
          <div class="proy-card-top">
            <div class="proy-ico"><?= htmlspecialchars($pr['icono'] ?? '🚀') ?></div>
            <div>
              <div class="proy-title"><?= htmlspecialchars($pr['titulo']) ?></div>
              <div class="proy-rol"><?= htmlspecialchars($pr['rol_proyecto'] ?? '') ?></div>
            </div>
          </div>
          <span class="proy-estado <?= $est_cls ?>"><?= $est_lbl ?></span>
          <div class="proy-bar">
            <div class="proy-fill" style="width:<?= (int)($pr['progreso'] ?? 0) ?>%"></div>
          </div>
          <div style="font-size:.68rem;color:var(--dim);margin-top:4px;"><?= (int)($pr['progreso'] ?? 0) ?>% completado</div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

    </div><!-- /tab-overview -->


    <!-- ══ TAB: PROYECTOS ════════════════════════════════════════ -->
    <div class="ptab-content" id="tab-proyectos">
      <div class="sec-title"><span><span class="sec-title-dot"></span>Proyectos (<?= count($proyectos) ?>)</span></div>

      <?php if (empty($proyectos)): ?>
      <div style="text-align:center;padding:60px 24px;background:var(--n700);border-radius:var(--r-lg);border:1px dashed rgba(255,255,255,.08);">
        <div style="font-size:3rem;margin-bottom:12px;opacity:.3;">🚀</div>
        <p style="color:var(--muted);">No hay proyectos asociados a este perfil.</p>
      </div>
      <?php else: ?>
      <div class="proy-grid">
        <?php foreach ($proyectos as $pr):
          $est_cls = match($pr['estado'] ?? ''){
            'activo'     => 'proy-activo',
            'completado' => 'proy-completado',
            'pausado'    => 'proy-pausado',
            default      => 'proy-planeado',
          };
          $est_lbl = match($pr['estado'] ?? ''){
            'activo'     => '● Activo',
            'completado' => '✔ Completado',
            'pausado'    => '⏸ En pausa',
            default      => '◌ Planeado',
          };
        ?>
        <div class="proy-card">
          <div class="proy-card-top">
            <div class="proy-ico"><?= htmlspecialchars($pr['icono'] ?? '🚀') ?></div>
            <div>
              <div class="proy-title"><?= htmlspecialchars($pr['titulo']) ?></div>
              <div class="proy-rol"><?= htmlspecialchars($pr['rol_proyecto'] ?? 'Colaborador') ?></div>
            </div>
          </div>
          <span class="proy-estado <?= $est_cls ?>"><?= $est_lbl ?></span>
          <div class="proy-bar" style="margin-top:8px;">
            <div class="proy-fill" style="width:<?= (int)($pr['progreso'] ?? 0) ?>%"></div>
          </div>
          <div style="font-size:.68rem;color:var(--dim);margin-top:4px;display:flex;justify-content:space-between;">
            <span><?= (int)($pr['progreso'] ?? 0) ?>% completado</span>
            <a href="proyecto.php?id=<?= (int)$pr['id'] ?>" style="color:var(--green);font-weight:600;">Ver →</a>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>


    <!-- ══ TAB: INFORMACIÓN ══════════════════════════════════════ -->
    <div class="ptab-content" id="tab-info">
      <div class="sec-title"><span><span class="sec-title-dot"></span>Datos del perfil</span></div>

      <div class="info-grid">

        <!-- Datos siempre públicos -->
        <div class="info-item">
          <div class="info-lbl">Nombre completo</div>
          <div class="info-val"><?= $nombre_completo ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Username</div>
          <div class="info-val">@<?= htmlspecialchars($user['username'] ?? '—') ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Ocupación</div>
          <div class="info-val"><?= htmlspecialchars($user['ocupacion'] ?? '—') ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Institución</div>
          <div class="info-val"><?= htmlspecialchars($user['institucion'] ?? '—') ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">País</div>
          <div class="info-val"><?= htmlspecialchars($user['pais'] ?? '—') ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Ciudad</div>
          <div class="info-val"><?= htmlspecialchars($user['ciudad'] ?? '—') ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Nivel educativo</div>
          <div class="info-val"><?= htmlspecialchars(ucfirst($user['nivel_educativo'] ?? '—')) ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Rol en VIROX</div>
          <div class="info-val"><?= htmlspecialchars(ucfirst($user['rol'] ?? '—')) ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Miembro desde</div>
          <div class="info-val"><?= !empty($user['fecha_registro']) ? date('d M Y', strtotime($user['fecha_registro'])) : '—' ?></div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Último acceso</div>
          <div class="info-val">
            <?php if ($puede_editar && !empty($user['ultimo_acceso'])): ?>
              <?= date('d M Y H:i', strtotime($user['ultimo_acceso'])) ?>
            <?php else: ?>
              <span class="info-private"><i class="fa fa-lock" style="margin-right:4px;font-size:.75rem;"></i>Privado</span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Datos sensibles: solo para el dueño/admin -->
        <div class="info-item">
          <div class="info-lbl">Correo electrónico</div>
          <div class="info-val">
            <?php if ($puede_editar): ?>
              <?= htmlspecialchars($user['correo'] ?? '—') ?>
            <?php else: ?>
              <span class="info-private"><i class="fa fa-lock" style="margin-right:4px;font-size:.75rem;"></i>Privado</span>
            <?php endif; ?>
          </div>
        </div>
        <div class="info-item">
          <div class="info-lbl">Teléfono</div>
          <div class="info-val">
            <?php if ($puede_editar): ?>
              <?= htmlspecialchars($user['telefono'] ?? '—') ?>
            <?php else: ?>
              <span class="info-private"><i class="fa fa-lock" style="margin-right:4px;font-size:.75rem;"></i>Privado</span>
            <?php endif; ?>
          </div>
        </div>

      </div>

      <?php if (!$puede_editar && $visitor_id === 0): ?>
      <div class="private-notice" style="margin-top:16px;">
        <i class="fa fa-circle-info" style="flex-shrink:0;"></i>
        <span>Algunos datos son privados. <a href="login.php" style="color:var(--gold);font-weight:700;">Inicia sesión</a> para ver más información.</span>
      </div>
      <?php endif; ?>

      <!-- Redes sociales -->
      <?php if (!empty($redes)): ?>
      <div class="sec-title" style="margin-top:24px;"><span><span class="sec-title-dot"></span>Redes y contacto</span></div>
      <div class="social-row">
        <?php foreach ($redes as [$ico, $url, $clr, $lbl]): ?>
        <a href="<?= htmlspecialchars($url) ?>" target="_blank" class="soc-link">
          <i class="<?= $ico ?>" style="color:<?= $clr ?>;"></i> <?= $lbl ?>
        </a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

    </div>


    <!-- ══ TAB: HABILIDADES ══════════════════════════════════════ -->
    <?php if (!empty($habilidades)): ?>
    <div class="ptab-content" id="tab-habilidades">
      <div class="sec-title"><span><span class="sec-title-dot"></span>Habilidades técnicas</span></div>
      <div class="skills-wrap" style="margin-bottom:24px;">
        <?php foreach ($habilidades as $sk): ?>
        <span class="skill-tag"><?= htmlspecialchars($sk) ?></span>
        <?php endforeach; ?>
      </div>

      <?php if (!empty($user['certificaciones'])): ?>
      <div class="sec-title"><span><span class="sec-title-dot"></span>Certificaciones</span></div>
      <div class="bio-card">
        <p class="bio-txt"><?= nl2br(htmlspecialchars($user['certificaciones'])) ?></p>
      </div>
      <?php endif; ?>

      <?php if (!empty($intereses)): ?>
      <div class="sec-title"><span><span class="sec-title-dot"></span>Áreas de interés</span></div>
      <div class="tags">
        <?php foreach ($intereses as $int): if (!$int) continue; ?>
        <span class="tag"><?= htmlspecialchars($int) ?></span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; ?>


    <!-- ══ TAB: CURSOS (solo para dueño/admin) ══════════════════ -->
    <?php if ($puede_editar): ?>
    <div class="ptab-content" id="tab-cursos">
      <div class="sec-title"><span><span class="sec-title-dot"></span>Cursos inscritos</span></div>

      <?php if (empty($cursos_rec)): ?>
      <div style="text-align:center;padding:60px 24px;background:var(--n700);border-radius:var(--r-lg);border:1px dashed rgba(255,255,255,.08);">
        <div style="font-size:3rem;margin-bottom:12px;opacity:.3;">📚</div>
        <p style="color:var(--muted);">Sin cursos inscritos aún.</p>
        <a href="AD.php" style="color:var(--gold);font-weight:700;display:inline-block;margin-top:10px;">Explorar cursos →</a>
      </div>
      <?php else: ?>
      <div class="cursos-grid">
        <?php foreach ($cursos_rec as $cr): $prog = (int)($cr['progreso'] ?? 0); ?>
        <div class="curso-card">
          <div class="curso-img">📖</div>
          <div class="curso-body">
            <div class="curso-title"><?= htmlspecialchars($cr['titulo']) ?></div>
            <div class="curso-prog"><div class="curso-prog-fill" style="width:<?= $prog ?>%"></div></div>
            <div class="curso-pct"><?= $prog ?>% <?= $cr['completado'] ? '— Completado ✅' : '' ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>


    <!-- ══ TAB: ACTIVIDAD (solo para dueño/admin) ══════════════ -->
    <div class="ptab-content" id="tab-actividad">
      <div class="sec-title"><span><span class="sec-title-dot"></span>Actividad reciente</span></div>
      <?php if (empty($actividad)): ?>
      <div style="text-align:center;padding:60px 24px;background:var(--n700);border-radius:var(--r-lg);">
        <div style="font-size:3rem;margin-bottom:12px;opacity:.3;">⏱</div>
        <p style="color:var(--muted);">Sin actividad registrada.</p>
      </div>
      <?php else: ?>
      <div class="act-list">
        <?php foreach ($actividad as $a):
          $ico_tipo = match($a['tipo'] ?? ''){
            'login'       => '🔑', 'perfil' => '✏️', 'proyecto' => '🚀',
            'curso'       => '🎓', 'pago'   => '💰', 'sesion'   => '🔓',
            'vista_perfil'=> '👁', default  => '📌'
          };
        ?>
        <div class="act-item">
          <div class="act-ico"><?= $ico_tipo ?></div>
          <div class="act-desc"><?= htmlspecialchars($a['descripcion'] ?? $a['tipo']) ?></div>
          <div class="act-date">
            <?php
              $diff = time() - strtotime($a['fecha']);
              if ($diff < 60)        echo 'hace '.$diff.'s';
              elseif ($diff < 3600)  echo 'hace '.round($diff/60).'m';
              elseif ($diff < 86400) echo 'hace '.round($diff/3600).'h';
              else                   echo date('d M', strtotime($a['fecha']));
            ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <?php endif; // $puede_editar ?>

  </main>
</div><!-- /prof-layout -->


<!-- ══ MODAL CONTACTAR ══ -->
<?php if ($visitor_id > 0 && !$es_dueno): ?>
<div class="modal" id="contactModal">
  <div class="modal-box">
    <div class="mhd">
      <h3><i class="fa fa-envelope" style="color:var(--green);margin-right:8px;"></i>
          Contactar a <?= htmlspecialchars($user['nombre'] ?? '') ?>
      </h3>
      <button class="mcls" onclick="closeModal()"><i class="fa fa-times"></i></button>
    </div>
    <div class="mbody">
      <input class="minput" type="text" id="cmAsunto" placeholder="Asunto del mensaje">
      <textarea class="minput mtarea" id="cmMensaje" placeholder="Escribe tu mensaje aquí..."></textarea>
      <div style="font-size:.72rem;color:var(--dim);display:flex;align-items:center;gap:6px;">
        <i class="fa fa-circle-info"></i>
        El mensaje se enviará a través del sistema interno de VIROX.
      </div>
    </div>
    <div class="mfoot">
      <button class="psb-btn psb-btn-ghost" style="padding:9px 18px;" onclick="closeModal()">Cancelar</button>
      <button class="psb-btn psb-btn-primary" style="padding:9px 18px;" onclick="sendMsg()">
        <i class="fa fa-paper-plane"></i> Enviar
      </button>
    </div>
  </div>
</div>
<?php endif; ?>


<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand"><span class="brand-hex">⬡</span><span class="brand-name">VIROX</span></div>
    <p class="footer-copy">© 2025 Team VIROX</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="equipo.php">Equipo</a>
      <a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>


<script>
/* ── Header scroll ── */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));

/* ── Burger ── */
document.getElementById('burger').addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Dropdown usuario ── */
function toggleDrop(btn) {
  const d = document.getElementById('userDrop');
  if (!d) return;
  d.classList.toggle('open');
}
document.addEventListener('click', e => {
  if (!e.target.closest('.user-wrap'))
    document.getElementById('userDrop')?.classList.remove('open');
});

/* ── Tabs ── */
function showTab(id, el) {
  document.querySelectorAll('.ptab-content').forEach(t => t.classList.remove('on'));
  document.querySelectorAll('.ptab').forEach(t => t.classList.remove('on'));
  const tab = document.getElementById('tab-' + id);
  if (tab) tab.classList.add('on');
  if (el) el.classList.add('on');
}

/* ── Animaciones de entrada ── */
// Barra de nivel
document.querySelectorAll('.psb-lvl-fill[data-w]').forEach(el => {
  setTimeout(() => el.style.width = el.dataset.w + '%', 400);
});

/* ── Modal contactar ── */
function openContactModal() {
  document.getElementById('contactModal')?.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal() {
  document.getElementById('contactModal')?.classList.remove('open');
  document.body.style.overflow = '';
}
document.getElementById('contactModal')?.addEventListener('click', e => {
  if (e.target === document.getElementById('contactModal')) closeModal();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

function sendMsg() {
  const asunto  = document.getElementById('cmAsunto')?.value.trim();
  const mensaje = document.getElementById('cmMensaje')?.value.trim();
  if (!asunto || !mensaje) {
    alert('Por favor completa el asunto y el mensaje.');
    return;
  }
  fetch('api/enviar_mensaje.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      destinatario_id: <?= $perfil_id ?>,
      asunto,
      mensaje
    })
  })
  .then(r => r.json())
  .then(d => {
    closeModal();
    alert(d.ok ? '✅ Mensaje enviado correctamente.' : '❌ Error: ' + (d.error || 'intenta de nuevo'));
  })
  .catch(() => {
    closeModal();
    alert('✅ Mensaje enviado.');
  });
}
</script>
</body>
</html>