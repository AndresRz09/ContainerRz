<?php
/**
 * IA.php — Asistente Multi-IA ContainerRZ
 * ══════════════════════════════════════════════════════════════════
 * Proveedores: Claude (Anthropic) · Gemini (Google) · GPT (OpenAI)
 * Las API keys están en config.php (nunca en este archivo)
 * ══════════════════════════════════════════════════════════════════
 */
include 'conexion.php';
session_start();

$usuario_nombre = $_SESSION['user_name'] ?? 'Visitante';
$usuario_rol    = $_SESSION['rol']       ?? 'cliente';
$usuario_id     = (int)($_SESSION['user_id'] ?? 0);
$avatar         = $_SESSION['avatar']    ?? 'assets/avatar-default.png';

// ── Historial desde BD ────────────────────────────────────────────
$historial = [];
if ($usuario_id && isset($conexion)) {
    $qh = $conexion->prepare(
        "SELECT id, titulo, herramienta, fecha
         FROM ia_conversaciones
         WHERE usuario_id = ?
         ORDER BY fecha DESC LIMIT 20"
    );
    if ($qh) {
        $qh->bind_param("i", $usuario_id);
        $qh->execute();
        $rh = $qh->get_result();
        while ($row = $rh->fetch_assoc()) $historial[] = $row;
        $qh->close();
    }
}

// ── Definición de agentes ─────────────────────────────────────────
$herramientas = [
    ['id'=>'asistente',  'ico'=>'🤖','titulo'=>'Asistente General',      'desc'=>'Resuelve dudas, explica conceptos y responde preguntas.',          'color'=>'green',  'provider'=>'claude'],
    ['id'=>'ciberseg',   'ico'=>'🛡', 'titulo'=>'Ciberseguridad',          'desc'=>'Vulnerabilidades, amenazas, hacking ético y defensas.',            'color'=>'red',    'provider'=>'claude'],
    ['id'=>'codigo',     'ico'=>'💻','titulo'=>'Asistente de Código',      'desc'=>'Genera, revisa, depura y optimiza código en múltiples lenguajes.', 'color'=>'blue',   'provider'=>'claude'],
    ['id'=>'aprendizaje','ico'=>'🎓','titulo'=>'Tutor de Aprendizaje',     'desc'=>'Rutas de estudio, quizzes y explicaciones personalizadas.',         'color'=>'purple', 'provider'=>'claude'],
    ['id'=>'analisis',   'ico'=>'📊','titulo'=>'Análisis de Datos',        'desc'=>'Interpreta datos, genera insights y sugiere visualizaciones.',      'color'=>'gold',   'provider'=>'gemini'],
    ['id'=>'proyectos',  'ico'=>'🚀','titulo'=>'Gestor de Proyectos',      'desc'=>'Planifica sprints, KPIs, tareas y metodologías ágiles.',            'color'=>'teal',   'provider'=>'claude'],
    ['id'=>'redaccion',  'ico'=>'✍️','titulo'=>'Redacción & Contenido',    'desc'=>'Documentación técnica, artículos, reportes y presentaciones.',      'color'=>'pink',   'provider'=>'openai'],
    ['id'=>'redes',      'ico'=>'🌐','titulo'=>'Redes & Infraestructura',  'desc'=>'Servidores, diagnóstico de red, VPNs y arquitectura cloud.',        'color'=>'orange', 'provider'=>'claude'],
    ['id'=>'ia_explica', 'ico'=>'🧠','titulo'=>'IA & Machine Learning',   'desc'=>'Algoritmos, modelos y aplicaciones prácticas de IA/ML.',            'color'=>'indigo', 'provider'=>'gemini'],
    ['id'=>'optimizador','ico'=>'⚡','titulo'=>'Optimizador de Sistemas',  'desc'=>'Rendimiento, cuellos de botella y mejoras en código y DB.',         'color'=>'yellow', 'provider'=>'claude'],
];

// Mapa color → CSS
$colorMap = [
    'green'  => ['bg'=>'rgba(40,166,128,.14)',  'bd'=>'rgba(40,166,128,.4)',  'tx'=>'#35d4a8'],
    'red'    => ['bg'=>'rgba(239,68,68,.12)',   'bd'=>'rgba(239,68,68,.35)',  'tx'=>'#fca5a5'],
    'blue'   => ['bg'=>'rgba(59,130,246,.12)',  'bd'=>'rgba(59,130,246,.35)', 'tx'=>'#93c5fd'],
    'purple' => ['bg'=>'rgba(139,92,246,.12)',  'bd'=>'rgba(139,92,246,.35)','tx'=>'#c4b5fd'],
    'gold'   => ['bg'=>'rgba(218,165,32,.14)',  'bd'=>'rgba(218,165,32,.4)',  'tx'=>'#f0c840'],
    'teal'   => ['bg'=>'rgba(20,184,166,.12)',  'bd'=>'rgba(20,184,166,.35)','tx'=>'#5eead4'],
    'pink'   => ['bg'=>'rgba(236,72,153,.12)',  'bd'=>'rgba(236,72,153,.35)','tx'=>'#f9a8d4'],
    'orange' => ['bg'=>'rgba(249,115,22,.12)',  'bd'=>'rgba(249,115,22,.35)','tx'=>'#fdba74'],
    'indigo' => ['bg'=>'rgba(99,102,241,.12)',  'bd'=>'rgba(99,102,241,.35)','tx'=>'#a5b4fc'],
    'yellow' => ['bg'=>'rgba(234,179,8,.12)',   'bd'=>'rgba(234,179,8,.35)', 'tx'=>'#fde047'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ContainerRZ · IA Multi-Proveedor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
/* ═══ VARIABLES ══════════════════════════════════════════════════ */
:root{
  --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
  --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
  --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
  --red:#ef4444;--txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
  --r-sm:8px;--r-md:14px;--r-lg:22px;
  --font:'Syne',sans-serif;--hh:64px;--sb:272px;--rp:270px;
}
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased}
html{scroll-behavior:smooth}
body{font-family:var(--font);background:var(--n900);color:var(--txt);height:100vh;display:flex;flex-direction:column;overflow:hidden}
::-webkit-scrollbar{width:4px}::-webkit-scrollbar-track{background:var(--n800)}::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px}
a{text-decoration:none;color:inherit}button{cursor:pointer;border:none;font-family:var(--font)}

/* ═══ HEADER ═════════════════════════════════════════════════════ */
.ia-hdr{
  height:var(--hh);flex-shrink:0;
  background:rgba(2,8,23,.95);backdrop-filter:blur(20px);
  border-bottom:1px solid rgba(40,166,128,.2);
  display:flex;align-items:center;justify-content:space-between;padding:0 20px;z-index:200;
}
.hdr-l{display:flex;align-items:center;gap:12px}
.hdr-brand{display:flex;align-items:center;gap:8px}
.hdr-brand-hex{font-size:1.3rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green))}
.hdr-brand-name{font-size:1.15rem;font-weight:900;color:var(--gold);letter-spacing:4px}
.hdr-sep{width:1px;height:22px;background:rgba(255,255,255,.1)}
.hdr-badge{
  display:flex;align-items:center;gap:7px;padding:4px 12px;border-radius:99px;
  background:var(--green-dim);border:1px solid rgba(40,166,128,.35);
  font-size:.75rem;font-weight:700;color:var(--green-lt);letter-spacing:.5px;
}
.pulse{width:7px;height:7px;background:var(--green);border-radius:50%;animation:pdot 1.8s ease-in-out infinite}
@keyframes pdot{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}}

/* Provider badge */
.provider-badge{
  display:flex;align-items:center;gap:6px;padding:4px 12px;border-radius:99px;
  font-size:.72rem;font-weight:700;letter-spacing:.5px;border:1px solid transparent;
  transition:all .3s;
}
.provider-badge.claude {background:rgba(255,136,0,.12);border-color:rgba(255,136,0,.3);color:#ffb347}
.provider-badge.gemini {background:rgba(66,133,244,.12);border-color:rgba(66,133,244,.3);color:#7ab3f7}
.provider-badge.openai {background:rgba(16,163,127,.12);border-color:rgba(16,163,127,.3);color:#4ecca5}

.hdr-r{display:flex;align-items:center;gap:8px}
.hdr-btn{
  display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:var(--r-md);
  background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
  color:var(--muted);font-size:.78rem;font-weight:600;transition:all .2s;
}
.hdr-btn:hover{background:rgba(255,255,255,.1);color:var(--txt)}
.hdr-av{width:30px;height:30px;border-radius:50%;object-fit:cover;border:2px solid var(--green)}

/* ═══ LAYOUT ═════════════════════════════════════════════════════ */
.ia-layout{display:grid;grid-template-columns:var(--sb) 1fr var(--rp);flex:1;overflow:hidden}

/* ═══ SIDEBAR IZQUIERDO ══════════════════════════════════════════ */
.ia-sb{background:var(--n800);border-right:1px solid rgba(255,255,255,.05);display:flex;flex-direction:column;overflow:hidden}
.sb-hd{padding:14px 16px 10px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0}
.sb-hd-lbl{font-size:.68rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:8px}
.sb-search{display:flex;align-items:center;gap:7px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-md);padding:7px 10px}
.sb-search i{color:var(--muted);font-size:.75rem;flex-shrink:0}
.sb-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font);font-size:.78rem;width:100%}
.sb-search input::placeholder{color:var(--dim)}

.sb-body{overflow-y:auto;flex:1;padding:8px 8px}
.sb-sec{font-size:.6rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 6px 4px;display:flex;align-items:center;gap:6px}
.sb-sec::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.05)}

/* Tool item */
.tool-item{display:flex;align-items:center;gap:9px;padding:8px 9px;border-radius:var(--r-md);cursor:pointer;transition:all .2s;margin-bottom:2px;border:1px solid transparent}
.tool-item:hover{background:rgba(255,255,255,.05)}
.tool-item.active{background:var(--green-dim);border-color:rgba(40,166,128,.3)}
.ti-ico{width:30px;height:30px;border-radius:var(--r-sm);display:flex;align-items:center;justify-content:center;font-size:.95rem;flex-shrink:0;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.08);transition:all .2s}
.tool-item.active .ti-ico{background:var(--green-dim);border-color:rgba(40,166,128,.3)}
.ti-info{flex:1;min-width:0}
.ti-name{font-size:.8rem;font-weight:700;color:var(--txt);margin-bottom:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.tool-item.active .ti-name{color:var(--green-lt)}
.ti-prov{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.5px}

/* Historial */
.hist-item{display:flex;align-items:center;gap:8px;padding:7px 9px;border-radius:var(--r-md);cursor:pointer;transition:all .2s;margin-bottom:2px}
.hist-item:hover{background:rgba(255,255,255,.05)}
.hist-item i{font-size:.7rem;color:var(--dim);flex-shrink:0}
.hist-txt{flex:1;min-width:0}
.hist-title{font-size:.76rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.hist-date{font-size:.62rem;color:var(--dim)}
.hist-del{width:18px;height:18px;border-radius:50%;background:none;color:var(--dim);font-size:.6rem;display:none;align-items:center;justify-content:center;transition:all .2s}
.hist-item:hover .hist-del{display:flex}
.hist-del:hover{background:rgba(239,68,68,.2);color:#f87171}

.sb-foot{padding:10px 12px;border-top:1px solid rgba(255,255,255,.05);flex-shrink:0}
.new-chat-btn{display:flex;align-items:center;justify-content:center;gap:7px;width:100%;padding:9px;background:linear-gradient(135deg,var(--green),#1d8f6e);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.8rem;transition:all .2s;box-shadow:0 3px 12px rgba(40,166,128,.3)}
.new-chat-btn:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(40,166,128,.4)}

/* ═══ PANEL CENTRAL — CHAT ════════════════════════════════════════ */
.ia-chat{display:flex;flex-direction:column;overflow:hidden;position:relative}

.tool-hdr{padding:12px 20px;border-bottom:1px solid rgba(255,255,255,.06);background:rgba(12,21,38,.8);flex-shrink:0;display:flex;align-items:center;gap:12px}
.th-ico{width:38px;height:38px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.15rem;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);flex-shrink:0}
.th-info strong{display:block;font-size:.9rem;font-weight:700;margin-bottom:1px}
.th-info span{font-size:.72rem;color:var(--muted)}
.th-right{margin-left:auto;display:flex;align-items:center;gap:6px}
.th-btn{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.72rem;display:flex;align-items:center;justify-content:center;transition:all .2s}
.th-btn:hover{background:var(--green-dim);color:var(--green-lt);border-color:var(--green)}

/* Mensajes */
.chat-msgs{flex:1;overflow-y:auto;padding:20px;scroll-behavior:smooth;background:radial-gradient(ellipse 60% 40% at 50% 0%,rgba(40,166,128,.04) 0%,transparent 60%),var(--n900)}

/* Pantalla de bienvenida */
.chat-welcome{display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%;text-align:center;padding:28px}
.cw-orb{position:relative;width:90px;height:90px;display:flex;align-items:center;justify-content:center;margin-bottom:20px}
.cw-ring{position:absolute;border-radius:50%;border:1.5px solid rgba(40,166,128,.25);animation:spin 10s linear infinite}
.cw-ring:nth-child(2){inset:12px;animation-duration:7s;animation-direction:reverse}
.cw-ring:nth-child(3){inset:24px;animation-duration:4s}
@keyframes spin{to{transform:rotate(360deg)}}
.cw-ico{font-size:2.4rem;position:relative;z-index:1}
.cw-title{font-size:1.3rem;font-weight:800;margin-bottom:6px}
.cw-sub{font-size:.84rem;color:var(--muted);line-height:1.7;max-width:460px;margin-bottom:22px}
.cw-cards{display:grid;grid-template-columns:1fr 1fr;gap:8px;width:100%;max-width:480px}
.cw-card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-md);padding:12px 14px;text-align:left;cursor:pointer;transition:all .2s}
.cw-card:hover{background:var(--green-dim);border-color:rgba(40,166,128,.3)}
.cw-card-ico{font-size:1.1rem;margin-bottom:5px}
.cw-card-txt{font-size:.77rem;color:var(--muted);line-height:1.4}
.cw-card:hover .cw-card-txt{color:var(--green-lt)}

/* Burbujas */
.msg{display:flex;gap:9px;margin-bottom:16px;animation:msgIn .3s ease both}
@keyframes msgIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.msg.user{flex-direction:row-reverse}
.msg-av{width:30px;height:30px;border-radius:50%;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:.8rem;overflow:hidden}
.msg-av img{width:100%;height:100%;object-fit:cover}
.ai-av{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt)}
.user-av{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3)}
.msg-bubble{max-width:72%;padding:11px 15px;border-radius:var(--r-lg);font-size:.865rem;line-height:1.7}
.msg.ai  .msg-bubble{background:var(--n600);border:1px solid rgba(255,255,255,.07);border-radius:4px var(--r-lg) var(--r-lg) var(--r-lg);color:var(--txt)}
.msg.user .msg-bubble{background:linear-gradient(135deg,var(--green),#1d8f6e);border-radius:var(--r-lg) 4px var(--r-lg) var(--r-lg);color:#fff}
.msg-meta{display:flex;align-items:center;gap:6px;margin-top:3px}
.msg-time{font-size:.6rem;color:var(--dim)}
.msg-prov{font-size:.6rem;padding:1px 6px;border-radius:99px;font-weight:700}
.msg-prov.claude{background:rgba(255,136,0,.15);color:#ffb347}
.msg-prov.gemini{background:rgba(66,133,244,.15);color:#7ab3f7}
.msg-prov.openai{background:rgba(16,163,127,.15);color:#4ecca5}
.msg-actions{display:flex;gap:4px;margin-top:4px;opacity:0;transition:opacity .2s}
.msg:hover .msg-actions{opacity:1}
.msg-act{width:22px;height:22px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--dim);font-size:.62rem;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s}
.msg-act:hover{background:var(--green-dim);color:var(--green-lt);border-color:var(--green)}

/* Código */
.msg-bubble pre{background:rgba(0,0,0,.45);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-sm);padding:10px;margin:7px 0;overflow-x:auto;font-size:.76rem;line-height:1.5;font-family:monospace}
.msg-bubble code{font-family:monospace;font-size:.8rem}
.msg-bubble p{margin-bottom:5px}.msg-bubble p:last-child{margin-bottom:0}
.msg-bubble ul,.msg-bubble ol{margin:5px 0 5px 16px}.msg-bubble li{margin-bottom:2px}
.msg-bubble strong{font-weight:700}
.msg-bubble h3,.msg-bubble h4{font-weight:700;margin:7px 0 3px;color:var(--green-lt)}

/* Typing */
.typing{display:none;gap:9px;align-items:center;margin-bottom:16px}
.typing.show{display:flex}
.typing-dots{display:flex;gap:4px;padding:9px 13px;background:var(--n600);border-radius:var(--r-lg);border:1px solid rgba(255,255,255,.07)}
.typing-dot{width:5px;height:5px;background:var(--muted);border-radius:50%;animation:tdot .8s ease-in-out infinite}
.typing-dot:nth-child(2){animation-delay:.2s}.typing-dot:nth-child(3){animation-delay:.4s}
@keyframes tdot{0%,80%,100%{transform:scale(.7);opacity:.4}40%{transform:scale(1);opacity:1}}

/* Bottom */
.chat-bottom{flex-shrink:0;border-top:1px solid rgba(255,255,255,.06)}
.sugg-bar{display:flex;gap:6px;padding:8px 18px;overflow-x:auto;flex-wrap:nowrap;background:rgba(12,21,38,.5);border-bottom:1px solid rgba(255,255,255,.04)}
.sugg-bar::-webkit-scrollbar{height:2px}
.sugg-chip{display:flex;align-items:center;gap:5px;padding:4px 12px;border-radius:99px;white-space:nowrap;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.72rem;font-weight:600;cursor:pointer;transition:all .2s;flex-shrink:0;font-family:var(--font)}
.sugg-chip:hover{background:var(--green-dim);border-color:rgba(40,166,128,.4);color:var(--green-lt)}

.chat-input-area{padding:12px 18px}
.input-box{display:flex;align-items:flex-end;gap:9px;background:var(--n600);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-lg);padding:9px 13px;transition:border-color .2s,box-shadow .2s}
.input-box:focus-within{border-color:var(--green);box-shadow:0 0 0 3px rgba(40,166,128,.1)}
.input-tools{display:flex;gap:4px;align-items:center;flex-shrink:0}
.inp-tool{width:26px;height:26px;border-radius:var(--r-sm);background:none;border:none;color:var(--dim);font-size:.76rem;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s}
.inp-tool:hover{background:rgba(255,255,255,.08);color:var(--muted)}
#chatInput{flex:1;background:none;border:none;outline:none;color:var(--txt);font-family:var(--font);font-size:.86rem;line-height:1.6;resize:none;max-height:120px;min-height:21px}
#chatInput::placeholder{color:var(--dim)}
.input-right{display:flex;align-items:center;gap:5px;flex-shrink:0}
.char-c{font-size:.62rem;color:var(--dim)}
.send-btn{width:34px;height:34px;border-radius:50%;background:var(--green);color:#fff;font-size:.82rem;display:flex;align-items:center;justify-content:center;transition:all .2s;box-shadow:0 2px 10px rgba(40,166,128,.3)}
.send-btn:hover{background:var(--green-lt);transform:scale(1.08)}
.send-btn:disabled{background:rgba(255,255,255,.1);color:var(--dim);transform:none;box-shadow:none;cursor:not-allowed}
.input-hint{display:flex;align-items:center;justify-content:space-between;padding:3px 2px 0;font-size:.62rem;color:var(--dim)}

/* Provider selector */
.provider-sel{display:flex;align-items:center;gap:4px;flex-shrink:0}
.prov-btn{padding:3px 9px;border-radius:99px;font-size:.68rem;font-weight:700;cursor:pointer;transition:all .2s;border:1px solid rgba(255,255,255,.1);background:none;color:var(--dim);font-family:var(--font)}
.prov-btn:hover{background:rgba(255,255,255,.08);color:var(--muted)}
.prov-btn.selected-claude{background:rgba(255,136,0,.15);border-color:rgba(255,136,0,.4);color:#ffb347}
.prov-btn.selected-gemini{background:rgba(66,133,244,.15);border-color:rgba(66,133,244,.4);color:#7ab3f7}
.prov-btn.selected-openai{background:rgba(16,163,127,.15);border-color:rgba(16,163,127,.4);color:#4ecca5}

/* ═══ PANEL DERECHO ══════════════════════════════════════════════ */
.ia-rp{background:var(--n800);border-left:1px solid rgba(255,255,255,.05);display:flex;flex-direction:column;overflow:hidden}
.rp-hd{padding:13px 15px 10px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0}
.rp-hd-lbl{font-size:.68rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px}
.rp-body{overflow-y:auto;flex:1;padding:10px 13px}
.rp-sec{font-size:.6rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 0 5px;border-bottom:1px solid rgba(255,255,255,.05);margin-bottom:7px}

.tool-detail-card{border-radius:var(--r-lg);padding:14px;margin-bottom:14px;border:1px solid rgba(40,166,128,.3);background:var(--green-dim)}
.td-ico{font-size:1.8rem;margin-bottom:6px}
.td-title{font-size:.88rem;font-weight:800;margin-bottom:3px}
.td-desc{font-size:.75rem;color:var(--muted);line-height:1.5}
.td-prov{display:inline-block;margin-top:6px;padding:2px 8px;border-radius:99px;font-size:.65rem;font-weight:700}

.cap-list{display:flex;flex-direction:column;gap:4px;margin-bottom:14px}
.cap-item{display:flex;align-items:center;gap:7px;padding:7px 9px;border-radius:var(--r-md);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);font-size:.76rem;color:var(--muted);cursor:pointer;transition:all .2s}
.cap-item:hover{background:var(--green-dim);color:var(--green-lt);border-color:rgba(40,166,128,.3)}

.qa-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:14px}
.qa-btn{display:flex;flex-direction:column;align-items:center;gap:4px;padding:10px 6px;border-radius:var(--r-md);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);font-size:.68rem;color:var(--muted);cursor:pointer;transition:all .2s;font-family:var(--font)}
.qa-btn:hover{background:var(--green-dim);color:var(--green-lt);border-color:rgba(40,166,128,.3)}
.qa-btn i{font-size:1rem}

.model-info{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);padding:11px 13px;margin-bottom:11px}
.mi-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}
.mi-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:.5px}
.mi-val{font-size:.72rem;color:var(--muted);font-weight:600}
.mi-badge{padding:2px 7px;border-radius:99px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);font-size:.62rem;color:var(--green-lt);font-weight:700}

.stats-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:12px}
.stat-card{background:rgba(255,255,255,.04);border-radius:var(--r-md);padding:9px;text-align:center}
.stat-n{font-size:1rem;font-weight:800;color:var(--gold)}
.stat-l{font-size:.58rem;color:var(--dim);text-transform:uppercase;letter-spacing:.5px;margin-top:1px}

.toggle-row{display:flex;align-items:center;justify-content:space-between;padding:4px 0}
.toggle-lbl{font-size:.76rem;color:var(--muted)}
.toggle{position:relative;width:34px;height:19px}
.toggle input{display:none}
.toggle-sl{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:.3s}
.toggle-sl::before{content:'';position:absolute;width:13px;height:13px;background:#fff;border-radius:50%;top:3px;left:3px;transition:.3s}
.toggle input:checked+.toggle-sl{background:var(--green)}
.toggle input:checked+.toggle-sl::before{transform:translateX(15px)}

/* ═══ RESPONSIVE ══════════════════════════════════════════════════ */
@media(max-width:1200px){.ia-layout{grid-template-columns:var(--sb) 1fr}.ia-rp{display:none}}
@media(max-width:820px){.ia-layout{grid-template-columns:1fr}.ia-sb{display:none}.ia-layout.sb-open .ia-sb{display:flex;position:fixed;left:0;top:var(--hh);bottom:0;z-index:500;width:var(--sb);box-shadow:4px 0 30px rgba(0,0,0,.5)}}
@media(max-width:480px){.hdr-brand-name{display:none}.cw-cards{grid-template-columns:1fr}}

/* ═══ NOTIFICACIÓN TOAST ═════════════════════════════════════════ */
.toast{position:fixed;bottom:20px;right:20px;padding:10px 18px;border-radius:var(--r-md);background:var(--n600);border:1px solid rgba(40,166,128,.4);color:var(--green-lt);font-size:.8rem;font-weight:600;z-index:9999;transform:translateY(60px);opacity:0;transition:all .3s;pointer-events:none}
.toast.show{transform:translateY(0);opacity:1}
</style>
</head>
<body>

<!-- ══ HEADER ═════════════════════════════════════════════════════ -->
<header class="ia-hdr">
  <div class="hdr-l">
    <a href="index.php" class="hdr-brand">
      <span class="hdr-brand-hex">⬡</span>
      <span class="hdr-brand-name">ContainerRZ</span>
    </a>
    <div class="hdr-sep"></div>
    <div class="hdr-badge"><div class="pulse"></div>IA Activa</div>
    <div class="provider-badge claude" id="globalProvBadge">🤖 Claude</div>
  </div>

  <div class="hdr-r">
    <button class="hdr-btn" onclick="toggleSidebar()" id="sbToggleBtn"><i class="fa fa-bars"></i></button>
    <button class="hdr-btn" onclick="exportChat()"><i class="fa fa-download"></i> Exportar</button>
    <button class="hdr-btn" onclick="clearChat()"><i class="fa fa-rotate-right"></i> Nueva</button>
    <a href="index.php" class="hdr-btn"><i class="fa fa-house"></i></a>
    <img src="<?= htmlspecialchars($avatar) ?>" class="hdr-av" alt="Avatar"
         onerror="this.src='assets/avatar-default.png'">
    <span style="font-size:.82rem;font-weight:600"><?= htmlspecialchars($usuario_nombre) ?></span>
  </div>
</header>


<!-- ══ LAYOUT ══════════════════════════════════════════════════════ -->
<div class="ia-layout" id="iaLayout">

  <!-- ─── SIDEBAR ──────────────────────────────────────────────── -->
  <aside class="ia-sb" id="iaSb">
    <div class="sb-hd">
      <div class="sb-hd-lbl">🔧 Funcionalidades</div>
      <div class="sb-search">
        <i class="fa fa-search"></i>
        <input type="text" id="toolSearch" placeholder="Buscar módulo...">
      </div>
    </div>

    <div class="sb-body" id="toolList">
      <div class="sb-sec">Módulos IA</div>
      <?php foreach ($herramientas as $tool):
        $clr = $colorMap[$tool['color']] ?? $colorMap['green'];
        $provLabel = strtoupper($tool['provider']);
      ?>
      <div class="tool-item <?= $tool['id'] === 'asistente' ? 'active' : '' ?>"
           onclick="selectTool(<?= htmlspecialchars(json_encode($tool), ENT_QUOTES) ?>, this)"
           data-id="<?= $tool['id'] ?>"
           data-search="<?= strtolower($tool['titulo']) ?>">
        <div class="ti-ico" style="background:<?= $clr['bg'] ?>;border-color:<?= $clr['bd'] ?>">
          <?= $tool['ico'] ?>
        </div>
        <div class="ti-info">
          <div class="ti-name"><?= htmlspecialchars($tool['titulo']) ?></div>
          <div class="ti-prov"><?= $provLabel ?></div>
        </div>
      </div>
      <?php endforeach; ?>

      <?php if (!empty($historial)): ?>
      <div class="sb-sec" style="margin-top:10px">Recientes</div>
      <?php foreach ($historial as $h): ?>
      <div class="hist-item">
        <i class="fa fa-clock-rotate-left"></i>
        <div class="hist-txt">
          <div class="hist-title"><?= htmlspecialchars($h['titulo']) ?></div>
          <div class="hist-date"><?= date('d M', strtotime($h['fecha'])) ?> · <?= $h['herramienta'] ?></div>
        </div>
        <button class="hist-del" onclick="deleteHistory(event,<?= $h['id'] ?>)"><i class="fa fa-xmark"></i></button>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="sb-foot">
      <button class="new-chat-btn" onclick="clearChat()"><i class="fa fa-plus"></i> Nueva conversación</button>
    </div>
  </aside>


  <!-- ─── PANEL CENTRAL ────────────────────────────────────────── -->
  <div class="ia-chat">

    <!-- Tool header -->
    <div class="tool-hdr">
      <div class="th-ico" id="thIco">🤖</div>
      <div class="th-info">
        <strong id="thTitle">Asistente General</strong>
        <span id="thDesc">Resuelve dudas, explica conceptos y responde preguntas.</span>
      </div>
      <div class="th-right">
        <!-- Selector de proveedor manual -->
        <div class="provider-sel">
          <button class="prov-btn selected-claude" onclick="setProvider('claude',this)" data-prov="claude">Claude</button>
          <button class="prov-btn" onclick="setProvider('gemini',this)" data-prov="gemini">Gemini</button>
          <button class="prov-btn" onclick="setProvider('openai',this)" data-prov="openai">GPT</button>
        </div>
        <button class="th-btn" onclick="toggleVoice()" id="voiceBtn" title="Voz"><i class="fa fa-microphone"></i></button>
        <button class="th-btn" onclick="copyLastMsg()" title="Copiar"><i class="fa fa-copy"></i></button>
        <button class="th-btn" onclick="clearChat()" title="Limpiar"><i class="fa fa-trash-can"></i></button>
      </div>
    </div>

    <!-- Mensajes -->
    <div class="chat-msgs" id="chatMsgs">
      <div class="chat-welcome" id="chatWelcome">
        <div class="cw-orb">
          <div class="cw-ring"></div><div class="cw-ring"></div><div class="cw-ring"></div>
          <span class="cw-ico">🤖</span>
        </div>
        <h2 class="cw-title">ContainerRZ IA activa</h2>
        <p class="cw-sub">Potenciado por Claude, Gemini y GPT. Elige tu módulo y empieza.</p>
        <div class="cw-cards">
          <div class="cw-card" onclick="sendQuick('¿Qué puedes hacer exactamente?')"><div class="cw-card-ico">💡</div><div class="cw-card-txt">¿Qué puedes hacer?</div></div>
          <div class="cw-card" onclick="sendQuick('Explícame qué es el ethical hacking')"><div class="cw-card-ico">🛡</div><div class="cw-card-txt">¿Qué es el ethical hacking?</div></div>
          <div class="cw-card" onclick="sendQuick('Crea un script Python para escanear puertos')"><div class="cw-card-ico">💻</div><div class="cw-card-txt">Script Python escaneo de puertos</div></div>
          <div class="cw-card" onclick="sendQuick('Dame una ruta de aprendizaje en ciberseguridad')"><div class="cw-card-ico">🎓</div><div class="cw-card-txt">Ruta de aprendizaje ciberseguridad</div></div>
        </div>
      </div>
    </div>

    <!-- Typing -->
    <div class="typing" id="typingInd">
      <div class="msg-av ai-av"><i class="fa fa-robot"></i></div>
      <div class="typing-dots"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>
    </div>

    <!-- Bottom -->
    <div class="chat-bottom">
      <div class="sugg-bar" id="suggBar"></div>
      <div class="chat-input-area">
        <div class="input-box">
          <div class="input-tools">
            <button class="inp-tool" onclick="insertCode()" title="Insertar código"><i class="fa fa-code"></i></button>
            <button class="inp-tool" id="voiceInputBtn" onclick="toggleVoiceInput()" title="Voz"><i class="fa fa-microphone"></i></button>
          </div>
          <textarea id="chatInput" rows="1" maxlength="4000"
            placeholder="Escribe aquí... (Enter envía, Shift+Enter nueva línea)"
            onkeydown="handleKey(event)"
            oninput="autoResize(this);updateCount()"></textarea>
          <div class="input-right">
            <span class="char-c" id="charCount">0/4000</span>
            <button class="send-btn" id="sendBtn" onclick="sendMessage()"><i class="fa fa-paper-plane"></i></button>
          </div>
        </div>
        <div class="input-hint">
          <span>Enter envía · Ctrl+K nueva · Ctrl+E exportar</span>
          <span id="modelInfo" style="color:var(--green-lt);font-weight:700">claude-sonnet-4 · ContainerRZ IA</span>
        </div>
      </div>
    </div>

  </div><!-- /ia-chat -->


  <!-- ─── PANEL DERECHO ─────────────────────────────────────────── -->
  <div class="ia-rp">
    <div class="rp-hd"><div class="rp-hd-lbl">🛠 Panel de Control</div></div>
    <div class="rp-body">

      <!-- Detalle herramienta -->
      <div class="tool-detail-card" id="rpDetail">
        <div class="td-ico">🤖</div>
        <div class="td-title">Asistente General</div>
        <div class="td-desc">Resuelve dudas, explica conceptos y responde preguntas.</div>
        <span class="td-prov claude" style="background:rgba(255,136,0,.15);color:#ffb347;border:1px solid rgba(255,136,0,.3)">Claude</span>
      </div>

      <!-- Acciones rápidas -->
      <div class="rp-sec">Acciones Rápidas</div>
      <div class="cap-list">
        <div class="cap-item" onclick="sendQuick('Explica con ejemplos prácticos y detallados')">💡 Explicar con ejemplos</div>
        <div class="cap-item" onclick="sendQuick('Dame un resumen conciso de los puntos clave')">📋 Resumir puntos clave</div>
        <div class="cap-item" onclick="sendQuick('Genera un quiz de 5 preguntas sobre este tema')">🧩 Generar quiz</div>
        <div class="cap-item" onclick="sendQuick('Crea un plan de acción paso a paso detallado')">🗺 Plan de acción</div>
        <div class="cap-item" onclick="sendQuick('Dame fuentes y recursos adicionales para aprender')">📚 Recursos de estudio</div>
      </div>

      <div class="rp-sec">Herramientas</div>
      <div class="qa-grid">
        <button class="qa-btn" onclick="sendQuick('Analiza y detecta vulnerabilidades en esto')"><i class="fa fa-shield-halved"></i>Analizar</button>
        <button class="qa-btn" onclick="sendQuick('Optimiza este código o proceso al máximo')"><i class="fa fa-bolt"></i>Optimizar</button>
        <button class="qa-btn" onclick="sendQuick('Genera documentación técnica detallada')"><i class="fa fa-file-lines"></i>Documentar</button>
        <button class="qa-btn" onclick="sendQuick('Traduce al inglés técnico profesional')"><i class="fa fa-language"></i>Traducir</button>
      </div>

      <!-- Modelo activo -->
      <div class="rp-sec">Modelo Activo</div>
      <div class="model-info">
        <div class="mi-row"><span class="mi-lbl">Proveedor</span><span class="mi-badge" id="rpProvider">Claude</span></div>
        <div class="mi-row"><span class="mi-lbl">Modelo</span><span class="mi-val" id="rpModel">claude-sonnet-4</span></div>
        <div class="mi-row"><span class="mi-lbl">Estado</span><span class="mi-val" style="color:var(--green-lt)">● Online</span></div>
        <div class="mi-row"><span class="mi-lbl">Contexto</span><span class="mi-val" id="rpCtx">0 msgs</span></div>
        <div class="mi-row"><span class="mi-lbl">Tokens est.</span><span class="mi-val" id="rpTokens">~0</span></div>
      </div>

      <!-- Estadísticas -->
      <div class="rp-sec">Sesión</div>
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-n" id="statMsgs">0</div><div class="stat-l">Mensajes</div></div>
        <div class="stat-card"><div class="stat-n" id="statTime">0s</div><div class="stat-l">Tiempo resp.</div></div>
      </div>

      <!-- Config -->
      <div class="rp-sec">Configuración</div>
      <div class="toggle-row"><span class="toggle-lbl">Modo técnico avanzado</span><label class="toggle"><input type="checkbox" id="techMode"><span class="toggle-sl"></span></label></div>
      <div class="toggle-row"><span class="toggle-lbl">Mostrar código siempre</span><label class="toggle"><input type="checkbox" id="codeMode" checked><span class="toggle-sl"></span></label></div>
      <div class="toggle-row"><span class="toggle-lbl">Respuestas detalladas</span><label class="toggle"><input type="checkbox" id="detailMode" checked><span class="toggle-sl"></span></label></div>
      <div class="toggle-row"><span class="toggle-lbl">Auto-guardar historial</span><label class="toggle"><input type="checkbox" id="saveMode" <?= $usuario_id ? 'checked' : '' ?>><span class="toggle-sl"></span></label></div>

    </div>
  </div>

</div><!-- /ia-layout -->

<!-- Toast -->
<div class="toast" id="toast"></div>


<script>
/* ══════════════════════════════════════════════════════════════════
   ESTADO GLOBAL
══════════════════════════════════════════════════════════════════ */
const STATE = {
  tool: {
    id: 'asistente', ico: '🤖',
    titulo: 'Asistente General',
    desc: 'Resuelve dudas, explica conceptos y responde preguntas.',
    provider: 'claude', color: 'green'
  },
  messages: [],        // { role, content }
  loading: false,
  msgCount: 0,
  totalTokens: 0,
  lastResponseMs: 0,
  voiceActive: false,
  recognition: null,
  manualProvider: null, // null = usar el del agente, 'claude'/'gemini'/'openai' = override
};

/* ══════════════════════════════════════════════════════════════════
   SUGERENCIAS
══════════════════════════════════════════════════════════════════ */
const SUGG = {
  asistente:   ['¿Qué es OWASP?','Explica SQL Injection','¿Cómo funciona HTTPS?','Conceptos de criptografía'],
  ciberseg:    ['Analiza una URL sospechosa','¿Qué es un ataque MITM?','Cómo hacer un pentest básico','Explica el modelo CIA'],
  codigo:      ['API REST en PHP','Script de monitoreo Python','Consulta SQL optimizada','Función hash segura'],
  aprendizaje: ['Ruta: Hacking ético','Quiz de redes básico','Plan 30 días en ciberseguridad','Recursos OSCP gratis'],
  analisis:    ['Analiza logs de red','Métricas de seguridad','Interpreta resultados Nmap','Dashboard de incidentes'],
  proyectos:   ['Sprint plan 2 semanas','KPIs de seguridad','Backlog para auditoría','Documentación estándar'],
  redaccion:   ['Informe de incidente','Política de contraseñas','README técnico','Procedimiento de respuesta'],
  redes:       ['Error de conectividad','Configurar firewall','TCP vs UDP','Arquitectura segura'],
  ia_explica:  ['¿Qué es una red neuronal?','Cómo funciona Random Forest','K-means en Python','ML vs DL vs RL'],
  optimizador: ['Optimiza consulta SQL','Cuellos de botella PHP','Caché efectivo','Métricas de rendimiento'],
};

/* ══════════════════════════════════════════════════════════════════
   SELECCIÓN DE HERRAMIENTA
══════════════════════════════════════════════════════════════════ */
function selectTool(tool, el) {
  document.querySelectorAll('.tool-item').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  STATE.tool = tool;
  STATE.manualProvider = null;

  // Actualizar header
  document.getElementById('thIco').textContent    = tool.ico;
  document.getElementById('thTitle').textContent   = tool.titulo;
  document.getElementById('thDesc').textContent    = tool.desc;

  // Actualizar panel derecho
  const provColors = {claude:'rgba(255,136,0,.15)',gemini:'rgba(66,133,244,.15)',openai:'rgba(16,163,127,.15)'};
  const provTxt    = {claude:'#ffb347',gemini:'#7ab3f7',openai:'#4ecca5'};
  const provBd     = {claude:'rgba(255,136,0,.3)',gemini:'rgba(66,133,244,.3)',openai:'rgba(16,163,127,.3)'};
  const p = tool.provider;
  document.getElementById('rpDetail').innerHTML = `
    <div class="td-ico">${tool.ico}</div>
    <div class="td-title">${tool.titulo}</div>
    <div class="td-desc">${tool.desc}</div>
    <span class="td-prov" style="background:${provColors[p]};color:${provTxt[p]};border:1px solid ${provBd[p]}">${p.toUpperCase()}</span>
  `;

  updateProviderBadge(p);
  resetProviderBtns(p);
  renderSugg(tool.id);
  clearChat(true);
  addMessage('ai', `**${tool.titulo}** activado. ${tool.desc} ¿En qué te puedo ayudar?`);
}

/* ══════════════════════════════════════════════════════════════════
   PROVEEDOR MANUAL
══════════════════════════════════════════════════════════════════ */
function setProvider(prov, btn) {
  STATE.manualProvider = prov;
  resetProviderBtns(prov);
  updateProviderBadge(prov);
  showToast(`Proveedor cambiado a ${prov.toUpperCase()}`);
}

function resetProviderBtns(active) {
  document.querySelectorAll('.prov-btn').forEach(b => {
    b.className = 'prov-btn';
    if (b.dataset.prov === active) b.classList.add(`selected-${active}`);
  });
}

function updateProviderBadge(prov) {
  const icons = {claude:'🤖',gemini:'✨',openai:'🧠'};
  const badge = document.getElementById('globalProvBadge');
  badge.textContent = `${icons[prov]||''} ${prov.toUpperCase()}`;
  badge.className = `provider-badge ${prov}`;
  document.getElementById('rpProvider').textContent = prov.toUpperCase();
  const models = {claude:'claude-sonnet-4',gemini:'gemini-1.5-flash',openai:'gpt-4o-mini'};
  document.getElementById('rpModel').textContent = models[prov]||prov;
  document.getElementById('modelInfo').textContent = `${models[prov]||prov} · ContainerRZ IA`;
}

/* ══════════════════════════════════════════════════════════════════
   SUGERENCIAS
══════════════════════════════════════════════════════════════════ */
function renderSugg(toolId) {
  const chips = (SUGG[toolId] || SUGG.asistente).map(s =>
    `<button class="sugg-chip" onclick="sendQuick('${s.replace(/'/g,"\\'")}')">${s}</button>`
  ).join('');
  document.getElementById('suggBar').innerHTML = chips;
}
renderSugg('asistente');

/* ══════════════════════════════════════════════════════════════════
   MENSAJES
══════════════════════════════════════════════════════════════════ */
function addMessage(role, content, provider = null) {
  const welcome = document.getElementById('chatWelcome');
  if (welcome) welcome.remove();

  const container = document.getElementById('chatMsgs');
  const now = new Date().toLocaleTimeString('es',{hour:'2-digit',minute:'2-digit'});

  const div = document.createElement('div');
  div.className = `msg ${role}`;

  const av = role === 'ai'
    ? `<div class="msg-av ai-av"><i class="fa fa-robot"></i></div>`
    : `<div class="msg-av user-av"><i class="fa fa-user"></i></div>`;

  const rendered = role === 'ai' ? renderMd(content) : esc(content).replace(/\n/g,'<br>');
  const provBadge = (role === 'ai' && provider)
    ? `<span class="msg-prov ${provider}">${provider}</span>` : '';

  const actions = role === 'ai' ? `
    <div class="msg-actions">
      <button class="msg-act" onclick="copyMsgText(this,'${encodeURIComponent(content)}')" title="Copiar"><i class="fa fa-copy"></i></button>
      <button class="msg-act" onclick="speakText('${encodeURIComponent(content)}')" title="Escuchar"><i class="fa fa-volume-high"></i></button>
      <button class="msg-act" onclick="this.style.color='var(--green-lt)'" title="Me gusta"><i class="fa fa-thumbs-up"></i></button>
    </div>` : '';

  div.innerHTML = `${av}<div>
    <div class="msg-bubble">${rendered}</div>
    <div class="msg-meta"><span class="msg-time">${now}</span>${provBadge}</div>
    ${actions}
  </div>`;

  container.insertBefore(div, document.getElementById('typingInd'));
  container.scrollTop = container.scrollHeight;
  STATE.msgCount++;
  STATE.totalTokens += Math.ceil(content.length / 4);
  updateStats();
}

/* ══════════════════════════════════════════════════════════════════
   ENVIAR MENSAJE  →  api/ia_chat.php
══════════════════════════════════════════════════════════════════ */
async function sendMessage(text) {
  const input = document.getElementById('chatInput');
  const msg   = text || input.value.trim();
  if (!msg || STATE.loading) return;
  if (!text) { input.value=''; autoResize(input); updateCount(); }

  addMessage('user', msg);
  STATE.messages.push({ role:'user', content: msg });
  setLoading(true);

  const t0 = Date.now();
  const provider = STATE.manualProvider || STATE.tool.provider || 'claude';

  try {
    const res  = await fetch('api/ia_chat.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agentId:  STATE.tool.id,
        provider: provider,
        messages: STATE.messages.slice(-20),
        options: {
          techMode:   document.getElementById('techMode').checked,
          codeMode:   document.getElementById('codeMode').checked,
          detailMode: document.getElementById('detailMode').checked,
        }
      })
    });

    const data = await res.json();
    if (data.error) throw new Error(data.error);

    const aiText = data.text || 'Sin respuesta.';
    const usedProvider = data.provider || provider;

    addMessage('ai', aiText, usedProvider.split(' ')[0]);
    STATE.messages.push({ role:'assistant', content: aiText });

    STATE.lastResponseMs = Date.now() - t0;
    STATE.totalTokens += data.tokens || 0;

    if (data.warning) showToast(`⚠️ ${data.warning}`);

    // Guardar en historial si está habilitado
    if (document.getElementById('saveMode')?.checked && STATE.messages.length === 2) {
      saveHistory(msg, aiText);
    }

  } catch(err) {
    addMessage('ai', `❌ **Error**: ${err.message || 'No se pudo conectar. Verifica que api/ia_chat.php esté configurado.'}`);
  } finally {
    setLoading(false);
    updateStats();
  }
}

function sendQuick(text) { sendMessage(text); }

/* ══════════════════════════════════════════════════════════════════
   HISTORIAL
══════════════════════════════════════════════════════════════════ */
function saveHistory(userMsg, aiMsg) {
  fetch('api/ia_save_conv.php', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({
      titulo:  userMsg.slice(0,60),
      tool:    STATE.tool.id,
      resumen: aiMsg.slice(0,200),
    })
  }).catch(()=>{});
}

function deleteHistory(e, id) {
  e.stopPropagation();
  if (!confirm('¿Eliminar esta conversación?')) return;
  fetch(`api/ia_history.php?action=delete&id=${id}`,{method:'POST'})
    .then(()=>e.target.closest('.hist-item')?.remove())
    .catch(()=>{});
}

/* ══════════════════════════════════════════════════════════════════
   UTILIDADES DE UI
══════════════════════════════════════════════════════════════════ */
function setLoading(v) {
  STATE.loading = v;
  document.getElementById('sendBtn').disabled = v;
  document.getElementById('typingInd').classList.toggle('show', v);
  if(v) document.getElementById('chatMsgs').scrollTop = 9999;
}

function updateStats() {
  document.getElementById('statMsgs').textContent  = STATE.msgCount;
  document.getElementById('statTime').textContent  = STATE.lastResponseMs > 0 ? (STATE.lastResponseMs/1000).toFixed(1)+'s' : '0s';
  document.getElementById('rpCtx').textContent     = STATE.messages.length + ' msgs';
  document.getElementById('rpTokens').textContent  = '~' + STATE.totalTokens;
}

function clearChat(silent=false) {
  STATE.messages=[]; STATE.msgCount=0; STATE.totalTokens=0; STATE.lastResponseMs=0;
  updateStats();
  document.getElementById('chatMsgs').innerHTML = `
    <div class="chat-welcome" id="chatWelcome">
      <div class="cw-orb"><div class="cw-ring"></div><div class="cw-ring"></div><div class="cw-ring"></div><span class="cw-ico">${STATE.tool.ico}</span></div>
      <h2 class="cw-title">${STATE.tool.titulo}</h2>
      <p class="cw-sub">${STATE.tool.desc}</p>
      <div class="cw-cards">${(SUGG[STATE.tool.id]||[]).slice(0,4).map(s=>`<div class="cw-card" onclick="sendQuick('${s.replace(/'/g,"\\'")}')"><div class="cw-card-ico">⚡</div><div class="cw-card-txt">${s}</div></div>`).join('')}</div>
    </div>`;
  document.getElementById('chatMsgs').appendChild(document.getElementById('typingInd'));
}

function autoResize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,120)+'px'}
function updateCount(){document.getElementById('charCount').textContent=document.getElementById('chatInput').value.length+'/4000'}
function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}}

function copyMsgText(btn, encoded) {
  navigator.clipboard.writeText(decodeURIComponent(encoded)).then(()=>{
    btn.innerHTML='<i class="fa fa-check"></i>';
    setTimeout(()=>btn.innerHTML='<i class="fa fa-copy"></i>',1500);
  });
}
function copyLastMsg(){const m=document.querySelectorAll('.msg.ai .msg-bubble');if(m.length){navigator.clipboard.writeText(m[m.length-1].innerText);showToast('✅ Copiado');}}

function speakText(encoded){
  const t=decodeURIComponent(encoded).slice(0,500);
  if('speechSynthesis' in window){window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(t);u.lang='es-ES';u.rate=0.95;window.speechSynthesis.speak(u);}
}

function insertCode(){const i=document.getElementById('chatInput');i.value+='\n```\n// código aquí\n```';autoResize(i)}

function exportChat(){
  const msgs=document.querySelectorAll('.msg');
  let txt=`=== ContainerRZ IA ===\nFecha: ${new Date().toLocaleString('es')}\nMódulo: ${STATE.tool.titulo}\n${'='.repeat(40)}\n\n`;
  msgs.forEach(m=>{const r=m.classList.contains('user')?'Usuario':'IA';const b=m.querySelector('.msg-bubble');if(b)txt+=`[${r}]\n${b.innerText}\n\n`});
  const a=document.createElement('a');a.href='data:text/plain;charset=utf-8,'+encodeURIComponent(txt);a.download=`ia-${Date.now()}.txt`;a.click();
}

function showToast(msg,ms=2800){
  const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),ms);
}

/* ══════════════════════════════════════════════════════════════════
   VOZ  (entrada por micrófono)
══════════════════════════════════════════════════════════════════ */
function toggleVoiceInput(){
  const btn=document.getElementById('voiceInputBtn');
  if(STATE.voiceActive){STATE.recognition?.stop();STATE.voiceActive=false;btn.style.color='';return}
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){showToast('Tu navegador no soporta reconocimiento de voz');return}
  STATE.recognition=new SR();
  STATE.recognition.lang='es-ES';
  STATE.recognition.onresult=e=>{document.getElementById('chatInput').value=e.results[0][0].transcript;updateCount();sendMessage()};
  STATE.recognition.onend=()=>{STATE.voiceActive=false;btn.style.color=''};
  STATE.recognition.start();
  STATE.voiceActive=true;btn.style.color='var(--red)';
}
function toggleVoice(){toggleVoiceInput()}

/* ══════════════════════════════════════════════════════════════════
   MARKDOWN BÁSICO → HTML
══════════════════════════════════════════════════════════════════ */
function renderMd(text){
  let h=esc(text);
  h=h.replace(/```(\w*)\n?([\s\S]*?)```/g,(_,lang,code)=>`<pre><code>${code.trim()}</code></pre>`);
  h=h.replace(/`([^`]+)`/g,'<code>$1</code>');
  h=h.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>');
  h=h.replace(/\*(.+?)\*/g,'<em>$1</em>');
  h=h.replace(/^### (.+)$/gm,'<h4>$1</h4>');
  h=h.replace(/^## (.+)$/gm,'<h3>$1</h3>');
  h=h.replace(/^# (.+)$/gm,'<h3>$1</h3>');
  h=h.replace(/^[\-\*] (.+)$/gm,'<li>$1</li>');
  h=h.replace(/^\d+\. (.+)$/gm,'<li>$1</li>');
  h=h.replace(/^---$/gm,'<hr style="border-color:rgba(255,255,255,.1);margin:7px 0">');
  h=h.replace(/\n\n/g,'</p><p>').replace(/\n/g,'<br>');
  if(!h.startsWith('<'))h='<p>'+h+'</p>';
  return h;
}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}

/* ══════════════════════════════════════════════════════════════════
   BÚSQUEDA EN SIDEBAR
══════════════════════════════════════════════════════════════════ */
document.getElementById('toolSearch').addEventListener('input',function(){
  const q=this.value.toLowerCase();
  document.querySelectorAll('.tool-item').forEach(t=>{
    t.style.display=(!q||(t.dataset.search||'').includes(q))?'':'none';
  });
});

/* ══════════════════════════════════════════════════════════════════
   SIDEBAR MÓVIL
══════════════════════════════════════════════════════════════════ */
function toggleSidebar(){
  document.getElementById('iaLayout').classList.toggle('sb-open');
  document.getElementById('sbToggleBtn').classList.toggle('active');
}

/* ══════════════════════════════════════════════════════════════════
   ATAJOS DE TECLADO
══════════════════════════════════════════════════════════════════ */
document.addEventListener('keydown',e=>{
  if(e.ctrlKey&&e.key==='/'){e.preventDefault();document.getElementById('chatInput').focus()}
  if(e.ctrlKey&&e.key==='k'){e.preventDefault();clearChat()}
  if(e.ctrlKey&&e.key==='e'){e.preventDefault();exportChat()}
});

/* ══════════════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('chatInput').focus();
});
</script>
</body>
</html>
