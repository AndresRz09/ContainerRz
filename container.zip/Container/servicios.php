<?php
include 'conexion.php';
session_start();

// ── Datos de servicios (estructura completa) ──────────────────────
$servicios = [

  // ── PROGRAMACIÓN ─────────────────────────────────────────────
  [
    'id'         => 'programacion',
    'ico'        => '💻',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'Programación',
    'subtitulo'  => 'Fundamentos y desarrollo de software',
    'color'      => 'green',
    'nivel'      => 'Básico → Avanzado',
    'duracion'   => '20 – 120 h',
    'precio_base'=> 150000,
    'definicion' => 'La programación es el proceso de diseñar, codificar, depurar y mantener el código fuente de programas computacionales para resolver problemas o realizar tareas. Actúa como puente de comunicación entre el ser humano y la máquina, utilizando lenguajes específicos para crear software, aplicaciones móviles, sitios web y sistemas de Inteligencia Artificial.',
    'importancia'=> 'En un mundo completamente digitalizado, la programación es el motor que impulsa la economía, la medicina, la ingeniería y la educación. Dominarla abre puertas a decenas de perfiles profesionales con alta demanda y excelente remuneración.',
    'conceptos'  => [
      ['🧮', 'Algoritmos', 'Secuencia lógica de pasos para resolver un problema. Toda solución de software nace de un algoritmo bien definido.'],
      ['📝', 'Lenguajes de Programación', 'Herramientas formales para escribir instrucciones: Python, JavaScript, Java, C++, C#, Go, Rust, entre muchos otros.'],
      ['🔄', 'Tipos de Programación', 'Imperativa, orientada a objetos, funcional, lógica y reactiva. Cada paradigma aborda los problemas desde una perspectiva distinta.'],
      ['🐛', 'Depuración', 'Proceso de identificar, analizar y corregir errores (bugs) en el código para garantizar el correcto funcionamiento.'],
      ['📦', 'Librerías y Frameworks', 'Conjuntos de código reutilizable que aceleran el desarrollo evitando reinventar la rueda.'],
      ['🔧', 'Control de Versiones', 'Herramientas como Git que permiten rastrear cambios, colaborar y revertir código.'],
    ],
    'parametros' => [
      'Programación desde cero (lógica y pseudocódigo)',
      'Introducción a lenguajes: Python, JavaScript, C++',
      'Variables, tipos de datos y operadores',
      'Estructuras de control: condicionales y ciclos',
      'Funciones, módulos y reutilización de código',
      'Manejo de errores y excepciones',
      'Programación orientada a objetos (POO)',
      'Programación funcional y lambdas',
      'Patrones de diseño GoF',
      'Testing unitario y TDD',
      'APIs REST y consumo de servicios externos',
      'Gestión de dependencias (npm, pip, Maven)',
      'Buenas prácticas y Clean Code',
      'Automatización de tareas y scripting',
      'Introducción a algoritmos y complejidad O(n)',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/nLRL_NcnK-4',
    'links' => [
      ['🐍', 'Python Official Docs',    'https://docs.python.org'],
      ['📘', 'MDN JavaScript',          'https://developer.mozilla.org/es/docs/Web/JavaScript'],
      ['📚', 'freeCodeCamp',            'https://www.freecodecamp.org'],
      ['🎓', 'The Odin Project',        'https://www.theodinproject.com'],
      ['⚡', 'LeetCode (Práctica)',     'https://leetcode.com'],
    ],
    'planes' => [
      ['Básico',    59000,  ['Lógica y pseudocódigo', '1 lenguaje a elección', '10 ejercicios prácticos', 'Soporte por chat']],
      ['Estándar',  129000, ['Todo lo Básico', '3 lenguajes', 'Proyecto integrador', 'POO completo', 'Soporte prioritario']],
      ['Premium',   250000, ['Todo lo Estándar', 'Patrones de diseño', 'Testing y CI/CD', 'Mentoría 1:1', 'Certificado VIROX']],
    ],
  ],

  // ── PROGRAMACIÓN WEB ─────────────────────────────────────────
  [
    'id'         => 'prog_web',
    'ico'        => '🌐',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'Programación Web',
    'subtitulo'  => 'Frontend, Backend y Full-Stack',
    'color'      => 'blue',
    'nivel'      => 'Básico → Full-Stack',
    'duracion'   => '30 – 150 h',
    'precio_base'=> 180000,
    'definicion' => 'La programación web es la disciplina que permite crear sitios, aplicaciones y plataformas accesibles desde navegadores o dispositivos conectados a internet. Abarca el desarrollo del lado del cliente (Frontend), del lado del servidor (Backend) y la integración de ambos (Full-Stack), empleando tecnologías como HTML, CSS, JavaScript, PHP, Node.js, React, entre otras.',
    'importancia'=> 'Más del 60% de las empresas del mundo dependen de presencia digital activa. Un desarrollador web competente puede construir desde portafolios personales hasta plataformas e-commerce de millones de usuarios.',
    'conceptos'  => [
      ['🖼', 'HTML5',        'Lenguaje de marcado que estructura el contenido de las páginas web. Base de todo sitio en internet.'],
      ['🎨', 'CSS3',         'Hojas de estilo que controlan el diseño, colores, animaciones y responsive design.'],
      ['⚡', 'JavaScript',   'Lenguaje de scripting que da interactividad al frontend y potencia el backend con Node.js.'],
      ['⚙️', 'PHP / Node',  'Lenguajes de servidor que procesan peticiones, gestionan bases de datos y entregan contenido dinámico.'],
      ['🔗', 'APIs REST',    'Interfaces que permiten la comunicación entre frontend y backend mediante HTTP y JSON.'],
      ['📱', 'Responsive',   'Técnicas para adaptar el diseño a móviles, tablets y escritorios automáticamente.'],
    ],
    'parametros' => [
      'HTML5 semántico y accesibilidad web (WCAG)',
      'CSS3 avanzado: Flexbox, Grid, animaciones',
      'JavaScript ES6+: promesas, async/await, fetch',
      'Frameworks Frontend: React, Vue.js, Svelte',
      'Backend con PHP 8 y Node.js / Express',
      'Bases de datos para web: MySQL, PostgreSQL, MongoDB',
      'Autenticación: JWT, OAuth2, sesiones',
      'Despliegue: Netlify, Vercel, AWS, DigitalOcean',
      'SEO técnico y optimización de rendimiento',
      'PWA (Progressive Web Apps)',
      'WebSockets y tiempo real',
      'Testing con Jest, Cypress y PHPUnit',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/ysEN5RaKOlA',
    'links' => [
      ['🌐', 'W3Schools',      'https://www.w3schools.com'],
      ['🔥', 'CSS Tricks',     'https://css-tricks.com'],
      ['⚛️', 'React Docs',    'https://react.dev'],
      ['📦', 'Node.js Docs',  'https://nodejs.org/docs'],
      ['🚀', 'Vercel',        'https://vercel.com/docs'],
    ],
    'planes' => [
      ['Básico',    75000,  ['HTML5 + CSS3', 'JS básico', 'Landing page estática', 'Soporte por chat']],
      ['Web Dev',   195000, ['Frontend completo', 'React/Vue', 'Backend con PHP/Node', 'BD integrada', 'Deploy incluido']],
      ['Full-Stack',380000, ['Todo Web Dev', 'PWA', 'APIs REST propias', 'Auth segura', 'Mentoría + Certificado']],
    ],
  ],

  // ── POO ──────────────────────────────────────────────────────
  [
    'id'         => 'poo',
    'ico'        => '🧩',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'POO',
    'subtitulo'  => 'Programación Orientada a Objetos',
    'color'      => 'purple',
    'nivel'      => 'Intermedio → Avanzado',
    'duracion'   => '25 – 80 h',
    'precio_base'=> 140000,
    'definicion' => 'La Programación Orientada a Objetos (POO) es un paradigma de programación que organiza el software en torno a objetos, que son instancias de clases con atributos (datos) y métodos (comportamientos). Sus cuatro pilares —Encapsulamiento, Herencia, Polimorfismo y Abstracción— permiten construir software modular, reutilizable y fácilmente mantenible.',
    'importancia'=> 'POO es el paradigma dominante en la industria. Frameworks y sistemas empresariales como Django, Spring, Laravel y .NET están construidos sobre sus principios. Dominarlo es esencial para cualquier desarrollador profesional.',
    'conceptos'  => [
      ['📦', 'Encapsulamiento', 'Ocultar la implementación interna de un objeto y exponer solo lo necesario mediante modificadores de acceso.'],
      ['🧬', 'Herencia',        'Mecanismo que permite que una clase hija herede atributos y métodos de una clase padre, promoviendo reutilización.'],
      ['🔄', 'Polimorfismo',    'Capacidad de un objeto de tomar múltiples formas. Un mismo método puede comportarse diferente según la clase que lo implemente.'],
      ['🎭', 'Abstracción',     'Representar solo las características esenciales de un objeto, ignorando los detalles irrelevantes.'],
      ['🏛', 'Clases e Interfaces', 'Plantillas para crear objetos y contratos que definen comportamientos obligatorios.'],
      ['🗺', 'Patrones GoF',   '23 patrones de diseño clásicos: Singleton, Factory, Observer, Strategy y más.'],
    ],
    'parametros' => [
      'Clases, objetos, atributos y métodos',
      'Constructores, destructores y sobrecarga',
      'Modificadores de acceso: público, privado, protegido',
      'Herencia simple y múltiple',
      'Clases abstractas e interfaces',
      'Polimorfismo: sobrescritura y sobrecarga',
      'Composición vs herencia',
      'Patrones creacionales: Singleton, Factory, Builder',
      'Patrones estructurales: Adapter, Decorator, Facade',
      'Patrones de comportamiento: Observer, Strategy, Command',
      'UML: diagramas de clases y secuencia',
      'Principios SOLID aplicados',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1618477388954-7852f32655ec?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/I848HdWjLMo',
    'links' => [
      ['📘', 'SOLID Principles',    'https://www.digitalocean.com/community/conceptual-articles/s-o-l-i-d-the-first-five-principles-of-object-oriented-design'],
      ['🏛', 'Refactoring Guru',    'https://refactoring.guru/es/design-patterns'],
      ['📚', 'Gang of Four Patterns','https://en.wikipedia.org/wiki/Design_Patterns'],
    ],
    'planes' => [
      ['Básico',    60000,  ['Clases y objetos', 'Los 4 pilares', '5 ejercicios prácticos']],
      ['Completo',  140000, ['Todo Básico', 'Patrones GoF', 'UML', 'Proyecto POO completo']],
      ['Enterprise',260000, ['Todo Completo', 'SOLID avanzado', 'Arquitectura limpia', 'Code Review']],
    ],
  ],

  // ── BASES DE DATOS ───────────────────────────────────────────
  [
    'id'         => 'bases_datos',
    'ico'        => '🗄',
    'categoria'  => 'Datos',
    'titulo'     => 'Bases de Datos',
    'subtitulo'  => 'SQL, NoSQL y diseño de datos',
    'color'      => 'gold',
    'nivel'      => 'Básico → DBA',
    'duracion'   => '20 – 100 h',
    'precio_base'=> 160000,
    'definicion' => 'Una base de datos es un sistema organizado para almacenar, gestionar y recuperar información de forma eficiente, segura y estructurada. Existen bases de datos relacionales (SQL: MySQL, PostgreSQL, SQL Server, Oracle) y no relacionales (NoSQL: MongoDB, Redis, Cassandra, Firebase) cada una óptima para diferentes escenarios.',
    'importancia'=> 'Toda aplicación del mundo real requiere almacenamiento persistente de datos. Sin bases de datos bien diseñadas no hay banca digital, redes sociales, e-commerce ni sistemas empresariales.',
    'conceptos'  => [
      ['📊', 'Modelo Relacional',   'Organiza datos en tablas con filas y columnas interrelacionadas mediante claves primarias y foráneas.'],
      ['🔍', 'SQL',                 'Structured Query Language: lenguaje estándar para consultar, insertar, actualizar y eliminar datos relacionales.'],
      ['📄', 'NoSQL',               'Bases de datos no relacionales: documentos (MongoDB), clave-valor (Redis), grafos (Neo4j), columnar (Cassandra).'],
      ['🗺', 'Normalización',       'Proceso de organizar una base de datos para reducir redundancia y mejorar la integridad (1FN, 2FN, 3FN, BCNF).'],
      ['⚡', 'Índices y rendimiento','Estructuras que aceleran las consultas. Incluye índices B-Tree, hash y full-text.'],
      ['🔒', 'Transacciones ACID',  'Atomicidad, Consistencia, Aislamiento y Durabilidad: propiedades que garantizan integridad en operaciones críticas.'],
    ],
    'parametros' => [
      'Modelado entidad-relación (ER) y diagrama UML',
      'SQL completo: DDL, DML, DCL, TCL',
      'Joins: INNER, LEFT, RIGHT, FULL, CROSS',
      'Subconsultas, CTEs y Window Functions',
      'Stored procedures, funciones y triggers',
      'Normalización hasta BCNF y desnormalización estratégica',
      'Índices, planes de ejecución y EXPLAIN',
      'Transacciones y control de concurrencia',
      'Bases de datos distribuidas y replicación',
      'MongoDB: CRUD, agregaciones, sharding',
      'Redis: caché, pub/sub y estructuras de datos',
      'Conexión desde PHP, Python, Node.js y Java',
      'Backup, restauración y seguridad de datos',
      'Migraciones con Flyway o Liquibase',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/HXV3zeQKqGY',
    'links' => [
      ['🐬', 'MySQL Docs',        'https://dev.mysql.com/doc/'],
      ['🐘', 'PostgreSQL Docs',   'https://www.postgresql.org/docs/'],
      ['🍃', 'MongoDB Docs',      'https://www.mongodb.com/docs/'],
      ['📚', 'SQLZoo (Práctica)', 'https://sqlzoo.net'],
    ],
    'planes' => [
      ['SQL Básico',  70000,  ['SELECT avanzado', 'Joins', 'Modelado ER', '10 ejercicios']],
      ['BD Completo', 165000, ['Todo SQL', 'NoSQL', 'Procedimientos', 'Optimización', 'Proyecto']],
      ['DBA Pro',     310000, ['Todo Completo', 'BD distribuidas', 'Alta disponibilidad', 'Certificado']],
    ],
  ],

  // ── CIBERSEGURIDAD ────────────────────────────────────────────
  [
    'id'         => 'ciberseguridad',
    'ico'        => '🛡',
    'categoria'  => 'Seguridad',
    'titulo'     => 'Ciberseguridad',
    'subtitulo'  => 'Ethical Hacking y protección digital',
    'color'      => 'red',
    'nivel'      => 'Básico → OSCP',
    'duracion'   => '40 – 200 h',
    'precio_base'=> 220000,
    'definicion' => 'La ciberseguridad es el conjunto de tecnologías, procesos y prácticas diseñadas para proteger redes, sistemas, programas y datos de ataques, daños o accesos no autorizados. Abarca desde la seguridad perimetral hasta el hacking ético, la respuesta a incidentes y el análisis forense digital.',
    'importancia'=> 'El cibercrimen genera pérdidas superiores a $8 billones de dólares anuales globalmente. Los profesionales en ciberseguridad son los más demandados del sector TI con salarios hasta un 40% superiores al promedio tecnológico.',
    'conceptos'  => [
      ['🔺', 'Modelo CIA',         'Confidencialidad, Integridad y Disponibilidad: los tres pilares fundamentales de la seguridad de la información.'],
      ['🔴', 'Ethical Hacking',    'Simulación controlada de ataques reales para identificar vulnerabilidades antes que los atacantes maliciosos.'],
      ['🕵', 'Análisis Forense',   'Investigación de incidentes de seguridad mediante recolección y análisis de evidencia digital.'],
      ['🛡', 'Blue Team / Red Team','Equipos defensivos (Blue) vs ofensivos (Red) que colaboran para fortalecer la postura de seguridad.'],
      ['🔐', 'Criptografía',       'Ciencia de proteger información mediante cifrado simétrico, asimétrico, hashing y firmas digitales.'],
      ['🌐', 'OWASP Top 10',       'Lista de las 10 vulnerabilidades web más críticas: SQLi, XSS, CSRF, SSRF, IDOR, entre otras.'],
    ],
    'parametros' => [
      'Fundamentos de redes: TCP/IP, UDP, DNS, HTTP/S',
      'Reconocimiento: OSINT, Nmap, Shodan, Recon-ng',
      'Escaneo de vulnerabilidades: Nessus, OpenVAS',
      'Explotación: Metasploit Framework, manual exploits',
      'Post-explotación y pivoting',
      'Ataques web: SQLi, XSS, CSRF, LFI/RFI, SSRF',
      'Inyecciones y bypass de autenticación',
      'Análisis de tráfico: Wireshark, tcpdump',
      'Seguridad en Active Directory y Kerberoasting',
      'Forense digital: Volatility, Autopsy',
      'Criptografía aplicada y SSL/TLS',
      'Hardening de sistemas Linux y Windows',
      'CTFs y laboratorios: HackTheBox, TryHackMe',
      'Certificaciones: CEH, eJPT, OSCP path',
      'Normativas: ISO 27001, NIST, GDPR',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/GHpL7WYEhI4',
    'links' => [
      ['🔴', 'HackTheBox',      'https://www.hackthebox.com'],
      ['🟢', 'TryHackMe',       'https://tryhackme.com'],
      ['📋', 'OWASP',           'https://owasp.org'],
      ['🔒', 'NIST Cybersec',  'https://www.nist.gov/cyberframework'],
      ['🎓', 'CEH Info',        'https://www.eccouncil.org/programs/certified-ethical-hacker-ceh/'],
    ],
    'planes' => [
      ['Fundamentos', 90000,  ['Redes + TCP/IP', 'OWASP Top 10', 'Nmap básico', 'Lab virtual']],
      ['Pentester',  225000,  ['Todo Fundamentos', 'Metasploit', 'Web hacking completo', 'AD básico', 'CTF incluido']],
      ['OSCP Path',  450000,  ['Todo Pentester', 'Forense', 'Red Team', 'Lab avanzado', 'Prep OSCP', 'Certificado']],
    ],
  ],

  // ── REDES Y CONECTIVIDAD ─────────────────────────────────────
  [
    'id'         => 'redes',
    'ico'        => '🌐',
    'categoria'  => 'Infraestructura',
    'titulo'     => 'Redes y Conectividad',
    'subtitulo'  => 'Infraestructura de comunicaciones',
    'color'      => 'teal',
    'nivel'      => 'Básico → CCNA/CompTIA',
    'duracion'   => '30 – 120 h',
    'precio_base'=> 175000,
    'definicion' => 'Las redes de computadoras son sistemas de comunicación que permiten el intercambio de datos entre dispositivos. Incluyen desde redes locales (LAN) hasta redes globales (WAN/Internet), empleando protocolos como TCP/IP, modelos OSI y dispositivos como routers, switches y firewalls.',
    'importancia'=> 'Toda organización moderna depende de su red para operar. Un ingeniero de redes diseña, implementa y asegura la infraestructura que conecta empleados, servidores, la nube y el mundo exterior.',
    'conceptos'  => [
      ['📡', 'Modelo OSI',        '7 capas que definen cómo los datos viajan de una aplicación a otra a través de la red.'],
      ['🔗', 'TCP/IP',            'Suite de protocolos estándar de internet: IP, TCP, UDP, ICMP, DNS, HTTP, SMTP, FTP.'],
      ['🔀', 'Ruteo',             'Proceso de reenviar paquetes entre redes usando protocolos como OSPF, BGP, RIP, EIGRP.'],
      ['🔒', 'VPN',               'Redes privadas virtuales que cifran el tráfico sobre internet para conexiones seguras.'],
      ['🏗', 'VLAN',              'Segmentación lógica de una red física en múltiples redes virtuales aisladas.'],
      ['☁️', 'SDN',              'Software Defined Networking: control centralizado de la infraestructura de red mediante software.'],
    ],
    'parametros' => [
      'Modelo OSI y TCP/IP: comparación y aplicación',
      'Subnetting y cálculo de máscaras CIDR',
      'Configuración de routers y switches Cisco/MikroTik',
      'Protocolos de ruteo: OSPF, BGP, EIGRP',
      'Switching: STP, VLANs, trunking, EtherChannel',
      'Servicios de red: DHCP, DNS, NTP, SNMP',
      'VPN: IPSec, SSL/TLS, WireGuard, OpenVPN',
      'Firewalls: iptables, pfSense, Cisco ASA',
      'Monitoreo: Zabbix, Nagios, PRTG, Grafana',
      'Wireless: 802.11, seguridad WPA3, controladores',
      'IPv6: direccionamiento y migración',
      'QoS y gestión de ancho de banda',
      'Packet Tracer y GNS3: laboratorios virtuales',
      'Certificaciones: CCNA, CompTIA Network+',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/qiQR5rTSshw',
    'links' => [
      ['🔵', 'Cisco CCNA',        'https://www.cisco.com/c/en/us/training-events/training-certifications/certifications/associate/ccna.html'],
      ['📡', 'CompTIA Network+',  'https://www.comptia.org/certifications/network'],
      ['🛠', 'Packet Tracer',     'https://www.netacad.com/courses/packet-tracer'],
    ],
    'planes' => [
      ['Básico',     80000,  ['OSI + TCP/IP', 'Subnetting', 'Servicios DHCP/DNS', 'Lab Packet Tracer']],
      ['Networking', 180000, ['Todo Básico', 'Ruteo avanzado', 'VLANs', 'VPN', 'Firewall']],
      ['CCNA Path',  340000, ['Todo Networking', 'SDN', 'Wireless', 'Monitoreo', 'Prep CCNA']],
    ],
  ],

  // ── IoT ──────────────────────────────────────────────────────
  [
    'id'         => 'iot',
    'ico'        => '📡',
    'categoria'  => 'Innovación',
    'titulo'     => 'IoT',
    'subtitulo'  => 'Internet de las Cosas',
    'color'      => 'orange',
    'nivel'      => 'Básico → Avanzado',
    'duracion'   => '30 – 100 h',
    'precio_base'=> 195000,
    'definicion' => 'El Internet de las Cosas (IoT) es la interconexión de objetos físicos (sensores, actuadores, electrodomésticos, vehículos) a internet para recopilar, intercambiar y procesar datos en tiempo real, creando sistemas inteligentes que automatizan entornos domésticos, industriales y urbanos.',
    'importancia'=> 'Para 2030 habrá más de 75 mil millones de dispositivos IoT conectados. Sectores como salud, manufactura, agricultura y ciudades inteligentes dependerán de profesionales capaces de diseñar ecosistemas IoT completos.',
    'conceptos'  => [
      ['🔌', 'Microcontroladores', 'Arduino, ESP32, Raspberry Pi: cerebros de los dispositivos IoT que procesan señales y ejecutan código.'],
      ['📶', 'Protocolos IoT',     'MQTT, CoAP, AMQP, HTTP/S: protocolos ligeros diseñados para comunicación eficiente entre dispositivos.'],
      ['☁️', 'Cloud IoT',         'Plataformas como AWS IoT, Azure IoT Hub y Google Cloud IoT para gestionar millones de dispositivos.'],
      ['🔒', 'Seguridad IoT',      'Desafíos únicos: autenticación de dispositivos, cifrado de datos en tránsito y en reposo, actualizaciones OTA.'],
      ['📊', 'Edge Computing',     'Procesamiento de datos en el borde de la red (near-device) para reducir latencia y ancho de banda.'],
      ['🏭', 'IIoT',              'Industrial Internet of Things: IoT aplicado a manufactura, automatización y control de procesos industriales.'],
    ],
    'parametros' => [
      'Introducción a Arduino y ESP32/ESP8266',
      'Programación en C/C++ para microcontroladores',
      'Sensores: temperatura, humedad, presión, distancia, gas',
      'Actuadores: servomotores, relés, LEDs, pantallas',
      'Protocolo MQTT: broker Mosquitto, publicar y suscribir',
      'Comunicación: WiFi, Bluetooth, Zigbee, LoRaWAN, NB-IoT',
      'Raspberry Pi: sistema operativo, GPIO, Python',
      'Dashboard con Node-RED y Grafana',
      'Integración con AWS IoT Core y Azure IoT Hub',
      'Seguridad: TLS en MQTT, autenticación X.509',
      'Edge computing con AWS Greengrass',
      'Proyectos: estación meteorológica, automatización hogar',
      'IIoT: PLC, SCADA y Modbus',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/LlhmzVL5bm8',
    'links' => [
      ['🔌', 'Arduino Docs',      'https://docs.arduino.cc'],
      ['📡', 'MQTT.org',          'https://mqtt.org'],
      ['☁️', 'AWS IoT Core',     'https://aws.amazon.com/iot-core/'],
    ],
    'planes' => [
      ['Maker',      85000,  ['Arduino básico', '5 sensores', 'MQTT intro', '3 proyectos']],
      ['Desarrollador',190000,['Todo Maker', 'ESP32 + WiFi', 'Node-RED', 'Cloud IoT', 'Dashboard']],
      ['Architect',  360000, ['Todo Desarrollador', 'IIoT', 'Edge', 'Seguridad avanzada', 'Proyecto completo']],
    ],
  ],

  // ── IA Y AUTOMATIZACIÓN ──────────────────────────────────────
  [
    'id'         => 'ia_auto',
    'ico'        => '🤖',
    'categoria'  => 'IA & Datos',
    'titulo'     => 'Automatización e IA',
    'subtitulo'  => 'Machine Learning y procesos inteligentes',
    'color'      => 'indigo',
    'nivel'      => 'Intermedio → Experto',
    'duracion'   => '40 – 180 h',
    'precio_base'=> 280000,
    'definicion' => 'La Inteligencia Artificial y la Automatización permiten que los sistemas aprendan de los datos, tomen decisiones y ejecuten tareas sin intervención humana constante. Incluye Machine Learning, Deep Learning, procesamiento de lenguaje natural (NLP), visión por computadora y automatización de procesos robóticos (RPA).',
    'importancia'=> 'La IA reemplazará el 30% de las tareas rutinarias para 2030, pero creará el doble de empleos especializados. Los ingenieros de IA son los profesionales con mayor crecimiento salarial del siglo XXI.',
    'conceptos'  => [
      ['🧠', 'Machine Learning',   'Algoritmos que aprenden patrones de datos: regresión, clasificación, clustering, reducción de dimensionalidad.'],
      ['🔗', 'Deep Learning',      'Redes neuronales profundas (CNN, RNN, Transformer) para visión, lenguaje y audio.'],
      ['💬', 'NLP',               'Procesamiento de lenguaje natural: análisis de sentimientos, traducción automática, chatbots, LLMs.'],
      ['👁', 'Visión Artificial',  'Reconocimiento de imágenes, detección de objetos (YOLO, R-CNN), segmentación semántica.'],
      ['🤖', 'RPA',               'Automatización robótica de procesos: UiPath, Automation Anywhere, n8n, Make.'],
      ['⚡', 'MLOps',             'Operacionalización de modelos ML: CI/CD para modelos, monitoreo en producción, reentrenamiento.'],
    ],
    'parametros' => [
      'Python para IA: NumPy, Pandas, Matplotlib, Seaborn',
      'Machine Learning con scikit-learn',
      'Regresión lineal, logística, árboles de decisión, SVM',
      'Ensamblados: Random Forest, Gradient Boosting, XGBoost',
      'Deep Learning con TensorFlow y PyTorch',
      'Redes CNN para clasificación de imágenes',
      'RNN y LSTM para series temporales y texto',
      'Transformers y LLMs: fine-tuning de modelos',
      'NLP: NLTK, spaCy, Hugging Face',
      'Computer Vision: OpenCV, YOLO, Detectron2',
      'MLOps: MLflow, DVC, Kubeflow',
      'APIs de IA: OpenAI, Anthropic, Google Gemini',
      'Automatización RPA: n8n, Make (Integromat)',
      'LangChain y agentes autónomos',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/aircAruvnKk',
    'links' => [
      ['🤗', 'Hugging Face',       'https://huggingface.co'],
      ['🔥', 'PyTorch Docs',       'https://pytorch.org/docs'],
      ['📊', 'scikit-learn',       'https://scikit-learn.org'],
      ['⚡', 'LangChain Docs',    'https://python.langchain.com'],
    ],
    'planes' => [
      ['ML Básico',   120000, ['Python IA', 'scikit-learn', '5 algoritmos', 'Proyecto dataset']],
      ['Deep Learning',290000,['Todo ML', 'TensorFlow/PyTorch', 'CNN+RNN', 'NLP básico', 'Deploy modelo']],
      ['IA Expert',   550000, ['Todo DL', 'LLMs', 'MLOps', 'RPA', 'Agentes IA', 'Certificado']],
    ],
  ],

  // ── CIENCIA DE DATOS ─────────────────────────────────────────
  [
    'id'         => 'ciencia_datos',
    'ico'        => '📊',
    'categoria'  => 'IA & Datos',
    'titulo'     => 'Ciencia de Datos',
    'subtitulo'  => 'Analytics, BI y estadística aplicada',
    'color'      => 'cyan',
    'nivel'      => 'Básico → Científico de Datos',
    'duracion'   => '35 – 150 h',
    'precio_base'=> 210000,
    'definicion' => 'La Ciencia de Datos es la disciplina interdisciplinaria que combina estadística, programación, visualización y conocimiento del dominio para extraer insights valiosos de grandes volúmenes de datos. Emplea el ciclo completo: recopilación, limpieza, análisis exploratorio, modelado predictivo y comunicación de resultados.',
    'importancia'=> 'Las empresas que adoptan decisiones basadas en datos tienen un 23% más de rentabilidad. El científico de datos es uno de los empleos más demandados y mejor pagados de la última década.',
    'conceptos'  => [
      ['📈', 'EDA',                'Análisis Exploratorio de Datos: estadísticas descriptivas, distribuciones, correlaciones y detección de outliers.'],
      ['🧹', 'Data Wrangling',     'Limpieza, transformación e integración de datos de múltiples fuentes para análisis.'],
      ['📉', 'Estadística',        'Probabilidad, inferencia estadística, pruebas de hipótesis, intervalos de confianza y regresiones.'],
      ['📊', 'Visualización',      'Tableau, Power BI, Matplotlib, Seaborn, Plotly: comunicar insights visualmente.'],
      ['🏭', 'Ingeniería de Datos', 'ETL/ELT, pipelines de datos, Data Lake, Data Warehouse, Apache Spark, Kafka.'],
      ['🎯', 'Business Intelligence','KPIs, dashboards ejecutivos, métricas de negocio y análisis de cohortes.'],
    ],
    'parametros' => [
      'Python para datos: Pandas, NumPy, Jupyter',
      'Estadística descriptiva e inferencial',
      'Probabilidad y distribuciones estadísticas',
      'Pruebas de hipótesis y A/B Testing',
      'EDA con Matplotlib, Seaborn, Plotly',
      'Feature engineering y selección de variables',
      'SQL avanzado para análisis de datos',
      'Power BI: modelado, DAX y dashboards',
      'Tableau: visualizaciones interactivas',
      'Apache Spark y PySpark para Big Data',
      'Pipelines de datos: Airflow, Luigi',
      'Google BigQuery y AWS Redshift',
      'Storytelling con datos y presentaciones ejecutivas',
      'Web scraping: BeautifulSoup, Scrapy, Selenium',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/X3paOmcrTjQ',
    'links' => [
      ['📊', 'Kaggle',          'https://www.kaggle.com'],
      ['📈', 'Towards Data Science','https://towardsdatascience.com'],
      ['⚡', 'Apache Spark',   'https://spark.apache.org/docs'],
    ],
    'planes' => [
      ['Analista',     95000,  ['Python datos', 'EDA', 'Power BI / Tableau', 'SQL analítico']],
      ['Data Scientist',215000,['Todo Analista', 'Estadística avanzada', 'ML integrado', 'A/B Testing', 'Proyecto completo']],
      ['Data Engineer',420000, ['Todo DS', 'Spark', 'Pipelines', 'BigQuery', 'Arquitectura de datos']],
    ],
  ],

  // ── CLOUD COMPUTING ──────────────────────────────────────────
  [
    'id'         => 'cloud',
    'ico'        => '☁️',
    'categoria'  => 'Infraestructura',
    'titulo'     => 'Cloud Computing',
    'subtitulo'  => 'AWS, Azure, GCP y arquitecturas cloud',
    'color'      => 'sky',
    'nivel'      => 'Básico → Architect',
    'duracion'   => '30 – 130 h',
    'precio_base'=> 235000,
    'definicion' => 'La computación en la nube es el modelo de entrega de recursos de TI (cómputo, almacenamiento, red, bases de datos, IA) a través de internet bajo demanda. Los tres grandes proveedores —AWS, Microsoft Azure y Google Cloud Platform— ofrecen más de 200 servicios cada uno para escalar aplicaciones globalmente.',
    'importancia'=> 'El 94% de las empresas globales usa algún servicio cloud. La migración a la nube reduce costos de infraestructura hasta un 40% y permite escalar de 10 a 10 millones de usuarios sin cambiar el código.',
    'conceptos'  => [
      ['🏗', 'IaaS/PaaS/SaaS',    'Modelos de servicio: Infraestructura, Plataforma y Software como servicio. Distintos niveles de abstracción y responsabilidad.'],
      ['📦', 'Contenedores',       'Docker y Kubernetes: empaquetado y orquestación de aplicaciones en contenedores portables.'],
      ['⚡', 'Serverless',         'AWS Lambda, Azure Functions, GCP Cloud Functions: código que se ejecuta sin gestionar servidores.'],
      ['🌐', 'CDN',               'Content Delivery Network: distribución global de contenido para baja latencia (CloudFront, Cloudflare, Akamai).'],
      ['🔒', 'Cloud Security',     'IAM, cifrado en reposo y tránsito, compliance (SOC2, ISO27001, HIPAA), Zero Trust.'],
      ['💰', 'FinOps',            'Optimización de costos cloud: Reserved Instances, Spot Instances, rightsizing y presupuestos.'],
    ],
    'parametros' => [
      'Fundamentos de cloud: regiones, zonas, servicios core',
      'AWS: EC2, S3, RDS, Lambda, VPC, IAM, CloudFront',
      'Azure: VMs, Blob Storage, AKS, Functions, Entra ID',
      'GCP: Compute Engine, GCS, BigQuery, GKE, Vertex AI',
      'Docker: imágenes, contenedores, Dockerfile, Compose',
      'Kubernetes: pods, servicios, deployments, Helm',
      'Terraform: infraestructura como código (IaC)',
      'CI/CD: GitHub Actions, GitLab CI, Jenkins, CodePipeline',
      'Serverless: arquitecturas event-driven',
      'Seguridad cloud: IAM avanzado, Security Hub, Defender',
      'Arquitecturas de alta disponibilidad y disaster recovery',
      'Microservicios y API Gateway',
      'FinOps y optimización de costos',
      'Certificaciones: AWS SAA, Azure AZ-900/AZ-104, GCP ACE',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/M988_fsOSWo',
    'links' => [
      ['☁️', 'AWS Training',        'https://aws.amazon.com/training/'],
      ['🔵', 'Microsoft Learn',     'https://learn.microsoft.com/azure'],
      ['🔴', 'Google Cloud Learn',  'https://cloud.google.com/learn'],
      ['🐳', 'Docker Docs',         'https://docs.docker.com'],
    ],
    'planes' => [
      ['Cloud Básico', 95000,  ['Fundamentos', 'AWS core (EC2+S3+RDS)', 'Docker intro', 'Deploy app']],
      ['DevOps',       245000, ['Todo Básico', 'Kubernetes', 'Terraform', 'CI/CD', 'Multi-cloud']],
      ['Architect',    490000, ['Todo DevOps', 'Alta disponibilidad', 'FinOps', 'Seguridad', 'Prep certificación']],
    ],
  ],

  // ── ESTRUCTURAS DE DATOS ──────────────────────────────────────
  [
    'id'         => 'estructuras',
    'ico'        => '🌲',
    'categoria'  => 'CS Fundamentals',
    'titulo'     => 'Estructuras de Datos',
    'subtitulo'  => 'Algoritmos y eficiencia computacional',
    'color'      => 'emerald',
    'nivel'      => 'Intermedio → Avanzado',
    'duracion'   => '25 – 90 h',
    'precio_base'=> 155000,
    'definicion' => 'Las estructuras de datos son formas organizadas de almacenar y gestionar datos en memoria para facilitar operaciones eficientes. Su correcta elección determina el rendimiento de cualquier sistema, siendo la base para entrevistas técnicas en FAANG y el desarrollo de sistemas de alto rendimiento.',
    'importancia'=> 'Google, Amazon y Meta basan sus entrevistas técnicas completamente en estructuras de datos y algoritmos. Un ingeniero que las domina resuelve problemas 10x más eficientemente que uno que no.',
    'conceptos'  => [
      ['📋', 'Arrays y Listas',    'Estructuras lineales: arrays estáticos/dinámicos, listas enlazadas simples, dobles y circulares.'],
      ['📚', 'Pilas y Colas',      'LIFO (Stack) y FIFO (Queue): fundamentales para parsing, BFS, DFS, gestión de tareas.'],
      ['🌲', 'Árboles',           'Binary Tree, BST, AVL, Red-Black Tree, Segment Tree, Fenwick Tree, Trie.'],
      ['🔗', 'Grafos',            'Representación: matriz/lista de adyacencia. Algoritmos: BFS, DFS, Dijkstra, Bellman-Ford, Floyd-Warshall.'],
      ['#️⃣', 'Hash Tables',        'Tablas hash: función de hash, manejo de colisiones (chaining, open addressing), complejidad O(1).'],
      ['⚡', 'Heaps',             'Min-Heap, Max-Heap, Priority Queue: fundamentales para algoritmos greedy y Dijkstra.'],
    ],
    'parametros' => [
      'Complejidad temporal y espacial: notación Big-O',
      'Arrays: búsqueda binaria, two pointers, sliding window',
      'Listas enlazadas: inversión, ciclos, merge',
      'Pilas: evaluación de expresiones, paréntesis',
      'Colas: BFS, deques, colas de prioridad',
      'Árboles binarios: traversals, altura, balanceo',
      'BST: búsqueda, inserción, eliminación',
      'Árboles AVL y Red-Black: rotaciones y rebalanceo',
      'Grafos: BFS, DFS, componentes conexas',
      'Grafos: Dijkstra, A*, Prim, Kruskal',
      'Hash Tables: implementación desde cero',
      'Dynamic Programming: memoización y tabulación',
      'Divide y vencerás: QuickSort, MergeSort',
      'Backtracking: N-Queens, Sudoku, permutaciones',
      'Segment Trees y Fenwick Trees',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/bum_19loj9A',
    'links' => [
      ['⚡', 'LeetCode',           'https://leetcode.com'],
      ['🎓', 'VisuAlgo',           'https://visualgo.net'],
      ['📚', 'CP-Algorithms',      'https://cp-algorithms.com'],
    ],
    'planes' => [
      ['Básico',    65000,  ['Arrays + Listas + Pilas', 'Big-O', '20 problemas LeetCode']],
      ['Intermedio',155000, ['Todo Básico', 'Árboles + Grafos', 'DP básica', '50 problemas']],
      ['FAANG Prep',300000, ['Todo Intermedio', 'Avanzado completo', '150 problemas', 'Entrevista simulada']],
    ],
  ],

  // ── SISTEMAS OPERATIVOS ──────────────────────────────────────
  [
    'id'         => 'sistemas_op',
    'ico'        => '⚙️',
    'categoria'  => 'CS Fundamentals',
    'titulo'     => 'Sistemas Operativos',
    'subtitulo'  => 'Gestión de procesos, memoria y concurrencia',
    'color'      => 'slate',
    'nivel'      => 'Intermedio → Avanzado',
    'duracion'   => '25 – 80 h',
    'precio_base'=> 145000,
    'definicion' => 'Un sistema operativo (SO) es el software fundamental que gestiona los recursos de hardware de un computador (CPU, memoria, disco, red) y proporciona servicios a las aplicaciones. Estudiar SO implica comprender cómo funcionan procesos, hilos, scheduling, memoria virtual, sistemas de archivos y sincronización.',
    'importancia'=> 'Comprender los SO permite escribir aplicaciones más eficientes, diagnosticar problemas de rendimiento, administrar servidores y desarrollar software de bajo nivel. Es esencial para DevOps, programadores de sistemas y arquitectos.',
    'conceptos'  => [
      ['⚙️', 'Procesos e Hilos',   'Gestión del ciclo de vida de procesos, hilos (threads), estados y context switching.'],
      ['🗓', 'Scheduling',         'Algoritmos de planificación de CPU: FCFS, SJF, Round Robin, Priority, Multilevel Queue.'],
      ['💾', 'Gestión de Memoria', 'Paginación, segmentación, memoria virtual, TLB, page replacement (LRU, FIFO, OPT).'],
      ['📁', 'Sistema de Archivos','FAT32, NTFS, ext4, ZFS: estructura, inodos, journaling y gestión del almacenamiento.'],
      ['🔒', 'Sincronización',     'Mutex, semáforos, monitores, deadlocks: condiciones, prevención y recuperación.'],
      ['🌐', 'I/O y Drivers',      'Subsistema de E/S, DMA, IRQ, drivers de dispositivos y gestión de periféricos.'],
    ],
    'parametros' => [
      'Arquitectura de un SO: kernel monolítico, microkernel, híbrido',
      'Llamadas al sistema (syscalls): fork, exec, wait, exit',
      'Procesos: creación, terminación, comunicación (IPC)',
      'Hilos: POSIX threads, sincronización y problemas clásicos',
      'Scheduling: análisis cuantitativo de algoritmos',
      'Memoria física: fragmentación interna y externa',
      'Memoria virtual: page tables, TLB, swapping',
      'Page replacement: LRU, Clock, Working Set',
      'Deadlock: condiciones de Coffman, grafos de asignación',
      'Sistemas de archivos: inodos, bloques, directorios',
      'RAID y almacenamiento persistente',
      'Virtualización: hipervisores tipo 1 y tipo 2, KVM, VMware',
      'Linux internals: /proc, /sys, kernel modules',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/26QPDBe-NB8',
    'links' => [
      ['🐧', 'Linux Kernel Docs',    'https://www.kernel.org/doc/'],
      ['📚', 'OSTep (Free Book)',    'https://pages.cs.wisc.edu/~remzi/OSTEP/'],
      ['⚙️', 'Geeks for Geeks OS', 'https://www.geeksforgeeks.org/operating-systems/'],
    ],
    'planes' => [
      ['Teoría',     60000,  ['Procesos + Scheduling + Memoria', 'Ejercicios teóricos']],
      ['Práctica',  150000,  ['Todo Teoría', 'Linux Internals', 'Sincronización', 'Virtualización']],
      ['Avanzado',  270000,  ['Todo Práctica', 'Kernel modules', 'Drivers', 'Proyecto SO']],
    ],
  ],

  // ── LINUX ────────────────────────────────────────────────────
  [
    'id'         => 'linux',
    'ico'        => '🐧',
    'categoria'  => 'Infraestructura',
    'titulo'     => 'Linux',
    'subtitulo'  => 'Administración de sistemas Unix/Linux',
    'color'      => 'amber',
    'nivel'      => 'Básico → SysAdmin',
    'duracion'   => '20 – 100 h',
    'precio_base'=> 165000,
    'definicion' => 'Linux es el sistema operativo más usado del mundo en servidores, supercomputadoras, dispositivos IoT y la nube. Aprender Linux significa dominar la línea de comandos, administrar servidores, automatizar tareas con Bash y gestionar la infraestructura que soporta el 90% de internet.',
    'importancia'=> 'El 96.4% de los servidores web del mundo corren Linux. Cualquier carrera en DevOps, Cloud, Seguridad o Desarrollo Backend requiere un dominio profundo de este sistema.',
    'conceptos'  => [
      ['🖥', 'Shell y CLI',         'Bash, Zsh: interfaz de línea de comandos para gestionar el sistema, automatizar y scripting.'],
      ['📁', 'Sistema de Archivos', 'Jerarquía FHS: /etc, /var, /home, /proc, /sys. Permisos, propietarios y ACLs.'],
      ['👤', 'Gestión de Usuarios', 'Creación, modificación, grupos, sudo, PAM y políticas de seguridad.'],
      ['🔧', 'Servicios y Daemons', 'systemd, service management, logs con journald, cron y at para tareas programadas.'],
      ['🌐', 'Redes en Linux',      'ip, ss, netstat, iptables, nftables, SSH, rsync, SCP.'],
      ['📦', 'Gestión de Paquetes', 'apt/dpkg (Debian/Ubuntu), dnf/rpm (RHEL/Fedora), pacman (Arch), compilación desde fuente.'],
    ],
    'parametros' => [
      'Instalación y configuración de distribuciones: Ubuntu, CentOS, Debian',
      'Comandos esenciales: ls, cd, cp, mv, rm, find, grep, awk, sed',
      'Gestión de permisos: chmod, chown, umask, ACLs',
      'Gestión de usuarios y grupos: useradd, passwd, sudoers',
      'Gestión de procesos: ps, top, htop, kill, nice, cgroups',
      'Sistema de archivos: mount, umount, df, du, lsblk, fdisk',
      'Networking: ip, ss, curl, wget, iptables, firewalld',
      'SSH: claves RSA/ED25519, configuración de servidor',
      'Bash scripting: variables, loops, funciones, pipes',
      'systemd: units, servicios, timers, journald',
      'Cron y tareas programadas',
      'Monitoring: top, sar, vmstat, iostat, Nagios, Zabbix',
      'Seguridad: SELinux, AppArmor, auditd, fail2ban',
      'LVM, RAID software, ZFS',
      'Certificaciones: LPIC-1, CompTIA Linux+, RHCSA',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/sWbUDq4S6Y8',
    'links' => [
      ['🐧', 'Linux Journey',       'https://linuxjourney.com'],
      ['📚', 'OverTheWire Bandit',  'https://overthewire.org/wargames/bandit/'],
      ['🔴', 'Red Hat Learn',       'https://www.redhat.com/en/services/training'],
    ],
    'planes' => [
      ['Básico',    70000,  ['CLI completo', 'Permisos', 'Bash scripting', 'SSH']],
      ['SysAdmin',  170000, ['Todo Básico', 'systemd', 'Redes', 'Seguridad', 'Monitoreo']],
      ['RHCSA Path',320000, ['Todo SysAdmin', 'LVM/RAID', 'SELinux', 'Prep RHCSA/LPIC']],
    ],
  ],

  // ── INGENIERÍA DE SOFTWARE ───────────────────────────────────
  [
    'id'         => 'ing_software',
    'ico'        => '🏗',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'Ingeniería de Software',
    'subtitulo'  => 'Arquitectura, calidad y proceso de desarrollo',
    'color'      => 'violet',
    'nivel'      => 'Intermedio → Arquitecto',
    'duracion'   => '30 – 120 h',
    'precio_base'=> 200000,
    'definicion' => 'La Ingeniería de Software es la disciplina que aplica principios de ingeniería al diseño, desarrollo, prueba y mantenimiento de software. Abarca todo el ciclo de vida del software (SDLC), metodologías ágiles, arquitecturas de software, aseguramiento de calidad y gestión de proyectos tecnológicos.',
    'importancia'=> 'El 70% de los proyectos de software fallan por mala gestión y diseño deficiente. Un ingeniero de software formado construye sistemas que escalan, se mantienen y entregan valor real al negocio.',
    'conceptos'  => [
      ['🔄', 'SDLC',              'Ciclo de vida del software: planificación, análisis, diseño, implementación, pruebas, despliegue y mantenimiento.'],
      ['🏃', 'Ágil / Scrum',      'Metodología iterativa con sprints, daily standups, product backlog y retrospectivas.'],
      ['🏛', 'Arquitecturas',     'Monolítica, microservicios, event-driven, hexagonal, CQRS, serverless y sus trade-offs.'],
      ['✅', 'QA y Testing',      'Unit testing, integration testing, E2E, TDD, BDD, performance testing y cobertura de código.'],
      ['🔄', 'DevOps',            'Cultura, prácticas y herramientas que unifican desarrollo y operaciones para entrega continua.'],
      ['📐', 'Clean Architecture', 'Principios SOLID, Clean Code, DRY, KISS, YAGNI aplicados a sistemas reales.'],
    ],
    'parametros' => [
      'SDLC: cascada, Agile, iterativo, espiral',
      'Scrum: roles, ceremonias, artefactos',
      'Kanban: tableros, WIP limits, métricas de flujo',
      'Requisitos: casos de uso, historias de usuario, DDD',
      'Diseño: UML, diagramas de secuencia y estado',
      'Arquitecturas: Clean Architecture, Hexagonal, MVC, MVVM',
      'Microservicios: diseño, comunicación y orquestación',
      'Event-Driven: eventos de dominio, CQRS, Event Sourcing',
      'Testing: pirámide de pruebas, TDD, BDD con Cucumber',
      'DevOps: pipelines CI/CD, Infrastructure as Code',
      'Gestión de deuda técnica y refactoring',
      'Métricas de calidad: DORA, SLO/SLA, NPS técnico',
      'Gestión de proyectos: PMI, planificación y estimación',
      'Code Review y pair programming',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/Y-LgmR302kc',
    'links' => [
      ['📘', 'Clean Code (Martin)', 'https://www.goodreads.com/book/show/3735293-clean-code'],
      ['🏃', 'Agile Manifesto',    'https://agilemanifesto.org'],
      ['🔄', 'DevOps Roadmap',     'https://roadmap.sh/devops'],
    ],
    'planes' => [
      ['Fundamentos', 85000,  ['SDLC', 'Scrum/Kanban', 'UML', 'Clean Code']],
      ['Arquitecto',  205000, ['Todo Fundamentos', 'Microservicios', 'Testing', 'DevOps', 'Proyecto']],
      ['Senior Dev',  400000, ['Todo Arquitecto', 'Event-Driven', 'DDD', 'Liderazgo técnico', 'Mentoría']],
    ],
  ],

  // ── SISTEMAS TRANSACCIONALES ──────────────────────────────────
  [
    'id'         => 'transaccionales',
    'ico'        => '💳',
    'categoria'  => 'Sistemas',
    'titulo'     => 'Sistemas Transaccionales',
    'subtitulo'  => 'Procesamiento de transacciones críticas',
    'color'      => 'green',
    'nivel'      => 'Avanzado',
    'duracion'   => '30 – 100 h',
    'precio_base'=> 230000,
    'definicion' => 'Los sistemas transaccionales (OLTP) son plataformas de software diseñadas para gestionar operaciones de negocio en tiempo real con altísima disponibilidad, consistencia y durabilidad. Son el núcleo de la banca digital, e-commerce, reservas y cualquier sistema que no puede permitirse perder datos.',
    'importancia'=> 'Un banco procesa millones de transacciones diariamente. Un fallo de 1 hora puede costar decenas de millones. Diseñar sistemas transaccionales robustos es una de las habilidades más valoradas y mejor remuneradas de la industria.',
    'conceptos'  => [
      ['💾', 'ACID',              'Atomicidad, Consistencia, Aislamiento y Durabilidad: propiedades que garantizan la integridad transaccional.'],
      ['🔒', 'Concurrencia',      'Control de acceso simultáneo: locking optimista/pesimista, MVCC y niveles de aislamiento SQL.'],
      ['📦', 'Sagas',            'Patrón para transacciones distribuidas en microservicios: coreografía y orquestación de compensaciones.'],
      ['📨', 'Mensajería',        'RabbitMQ, Kafka, SQS: comunicación asíncrona garantizada para desacoplar servicios críticos.'],
      ['⚡', 'Rendimiento',       'Optimización de queries, índices, connection pooling, caching con Redis y particionamiento.'],
      ['🔄', 'Alta Disponibilidad','Replicación, failover automático, circuit breakers y estrategias de recuperación ante desastres.'],
    ],
    'parametros' => [
      'Fundamentos ACID y modelos de consistencia',
      'Niveles de aislamiento: Read Uncommitted, Read Committed, Repeatable Read, Serializable',
      'Locking: shared locks, exclusive locks, deadlock detection',
      'MVCC en PostgreSQL y MySQL InnoDB',
      'Diseño de esquemas para OLTP: normalización extrema',
      'Stored procedures, triggers y restricciones',
      'Mensajería transaccional: RabbitMQ, Kafka',
      'Outbox Pattern y exactly-once semantics',
      'Sagas: coreografía vs orquestación',
      'Connection pooling: PgBouncer, HikariCP',
      'Caching transaccional: Redis + LUA scripts',
      'Idempotencia y reintentos seguros',
      'Monitoreo: alertas, métricas y trazabilidad distribuida',
      'Pasarelas de pago: Stripe, PayU, Wompi APIs',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/5ZjhNTM8XU8',
    'links' => [
      ['💳', 'Stripe Docs',        'https://stripe.com/docs'],
      ['📨', 'Kafka Docs',         'https://kafka.apache.org/documentation/'],
      ['🐘', 'PostgreSQL MVCC',    'https://www.postgresql.org/docs/current/mvcc.html'],
    ],
    'planes' => [
      ['Fundamentos', 95000,  ['ACID + Transacciones', 'Locking + MVCC', 'Diseño OLTP']],
      ['Sistemas Pro', 235000, ['Todo Fundamentos', 'Mensajería', 'Sagas', 'Caching', 'Alta disponibilidad']],
      ['Enterprise',   450000, ['Todo Pro', 'Pasarelas de pago', 'PCI DSS', 'Auditoría', 'Proyecto bancario']],
    ],
  ],

  // ── MATEMÁTICAS ──────────────────────────────────────────────
  [
    'id'         => 'matematicas',
    'ico'        => '📐',
    'categoria'  => 'Ciencias',
    'titulo'     => 'Matemáticas para TI',
    'subtitulo'  => 'Fundamentos matemáticos del cómputo',
    'color'      => 'rose',
    'nivel'      => 'Básico → Avanzado',
    'duracion'   => '20 – 120 h',
    'precio_base'=> 130000,
    'definicion' => 'Las matemáticas son el lenguaje universal de la informática. Álgebra lineal, cálculo, estadística, matemáticas discretas y teoría de grafos son la base de la IA, la criptografía, los algoritmos y los gráficos por computadora. Sin matemáticas sólidas no hay ingeniería de software de alto nivel.',
    'importancia'=> 'Álgebra lineal es la base de deep learning. La estadística sustenta la ciencia de datos. La criptografía nace de la teoría de números. Matemáticas = poder para resolver problemas que el resto no puede.',
    'conceptos'  => [
      ['➕', 'Álgebra Lineal',    'Vectores, matrices, transformaciones lineales, espacios vectoriales, autovalores: corazón del Machine Learning.'],
      ['📉', 'Cálculo',           'Derivadas, gradientes, integrales: optimización de funciones de costo en redes neuronales.'],
      ['📊', 'Estadística y Prob.','Distribuciones, inferencia, máxima verosimilitud, bayesianismo: fundamentos de ML y ciencia de datos.'],
      ['🔢', 'Matemáticas Discretas','Lógica proposicional, teoría de conjuntos, combinatoria, grafos y recurrencias.'],
      ['🔒', 'Teoría de Números', 'Aritmética modular, números primos, RSA: base de la criptografía moderna.'],
      ['📐', 'Geometría Computacional','Convex Hull, triangulación, intersección de segmentos: gráficos y visión artificial.'],
    ],
    'parametros' => [
      'Álgebra lineal: vectores, matrices, determinantes',
      'Transformaciones lineales y espacios vectoriales',
      'Autovalores y autovectores (PCA, SVD)',
      'Cálculo diferencial: derivadas y regla de la cadena',
      'Gradiente, gradiente descendente y optimización',
      'Probabilidad: variables aleatorias y distribuciones',
      'Estadística inferencial: estimación y pruebas de hipótesis',
      'Matemáticas discretas: lógica y teoría de conjuntos',
      'Combinatoria: permutaciones, combinaciones, principio de inclusión-exclusión',
      'Teoría de grafos: caminos, ciclos, árboles, coloración',
      'Recurrencias y inducción matemática',
      'Teoría de números: módulo, primos, criptografía RSA',
      'Geometría computacional básica',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1509228468518-180dd4864904?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/fNk_zzaMoSs',
    'links' => [
      ['📐', '3Blue1Brown',       'https://www.3blue1brown.com'],
      ['📊', 'Khan Academy Mate', 'https://www.khanacademy.org/math'],
      ['📚', 'MIT OpenCourseWare','https://ocw.mit.edu/courses/mathematics/'],
    ],
    'planes' => [
      ['Básico',    55000,  ['Álgebra lineal', 'Estadística básica', 'Matemáticas discretas']],
      ['IA Math',   135000, ['Todo Básico', 'Cálculo + optimización', 'Probabilidad avanzada']],
      ['Experto',   255000, ['Todo IA Math', 'Teoría de números', 'Geometría computacional', 'Proyecto]']],
    ],
  ],

  // ── VIDEOJUEGOS ───────────────────────────────────────────────
  [
    'id'         => 'videojuegos',
    'ico'        => '🎮',
    'categoria'  => 'Creativo',
    'titulo'     => 'Desarrollo de Videojuegos',
    'subtitulo'  => 'Unity, Unreal y game design',
    'color'      => 'pink',
    'nivel'      => 'Básico → Pro',
    'duracion'   => '40 – 160 h',
    'precio_base'=> 210000,
    'definicion' => 'El desarrollo de videojuegos combina programación, arte, diseño de niveles, música y narrativa para crear experiencias interactivas. Las industrias de videojuegos y gamificación empresarial son mercados de más de $200 mil millones anuales con altísima demanda de desarrolladores.',
    'importancia'=> 'Los videojuegos son la industria de entretenimiento más grande del planeta, superando al cine y la música juntos. La gamificación empresarial, el metaverso y la realidad virtual abren mercados adicionales enormes.',
    'conceptos'  => [
      ['🎮', 'Game Loop',         'Ciclo fundamental Update/Render que mantiene el juego corriendo a 30-120 FPS.'],
      ['🎨', 'Game Design',       'Mecánicas, dinámicas, experiencia de jugador, balanceo y economía del juego.'],
      ['🧮', 'Física de Juegos',  'Rigidbodies, colisiones, gravedad, ragdoll: simulación física en tiempo real.'],
      ['🤖', 'IA en Juegos',      'Máquinas de estado, árboles de comportamiento, pathfinding A*, GOAP.'],
      ['🖼', 'Gráficos 3D',       'Render pipeline, shaders, materiales, iluminación PBR, LOD, post-processing.'],
      ['📱', 'Mobile Gaming',     'Optimización para móvil, monetización freemium, ads, IAP y stores.'],
    ],
    'parametros' => [
      'Unity 3D: escenas, GameObjects, componentes',
      'C# en Unity: scripts, coroutines, eventos',
      'Física: Rigidbodies, Colliders, Triggers',
      'Animación: Animator, blend trees, IK',
      'UI: Canvas, TextMesh Pro, HUD',
      'Audio: AudioSource, mixer, reverb zones',
      'Pathfinding: NavMesh, A* manual',
      'IA: State Machines, Behavior Trees',
      'Shaders con Shader Graph y HLSL',
      'Multiplayer: Unity Netcode, Mirror, Photon',
      'Unreal Engine 5: Blueprints y C++',
      'Nanite, Lumen y MetaHuman',
      'Monetización: Unity Ads, IAP, Analytics',
      'Publicación en Steam, Play Store, App Store',
      'VR/AR: Oculus SDK, ARFoundation',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/gB1F9G0JXOo',
    'links' => [
      ['🎮', 'Unity Learn',        'https://learn.unity.com'],
      ['🔵', 'Unreal Docs',        'https://docs.unrealengine.com'],
      ['📐', 'GDC Talks',          'https://www.gdcvault.com/free'],
    ],
    'planes' => [
      ['Indie Maker',  90000,  ['Unity básico', 'Física + UI', 'Juego 2D completo', 'Publicación']],
      ['Game Dev',    215000,  ['Todo Indie', '3D completo', 'IA + Multiplayer', 'Shader básico']],
      ['Studio Pro',  420000,  ['Todo Game Dev', 'Unreal 5', 'VR/AR', 'Monetización', 'Portfolio']],
    ],
  ],

  // ── DESARROLLO MÓVIL ──────────────────────────────────────────
  [
    'id'         => 'mobile',
    'ico'        => '📱',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'Desarrollo Móvil',
    'subtitulo'  => 'Android, iOS y multiplataforma',
    'color'      => 'blue',
    'nivel'      => 'Básico → Senior',
    'duracion'   => '40 – 150 h',
    'precio_base'=> 220000,
    'definicion' => 'El desarrollo móvil abarca la creación de aplicaciones para dispositivos Android e iOS. Puede ser nativo (Kotlin/Java para Android, Swift para iOS), multiplataforma (Flutter, React Native, Xamarin) o híbrido (Ionic, Capacitor). El mercado móvil supera los $500 mil millones anuales.',
    'importancia'=> 'El 60% del tráfico de internet viene de dispositivos móviles. Una app bien diseñada puede alcanzar millones de usuarios en días. La demanda de desarrolladores móviles supera la oferta en Latinoamérica.',
    'conceptos'  => [
      ['🤖', 'Android (Kotlin)',   'Lenguaje oficial de Android: coroutines, Jetpack Compose, ViewModel, Room, Retrofit.'],
      ['🍎', 'iOS (Swift)',        'Lenguaje de Apple: SwiftUI, UIKit, Combine, CoreData, ARKit, CloudKit.'],
      ['💙', 'Flutter/Dart',       'SDK de Google para apps nativas multiplataforma con un solo codebase en Dart.'],
      ['⚛️', 'React Native',      'Framework de Meta para apps móviles usando React y JavaScript/TypeScript.'],
      ['🏪', 'App Stores',        'Publicación en Google Play Store y Apple App Store: revisión, metadata y monetización.'],
      ['📊', 'Analytics Móvil',   'Firebase Analytics, Mixpanel, Amplitude: entender el comportamiento del usuario.'],
    ],
    'parametros' => [
      'Kotlin: sintaxis, coroutines, extensions, sealed classes',
      'Android: Activities, Fragments, ViewModel, LiveData',
      'Jetpack Compose: UI declarativa en Android',
      'Swift: Optionals, closures, protocolos, generics',
      'SwiftUI: vistas, bindings, environment, animations',
      'Flutter: widgets, state management (Riverpod, Bloc)',
      'React Native: componentes, navegación, native modules',
      'Arquitecturas móviles: MVVM, Clean Architecture',
      'Persistencia: Room, CoreData, SQLite, Shared Preferences',
      'Redes: Retrofit, Ktor, URLSession, Axios',
      'Notificaciones push: FCM, APNS',
      'Autenticación: Firebase Auth, OAuth2 social login',
      'Pagos en app: Google Pay, Apple Pay, Stripe',
      'Testing móvil: Espresso, XCTest, Detox',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/fis26HvvDII',
    'links' => [
      ['🤖', 'Android Developers',  'https://developer.android.com/docs'],
      ['🍎', 'Swift Docs',          'https://swift.org/documentation/'],
      ['💙', 'Flutter Docs',        'https://flutter.dev/docs'],
    ],
    'planes' => [
      ['Android/iOS',  95000,  ['Un sistema nativo', 'Navegación + Listas + Redes', 'App completa']],
      ['Full Mobile',  225000, ['Android + iOS', 'Flutter', 'Firebase', 'Publicación real']],
      ['Mobile Senior',430000, ['Todo Full Mobile', 'Arquitectura limpia', 'Testing', 'Mentoría']],
    ],
  ],

  // ── TEORÍA DE LA COMPUTACIÓN ──────────────────────────────────
  [
    'id'         => 'teoria_comp',
    'ico'        => '🧮',
    'categoria'  => 'CS Fundamentals',
    'titulo'     => 'Teoría de la Computación',
    'subtitulo'  => 'Autómatas, lenguajes formales y computabilidad',
    'color'      => 'slate',
    'nivel'      => 'Avanzado',
    'duracion'   => '20 – 80 h',
    'precio_base'=> 135000,
    'definicion' => 'La teoría de la computación estudia los fundamentos matemáticos de los computadores: qué problemas pueden resolverse algorítmicamente, qué tan eficientemente, y cuáles son los límites intrínsecos de la computación. Incluye autómatas, lenguajes formales, computabilidad y complejidad computacional.',
    'importancia'=> 'Sin teoría de la computación no existirían los compiladores, los algoritmos de compresión, la criptografía, ni los sistemas de IA actuales. Es la base de toda la informática teórica y aplicada.',
    'conceptos'  => [
      ['🤖', 'Autómatas',          'Autómatas finitos deterministas (AFD) y no deterministas (AFN): modelos de cómputo para lenguajes regulares.'],
      ['📝', 'Gramáticas Formales', 'Jerarquía de Chomsky: regulares, libres de contexto, sensibles al contexto y sin restricciones.'],
      ['⚙️', 'Máquinas de Turing', 'Modelo teórico de computación universal que define qué problemas son computables.'],
      ['📊', 'Complejidad',        'Clases P, NP, NP-completo, NP-difícil: clasificación de problemas por su dificultad computacional.'],
      ['🔒', 'Computabilidad',     'Tesis de Church-Turing, problema de la parada, reducción y indecidibilidad.'],
      ['📐', 'Compiladores',       'Análisis léxico, sintáctico (parsers), semántico, optimización y generación de código.'],
    ],
    'parametros' => [
      'Autómatas finitos deterministas y no deterministas',
      'Construcción de subsets (AFN → AFD)',
      'Expresiones regulares y su conexión con autómatas',
      'Gramáticas libres de contexto (GLC)',
      'Autómatas de pila (AP) y lenguajes libres de contexto',
      'Máquinas de Turing: diseño y análisis',
      'Tesis de Church-Turing',
      'Problema de la parada y reducción',
      'Lenguajes recursivamente enumerables y recursivos',
      'Complejidad temporal: P vs NP',
      'Problemas NP-completos: SAT, 3-SAT, TSP, clique',
      'Clases de complejidad: PSPACE, EXPTIME, #P',
      'Construcción de lexers con expresiones regulares',
      'Parsers: LL(1), LR(0), SLR(1), LALR(1)',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/9syvZr-9xwk',
    'links' => [
      ['📚', 'JFLAP Tool',           'https://www.jflap.org'],
      ['🎓', 'MIT 6.045 TCS',        'https://ocw.mit.edu'],
      ['📖', 'Sipser - Intro to TOC', 'https://www.amazon.com/Introduction-Theory-Computation-Michael-Sipser/dp/113318779X'],
    ],
    'planes' => [
      ['Autómatas',  60000,  ['AFD/AFN', 'Gramáticas', 'Expresiones regulares', 'JFLAP']],
      ['Completo',   140000, ['Todo Autómatas', 'Turing', 'P vs NP', 'Reducción', 'Proyecto compilador']],
    ],
  ],

  // ── DESARROLLO EN PLATAFORMAS ─────────────────────────────────
  [
    'id'         => 'plataformas',
    'ico'        => '🏢',
    'categoria'  => 'Desarrollo',
    'titulo'     => 'Desarrollo en Plataformas',
    'subtitulo'  => 'Shopify, Salesforce, SAP, WordPress',
    'color'      => 'gold',
    'nivel'      => 'Básico → Certified',
    'duracion'   => '20 – 100 h',
    'precio_base'=> 175000,
    'definicion' => 'El desarrollo basado en plataformas consiste en personalizar, extender y construir sobre plataformas existentes de alto valor empresarial: CMS como WordPress, e-commerce como Shopify, CRM como Salesforce, ERP como SAP, y low-code como Power Platform o Appian. Permite entregar soluciones rápidamente sin construir desde cero.',
    'importancia'=> 'El 43% de todos los sitios web del mundo usan WordPress. Salesforce tiene más de 150,000 clientes empresariales. Un desarrollador certificado en estas plataformas tiene acceso inmediato a proyectos de alto valor.',
    'conceptos'  => [
      ['📝', 'WordPress',          'CMS más usado del mundo: temas, plugins, WooCommerce, Gutenberg, REST API y Headless WordPress.'],
      ['🛒', 'Shopify',            'Plataforma e-commerce: Liquid templates, Shopify Apps, Storefront API, Checkout extensibility.'],
      ['🔵', 'Salesforce',         'CRM líder: Apex, LWC, Flow, SOQL, declarative tools, integraciones y certificaciones.'],
      ['⚡', 'Power Platform',     'Microsoft low-code: Power Apps, Power Automate, Power BI, Dataverse.'],
      ['🏭', 'SAP',               'ERP empresarial: módulos FI, MM, SD; ABAP básico e integraciones SAP BTP.'],
      ['🔧', 'Low-Code/No-Code',   'Bubble, Webflow, Adalo, AppGyver: creación rápida de aplicaciones sin programación profunda.'],
    ],
    'parametros' => [
      'WordPress: instalación, temas child, hooks, filtros',
      'Desarrollo de plugins WordPress en PHP',
      'WooCommerce: tienda, pasarela de pago, inventario',
      'Shopify: Liquid, secciones, metafields, apps',
      'Shopify Partner: publicación en App Store',
      'Salesforce: configuración, Apex, LWC, Flow Builder',
      'Salesforce Admin + Developer certifications path',
      'Power Apps: canvas apps, model-driven apps',
      'Power Automate: flujos de automatización',
      'Power BI: datasources, DAX, dashboards',
      'SAP Fiori y SAP BTP fundamentos',
      'Webflow: diseño sin código con CMS',
      'Integraciones: Zapier, Make, APIs REST',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/jGBnCMWEOf8',
    'links' => [
      ['📝', 'WordPress Developer', 'https://developer.wordpress.org'],
      ['🛒', 'Shopify Dev',         'https://shopify.dev'],
      ['🔵', 'Salesforce Trailhead','https://trailhead.salesforce.com'],
    ],
    'planes' => [
      ['WordPress',   70000,  ['WordPress completo', 'WooCommerce', 'Plugin básico', 'Deploy']],
      ['E-Commerce',  175000, ['Todo WP', 'Shopify', 'Salesforce básico', 'Integraciones']],
      ['Enterprise',  350000, ['Todo E-Commerce', 'Salesforce certificado', 'Power Platform', 'SAP']],
    ],
  ],

  // ── FÍSICA COMPUTACIONAL ──────────────────────────────────────
  [
    'id'         => 'fisica',
    'ico'        => '⚛️',
    'categoria'  => 'Ciencias',
    'titulo'     => 'Física Computacional',
    'subtitulo'  => 'Simulación y modelado numérico',
    'color'      => 'cyan',
    'nivel'      => 'Avanzado',
    'duracion'   => '30 – 100 h',
    'precio_base'=> 170000,
    'definicion' => 'La física computacional aplica métodos numéricos y algoritmos para resolver problemas físicos que no tienen solución analítica. Incluye simulación de sistemas dinámicos, mecánica cuántica computacional, dinámica de fluidos, electromagnetismo numérico y modelado de partículas.',
    'importancia'=> 'La física computacional impulsa los avances en meteorología, diseño aeroespacial, semiconductores, energía nuclear y biotecnología. Es esencial para ingenieros que trabajan en simulación científica de alto rendimiento.',
    'conceptos'  => [
      ['📐', 'Métodos Numéricos',   'Diferencias finitas, elementos finitos, integración numérica, interpolación y optimización numérica.'],
      ['🌊', 'Dinámica de Fluidos', 'CFD (Computational Fluid Dynamics): ecuaciones de Navier-Stokes discretizadas.'],
      ['⚛️', 'Mecánica Cuántica',  'DFT (Density Functional Theory), Hartree-Fock, simulación de sistemas cuánticos.'],
      ['🔮', 'Monte Carlo',        'Métodos estocásticos para simulación de sistemas complejos y cálculo de integrales.'],
      ['🧬', 'Dinámica Molecular',  'Simulación del movimiento de átomos y moléculas usando potenciales de interacción.'],
      ['💻', 'HPC',               'High Performance Computing: MPI, OpenMP, GPU computing con CUDA para cálculo paralelo.'],
    ],
    'parametros' => [
      'Python científico: NumPy, SciPy, Matplotlib',
      'Ecuaciones diferenciales ordinarias (EDO): RK4, Adams',
      'Ecuaciones en derivadas parciales (EDP): método de diferencias finitas',
      'Álgebra lineal numérica: sistemas, autovalores',
      'Transformada de Fourier discreta (DFT/FFT)',
      'Monte Carlo: integración y simulación estadística',
      'Dinámica molecular con LAMMPS',
      'CFD básico: simulación de flujo de Poiseuille',
      'Mecánica cuántica: niveles de energía, barrera túnel',
      'Paralelismo con OpenMP y MPI',
      'CUDA: programación GPU con Python (CuPy)',
      'Visualización científica: VTK, ParaView, Mayavi',
    ],
    'foto'  => 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=800&q=80',
    'video' => 'https://www.youtube.com/embed/4i7GrHHhvFk',
    'links' => [
      ['🔬', 'SciPy Docs',      'https://docs.scipy.org'],
      ['⚛️', 'LAMMPS',         'https://www.lammps.org'],
      ['🖥', 'CUDA Docs',       'https://docs.nvidia.com/cuda/'],
    ],
    'planes' => [
      ['Métodos Numéricos', 70000,  ['EDO/EDP', 'Monte Carlo', 'Python científico']],
      ['Simulación',        170000, ['Todo MN', 'CFD básico', 'Dinámica molecular', 'GPU intro']],
      ['HPC Avanzado',      330000, ['Todo Simulación', 'MPI/OpenMP', 'CUDA', 'Proyecto HPC']],
    ],
  ],

];

// Categorías únicas para filtro
$categorias_unicas = array_unique(array_column($servicios, 'categoria'));
sort($categorias_unicas);

// Mapa de colores CSS
$color_map = [
  'green'  => ['rgba(40,166,128,.14)',  'rgba(40,166,128,.5)',  '#35d4a8'],
  'blue'   => ['rgba(59,130,246,.14)',  'rgba(59,130,246,.5)',  '#93c5fd'],
  'purple' => ['rgba(139,92,246,.14)', 'rgba(139,92,246,.5)',  '#c4b5fd'],
  'gold'   => ['rgba(218,165,32,.14)', 'rgba(218,165,32,.5)',  '#f0c840'],
  'red'    => ['rgba(239,68,68,.14)',  'rgba(239,68,68,.5)',   '#fca5a5'],
  'teal'   => ['rgba(20,184,166,.14)', 'rgba(20,184,166,.5)',  '#5eead4'],
  'orange' => ['rgba(249,115,22,.14)', 'rgba(249,115,22,.5)',  '#fdba74'],
  'indigo' => ['rgba(99,102,241,.14)', 'rgba(99,102,241,.5)',  '#a5b4fc'],
  'cyan'   => ['rgba(6,182,212,.14)',  'rgba(6,182,212,.5)',   '#67e8f9'],
  'emerald'=> ['rgba(16,185,129,.14)', 'rgba(16,185,129,.5)',  '#6ee7b7'],
  'slate'  => ['rgba(100,116,139,.14)','rgba(100,116,139,.5)', '#94a3b8'],
  'amber'  => ['rgba(245,158,11,.14)', 'rgba(245,158,11,.5)',  '#fde68a'],
  'violet' => ['rgba(124,58,237,.14)', 'rgba(124,58,237,.5)',  '#c4b5fd'],
  'rose'   => ['rgba(244,63,94,.14)',  'rgba(244,63,94,.5)',   '#fda4af'],
  'pink'   => ['rgba(236,72,153,.14)', 'rgba(236,72,153,.5)',  '#f9a8d4'],
  'sky'    => ['rgba(14,165,233,.14)', 'rgba(14,165,233,.5)',  '#7dd3fc'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Servicios — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ════════════════════════════════════════════════════════════
       VARIABLES & RESET — Fuente única: Syne
    ════════════════════════════════════════════════════════════ */
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;--n400:#243450;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --red:#ef4444;--red-dim:rgba(239,68,68,.12);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --sh-sm:0 4px 18px rgba(0,0,0,.35);--sh-md:0 10px 36px rgba(0,0,0,.5);--sh-lg:0 24px 64px rgba(0,0,0,.6);
      --r-sm:8px;--r-md:14px;--r-lg:22px;--r-xl:32px;
      --font:'Syne',sans-serif;--hh:68px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font);background:var(--n900);color:var(--txt);overflow-x:hidden;}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);} ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;} button{cursor:pointer;border:none;font-family:var(--font);}

    /* ══ HEADER ═══════════════════════════════════════════════ */
    .site-header{position:sticky;top:0;z-index:900;height:var(--hh);background:rgba(2,8,23,.92);backdrop-filter:blur(20px);border-bottom:1px solid rgba(40,166,128,.2);transition:box-shadow .3s;}
    .site-header.hdr-on{box-shadow:0 4px 40px rgba(0,0,0,.65);border-bottom-color:rgba(218,165,32,.25);}
    .header-inner{max-width:1480px;margin:auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 28px;}
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-hex{font-size:1.5rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green));}
    .brand-name{font-size:1.45rem;font-weight:900;color:var(--gold);letter-spacing:4px;text-shadow:0 0 18px rgba(218,165,32,.5);}
    .main-nav{display:flex;align-items:center;gap:4px;}
    .nav-link{padding:8px 15px;border-radius:var(--r-sm);font-weight:600;font-size:.9rem;color:var(--muted);transition:all .2s;}
    .nav-link:hover,.nav-link.active{color:var(--txt);background:rgba(255,255,255,.06);}
    .nav-link.active{color:var(--green-lt);border-bottom:2px solid var(--green);}
    .nav-cta{margin-left:12px;padding:9px 20px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.88rem;transition:all .2s;}
    .nav-cta:hover{background:var(--gold);transform:translateY(-2px);}
    .user-wrap{position:relative;margin-left:12px;}
    .user-pill{display:flex;align-items:center;gap:8px;padding:8px 16px;background:var(--green-dim);border:1px solid var(--green);border-radius:99px;color:var(--txt);font-weight:600;font-size:.88rem;transition:background .2s;}
    .user-drop{display:none;position:absolute;right:0;top:calc(100% + 10px);background:var(--n600);border:1px solid rgba(255,255,255,.08);border-radius:var(--r-md);min-width:200px;overflow:hidden;box-shadow:var(--sh-md);z-index:200;}
    .user-wrap:hover .user-drop{display:block;}
    .user-drop a{display:flex;align-items:center;gap:10px;padding:12px 16px;font-size:.88rem;color:var(--txt);transition:background .2s;}
    .user-drop a:hover{background:rgba(255,255,255,.06);}
    .drop-danger{color:#f87171 !important;}
    .burger{display:none;flex-direction:column;gap:5px;padding:8px;background:none;}
    .burger span{display:block;width:24px;height:2px;background:var(--txt);border-radius:99px;transition:transform .3s,opacity .3s;}
    .burger-x span:nth-child(1){transform:translateY(7px) rotate(45deg);}
    .burger-x span:nth-child(2){opacity:0;}
    .burger-x span:nth-child(3){transform:translateY(-7px) rotate(-45deg);}

    /* ══ HERO ══════════════════════════════════════════════════ */
    .sv-hero{
      position:relative;padding:60px 28px 48px;text-align:center;
      background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,var(--n900) 70%);
      border-bottom:1px solid rgba(40,166,128,.15);overflow:hidden;
    }
    .sv-hero-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:52px 52px;}
    .sv-orb{position:absolute;border-radius:50%;filter:blur(90px);}
    .so1{width:450px;height:450px;background:radial-gradient(circle,rgba(40,166,128,.15),transparent 70%);top:-120px;left:-80px;animation:orbf 9s ease-in-out infinite;}
    .so2{width:350px;height:350px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-60px;right:-40px;animation:orbf 11s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}
    .sv-hero-content{position:relative;z-index:1;max-width:780px;margin:auto;}
    .sv-hero-tag{display:inline-block;padding:4px 14px;background:var(--green-dim);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.75rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:16px;}
    .sv-hero h1{font-size:clamp(1.8rem,3.5vw,3.2rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:10px;}
    .sv-hero h1 span{color:var(--gold);text-shadow:0 0 28px rgba(218,165,32,.4);}
    .sv-hero p{font-size:.95rem;color:var(--muted);line-height:1.7;margin-bottom:20px;}
    .sv-hero-stats{display:inline-flex;align-items:center;gap:20px;padding:14px 28px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);}
    .hstat{text-align:center;}
    .hstat-n{display:block;font-size:1.8rem;font-weight:900;color:var(--gold);}
    .hstat-l{font-size:.68rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;}
    .hstat-div{width:1px;height:32px;background:rgba(255,255,255,.1);}

    /* ══ CONTROLES ════════════════════════════════════════════ */
    .sv-controls{
      max-width:1480px;margin:0 auto;padding:28px 28px 0;
      display:flex;align-items:center;gap:12px;flex-wrap:wrap;
    }
    .sv-search-wrap{display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-lg);padding:9px 16px;flex:1;max-width:360px;}
    .sv-search-wrap i{color:var(--muted);flex-shrink:0;}
    .sv-search-wrap input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font);font-size:.88rem;width:100%;}
    .sv-search-wrap input::placeholder{color:var(--dim);}
    .cat-chips{display:flex;gap:6px;flex-wrap:wrap;flex:1;}
    .cat-chip{padding:6px 14px;border-radius:99px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.78rem;font-weight:600;cursor:pointer;transition:all .2s;font-family:var(--font);}
    .cat-chip:hover{background:rgba(255,255,255,.1);color:var(--txt);}
    .cat-chip.on{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}
    .view-toggle{display:flex;gap:4px;background:rgba(255,255,255,.05);padding:3px;border-radius:var(--r-sm);}
    .vt-btn{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.82rem;color:var(--muted);cursor:pointer;transition:all .2s;background:none;}
    .vt-btn.on{background:var(--green);color:#fff;}

    /* ══ GRID DE SERVICIOS ════════════════════════════════════ */
    .sv-layout{max-width:1480px;margin:0 auto;padding:28px;}
    .sv-count{font-size:.8rem;color:var(--muted);margin-bottom:16px;}
    .sv-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;transition:all .3s;}
    .sv-grid.list-view{grid-template-columns:1fr;}

    /* ══ TARJETA DE SERVICIO ══════════════════════════════════ */
    .sv-card{
      background:var(--n700);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);overflow:hidden;cursor:pointer;
      transition:transform .25s,border-color .25s,box-shadow .25s;
      animation:cardIn .4s ease both;
    }
    @keyframes cardIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
    .sv-card:hover{transform:translateY(-6px);box-shadow:var(--sh-md);}
    .sv-card.hidden{display:none;}

    .sv-card-banner{
      height:80px;position:relative;overflow:hidden;
      display:flex;align-items:center;justify-content:center;
    }
    .sv-card-banner-grid{
      position:absolute;inset:0;
      background-image:linear-gradient(rgba(255,255,255,.04) 1px,transparent 1px),
                       linear-gradient(90deg,rgba(255,255,255,.04) 1px,transparent 1px);
      background-size:18px 18px;
    }
    .sv-card-ico-big{font-size:2.5rem;position:relative;z-index:1;}
    .sv-card-cat-badge{
      position:absolute;top:8px;right:8px;z-index:2;
      padding:2px 8px;border-radius:99px;font-size:.6rem;font-weight:700;letter-spacing:.5px;
    }

    .sv-card-body{padding:16px;}
    .sv-card-title{font-size:.95rem;font-weight:800;color:var(--txt);margin-bottom:3px;}
    .sv-card-sub{font-size:.72rem;color:var(--muted);margin-bottom:10px;}
    .sv-card-desc{font-size:.78rem;color:var(--muted);line-height:1.55;margin-bottom:12px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
    .sv-card-meta{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;}
    .sv-meta-chip{display:flex;align-items:center;gap:4px;padding:3px 8px;border-radius:99px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);font-size:.62rem;color:var(--muted);}
    .sv-card-price{display:flex;align-items:center;justify-content:space-between;}
    .sv-price-from{font-size:.62rem;color:var(--dim);}
    .sv-price-amt{font-size:1rem;font-weight:800;color:var(--gold);}
    .sv-card-btn{
      display:flex;align-items:center;justify-content:center;gap:6px;
      width:100%;margin-top:12px;padding:9px;
      background:var(--green-dim);border:1px solid rgba(40,166,128,.3);
      border-radius:var(--r-md);color:var(--green-lt);font-size:.8rem;font-weight:700;
      transition:all .2s;
    }
    .sv-card-btn:hover{background:var(--green);color:#fff;border-color:var(--green);}

    /* Vista lista */
    .list-view .sv-card{display:flex;flex-direction:row;align-items:stretch;}
    .list-view .sv-card-banner{width:80px;height:auto;flex-shrink:0;}
    .list-view .sv-card-body{flex:1;display:flex;align-items:center;gap:16px;padding:14px 18px;}
    .list-view .sv-card-info{flex:1;}
    .list-view .sv-card-desc{display:none;}
    .list-view .sv-card-btn{width:auto;margin-top:0;padding:7px 16px;flex-shrink:0;}

    /* ══ MODAL DE SERVICIO ════════════════════════════════════ */
    .sv-modal-overlay{
      position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:9999;
      display:none;align-items:flex-start;justify-content:center;
      padding:20px;overflow-y:auto;
    }
    .sv-modal-overlay.open{display:flex;}
    .sv-modal{
      background:var(--n800);border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-xl);width:100%;max-width:1000px;
      box-shadow:var(--sh-lg);animation:modalIn .35s ease both;
      margin:auto;
    }
    @keyframes modalIn{from{opacity:0;transform:translateY(32px) scale(.97)}to{opacity:1;transform:none}}

    /* Header del modal */
    .sm-header{
      display:flex;align-items:flex-start;gap:18px;
      padding:28px 32px;border-bottom:1px solid rgba(255,255,255,.07);
      position:relative;
    }
    .sm-ico{
      width:60px;height:60px;border-radius:var(--r-lg);
      display:flex;align-items:center;justify-content:center;
      font-size:1.8rem;flex-shrink:0;
    }
    .sm-info{flex:1;}
    .sm-cat{font-size:.7rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:4px;}
    .sm-title{font-size:1.5rem;font-weight:900;color:var(--txt);margin-bottom:4px;letter-spacing:.5px;}
    .sm-sub{font-size:.88rem;color:var(--muted);margin-bottom:10px;}
    .sm-meta-row{display:flex;gap:10px;flex-wrap:wrap;}
    .sm-meta-badge{display:flex;align-items:center;gap:5px;padding:4px 12px;border-radius:99px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);font-size:.72rem;color:var(--muted);}
    .sm-close{
      position:absolute;top:16px;right:16px;
      width:32px;height:32px;border-radius:50%;
      background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
      color:var(--muted);display:flex;align-items:center;justify-content:center;
      font-size:.85rem;cursor:pointer;transition:all .2s;
    }
    .sm-close:hover{background:rgba(239,68,68,.2);color:#f87171;}

    /* Tabs del modal */
    .sm-tabs{display:flex;gap:2px;padding:0 32px;border-bottom:1px solid rgba(255,255,255,.06);overflow-x:auto;}
    .sm-tab{
      padding:12px 18px;font-size:.82rem;font-weight:700;color:var(--muted);
      border-bottom:2px solid transparent;cursor:pointer;transition:all .2s;white-space:nowrap;
      background:none;
    }
    .sm-tab:hover{color:var(--txt);}
    .sm-tab.on{color:var(--green-lt);border-bottom-color:var(--green);}

    /* Contenido de los tabs */
    .sm-body{padding:28px 32px;}
    .sm-tab-content{display:none;animation:tabIn .3s ease both;}
    .sm-tab-content.on{display:block;}
    @keyframes tabIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

    /* Definición e importancia */
    .sm-section-title{font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:10px;display:flex;align-items:center;gap:6px;}
    .sm-section-title::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.06);}
    .sm-text{font-size:.88rem;color:var(--muted);line-height:1.8;margin-bottom:20px;}
    .sm-importance{background:var(--green-dim);border:1px solid rgba(40,166,128,.25);border-radius:var(--r-md);padding:16px 18px;font-size:.85rem;color:var(--green-lt);line-height:1.7;margin-bottom:20px;}
    .sm-importance i{margin-right:8px;}

    /* Conceptos grid */
    .sm-concepts-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px;margin-bottom:20px;}
    .sm-concept{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:16px;}
    .sm-concept-ico{font-size:1.4rem;margin-bottom:6px;}
    .sm-concept-title{font-size:.85rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .sm-concept-desc{font-size:.78rem;color:var(--muted);line-height:1.55;}

    /* Parámetros lista */
    .sm-params-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-bottom:4px;}
    .sm-param{
      display:flex;align-items:flex-start;gap:8px;
      padding:8px 10px;border-radius:var(--r-sm);
      background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.05);
      font-size:.78rem;color:var(--muted);
    }
    .sm-param-dot{width:6px;height:6px;border-radius:50%;background:var(--green);flex-shrink:0;margin-top:5px;}

    /* Foto y Video */
    .sm-media-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
    .sm-foto{border-radius:var(--r-lg);overflow:hidden;aspect-ratio:16/9;background:var(--n600);}
    .sm-foto img{width:100%;height:100%;object-fit:cover;}
    .sm-video{border-radius:var(--r-lg);overflow:hidden;aspect-ratio:16/9;background:#000;}
    .sm-video iframe{width:100%;height:100%;border:none;}

    /* Links */
    .sm-links-list{display:flex;flex-direction:column;gap:8px;}
    .sm-link{
      display:flex;align-items:center;gap:12px;
      padding:12px 16px;border-radius:var(--r-md);
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      transition:all .2s;text-decoration:none;
    }
    .sm-link:hover{background:var(--green-dim);border-color:rgba(40,166,128,.3);}
    .sm-link-ico{font-size:1.1rem;flex-shrink:0;}
    .sm-link-txt{font-size:.85rem;font-weight:600;color:var(--txt);flex:1;}
    .sm-link:hover .sm-link-txt{color:var(--green-lt);}
    .sm-link-arrow{color:var(--dim);font-size:.75rem;transition:transform .2s;}
    .sm-link:hover .sm-link-arrow{transform:translateX(4px);color:var(--green);}

    /* Planes */
    .sm-planes-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;}
    .sm-plan{
      background:var(--n600);border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-lg);padding:22px;display:flex;flex-direction:column;gap:12px;
      transition:transform .2s,border-color .2s,box-shadow .2s;position:relative;overflow:hidden;
    }
    .sm-plan:hover{transform:translateY(-4px);box-shadow:var(--sh-md);}
    .sm-plan.popular{border-color:var(--gold);}
    .sm-plan.popular::before{content:'⭐ Más elegido';position:absolute;top:0;right:0;background:var(--gold);color:#000;font-size:.62rem;font-weight:800;padding:4px 10px;border-radius:0 0 0 var(--r-sm);}
    .sm-plan-name{font-size:.9rem;font-weight:800;color:var(--txt);}
    .sm-plan-price{font-size:1.8rem;font-weight:900;color:var(--gold);line-height:1;}
    .sm-plan-price span{font-size:.75rem;color:var(--muted);font-weight:400;}
    .sm-plan-items{display:flex;flex-direction:column;gap:5px;flex:1;}
    .sm-plan-item{display:flex;align-items:flex-start;gap:7px;font-size:.78rem;color:var(--muted);}
    .sm-plan-item::before{content:'✓';color:var(--green);font-weight:700;flex-shrink:0;}
    .sm-plan-btn{
      padding:10px;border-radius:var(--r-md);font-weight:700;font-size:.82rem;
      background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);
      transition:all .2s;
    }
    .sm-plan-btn:hover{background:var(--green);color:#fff;border-color:var(--green);}

    /* ══ PASARELA DE PAGO — 2 botones principales ════════════ */
    .sm-pasarela{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:22px;}

    /* Botones grandes de pasarela */
    .pay-gateways-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px;}
    .pay-gw-btn{
      display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;
      padding:22px 16px;border-radius:var(--r-lg);
      border:2px solid rgba(255,255,255,.1);
      font-family:var(--font);font-size:.88rem;font-weight:700;
      color:var(--txt);text-decoration:none;cursor:pointer;
      transition:transform .22s,box-shadow .22s,border-color .22s;
      position:relative;overflow:hidden;
    }
    .pay-gw-btn:hover{transform:translateY(-4px);box-shadow:0 10px 30px rgba(0,0,0,.45);}

    /* Mercado Pago — azul */
    .pay-gw-mp{background:linear-gradient(145deg,rgba(0,158,227,.15),rgba(0,95,171,.1));}
    .pay-gw-mp:hover{border-color:#009FE3;box-shadow:0 10px 30px rgba(0,158,227,.25);}
    .pay-gw-mp .gw-logo{font-size:2rem;}
    .pay-gw-mp .gw-name{font-size:.92rem;color:#00CFFF;}
    .pay-gw-mp .gw-desc{font-size:.68rem;color:var(--muted);text-align:center;line-height:1.4;}

    /* ePayco — verde oscuro */
    .pay-gw-ep{background:linear-gradient(145deg,rgba(0,100,60,.15),rgba(0,60,30,.1));}
    .pay-gw-ep:hover{border-color:#00A651;box-shadow:0 10px 30px rgba(0,166,81,.22);}
    .pay-gw-ep .gw-logo{font-size:2rem;}
    .pay-gw-ep .gw-name{font-size:.92rem;color:#00d471;}
    .pay-gw-ep .gw-desc{font-size:.68rem;color:var(--muted);text-align:center;line-height:1.4;}

    /* Badge "Seguro" */
    .pay-gw-btn .gw-secure{
      position:absolute;top:8px;right:8px;
      padding:2px 7px;border-radius:99px;font-size:.58rem;font-weight:700;
      background:rgba(255,255,255,.08);color:rgba(255,255,255,.5);
    }

    /* Métodos aceptados (etiquetas) */
    .pay-methods-tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px;justify-content:center;}
    .pay-tag{display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:99px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.07);font-size:.68rem;color:var(--muted);}
    .pay-tag i{font-size:.72rem;}

    /* Separador */
    .pay-sep{display:flex;align-items:center;gap:10px;margin:12px 0 10px;}
    .pay-sep::before,.pay-sep::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.07);}
    .pay-sep span{font-size:.68rem;color:var(--dim);white-space:nowrap;}

    .sm-pay-note{font-size:.72rem;color:var(--dim);padding:10px 12px;background:rgba(255,255,255,.03);border-radius:var(--r-sm);display:flex;align-items:center;gap:6px;}

    @media(max-width:480px){.pay-gateways-row{grid-template-columns:1fr;}}

    /* ══ FOOTER ════════════════════════════════════════════════ */
    .site-footer{background:#050d1a;border-top:1px solid rgba(40,166,128,.12);padding:32px 28px;margin-top:60px;}
    .footer-inner{max-width:1480px;margin:auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;}
    .footer-brand{display:flex;align-items:center;gap:10px;}
    .footer-copy{font-size:.8rem;color:var(--dim);}
    .footer-nav{display:flex;gap:18px;}
    .footer-nav a{font-size:.8rem;color:var(--dim);font-weight:600;transition:color .2s;}
    .footer-nav a:hover{color:var(--green);}

    /* ══ RESPONSIVE ═══════════════════════════════════════════ */
    @media(max-width:820px){
      .burger{display:flex;}
      .main-nav{position:fixed;top:var(--hh);left:0;right:0;background:var(--n800);flex-direction:column;padding:20px;gap:6px;border-bottom:1px solid rgba(255,255,255,.06);transform:translateY(-110%);transition:transform .35s ease;z-index:999;}
      .nav-open{transform:translateY(0)!important;}
      .sv-controls{padding:16px;}
      .sv-search-wrap{max-width:100%;}
      .sm-media-grid,.sm-params-grid{grid-template-columns:1fr;}
      .sm-body{padding:18px 20px;}
      .sm-header{padding:20px;}
      .sm-tabs{padding:0 20px;}
    }
    @media(max-width:560px){
      .sv-grid{grid-template-columns:1fr 1fr;}
      .sm-planes-grid{grid-template-columns:1fr;}
      .sm-concepts-grid{grid-template-columns:1fr;}
    }
    @media(max-width:380px){
      .sv-grid{grid-template-columns:1fr;}
    }
  </style>
</head>
<body>

<!-- ══ HEADER ════════════════════════════════════════════════════════ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyectos</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link active">Servicios</a>
      <a href="AD.php" class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php" class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>
      <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span style="width:26px;height:26px;background:var(--n500);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuario') ?></span>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Salir</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ══ HERO ══════════════════════════════════════════════════════════ -->
<div class="sv-hero">
  <div class="sv-hero-grid"></div>
  <div class="sv-orb so1"></div>
  <div class="sv-orb so2"></div>
  <div class="sv-hero-content">
    <span class="sv-hero-tag">⬡ Catálogo de Servicios — Team VIROX</span>
    <h1>Nuestros <span>Servicios Digitales</span></h1>
    <p>Más de <?= count($servicios) ?> áreas de conocimiento y desarrollo tecnológico. Desde fundamentos hasta nivel experto.</p>
    <div class="sv-hero-stats">
      <div class="hstat"><span class="hstat-n"><?= count($servicios) ?>+</span><span class="hstat-l">Servicios</span></div>
      <div class="hstat-div"></div>
      <div class="hstat"><span class="hstat-n"><?= count($categorias_unicas) ?></span><span class="hstat-l">Categorías</span></div>
      <div class="hstat-div"></div>
      <div class="hstat"><span class="hstat-n">3</span><span class="hstat-l">Planes por área</span></div>
      <div class="hstat-div"></div>
      <div class="hstat"><span class="hstat-n">100%</span><span class="hstat-l">Digital</span></div>
    </div>
  </div>
</div>


<!-- ══ CONTROLES ════════════════════════════════════════════════════ -->
<div class="sv-controls">
  <div class="sv-search-wrap">
    <i class="fa fa-search"></i>
    <input type="text" id="svSearch" placeholder="Buscar servicio...">
  </div>
  <div class="cat-chips">
    <span class="cat-chip on" onclick="filterCat('todos',this)">Todos</span>
    <?php foreach ($categorias_unicas as $cat): ?>
    <span class="cat-chip" onclick="filterCat('<?= htmlspecialchars($cat, ENT_QUOTES) ?>',this)"><?= htmlspecialchars($cat) ?></span>
    <?php endforeach; ?>
  </div>
  <div class="view-toggle">
    <button class="vt-btn on" id="vGrid" onclick="setView('grid',this)" title="Cuadrícula"><i class="fa fa-th-large"></i></button>
    <button class="vt-btn"    id="vList" onclick="setView('list',this)" title="Lista"><i class="fa fa-list"></i></button>
  </div>
</div>


<!-- ══ GRID DE SERVICIOS ════════════════════════════════════════════ -->
<div class="sv-layout">
  <div class="sv-count" id="svCount">Mostrando <strong><?= count($servicios) ?></strong> servicios</div>
  <div class="sv-grid" id="svGrid">
    <?php foreach ($servicios as $i => $s):
      $clr = $color_map[$s['color']] ?? $color_map['green'];
      $precio_fmt = '$' . number_format($s['precio_base'], 0, ',', '.');
    ?>
    <div class="sv-card"
         data-id="<?= $s['id'] ?>"
         data-cat="<?= htmlspecialchars($s['categoria']) ?>"
         data-nombre="<?= htmlspecialchars(strtolower($s['titulo'] . ' ' . $s['subtitulo'])) ?>"
         style="animation-delay:<?= $i * 0.03 ?>s;"
         onclick="openModal('<?= $s['id'] ?>')">

      <div class="sv-card-banner" style="background:linear-gradient(135deg,rgba(0,0,0,.3),<?= $clr[0] ?>);">
        <div class="sv-card-banner-grid"></div>
        <div style="position:absolute;inset:0;background:radial-gradient(circle at 70% 30%,<?= $clr[0] ?>,transparent 70%);"></div>
        <span class="sv-card-ico-big"><?= $s['ico'] ?></span>
        <span class="sv-card-cat-badge" style="background:<?= $clr[0] ?>;border:1px solid <?= $clr[1] ?>;color:<?= $clr[2] ?>;">
          <?= htmlspecialchars($s['categoria']) ?>
        </span>
      </div>

      <div class="sv-card-body">
        <div class="sv-card-title"><?= htmlspecialchars($s['titulo']) ?></div>
        <div class="sv-card-sub"><?= htmlspecialchars($s['subtitulo']) ?></div>
        <div class="sv-card-desc"><?= htmlspecialchars($s['definicion']) ?></div>
        <div class="sv-card-meta">
          <span class="sv-meta-chip"><i class="fa fa-signal"></i> <?= $s['nivel'] ?></span>
          <span class="sv-meta-chip"><i class="fa fa-clock"></i> <?= $s['duracion'] ?></span>
          <span class="sv-meta-chip"><i class="fa fa-list"></i> <?= count($s['parametros']) ?> temas</span>
        </div>
        <div class="sv-card-price">
          <div>
            <div class="sv-price-from">Desde</div>
            <div class="sv-price-amt"><?= $precio_fmt ?> COP</div>
          </div>
          <div style="display:flex;gap:4px;">
            <?php foreach (array_slice($s['planes'], 0, 3) as $p):
              $nm = $p[0];
            ?>
            <span style="font-size:.6rem;padding:2px 6px;border-radius:99px;background:rgba(255,255,255,.06);color:var(--dim);"><?= $nm ?></span>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="sv-card-btn" style="background:<?= $clr[0] ?>;border-color:<?= $clr[1] ?>;color:<?= $clr[2] ?>;">
          <i class="fa fa-eye"></i> Ver servicio completo
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>


<!-- ══ MODAL DE SERVICIO ════════════════════════════════════════════ -->
<div class="sv-modal-overlay" id="svModalOverlay">
  <div class="sv-modal" id="svModal">

    <!-- Header dinámico -->
    <div class="sm-header" id="smHeader">
      <div class="sm-ico" id="smIco">🤖</div>
      <div class="sm-info">
        <div class="sm-cat" id="smCat">Categoría</div>
        <div class="sm-title" id="smTitle">Servicio</div>
        <div class="sm-sub"   id="smSub">Subtítulo</div>
        <div class="sm-meta-row">
          <span class="sm-meta-badge" id="smNivel"><i class="fa fa-signal" style="margin-right:4px;"></i></span>
          <span class="sm-meta-badge" id="smDuracion"><i class="fa fa-clock" style="margin-right:4px;"></i></span>
          <span class="sm-meta-badge" id="smPrecio"><i class="fa fa-tag" style="margin-right:4px;"></i></span>
        </div>
      </div>
      <button class="sm-close" onclick="closeModal()"><i class="fa fa-times"></i></button>
    </div>

    <!-- Tabs -->
    <div class="sm-tabs">
      <button class="sm-tab on" onclick="smTab('definicion',this)">📋 Definición</button>
      <button class="sm-tab"    onclick="smTab('conceptos',this)">🧩 Conceptos</button>
      <button class="sm-tab"    onclick="smTab('parametros',this)">⚙️ Parámetros</button>
      <button class="sm-tab"    onclick="smTab('media',this)">📸 Foto & Video</button>
      <button class="sm-tab"    onclick="smTab('links',this)">🔗 Links</button>
      <button class="sm-tab"    onclick="smTab('planes',this)">💳 Planes & Pagos</button>
    </div>

    <!-- Contenido de tabs -->
    <div class="sm-body">

      <!-- Definición -->
      <div class="sm-tab-content on" id="stc-definicion">
        <div class="sm-section-title"><span>📖</span> Definición</div>
        <p class="sm-text" id="smDefinicion"></p>
        <div class="sm-section-title"><span>🎯</span> Importancia</div>
        <div class="sm-importance" id="smImportancia"><i class="fa fa-circle-info"></i></div>
      </div>

      <!-- Conceptos clave -->
      <div class="sm-tab-content" id="stc-conceptos">
        <div class="sm-section-title"><span>🧩</span> Conceptos Clave</div>
        <div class="sm-concepts-grid" id="smConceptos"></div>
      </div>

      <!-- Parámetros / Listado específico -->
      <div class="sm-tab-content" id="stc-parametros">
        <div class="sm-section-title"><span>📌</span> Listado Específico de Temas y Parámetros</div>
        <p style="font-size:.78rem;color:var(--muted);margin-bottom:14px;">Todos los puntos que cubrimos como parte de este servicio. Adaptamos el contenido al nivel y necesidades del usuario.</p>
        <div class="sm-params-grid" id="smParametros"></div>
      </div>

      <!-- Media -->
      <div class="sm-tab-content" id="stc-media">
        <div class="sm-section-title"><span>📸</span> Imagen de Referencia</div>
        <div class="sm-media-grid">
          <div class="sm-foto"><img id="smFoto" src="" alt="" loading="lazy"></div>
          <div class="sm-video"><iframe id="smVideo" src="" allowfullscreen loading="lazy"></iframe></div>
        </div>
        <p style="font-size:.72rem;color:var(--dim);margin-top:10px;text-align:center;">📌 Los recursos multimedia pueden ser personalizados para el cliente.</p>
      </div>

      <!-- Links -->
      <div class="sm-tab-content" id="stc-links">
        <div class="sm-section-title"><span>🔗</span> Recursos y Referencias</div>
        <p style="font-size:.78rem;color:var(--muted);margin-bottom:14px;">Los siguientes recursos externos pueden ayudarte a profundizar en este servicio y ampliar tu conocimiento.</p>
        <div class="sm-links-list" id="smLinks"></div>
      </div>

      <!-- Planes y Pagos -->
      <div class="sm-tab-content" id="stc-planes">
        <div class="sm-section-title"><span>💰</span> Planes y Ofertas</div>
        <div class="sm-planes-grid" id="smPlanes"></div>

        <div class="sm-section-title" style="margin-top:24px;"><span>💳</span> Pasarelas de Pago</div>
        <div class="sm-pasarela">

          <!-- ── Dos botones principales ── -->
          <div class="pay-gateways-row" id="payGatewaysRow">
            <!-- Se renderizan desde JS con el servicio y precio actuales -->
          </div>

          <!-- ── Métodos aceptados ── -->
          <div class="pay-sep"><span>métodos aceptados en ambas pasarelas</span></div>
          <div class="pay-methods-tags">
            <span class="pay-tag"><i class="fa fa-university"></i> PSE</span>
            <span class="pay-tag"><i class="fa fa-credit-card"></i> Visa / Mastercard</span>
            <span class="pay-tag"><i class="fa fa-mobile-alt"></i> Nequi</span>
            <span class="pay-tag"><i class="fa fa-piggy-bank"></i> Daviplata</span>
            <span class="pay-tag"><i class="fa fa-money-bill-wave"></i> Efecty</span>
            <span class="pay-tag"><i class="fa fa-arrows-left-right"></i> Transferencia</span>
          </div>

          <div class="sm-pay-note">
            <i class="fa fa-shield-halved" style="color:var(--green);"></i>
            Pagos procesados de forma segura con cifrado SSL. Precios en COP.
            Al hacer clic serás redirigido a la pasarela seleccionada.
          </div>
        </div>

        <!-- Oferta personalizada -->
        <div style="margin-top:16px;padding:16px 18px;background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);border-radius:var(--r-md);">
          <strong style="display:block;font-size:.85rem;color:var(--gold-lt);margin-bottom:6px;">🎁 ¿Necesitas algo personalizado?</strong>
          <p style="font-size:.78rem;color:var(--muted);margin-bottom:10px;">Diseñamos planes a medida para empresas, grupos y necesidades específicas. Descuentos especiales para más de 3 servicios.</p>
          <a href="contacto.php" style="display:inline-flex;align-items:center;gap:6px;padding:8px 16px;background:var(--gold);color:#000;border-radius:var(--r-md);font-size:.8rem;font-weight:700;">
            <i class="fa fa-paper-plane"></i> Cotizar plan personalizado
          </a>
        </div>
      </div>

    </div><!-- /sm-body -->
  </div><!-- /sv-modal -->
</div><!-- /sv-modal-overlay -->


<!-- ══ FOOTER ════════════════════════════════════════════════════════ -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name" style="font-size:1.2rem;letter-spacing:3px;">VIROX</span>
    </div>
    <p class="footer-copy">© 2025 Team VIROX — Todos los derechos reservados</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyectos</a>
      <a href="equipo.php">Equipo</a>
      <a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>


<script>
/* ════════════════════════════════════════════════════════════════════
   DATOS DE SERVICIOS (PHP → JS)
════════════════════════════════════════════════════════════════════ */
const SERVICIOS = <?= json_encode($servicios, JSON_UNESCAPED_UNICODE) ?>;

/* ════════════════════════════════════════════════════════════════════
   HEADER SCROLL + BURGER
════════════════════════════════════════════════════════════════════ */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));
document.getElementById('burger')?.addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ════════════════════════════════════════════════════════════════════
   FILTROS Y BÚSQUEDA
════════════════════════════════════════════════════════════════════ */
let activeFilter = 'todos';

function filterCat(cat, el) {
  document.querySelectorAll('.cat-chip').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  activeFilter = cat;
  applyFilters();
}

function applyFilters() {
  const q = document.getElementById('svSearch').value.toLowerCase();
  const cards = document.querySelectorAll('.sv-card');
  let visible = 0;
  cards.forEach(card => {
    const cat    = card.dataset.cat  || '';
    const nombre = card.dataset.nombre || '';
    const showCat  = activeFilter === 'todos' || cat === activeFilter;
    const showQ    = !q || nombre.includes(q);
    const show     = showCat && showQ;
    card.classList.toggle('hidden', !show);
    if (show) visible++;
  });
  document.getElementById('svCount').innerHTML =
    `Mostrando <strong>${visible}</strong> servicios`;
}

document.getElementById('svSearch').addEventListener('input', applyFilters);

/* ════════════════════════════════════════════════════════════════════
   VISTA GRID / LISTA
════════════════════════════════════════════════════════════════════ */
function setView(v, btn) {
  document.querySelectorAll('.vt-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  document.getElementById('svGrid').classList.toggle('list-view', v === 'list');
}

/* ════════════════════════════════════════════════════════════════════
   MODAL
════════════════════════════════════════════════════════════════════ */
const COLOR_MAP = <?= json_encode($color_map, JSON_UNESCAPED_UNICODE) ?>;

function openModal(id) {
  const s = SERVICIOS.find(x => x.id === id);
  if (!s) return;

  const clr = COLOR_MAP[s.color] || COLOR_MAP['green'];

  // Header
  document.getElementById('smIco').textContent = s.ico;
  document.getElementById('smIco').style.background = clr[0];
  document.getElementById('smIco').style.border     = `1px solid ${clr[1]}`;
  document.getElementById('smCat').textContent  = s.categoria;
  document.getElementById('smCat').style.color  = clr[2];
  document.getElementById('smTitle').textContent = s.titulo;
  document.getElementById('smSub').textContent   = s.subtitulo;
  document.getElementById('smNivel').innerHTML   = `<i class="fa fa-signal" style="margin-right:4px;color:${clr[2]};"></i>${s.nivel}`;
  document.getElementById('smDuracion').innerHTML= `<i class="fa fa-clock" style="margin-right:4px;"></i>${s.duracion}`;
  document.getElementById('smPrecio').innerHTML  = `<i class="fa fa-tag" style="margin-right:4px;color:var(--gold);"></i>Desde $${s.precio_base.toLocaleString('es')} COP`;

  // Color del borde del modal
  document.getElementById('svModal').style.borderColor = clr[1];

  // Definición
  document.getElementById('smDefinicion').textContent   = s.definicion;
  document.getElementById('smImportancia').innerHTML    = `<i class="fa fa-lightbulb"></i> ${s.importancia}`;

  // Conceptos
  const concGrid = document.getElementById('smConceptos');
  concGrid.innerHTML = s.conceptos.map(([ico, titulo, desc]) => `
    <div class="sm-concept" style="border-color:${clr[1]};">
      <div class="sm-concept-ico">${ico}</div>
      <div class="sm-concept-title">${titulo}</div>
      <div class="sm-concept-desc">${desc}</div>
    </div>`).join('');

  // Parámetros
  const parGrid = document.getElementById('smParametros');
  parGrid.innerHTML = s.parametros.map(p => `
    <div class="sm-param">
      <div class="sm-param-dot" style="background:${clr[2]};"></div>
      <span>${p}</span>
    </div>`).join('');

  // Foto y Video
  document.getElementById('smFoto').src = s.foto;
  document.getElementById('smFoto').alt = s.titulo;
  document.getElementById('smVideo').src = s.video + '?rel=0&modestbranding=1';

  // Links
  const linksEl = document.getElementById('smLinks');
  linksEl.innerHTML = s.links.map(([ico, txt, url]) => `
    <a href="${url}" target="_blank" rel="noopener" class="sm-link">
      <span class="sm-link-ico">${ico}</span>
      <span class="sm-link-txt">${txt}</span>
      <span style="font-size:.68rem;color:var(--dim);margin-right:4px;">${new URL(url).hostname}</span>
      <i class="fa fa-arrow-up-right-from-square sm-link-arrow"></i>
    </a>`).join('');

  // Planes
  const planesEl = document.getElementById('smPlanes');
  planesEl.innerHTML = s.planes.map(([nombre, precio, items], i) => {
    const isPopular = i === 1;
    const priceFmt  = '$' + precio.toLocaleString('es');
    return `
    <div class="sm-plan ${isPopular ? 'popular' : ''}">
      <div class="sm-plan-name">${nombre}</div>
      <div class="sm-plan-price">${priceFmt} <span>COP / servicio</span></div>
      <div class="sm-plan-items">
        ${items.map(it => `<div class="sm-plan-item">${it}</div>`).join('')}
      </div>
      <button class="sm-plan-btn" style="background:${isPopular ? clr[0] : ''};border-color:${isPopular ? clr[1] : ''};color:${isPopular ? clr[2] : ''};"
              onclick="seleccionarPlan('${s.titulo}','${nombre}',${precio})">
        <i class="fa fa-shopping-cart"></i> Adquirir ${nombre}
      </button>
    </div>`;
  }).join('');

  // Renderizar botones de pasarela con datos del servicio actual
  renderPasarelas(s.titulo, '', s.precio_base);

  // Abrir modal, reset al primer tab
  smTab('definicion', document.querySelectorAll('.sm-tab')[0]);
  document.getElementById('svModalOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('svModalOverlay').classList.remove('open');
  document.body.style.overflow = '';
  // Detener video
  const iframe = document.getElementById('smVideo');
  iframe.src = iframe.src;
}

document.getElementById('svModalOverlay').addEventListener('click', function (e) {
  if (e.target === this) closeModal();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });

/* ════════════════════════════════════════════════════════════════════
   TABS DEL MODAL
════════════════════════════════════════════════════════════════════ */
function smTab(id, btn) {
  document.querySelectorAll('.sm-tab-content').forEach(c => c.classList.remove('on'));
  document.querySelectorAll('.sm-tab').forEach(t => t.classList.remove('on'));
  document.getElementById('stc-' + id).classList.add('on');
  btn.classList.add('on');
}

/* ════════════════════════════════════════════════════════════════════
   PASARELAS DE PAGO — Links reales
   MercadoPago : https://link.mercadopago.com.co/containerrz
   ePayco      : https://secure.payco.co/checkoutopen/37b6bb65-23a0-4880-852f-3a43572c8d86
════════════════════════════════════════════════════════════════════ */
const PASARELAS_CONFIG = {
  mercadopago: {
    url:   'https://link.mercadopago.com.co/containerrz',
    logo:  '💙',
    name:  'Mercado Pago',
    desc:  'PSE · Tarjeta · Nequi · Daviplata · Efecty',
    cls:   'pay-gw-mp',
  },
  epayco: {
    url:   'https://secure.payco.co/checkoutopen/37b6bb65-23a0-4880-852f-3a43572c8d86',
    logo:  '🟢',
    name:  'ePayco',
    desc:  'PSE · Tarjeta · Nequi · Efecty · Baloto',
    cls:   'pay-gw-ep',
  },
};

// Se llama desde openModal() para renderizar los botones con el servicio actual
function renderPasarelas(servicio, planNombre, precio) {
  const row = document.getElementById('payGatewaysRow');
  if (!row) return;

  row.innerHTML = Object.values(PASARELAS_CONFIG).map(gw => {
    // Añadimos referencia como query param para trazabilidad
    const ref    = 'CRZ-' + Date.now();
    const params = new URLSearchParams({
      description: encodeURIComponent(servicio + ' — ' + (planNombre || 'Plan')),
      amount:      precio,
      reference:   ref,
    });
    const checkoutUrl = gw.url;   // Los links ya son checkout directo — no necesitan params

    return `
    <a href="${checkoutUrl}"
       target="_blank" rel="noopener noreferrer"
       class="pay-gw-btn ${gw.cls}"
       onclick="logIntencion('${gw.name}', '${servicio}', ${precio})">
      <span class="gw-secure">🔒 Seguro</span>
      <span class="gw-logo">${gw.logo}</span>
      <span class="gw-name">${gw.name}</span>
      <span class="gw-desc">${gw.desc}</span>
    </a>`;
  }).join('');
}

// Registro silencioso de intención de pago (no bloquea la redirección)
function logIntencion(pasarela, servicio, precio) {
  try {
    fetch('api/registrar_pago.php', {
      method:    'POST',
      headers:   { 'Content-Type': 'application/json' },
      body:      JSON.stringify({ pasarela, servicio, precio }),
      keepalive: true,
    }).catch(() => {});
  } catch(e) {}
  // La redirección al href ocurre normalmente — esto solo registra
}

// Seleccionar un plan: actualiza las pasarelas con el precio del plan y salta a pagos
function seleccionarPlan(servicio, plan, precio) {
  // 1. Actualiza los botones de pasarela con el precio real del plan
  renderPasarelas(servicio, plan, precio);

  // 2. Cambia al tab de planes/pagos
  smTab('planes', document.querySelectorAll('.sm-tab')[5]);

  // 3. Hace scroll suave hasta los botones de pago
  setTimeout(() => {
    const row = document.getElementById('payGatewaysRow');
    if (row) row.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 200);

  // 4. Resaltar brevemente los botones para llamar la atención
  setTimeout(() => {
    document.querySelectorAll('.pay-gw-btn').forEach(btn => {
      btn.style.transform = 'translateY(-6px)';
      btn.style.boxShadow = '0 12px 36px rgba(0,0,0,.5)';
      setTimeout(() => {
        btn.style.transform = '';
        btn.style.boxShadow = '';
      }, 800);
    });
  }, 400);
}

/* ── Wrapper adquirirPlan (mantiene compatibilidad) ─────────────── */
function adquirirPlan(servicio, plan, precio) {
  seleccionarPlan(servicio, plan, precio);
}

/* ════════════════════════════════════════════════════════════════════
   ANIMACIÓN REVEAL DE TARJETAS
════════════════════════════════════════════════════════════════════ */
const obs = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.06 });

document.querySelectorAll('.sv-card').forEach((c, i) => {
  c.style.opacity = '0';
  c.style.transform = 'translateY(20px)';
  c.style.transition = `opacity .4s ease ${i * 0.035}s, transform .4s ease ${i * 0.035}s`;
  obs.observe(c);
});
</script>
</body>
</html>