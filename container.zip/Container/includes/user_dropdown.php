<?php
/**
 * includes/user_dropdown.php
 * ─────────────────────────────────────────────────────────────────────────────
 * Componente reutilizable del menú de usuario del header.
 * Incluir en CUALQUIER página con:
 *   <?php include 'includes/user_dropdown.php'; ?>
 *   o
 *   <?php include __DIR__ . '/includes/user_dropdown.php'; ?>
 *
 * FUNCIONES:
 * - Dropdown por CLIC (no hover) — se mantiene abierto
 * - Opción "Mi Panel" según rol (solo para no-clientes)
 * - Enlace a perfil, editar perfil y cerrar sesión
 * - Avatar real desde sesión
 * - Cierra al hacer clic fuera o en Escape
 * ─────────────────────────────────────────────────────────────────────────────
 */

// Determinar la ruta base según la profundidad del archivo que incluye este componente
// Se detecta automáticamente comparando la ruta real del script con el directorio raíz
$_base_path = '';
if (isset($_SERVER['SCRIPT_FILENAME'])) {
    $script_dir   = dirname(realpath($_SERVER['SCRIPT_FILENAME']));
    $root_dir     = realpath(__DIR__ . '/..');   // asume que includes/ está en la raíz
    // Calcular cuántos niveles de profundidad hay
    if ($script_dir !== $root_dir) {
        $relative = str_replace($root_dir, '', $script_dir);
        $depth    = substr_count(trim($relative, DIRECTORY_SEPARATOR), DIRECTORY_SEPARATOR) + 1;
        $_base_path = str_repeat('../', $depth);
    }
}

// Datos de sesión
$_uid       = $_SESSION['user_id']   ?? 0;
$_uname     = $_SESSION['user_name'] ?? 'Usuario';
$_rol       = $_SESSION['rol']       ?? 'cliente';
$_avatar    = $_SESSION['avatar']    ?? '';
$_first_name= explode(' ', $_uname)[0];

// ── Rutas del panel según rol ─────────────────────────────────────────────────
$_panel_links = [
    'superadmin' => ['superadmin/index.php', '👑', 'Panel SuperAdmin'],
    'admin'      => ['admin/index.php',       '⚙️', 'Panel Admin'],
    'empleado'   => ['empleado/index.php',    '👔', 'Mi Panel'],
    'creador'    => ['creador/index.php',     '🎨', 'Panel Creador'],
    'consultor'  => ['consultor/index.php',   '🔍', 'Mi Panel'],
    'empresa'    => ['empresa/index.php',     '🏢', 'Mi Panel'],
];
$_has_panel = isset($_panel_links[$_rol]);
$_panel     = $_panel_links[$_rol] ?? null;

// ── Avatar src ────────────────────────────────────────────────────────────────
$_avatar_src = $_base_path . 'assets/avatar-default.png';
if (!empty($_avatar)) {
    // Si es URL externa
    if (str_starts_with($_avatar, 'http')) {
        $_avatar_src = $_avatar;
    } else {
        // Buscar el archivo con y sin prefijo base
        $try1 = $_avatar;
        $try2 = $_base_path . $_avatar;
        $fs1  = realpath(dirname($_SERVER['SCRIPT_FILENAME']) . '/' . $try1);
        $fs2  = realpath(dirname($_SERVER['SCRIPT_FILENAME']) . '/' . ltrim($try2, '/'));
        if ($fs1 && file_exists($fs1)) {
            $_avatar_src = $try1;
        } elseif ($fs2 && file_exists($fs2)) {
            $_avatar_src = $try2;
        } else {
            // Usar la ruta tal cual (puede ser relativa correcta desde el HTML)
            $_avatar_src = $_avatar;
        }
    }
}

// ── Badge de rol ──────────────────────────────────────────────────────────────
$_rol_badge = match($_rol) {
    'superadmin' => ['👑', 'SuperAdmin',   'drop-badge--purple'],
    'admin'      => ['⚙️', 'Admin',        'drop-badge--gold'],
    'empleado'   => ['👔', 'Empleado',     'drop-badge--green'],
    'creador'    => ['🎨', 'Creador',      'drop-badge--blue'],
    'consultor'  => ['🔍', 'Consultor',    'drop-badge--teal'],
    'empresa'    => ['🏢', 'Empresa',      'drop-badge--orange'],
    default      => ['👤', 'Cliente',      'drop-badge--gray'],
};
?>

<div class="user-wrap" id="userWrap">

    <!-- ── Pill / Botón ── -->
    <button class="user-pill" id="userPillBtn"
            onclick="toggleUserDrop(event)"
            aria-haspopup="true" aria-expanded="false">

        <!-- Avatar -->
        <span class="user-av-wrap">
            <img src="<?= htmlspecialchars($_avatar_src) ?>"
                 alt="<?= htmlspecialchars($_first_name) ?>"
                 class="user-av-img"
                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <span class="user-av-fallback" style="display:none;">
                <i class="fa fa-user"></i>
            </span>
        </span>

        <!-- Nombre -->
        <span class="user-pill-name"><?= htmlspecialchars($_first_name) ?></span>

        <!-- Chevron animado -->
        <i class="fa fa-chevron-down user-pill-chevron" id="userPillChevron"></i>
    </button>

    <!-- ── Dropdown ── -->
    <div class="user-drop" id="userDrop" role="menu">

        <!-- Cabecera con info del usuario -->
        <div class="drop-header">
            <div class="drop-av-big">
                <img src="<?= htmlspecialchars($_avatar_src) ?>"
                     alt="<?= htmlspecialchars($_uname) ?>"
                     onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                <span style="display:none;width:100%;height:100%;align-items:center;justify-content:center;font-size:1.4rem;">👤</span>
            </div>
            <div class="drop-user-info">
                <div class="drop-user-name"><?= htmlspecialchars($_uname) ?></div>
                <span class="drop-badge <?= $_rol_badge[2] ?>">
                    <?= $_rol_badge[0] ?> <?= $_rol_badge[1] ?>
                </span>
            </div>
        </div>

        <div class="drop-divider"></div>

        <!-- ── Opción: Panel del rol (solo no-clientes) ── -->
        <?php if ($_has_panel && $_panel): ?>
        <a href="<?= $_base_path . $_panel[0] ?>" class="drop-item drop-item--panel" role="menuitem">
            <span class="drop-item-ico"><?= $_panel[1] ?></span>
            <div class="drop-item-body">
                <span class="drop-item-label"><?= htmlspecialchars($_panel[2]) ?></span>
                <span class="drop-item-sub">Ir a tu panel de control</span>
            </div>
            <i class="fa fa-arrow-right drop-item-arrow"></i>
        </a>
        <div class="drop-divider"></div>
        <?php endif; ?>

        <!-- ── Opciones generales ── -->
        <a href="<?= $_base_path ?>ver-perfil.php?id=<?= (int)$_uid ?>"
           class="drop-item" role="menuitem">
            <i class="fa fa-id-card drop-item-ico-fa"></i>
            <div class="drop-item-body">
                <span class="drop-item-label">Mi perfil</span>
                <span class="drop-item-sub">Ver tu perfil público</span>
            </div>
        </a>

        <a href="<?= $_base_path ?>editar-perfil.php"
           class="drop-item" role="menuitem">
            <i class="fa fa-pen drop-item-ico-fa"></i>
            <div class="drop-item-body">
                <span class="drop-item-label">Editar perfil</span>
                <span class="drop-item-sub">Actualizar datos y foto</span>
            </div>
        </a>

        <a href="<?= $_base_path ?>index.php"
           class="drop-item" role="menuitem">
            <i class="fa fa-house drop-item-ico-fa"></i>
            <div class="drop-item-body">
                <span class="drop-item-label">Inicio</span>
                <span class="drop-item-sub">Volver a la página principal</span>
            </div>
        </a>

        <div class="drop-divider"></div>

        <!-- ── Cerrar sesión ── -->
        <a href="<?= $_base_path ?>logout.php"
           class="drop-item drop-item--danger" role="menuitem">
            <i class="fa fa-right-from-bracket drop-item-ico-fa"></i>
            <div class="drop-item-body">
                <span class="drop-item-label">Cerrar sesión</span>
                <span class="drop-item-sub">Salir de tu cuenta</span>
            </div>
        </a>

    </div><!-- /user-drop -->
</div><!-- /user-wrap -->