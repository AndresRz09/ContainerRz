<?php
include 'conexion.php';
session_start();

// ── Control de acceso ────────────────────────────────────────────────────────
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
if (!in_array($_SESSION['rol'] ?? '', ['admin', 'superadmin', 'empleado'])) {
    header("Location: proyecto.php");
    exit();
}

$uid     = (int)$_SESSION['user_id'];
$tipo_qt = $_GET['tipo'] ?? 'propio';   // 'propio' | 'otros'
$success = '';
$error   = '';
$errors  = [];

// ── Traer usuarios para campo "Equipo del proyecto" ──────────────────────────
$usuarios_lista = [];
$qu = $conexion->query("SELECT id, nombre, apellido, rol FROM usuarios WHERE activo=1 ORDER BY nombre ASC");
if ($qu) while ($u = $qu->fetch_assoc()) $usuarios_lista[] = $u;

// ── PROCESAR FORMULARIO ──────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {

    // Campos básicos
    $titulo      = trim($_POST['titulo']       ?? '');
    $descripcion = trim($_POST['descripcion']  ?? '');
    $tipo        = in_array($_POST['tipo'] ?? '', ['propio','comunidad','cliente','academico'])
                   ? $_POST['tipo'] : 'propio';
    $categoria   = trim($_POST['categoria']    ?? '');
    $subtipo     = trim($_POST['subtipo']      ?? '');
    $icono       = trim($_POST['icono']        ?? '🚀');
    $estado      = in_array($_POST['estado'] ?? '', ['planeado','activo','pausado','completado','cancelado'])
                   ? $_POST['estado'] : 'planeado';
    $progreso    = max(0, min(100, (int)($_POST['progreso'] ?? 0)));
    $tecnologias = trim($_POST['tecnologias']  ?? '');
    $areas       = trim($_POST['areas']        ?? '');
    $fecha_inicio= trim($_POST['fecha_inicio'] ?? '');
    $fecha_fin   = trim($_POST['fecha_fin']    ?? '');
    $repositorio = filter_var(trim($_POST['repositorio'] ?? ''), FILTER_SANITIZE_URL);
    $url_demo    = filter_var(trim($_POST['url_demo']    ?? ''), FILTER_SANITIZE_URL);
    $privado     = isset($_POST['privado']) ? 1 : 0;
    $presupuesto = !empty($_POST['presupuesto']) ? (float)$_POST['presupuesto'] : null;
    $miembros_ids= $_POST['miembros'] ?? [];   // array de user ids
    $roles_mbs   = $_POST['roles_miembros'] ?? [];

    // Validaciones
    if (empty($titulo))      $errors[] = "El título es obligatorio.";
    if (strlen($titulo) > 200) $errors[] = "El título no puede superar 200 caracteres.";
    if (!empty($fecha_inicio) && !empty($fecha_fin) && $fecha_fin < $fecha_inicio)
        $errors[] = "La fecha de fin no puede ser anterior a la de inicio.";

    if (empty($errors)) {
        // Insertar proyecto
        $ins = $conexion->prepare(
            "INSERT INTO proyectos
             (titulo, descripcion, tipo, categoria, subtipo, icono, estado, progreso,
              tecnologias, areas, fecha_inicio, fecha_fin, repositorio, url_demo,
              privado, presupuesto, creado_por)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        );

        $f_ini = !empty($fecha_inicio) ? $fecha_inicio : null;
        $f_fin = !empty($fecha_fin)    ? $fecha_fin    : null;

        $ins->bind_param(
            "sssssssisisssssdi",
            $titulo, $descripcion, $tipo, $categoria, $subtipo, $icono,
            $estado, $progreso, $tecnologias, $areas,
            $f_ini, $f_fin, $repositorio, $url_demo,
            $privado, $presupuesto, $uid
        );

        if ($ins->execute()) {
            $nuevo_id = $conexion->insert_id;
            $ins->close();

            // Agregar creador como admin del proyecto
            $ipu = $conexion->prepare(
                "INSERT INTO proyecto_usuarios (proyecto_id, usuario_id, rol_proyecto, permisos)
                 VALUES (?,?,'Líder','ver,editar,admin')"
            );
            $ipu->bind_param("ii", $nuevo_id, $uid);
            $ipu->execute();
            $ipu->close();

            // Agregar otros miembros seleccionados
            foreach ($miembros_ids as $idx => $mid) {
                $mid = (int)$mid;
                if ($mid === $uid) continue; // ya agregado
                $rol_m = htmlspecialchars($roles_mbs[$idx] ?? 'Colaborador', ENT_QUOTES);
                $ipm = $conexion->prepare(
                    "INSERT IGNORE INTO proyecto_usuarios (proyecto_id, usuario_id, rol_proyecto, permisos)
                     VALUES (?,?,?,'ver')"
                );
                $ipm->bind_param("iis", $nuevo_id, $mid, $rol_m);
                $ipm->execute();
                $ipm->close();
            }

            // KPIs iniciales si se proveyeron
            $kpi_nombres = $_POST['kpi_nombre'] ?? [];
            $kpi_valores = $_POST['kpi_valor']  ?? [];
            $kpi_iconos  = $_POST['kpi_icono']  ?? [];
            foreach ($kpi_nombres as $ki => $kn) {
                $kn = trim($kn); if (!$kn) continue;
                $kv = trim($kpi_valores[$ki] ?? '');
                $ko = trim($kpi_iconos[$ki]  ?? '📌');
                $ikpi = $conexion->prepare(
                    "INSERT INTO proyecto_kpis (proyecto_id, nombre, valor, icono) VALUES (?,?,?,?)"
                );
                $ikpi->bind_param("isss", $nuevo_id, $kn, $kv, $ko);
                $ikpi->execute();
                $ikpi->close();
            }

            // Avance inicial
            if (!empty($_POST['avance_titulo'])) {
                $av_tit  = trim($_POST['avance_titulo']);
                $av_desc = trim($_POST['avance_desc'] ?? '');
                $av_fec  = !empty($_POST['avance_fecha']) ? $_POST['avance_fecha'] : date('Y-m-d');
                $iav = $conexion->prepare(
                    "INSERT INTO proyecto_avances (proyecto_id, titulo, descripcion, fecha, autor_id)
                     VALUES (?,?,?,?,?)"
                );
                $iav->bind_param("isssi", $nuevo_id, $av_tit, $av_desc, $av_fec, $uid);
                $iav->execute();
                $iav->close();
            }

            // Registrar actividad
            $act = $conexion->prepare(
                "INSERT INTO actividad_usuario (usuario_id, tipo, descripcion)
                 VALUES (?,'proyecto','Creó el proyecto: $titulo')"
            );
            if ($act) { $act->bind_param("i", $uid); $act->execute(); $act->close(); }

            header("Location: proyecto.php?nuevo=1&id=$nuevo_id");
            exit();
        } else {
            $error = "Error al guardar el proyecto: " . $conexion->error;
            $ins->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Nuevo Proyecto — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
    :root{--hh:68px;}
    .np-wrap{max-width:900px;margin:40px auto;padding:0 24px 60px;}
    .np-hero{
      background:linear-gradient(135deg,#0b1f40,#0e2a1f);
      border:1px solid rgba(40,166,128,.2);
      border-radius:24px;padding:36px 40px;
      display:flex;align-items:center;gap:20px;margin-bottom:36px;
      position:relative;overflow:hidden;
    }
    .np-hero::before{
      content:'';position:absolute;inset:0;
      background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),
        linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);
      background-size:36px 36px;
    }
    .np-hero-ico{font-size:3.2rem;position:relative;z-index:1;}
    .np-hero-txt{position:relative;z-index:1;}
    .np-hero-txt h1{font-family:var(--font-d);font-size:1.6rem;font-weight:700;color:var(--txt);letter-spacing:2px;}
    .np-hero-txt p{color:var(--muted);font-size:.9rem;margin-top:4px;}

    /* ── Tarjeta sección ── */
    .np-card{
      background:var(--n800);border:1px solid rgba(255,255,255,.07);
      border-radius:20px;padding:28px 32px;margin-bottom:24px;
    }
    .np-section-hd{
      display:flex;align-items:center;gap:12px;
      margin-bottom:22px;padding-bottom:14px;
      border-bottom:1px solid rgba(255,255,255,.06);
    }
    .np-section-num{
      width:28px;height:28px;border-radius:50%;
      background:var(--green-dim);border:1px solid var(--green);
      display:flex;align-items:center;justify-content:center;
      font-size:.72rem;font-weight:800;color:var(--green-lt);flex-shrink:0;
    }
    .np-section-title{font-family:var(--font-d);font-size:.9rem;font-weight:700;color:var(--txt);letter-spacing:1px;}

    /* ── Grid de campos ── */
    .np-grid{display:grid;gap:18px;}
    .np-grid-2{grid-template-columns:1fr 1fr;}
    .np-grid-3{grid-template-columns:1fr 1fr 1fr;}
    @media(max-width:640px){.np-grid-2,.np-grid-3{grid-template-columns:1fr;}}

    /* ── Campo de formulario ── */
    .np-field{display:flex;flex-direction:column;gap:6px;}
    .np-label{
      font-size:.75rem;font-weight:700;color:var(--muted);
      text-transform:uppercase;letter-spacing:1px;
    }
    .np-label span.req{color:#f87171;margin-left:3px;}
    .np-input,.np-select,.np-textarea{
      background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.1);
      border-radius:12px;padding:11px 16px;
      color:var(--txt);font-family:var(--font-b);font-size:.9rem;
      transition:border-color .2s,background .2s;width:100%;
    }
    .np-input:focus,.np-select:focus,.np-textarea:focus{
      outline:none;border-color:var(--green);background:rgba(40,166,128,.05);
    }
    .np-input::placeholder,.np-textarea::placeholder{color:var(--dim);}
    .np-textarea{resize:vertical;min-height:100px;line-height:1.6;}
    .np-select option{background:var(--n800);}
    .np-hint{font-size:.72rem;color:var(--dim);margin-top:2px;}

    /* ── Progreso slider ── */
    .prog-row{display:flex;align-items:center;gap:16px;}
    .prog-row input[type=range]{flex:1;accent-color:var(--green);}
    .prog-val{
      font-family:var(--font-d);font-size:1rem;font-weight:700;
      color:var(--gold);min-width:48px;text-align:right;
    }

    /* ── Selector de icono ── */
    .ico-grid{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;}
    .ico-opt{
      width:38px;height:38px;border-radius:10px;
      background:rgba(255,255,255,.06);border:2px solid transparent;
      display:flex;align-items:center;justify-content:center;
      font-size:1.3rem;cursor:pointer;transition:all .15s;
    }
    .ico-opt:hover{background:rgba(40,166,128,.1);border-color:rgba(40,166,128,.3);}
    .ico-opt.on{background:var(--green-dim);border-color:var(--green);}

    /* ── KPI dinámico ── */
    .kpi-row{
      display:grid;grid-template-columns:2fr 1.5fr 1fr auto;gap:10px;
      align-items:center;background:rgba(255,255,255,.03);
      border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:12px 14px;
    }
    .kpi-row .rm-btn{
      width:30px;height:30px;border-radius:50%;background:rgba(239,68,68,.12);
      border:1px solid rgba(239,68,68,.25);color:#f87171;
      display:flex;align-items:center;justify-content:center;
      font-size:.75rem;cursor:pointer;transition:all .2s;flex-shrink:0;
    }
    .kpi-row .rm-btn:hover{background:rgba(239,68,68,.25);}
    #kpiList{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}

    /* ── Miembros equipo ── */
    .member-row{
      display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:center;
      background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);
      border-radius:12px;padding:12px 14px;
    }
    #memberList{display:flex;flex-direction:column;gap:8px;margin-bottom:10px;}

    /* ── Add button ── */
    .np-add-btn{
      display:inline-flex;align-items:center;gap:7px;
      padding:8px 16px;background:rgba(40,166,128,.1);
      border:1px solid rgba(40,166,128,.3);border-radius:10px;
      color:var(--green-lt);font-size:.82rem;font-weight:600;
      cursor:pointer;transition:all .2s;font-family:var(--font-b);
    }
    .np-add-btn:hover{background:var(--green-dim);border-color:var(--green);}

    /* ── Switch toggle ── */
    .sw-row{display:flex;align-items:center;gap:12px;}
    .sw{position:relative;width:44px;height:24px;flex-shrink:0;}
    .sw input{opacity:0;width:0;height:0;}
    .sw-slider{
      position:absolute;inset:0;background:rgba(255,255,255,.12);
      border-radius:99px;cursor:pointer;transition:background .3s;
    }
    .sw-slider::before{
      content:'';position:absolute;width:18px;height:18px;
      left:3px;bottom:3px;background:#fff;border-radius:50%;transition:transform .3s;
    }
    .sw input:checked + .sw-slider{background:var(--green);}
    .sw input:checked + .sw-slider::before{transform:translateX(20px);}
    .sw-label{font-size:.88rem;color:var(--muted);}

    /* ── Errors / success ── */
    .np-alert{
      padding:14px 18px;border-radius:12px;margin-bottom:20px;
      font-size:.88rem;display:flex;align-items:flex-start;gap:10px;
    }
    .np-alert-err{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);color:#f87171;}
    .np-alert-ok {background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
    .np-alert ul{margin:4px 0 0 16px;}

    /* ── Footer actions ── */
    .np-actions{
      display:flex;justify-content:flex-end;gap:12px;
      padding-top:24px;border-top:1px solid rgba(255,255,255,.06);
    }
    .np-btn-cancel{
      padding:12px 28px;background:rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.1);border-radius:14px;
      color:var(--muted);font-size:.9rem;font-weight:600;
      cursor:pointer;font-family:var(--font-b);transition:all .2s;
    }
    .np-btn-cancel:hover{background:rgba(255,255,255,.1);}
    .np-btn-save{
      padding:12px 32px;background:linear-gradient(135deg,var(--green),#1d8f6e);
      border:none;border-radius:14px;color:#fff;
      font-size:.9rem;font-weight:700;cursor:pointer;
      font-family:var(--font-b);transition:all .2s;
      box-shadow:0 4px 20px rgba(40,166,128,.35);
    }
    .np-btn-save:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(40,166,128,.45);}
  </style>
</head>
<body>

<!-- HEADER -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">ContainerRz</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link active">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php"        class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php"        class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>
      <div class="user-wrap">
        <button class="user-pill" onclick="toggleDrop(this)">
          <?php if(!empty($_SESSION['avatar'])): ?>
            <img src="<?= htmlspecialchars($_SESSION['avatar']) ?>" alt="" style="width:26px;height:26px;border-radius:50%;object-fit:cover;">
          <?php else: ?>
            <span class="user-av"><i class="fa fa-user"></i></span>
          <?php endif; ?>
          <span><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span>
          <i class="fa fa-chevron-down" style="font-size:.65rem;opacity:.6;"></i>
        </button>
        <div class="user-drop" id="userDrop">
          <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
          <a href="editar-perfil.php"><i class="fa fa-pen"></i> Editar perfil</a>
          <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Cerrar sesión</a>
        </div>
      </div>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<div class="np-wrap">

  <!-- Hero -->
  <div class="np-hero">
    <div class="np-hero-ico">🚀</div>
    <div class="np-hero-txt">
      <h1>Nuevo Proyecto</h1>
      <p>Completa la información para registrar el proyecto en ContainerRz</p>
    </div>
  </div>

  <!-- Alertas -->
  <?php if (!empty($errors)): ?>
  <div class="np-alert np-alert-err">
    <i class="fa fa-circle-exclamation" style="margin-top:2px;flex-shrink:0;"></i>
    <div>
      <strong>Por favor corrige los siguientes errores:</strong>
      <ul><?php foreach($errors as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?></ul>
    </div>
  </div>
  <?php endif; ?>
  <?php if ($error): ?>
  <div class="np-alert np-alert-err"><i class="fa fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST" action="">
    <input type="hidden" name="guardar" value="1">

    <!-- ══ 1. INFORMACIÓN BÁSICA ══════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">1</div>
        <span class="np-section-title">Información Básica</span>
      </div>

      <div class="np-grid np-grid-2" style="margin-bottom:18px;">
        <!-- Icono selector -->
        <div class="np-field">
          <label class="np-label">Icono del proyecto</label>
          <input type="hidden" name="icono" id="icoInput" value="🚀">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
            <span id="icoPreview" style="font-size:2.2rem;">🚀</span>
            <span class="np-hint">Haz clic en uno de los iconos:</span>
          </div>
          <div class="ico-grid" id="icoGrid">
            <?php foreach(['🚀','💻','🔐','🌐','🤖','📱','🎓','🔬','🌱','🎨','🏗','⚡','📊','🛡','🌍','🎮','🔧','📡','🏆','💡'] as $ico): ?>
            <div class="ico-opt<?= $ico==='🚀' ? ' on' : '' ?>" onclick="setIco('<?= $ico ?>')"><?= $ico ?></div>
            <?php endforeach; ?>
          </div>
        </div>

        <!-- Tipo -->
        <div class="np-field" style="align-self:start;">
          <label class="np-label">Tipo de proyecto <span class="req">*</span></label>
          <select name="tipo" class="np-select" required>
            <option value="propio"    <?= ($tipo_qt==='propio'||($_POST['tipo']??'')==='propio')    ? 'selected' : '' ?>>🏠 Proyecto Propio</option>
            <option value="comunidad" <?= ($tipo_qt==='otros' ||($_POST['tipo']??'')==='comunidad') ? 'selected' : '' ?>>🌍 Comunidad</option>
            <option value="cliente"   <?= ($_POST['tipo']??'')==='cliente'   ? 'selected' : '' ?>>🤝 Cliente</option>
            <option value="academico" <?= ($_POST['tipo']??'')==='academico' ? 'selected' : '' ?>>🎓 Académico</option>
          </select>
        </div>
      </div>

      <div class="np-grid" style="margin-bottom:18px;">
        <div class="np-field">
          <label class="np-label">Título del proyecto <span class="req">*</span></label>
          <input type="text" name="titulo" class="np-input" placeholder="Ej: Plataforma de Ciberseguridad VIROX"
                 value="<?= htmlspecialchars($_POST['titulo'] ?? '') ?>" maxlength="200" required>
        </div>
      </div>

      <div class="np-grid" style="margin-bottom:18px;">
        <div class="np-field">
          <label class="np-label">Descripción</label>
          <textarea name="descripcion" class="np-textarea" placeholder="Describe el objetivo, alcance y motivación del proyecto…"><?= htmlspecialchars($_POST['descripcion'] ?? '') ?></textarea>
        </div>
      </div>

      <div class="np-grid np-grid-3">
        <div class="np-field">
          <label class="np-label">Categoría</label>
          <input type="text" name="categoria" class="np-input" placeholder="Ej: Tecnología, Educación…"
                 value="<?= htmlspecialchars($_POST['categoria'] ?? '') ?>">
        </div>
        <div class="np-field">
          <label class="np-label">Subtipo</label>
          <input type="text" name="subtipo" class="np-input" placeholder="Ej: MVP, Investigación…"
                 value="<?= htmlspecialchars($_POST['subtipo'] ?? '') ?>">
        </div>
        <div class="np-field">
          <label class="np-label">Presupuesto (COP)</label>
          <input type="number" name="presupuesto" class="np-input" placeholder="0.00" min="0" step="0.01"
                 value="<?= htmlspecialchars($_POST['presupuesto'] ?? '') ?>">
        </div>
      </div>
    </div>

    <!-- ══ 2. ESTADO Y PROGRESO ════════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">2</div>
        <span class="np-section-title">Estado y Progreso</span>
      </div>

      <div class="np-grid np-grid-2" style="margin-bottom:18px;">
        <div class="np-field">
          <label class="np-label">Estado actual <span class="req">*</span></label>
          <select name="estado" class="np-select" required>
            <option value="planeado"   <?= ($_POST['estado']??'')==='planeado'   ? 'selected':'' ?>>◌ Planeado</option>
            <option value="activo"     <?= ($_POST['estado']??'activo')==='activo' ? 'selected':'' ?>>● Activo</option>
            <option value="pausado"    <?= ($_POST['estado']??'')==='pausado'    ? 'selected':'' ?>>⏸ En Pausa</option>
            <option value="completado" <?= ($_POST['estado']??'')==='completado' ? 'selected':'' ?>>✔ Completado</option>
            <option value="cancelado"  <?= ($_POST['estado']??'')==='cancelado'  ? 'selected':'' ?>>✖ Cancelado</option>
          </select>
        </div>
        <div class="np-field">
          <label class="np-label">Progreso: <span id="progLabel"><?= (int)($_POST['progreso']??0) ?>%</span></label>
          <div class="prog-row">
            <input type="range" name="progreso" id="progresoSlider" min="0" max="100" step="5"
                   value="<?= (int)($_POST['progreso']??0) ?>"
                   oninput="document.getElementById('progLabel').textContent=this.value+'%'">
            <span class="prog-val" id="progDisplay"><?= (int)($_POST['progreso']??0) ?>%</span>
          </div>
        </div>
      </div>

      <div class="np-grid np-grid-2">
        <div class="np-field">
          <label class="np-label">Fecha de inicio</label>
          <input type="date" name="fecha_inicio" class="np-input"
                 value="<?= htmlspecialchars($_POST['fecha_inicio'] ?? '') ?>">
        </div>
        <div class="np-field">
          <label class="np-label">Fecha estimada de fin</label>
          <input type="date" name="fecha_fin" class="np-input"
                 value="<?= htmlspecialchars($_POST['fecha_fin'] ?? '') ?>">
        </div>
      </div>
    </div>

    <!-- ══ 3. TECNOLOGÍAS Y ÁREAS ══════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">3</div>
        <span class="np-section-title">Tecnologías y Áreas</span>
      </div>

      <div class="np-grid np-grid-2">
        <div class="np-field">
          <label class="np-label">Tecnologías utilizadas</label>
          <input type="text" name="tecnologias" class="np-input"
                 placeholder="PHP, MySQL, React, Docker, Python…"
                 value="<?= htmlspecialchars($_POST['tecnologias'] ?? '') ?>">
          <span class="np-hint">Separadas por coma</span>
        </div>
        <div class="np-field">
          <label class="np-label">Áreas involucradas</label>
          <input type="text" name="areas" class="np-input"
                 placeholder="Backend, Seguridad, UX, DevOps…"
                 value="<?= htmlspecialchars($_POST['areas'] ?? '') ?>">
          <span class="np-hint">Separadas por coma</span>
        </div>
      </div>
    </div>

    <!-- ══ 4. ENLACES ══════════════════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">4</div>
        <span class="np-section-title">Repositorio y Demo</span>
      </div>

      <div class="np-grid np-grid-2">
        <div class="np-field">
          <label class="np-label"><i class="fa fa-code-branch" style="color:var(--green);"></i> Repositorio</label>
          <input type="url" name="repositorio" class="np-input" placeholder="https://github.com/..."
                 value="<?= htmlspecialchars($_POST['repositorio'] ?? '') ?>">
        </div>
        <div class="np-field">
          <label class="np-label"><i class="fa fa-external-link" style="color:var(--gold);"></i> URL de demo</label>
          <input type="url" name="url_demo" class="np-input" placeholder="https://demo.proyecto.com"
                 value="<?= htmlspecialchars($_POST['url_demo'] ?? '') ?>">
        </div>
      </div>

      <div class="sw-row" style="margin-top:16px;">
        <label class="sw">
          <input type="checkbox" name="privado" <?= !empty($_POST['privado']) ? 'checked' : '' ?>>
          <span class="sw-slider"></span>
        </label>
        <span class="sw-label">Proyecto privado (solo visible para miembros del equipo)</span>
      </div>
    </div>

    <!-- ══ 5. KPIs INICIALES ══════════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">5</div>
        <span class="np-section-title">KPIs (opcional)</span>
      </div>
      <p style="font-size:.82rem;color:var(--dim);margin-bottom:16px;">Define métricas clave para medir el éxito del proyecto.</p>

      <div id="kpiList"><!-- filas de KPI dinámicas --></div>

      <button type="button" class="np-add-btn" onclick="addKpi()">
        <i class="fa fa-plus"></i> Agregar KPI
      </button>
    </div>

    <!-- ══ 6. AVANCE INICIAL ══════════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">6</div>
        <span class="np-section-title">Avance Inicial (opcional)</span>
      </div>

      <div class="np-grid np-grid-2" style="margin-bottom:14px;">
        <div class="np-field">
          <label class="np-label">Título del avance</label>
          <input type="text" name="avance_titulo" class="np-input" placeholder="Ej: Kick-off del proyecto"
                 value="<?= htmlspecialchars($_POST['avance_titulo'] ?? '') ?>">
        </div>
        <div class="np-field">
          <label class="np-label">Fecha</label>
          <input type="date" name="avance_fecha" class="np-input"
                 value="<?= htmlspecialchars($_POST['avance_fecha'] ?? date('Y-m-d')) ?>">
        </div>
      </div>
      <div class="np-field">
        <label class="np-label">Descripción del avance</label>
        <textarea name="avance_desc" class="np-textarea" style="min-height:70px;"
                  placeholder="Describe qué se logró en este hito…"><?= htmlspecialchars($_POST['avance_desc'] ?? '') ?></textarea>
      </div>
    </div>

    <!-- ══ 7. EQUIPO ══════════════════════════════════════════════════ -->
    <div class="np-card">
      <div class="np-section-hd">
        <div class="np-section-num">7</div>
        <span class="np-section-title">Equipo del Proyecto</span>
      </div>
      <p style="font-size:.82rem;color:var(--dim);margin-bottom:16px;">
        Tú serás agregado automáticamente como Líder. Agrega más colaboradores si lo deseas.
      </p>

      <div id="memberList"><!-- filas de miembros --></div>

      <button type="button" class="np-add-btn" onclick="addMember()">
        <i class="fa fa-user-plus"></i> Agregar miembro
      </button>
    </div>

    <!-- ══ ACCIONES ════════════════════════════════════════════════════ -->
    <div class="np-actions">
      <button type="button" class="np-btn-cancel" onclick="history.back()">
        <i class="fa fa-arrow-left"></i> Cancelar
      </button>
      <button type="submit" class="np-btn-save">
        <i class="fa fa-floppy-disk"></i> Guardar Proyecto
      </button>
    </div>

  </form>
</div><!-- /np-wrap -->


<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand"><span class="brand-hex">⬡</span><span class="brand-name">VIROX</span></div>
    <p class="footer-copy">© 2025 Team VIROX</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyectos</a>
      <a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>


<script>
/* ── Header scroll ── */
window.addEventListener('scroll',()=>
  document.getElementById('siteHeader').classList.toggle('hdr-on',scrollY>40));

/* ── Burger ── */
document.getElementById('burger').addEventListener('click',function(){
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Dropdown usuario ── */
function toggleDrop(btn){
  const d = document.getElementById('userDrop');
  d.classList.toggle('open');
  btn.classList.toggle('active');
}
document.addEventListener('click', e=>{
  if(!e.target.closest('.user-wrap')) {
    document.getElementById('userDrop')?.classList.remove('open');
  }
});

/* ── Icono selector ── */
function setIco(ico){
  document.getElementById('icoInput').value = ico;
  document.getElementById('icoPreview').textContent = ico;
  document.querySelectorAll('.ico-opt').forEach(o=>o.classList.remove('on'));
  event.target.classList.add('on');
}

/* ── Progreso slider ── */
const slider = document.getElementById('progresoSlider');
const disp   = document.getElementById('progDisplay');
slider.addEventListener('input', ()=> disp.textContent = slider.value + '%');

/* ── KPI dinámico ── */
let kpiCount = 0;
function addKpi(){
  const list = document.getElementById('kpiList');
  const idx  = kpiCount++;
  const row  = document.createElement('div');
  row.className = 'kpi-row';
  row.innerHTML = `
    <input type="text" name="kpi_nombre[]" class="np-input" placeholder="Nombre del KPI" style="background:transparent;border:none;padding:0;">
    <input type="text" name="kpi_valor[]"  class="np-input" placeholder="Valor actual"   style="background:transparent;border:none;padding:0;">
    <input type="text" name="kpi_icono[]"  class="np-input" placeholder="📌 Icono"        style="background:transparent;border:none;padding:0;width:70px;">
    <button type="button" class="rm-btn" onclick="this.closest('.kpi-row').remove()"><i class="fa fa-times"></i></button>
  `;
  list.appendChild(row);
  row.querySelector('input').focus();
}

/* ── Miembros dinámico ── */
const USUARIOS = <?= json_encode(array_map(fn($u)=>['id'=>$u['id'],'name'=>$u['nombre'].' '.$u['apellido']], $usuarios_lista)) ?>;

function addMember(){
  const list = document.getElementById('memberList');
  const row  = document.createElement('div');
  row.className = 'member-row';

  const opts = USUARIOS.map(u=>`<option value="${u.id}">${u.name}</option>`).join('');
  row.innerHTML = `
    <select name="miembros[]" class="np-select">${opts}</select>
    <input type="text" name="roles_miembros[]" class="np-input" placeholder="Rol en el proyecto (Ej: Dev, QA…)">
    <button type="button" class="rm-btn kpi-row" onclick="this.closest('.member-row').remove()"
            style="width:30px;height:30px;border-radius:50%;background:rgba(239,68,68,.12);
                   border:1px solid rgba(239,68,68,.25);color:#f87171;display:flex;align-items:center;
                   justify-content:center;font-size:.75rem;cursor:pointer;flex-shrink:0;">
      <i class="fa fa-times"></i>
    </button>
  `;
  list.appendChild(row);
}
</script>
</body>
</html>