<?php
// ═══════════════════════════════════════════════════════════════════════════
//  VIROX — admin/index.php  |  Dashboard del Administrador
//  Roles permitidos: admin, superadmin
// ═══════════════════════════════════════════════════════════════════════════
include '../conexion.php';
session_start();

// ── Seguridad ────────────────────────────────────────────────────────────
if (!isset($_SESSION['user_id'])) { header('Location: ../login.php'); exit(); }
if (!in_array($_SESSION['rol'] ?? '', ['admin'])) {
    header('Location: ../index.php'); exit();
}

$uid    = (int)$_SESSION['user_id'];
$rol    = $_SESSION['rol']      ?? 'admin';
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'Admin');
$avatar = htmlspecialchars($_SESSION['avatar']    ?? '../assets/avatar-default.png');
$es_super = ($rol === 'superadmin');

// ── Helpers ──────────────────────────────────────────────────────────────
function qrow(mysqli $db, string $sql, string $t = '', ...$p): ?array {
    $s = $db->prepare($sql); if (!$s) return null;
    if ($t) $s->bind_param($t, ...$p);
    $s->execute(); $r = $s->get_result()->fetch_assoc(); $s->close(); return $r;
}
function qall(mysqli $db, string $sql, string $t = '', ...$p): array {
    $s = $db->prepare($sql); if (!$s) return [];
    if ($t) $s->bind_param($t, ...$p);
    $s->execute(); $rows = $s->get_result()->fetch_all(MYSQLI_ASSOC); $s->close(); return $rows;
}
function qval(mysqli $db, string $sql, string $t = '', ...$p): mixed {
    $r = qrow($db, $sql, $t, ...$p); return $r ? reset($r) : 0;
}

// ══════════════════════════════════════════════════════════════════════════
//  PROCESAR ACCIONES AJAX/POST
// ══════════════════════════════════════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $accion = $_POST['accion'] ?? '';

    // ── Cambiar rol de usuario ───────────────────────────────────────────
    if ($accion === 'cambiar_rol') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $nuevo_rol = $_POST['rol'] ?? '';
        $roles_validos = ['cliente','consultor','creador','empleado'];
        if ($es_super) $roles_validos[] = 'superadmin';
        if ($user_id && in_array($nuevo_rol, $roles_validos) && $user_id !== $uid) {
            $u = $conexion->prepare("UPDATE usuarios SET rol=? WHERE id=?");
            if ($u) { $u->bind_param("si", $nuevo_rol, $user_id); $u->execute(); $u->close(); }
            // Auditoría
            $ins = $conexion->prepare("INSERT INTO auditoria (usuario_id,tabla,operacion,registro_id,datos_despues,ip,fecha) VALUES (?,?,?,?,?,?,NOW())");
            if ($ins) { $ip = $_SERVER['REMOTE_ADDR']; $det = json_encode(['rol'=>$nuevo_rol]); $ins->bind_param("isssss",$uid,'usuarios','UPDATE',$user_id,$det,$ip); $ins->execute(); $ins->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Acción no permitida']);
        exit();
    }

    if ($accion === 'toggle_activo') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $activo  = (int)($_POST['activo'] ?? 0);
        if ($user_id && $user_id !== $uid) {
            $u = $conexion->prepare("UPDATE usuarios SET activo=? WHERE id=?");
            if ($u) { $u->bind_param("ii", $activo, $user_id); $u->execute(); $u->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'No permitido']);
        exit();
    }

    // ── Verificar usuario ────────────────────────────────────────────────
    if ($accion === 'verificar_usuario') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $ver     = (int)($_POST['verificado'] ?? 1);
        if ($user_id) {
            $u = $conexion->prepare("UPDATE usuarios SET verificado=? WHERE id=?");
            if ($u) { $u->bind_param("ii", $ver, $user_id); $u->execute(); $u->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false]);
        exit();
    }

    // ── Gestionar adquisición de servicio ────────────────────────────────
    if ($accion === 'gestionar_adquisicion') {
        $adq_id = (int)($_POST['adq_id'] ?? 0);
        $estado = in_array($_POST['estado']??'',['pagado','cancelado','reembolsado']) ? $_POST['estado'] : '';
        if ($adq_id && $estado) {
            $u = $conexion->prepare("UPDATE servicio_adquisiciones SET estado=? WHERE id=?");
            if ($u) { $u->bind_param("si",$estado,$adq_id); $u->execute(); $u->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos inválidos']);
        exit();
    }

    // ── Gestionar PQRS ───────────────────────────────────────────────────
    if ($accion === 'gestionar_pqrs') {
        $pqrs_id   = (int)($_POST['pqrs_id'] ?? 0);
        $estado    = in_array($_POST['estado']??'',['abierto','en_proceso','resuelto','cerrado']) ? $_POST['estado'] : '';
        $respuesta = htmlspecialchars(trim($_POST['respuesta'] ?? ''), ENT_QUOTES);
        if ($pqrs_id && $estado) {
            $u = $conexion->prepare("UPDATE pqrs SET estado=?, respuesta=?, fecha_respuesta=NOW(), respondido_por=? WHERE id=?");
            if ($u) { $u->bind_param("ssii",$estado,$respuesta,$uid,$pqrs_id); $u->execute(); $u->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos inválidos']);
        exit();
    }

    // ── Crear proyecto ───────────────────────────────────────────────────
    if ($accion === 'crear_proyecto') {
        $titulo = htmlspecialchars(trim($_POST['titulo'] ?? ''), ENT_QUOTES);
        $desc   = htmlspecialchars(trim($_POST['descripcion'] ?? ''), ENT_QUOTES);
        $tipo   = in_array($_POST['tipo']??'',['propio','comunidad','cliente','academico']) ? $_POST['tipo'] : 'propio';
        $icon   = htmlspecialchars(trim($_POST['icono'] ?? '🚀'), ENT_QUOTES);
        $areas  = htmlspecialchars(trim($_POST['areas'] ?? ''), ENT_QUOTES);
        $tecn   = htmlspecialchars(trim($_POST['tecnologias'] ?? ''), ENT_QUOTES);
        $f_ini  = $_POST['fecha_inicio'] ?? date('Y-m-d');
        if ($titulo) {
            $ins = $conexion->prepare("INSERT INTO proyectos (titulo,descripcion,tipo,icono,areas,tecnologias,fecha_inicio,estado,creado_por,fecha_creacion) VALUES (?,?,?,?,?,?,?,'planeado',?,NOW())");
            if ($ins) { $ins->bind_param("sssssssi",$titulo,$desc,$tipo,$icon,$areas,$tecn,$f_ini,$uid); $ins->execute(); $last=$conexion->insert_id; $ins->close(); echo json_encode(['ok'=>true,'id'=>$last]); }
            else echo json_encode(['ok'=>false,'error'=>$conexion->error]);
        } else echo json_encode(['ok'=>false,'error'=>'Título requerido']);
        exit();
    }

    // ── Asignar empleado a proyecto ──────────────────────────────────────
    if ($accion === 'asignar_empleado') {
        $proy_id  = (int)($_POST['proyecto_id'] ?? 0);
        $emp_id   = (int)($_POST['empleado_id'] ?? 0);
        $rol_proy = htmlspecialchars(trim($_POST['rol_proyecto'] ?? 'Colaborador'), ENT_QUOTES);
        if ($proy_id && $emp_id) {
            $ins = $conexion->prepare("INSERT IGNORE INTO proyecto_usuarios (proyecto_id,usuario_id,rol_proyecto,permisos,fecha_ingreso) VALUES (?,?,?,'ver,editar',NOW())");
            if ($ins) { $ins->bind_param("iis",$proy_id,$emp_id,$rol_proy); $ins->execute(); $ins->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Datos inválidos']);
        exit();
    }

    // ── Enviar mensaje masivo / notificación ─────────────────────────────
    if ($accion === 'enviar_mensaje') {
        $dest_id = (int)($_POST['destinatario_id'] ?? 0);
        $asunto  = htmlspecialchars(trim($_POST['asunto']  ?? ''), ENT_QUOTES);
        $mensaje = htmlspecialchars(trim($_POST['mensaje'] ?? ''), ENT_QUOTES);
        if ($dest_id && $asunto && $mensaje) {
            $ins = $conexion->prepare("INSERT INTO mensajes_internos (remitente_id,destinatario_id,asunto,mensaje,fecha) VALUES (?,?,?,?,NOW())");
            if ($ins) { $ins->bind_param("iiss",$uid,$dest_id,$asunto,$mensaje); $ins->execute(); $ins->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Completa todos los campos']);
        exit();
    }

    // ── Publicar novedad ─────────────────────────────────────────────────
    if ($accion === 'publicar_novedad') {
        $titulo = htmlspecialchars(trim($_POST['titulo'] ?? ''), ENT_QUOTES);
        $desc   = htmlspecialchars(trim($_POST['descripcion'] ?? ''), ENT_QUOTES);
        $tipo   = in_array($_POST['tipo']??'',['nuevo','mejora','mantenimiento','alerta']) ? $_POST['tipo'] : 'nuevo';
        if ($titulo) {
            $ins = $conexion->prepare("INSERT INTO novedades (titulo,descripcion,tipo,fecha) VALUES (?,?,?,NOW())");
            if ($ins) { $ins->bind_param("sss",$titulo,$desc,$tipo); $ins->execute(); $ins->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false,'error'=>'Título requerido']);
        exit();
    }

    // ── Actualizar configuración ─────────────────────────────────────────
    if ($accion === 'update_config') {
        $clave = htmlspecialchars(trim($_POST['clave'] ?? ''), ENT_QUOTES);
        $valor = htmlspecialchars(trim($_POST['valor'] ?? ''), ENT_QUOTES);
        if ($clave) {
            $u = $conexion->prepare("UPDATE configuracion SET valor=? WHERE clave=?");
            if ($u) { $u->bind_param("ss",$valor,$clave); $u->execute(); $u->close(); }
            echo json_encode(['ok'=>true]);
        } else echo json_encode(['ok'=>false]);
        exit();
    }

    echo json_encode(['ok'=>false,'error'=>'Acción no reconocida']);
    exit();
}

// ══════════════════════════════════════════════════════════════════════════
//  CARGAR DATOS
// ══════════════════════════════════════════════════════════════════════════

// ── Estadísticas generales ────────────────────────────────────────────
$stats = [
    'usuarios_total'    => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios"),
    'empleados'         => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios WHERE rol='empleado' AND activo=1"),
    'clientes'          => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios WHERE rol='cliente' AND activo=1"),
    'proyectos_activos' => (int)qval($conexion,"SELECT COUNT(*) FROM proyectos WHERE estado='activo'"),
    'proyectos_total'   => (int)qval($conexion,"SELECT COUNT(*) FROM proyectos"),
    'servicios_pend'    => (int)qval($conexion,"SELECT COUNT(*) FROM servicio_adquisiciones WHERE estado='pendiente'"),
    'servicios_total'   => (int)qval($conexion,"SELECT COUNT(*) FROM servicio_adquisiciones"),
    'pqrs_abiertas'     => (int)qval($conexion,"SELECT COUNT(*) FROM pqrs WHERE estado IN ('abierto','en_proceso')"),
    'ingresos_mes'      => (float)(qval($conexion,"SELECT COALESCE(SUM(monto),0) FROM servicio_adquisiciones WHERE estado='pagado' AND MONTH(fecha)=MONTH(NOW()) AND YEAR(fecha)=YEAR(NOW())") ?? 0),
    'msgs_sin_leer'     => (int)qval($conexion,"SELECT COUNT(*) FROM mensajes_internos WHERE destinatario_id=? AND leido=0","i",$uid),
    'usuarios_nuevos'   => (int)qval($conexion,"SELECT COUNT(*) FROM usuarios WHERE fecha_registro >= DATE_SUB(NOW(),INTERVAL 7 DAY)"),
    'logins_hoy'        => (int)qval($conexion,"SELECT COUNT(*) FROM log_accesos WHERE accion='login_ok' AND DATE(fecha)=CURDATE()"),
];

// ── Usuarios ──────────────────────────────────────────────────────────
$todos_usuarios = qall($conexion,
    "SELECT u.id, u.nombre, u.apellido, u.username, u.avatar, u.rol,
             u.activo, u.verificado, u.ultimo_acceso, u.fecha_registro,
             u.area_tecnologica, u.cargo_equipo, u.tipo_usuario,
             us.correo
     FROM usuarios u
     LEFT JOIN usuarios_seguridad us ON us.usuario_id = u.id
     ORDER BY u.fecha_registro DESC LIMIT 100"
);

$empleados = array_filter($todos_usuarios, fn($u) => in_array($u['rol'],['empleado','admin','superadmin','creador']));
$clientes  = array_filter($todos_usuarios, fn($u) => in_array($u['rol'],['cliente','consultor']));
$sin_verificar = array_filter($todos_usuarios, fn($u) => !$u['verificado'] && $u['activo']);

// ── Proyectos ─────────────────────────────────────────────────────────
$proyectos = qall($conexion,
    "SELECT p.*,
             u.nombre AS creador_nombre,
             COUNT(DISTINCT pu.usuario_id) AS miembros,
             COUNT(DISTINCT pa.id) AS avances
     FROM proyectos p
     LEFT JOIN usuarios u ON u.id = p.creado_por
     LEFT JOIN proyecto_usuarios pu ON pu.proyecto_id = p.id
     LEFT JOIN proyecto_avances  pa ON pa.proyecto_id = p.id
     GROUP BY p.id ORDER BY p.estado='activo' DESC, p.fecha_creacion DESC LIMIT 50"
);

// ── Adquisiciones de servicios ────────────────────────────────────────
$adquisiciones = qall($conexion,
    "SELECT sa.*, s.titulo AS srv_titulo, s.icono AS srv_icono, s.categoria AS srv_cat,
             u.nombre AS cli_nombre, u.apellido AS cli_apellido, u.avatar AS cli_avatar
     FROM servicio_adquisiciones sa
     JOIN servicios s ON s.id = sa.servicio_id
     JOIN usuarios  u ON u.id = sa.usuario_id
     ORDER BY sa.fecha DESC LIMIT 60"
);
$adq_pendientes = array_filter($adquisiciones, fn($a) => $a['estado'] === 'pendiente');

// ── PQRS ──────────────────────────────────────────────────────────────
$pqrs_lista = qall($conexion,
    "SELECT p.*, u.nombre AS usr_nombre, u.apellido AS usr_apellido
     FROM pqrs p LEFT JOIN usuarios u ON u.id = p.usuario_id
     ORDER BY
       FIELD(p.prioridad,'urgente','alta','normal','baja'),
       FIELD(p.estado,'abierto','en_proceso','resuelto','cerrado'),
       p.fecha DESC LIMIT 50"
);

// ── Mensajes recibidos ────────────────────────────────────────────────
$mensajes = qall($conexion,
    "SELECT mi.*, u.nombre AS rem_nombre, u.apellido AS rem_apellido, u.avatar AS rem_avatar
     FROM mensajes_internos mi
     JOIN usuarios u ON u.id = mi.remitente_id
     WHERE mi.destinatario_id = ?
     ORDER BY mi.leido ASC, mi.fecha DESC LIMIT 30",
    "i", $uid
);

// ── Log de accesos recientes ──────────────────────────────────────────
$log_accesos = qall($conexion,
    "SELECT la.*, u.nombre, u.apellido, u.rol
     FROM log_accesos la
     LEFT JOIN usuarios u ON u.id = la.usuario_id
     ORDER BY la.fecha DESC LIMIT 30"
);

// ── Empleados para asignación ─────────────────────────────────────────
$empleados_lista = qall($conexion,
    "SELECT id, nombre, apellido, area_tecnologica, cargo_equipo, rol
     FROM usuarios WHERE rol IN ('empleado','admin') AND activo=1 ORDER BY nombre"
);

// ── Novedades ─────────────────────────────────────────────────────────
$novedades = qall($conexion,
    "SELECT * FROM novedades ORDER BY fecha DESC LIMIT 10"
);

// ── Configuración del sistema ─────────────────────────────────────────
$config_sistema = qall($conexion,
    "SELECT clave, valor, grupo, tipo FROM configuracion
     WHERE grupo IN ('empresa','general','seguridad','contacto') ORDER BY grupo, clave"
);
$config_map = [];
foreach ($config_sistema as $c) $config_map[$c['clave']] = $c['valor'];

// ── Ingresos últimos 7 días (para gráfico) ────────────────────────────
$ingresos_7d = qall($conexion,
    "SELECT DATE(fecha) AS dia, COALESCE(SUM(monto),0) AS total, COUNT(*) AS cnt
     FROM servicio_adquisiciones
     WHERE estado='pagado' AND fecha >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
     GROUP BY DATE(fecha) ORDER BY dia ASC"
);

// ── Usuarios nuevos por día (últimos 7 días) ──────────────────────────
$usuarios_7d = qall($conexion,
    "SELECT DATE(fecha_registro) AS dia, COUNT(*) AS cnt
     FROM usuarios WHERE fecha_registro >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
     GROUP BY DATE(fecha_registro) ORDER BY dia ASC"
);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Panel Admin — ContainerRz</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
  /* ══ VARIABLES & RESET ══ */
  :root{
    --n950:#010610;--n900:#020817;--n800:#0c1526;
    --n700:#111827;--n600:#182035;--n500:#1e2d47;--n400:#243450;
    --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.13);
    --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.13);
    --blue:#3b82f6;--blue-lt:#93c5fd;--blue-dim:rgba(59,130,246,.13);
    --purple:#8b5cf6;--purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
    --red:#ef4444;--red-lt:#fca5a5;--red-dim:rgba(239,68,68,.12);
    --orange:#f97316;--orange-dim:rgba(249,115,22,.13);
    --teal:#14b8a6;--teal-dim:rgba(20,184,166,.13);
    --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
    --sh-sm:0 4px 18px rgba(0,0,0,.4);--sh-md:0 10px 36px rgba(0,0,0,.5);--sh-lg:0 24px 60px rgba(0,0,0,.65);
    --r-sm:8px;--r-md:14px;--r-lg:20px;--r-xl:28px;
    --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
    --sidebar-w:260px;--topbar-h:64px;
  }
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
  html{scroll-behavior:smooth;}
  body{font-family:var(--font-b);background:var(--n950);color:var(--txt);min-height:100vh;overflow-x:hidden;}
  ::-webkit-scrollbar{width:5px;height:5px;}::-webkit-scrollbar-track{background:var(--n800);}::-webkit-scrollbar-thumb{background:var(--gold);border-radius:99px;}
  a{text-decoration:none;color:inherit;}button{cursor:pointer;border:none;font-family:var(--font-b);background:none;}img{display:block;max-width:100%;}

  /* ══ LAYOUT ══ */
  .adm-wrap{display:grid;grid-template-columns:var(--sidebar-w) 1fr;grid-template-rows:var(--topbar-h) 1fr;grid-template-areas:"sidebar topbar""sidebar main";min-height:100vh;}

  /* ══ SIDEBAR ══ */
  .adm-sidebar{grid-area:sidebar;position:fixed;top:0;left:0;bottom:0;width:var(--sidebar-w);z-index:300;background:var(--n900);border-right:1px solid rgba(218,165,32,.15);display:flex;flex-direction:column;transition:transform .3s;}
  .sb-brand{display:flex;align-items:center;gap:10px;padding:0 20px;height:var(--topbar-h);border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;}
  .sb-brand-ico{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--gold),#b8860b);display:flex;align-items:center;justify-content:center;font-size:.85rem;color:#000;font-family:var(--font-d);font-weight:900;box-shadow:0 0 12px rgba(218,165,32,.35);}
  .sb-brand-name{font-family:var(--font-d);font-size:.9rem;font-weight:900;color:var(--gold);letter-spacing:3px;}
  .sb-badge{margin-left:auto;padding:2px 8px;background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);border-radius:99px;font-size:.58rem;font-weight:700;color:var(--gold-lt);letter-spacing:1px;}
  .sb-badge.super{background:rgba(139,92,246,.15);border-color:rgba(139,92,246,.4);color:var(--purple-lt);}

  .sb-profile{display:flex;align-items:center;gap:12px;padding:16px 20px;border-bottom:1px solid rgba(255,255,255,.06);flex-shrink:0;}
  .sb-av{width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);box-shadow:0 0 12px rgba(218,165,32,.3);flex-shrink:0;}
  .sb-uname{font-size:.82rem;font-weight:700;color:var(--txt);}
  .sb-urole{font-size:.65rem;color:var(--gold-lt);text-transform:uppercase;letter-spacing:1px;}
  .sb-status{display:flex;align-items:center;gap:4px;margin-top:2px;}
  .sb-dot{width:6px;height:6px;border-radius:50%;background:var(--green);animation:sdot 2s ease-in-out infinite;}
  @keyframes sdot{0%,100%{opacity:1}50%{opacity:.4}}
  .sb-status-txt{font-size:.62rem;color:var(--muted);}

  .sb-nav{flex:1;overflow-y:auto;padding:12px 10px;}
  .sb-nav::-webkit-scrollbar{width:2px;}
  .sb-sec-lbl{font-size:.58rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:10px 10px 4px;}
  .sb-item{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:var(--r-md);color:var(--muted);font-size:.84rem;font-weight:600;cursor:pointer;transition:all .2s;border-left:3px solid transparent;margin-bottom:2px;}
  .sb-item:hover{background:rgba(255,255,255,.05);color:var(--txt);}
  .sb-item.active{background:var(--gold-dim);color:var(--gold-lt);border-left-color:var(--gold);}
  .sb-item .sb-ico{width:18px;text-align:center;flex-shrink:0;}
  .sb-item .sb-badge-cnt{margin-left:auto;padding:1px 6px;background:var(--red);color:#fff;border-radius:99px;font-size:.58rem;font-weight:800;}
  .sb-item .sb-badge-cnt.gold{background:var(--gold);color:#000;}
  .sb-sep{height:1px;background:rgba(255,255,255,.06);margin:8px 10px;}
  .sb-footer{padding:12px 10px;border-top:1px solid rgba(255,255,255,.06);display:flex;gap:6px;flex-shrink:0;}
  .sb-foot-btn{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:8px;border-radius:var(--r-md);font-size:.75rem;font-weight:600;transition:all .2s;}
  .sfb-emp{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.2);color:var(--green-lt);}
  .sfb-emp:hover{background:rgba(40,166,128,.2);}
  .sfb-logout{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);color:#f87171;}
  .sfb-logout:hover{background:rgba(239,68,68,.2);}

  /* ══ TOPBAR ══ */
  .adm-topbar{grid-area:topbar;position:sticky;top:0;z-index:200;height:var(--topbar-h);background:rgba(2,8,23,.92);backdrop-filter:blur(20px);border-bottom:1px solid rgba(218,165,32,.12);display:flex;align-items:center;gap:14px;padding:0 24px;}
  .tb-burger{display:none;width:36px;height:36px;border-radius:var(--r-sm);background:rgba(255,255,255,.05);color:var(--muted);align-items:center;justify-content:center;font-size:.9rem;}
  .tb-title{font-family:var(--font-d);font-size:.85rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .tb-sec-name{font-size:.78rem;color:var(--muted);}
  .tb-search{flex:1;max-width:380px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);border-radius:99px;padding:7px 16px;transition:all .2s;}
  .tb-search:focus-within{border-color:var(--gold);box-shadow:0 0 0 3px rgba(218,165,32,.1);}
  .tb-search input{background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:100%;}
  .tb-search input::placeholder{color:var(--dim);}
  .tb-actions{margin-left:auto;display:flex;align-items:center;gap:8px;}
  .tb-action-btn{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.8rem;transition:all .2s;position:relative;cursor:pointer;}
  .tb-action-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .tb-notif-dot{position:absolute;top:5px;right:5px;width:8px;height:8px;border-radius:50%;background:var(--red);border:2px solid var(--n900);}
  .tb-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid var(--gold);cursor:pointer;}

  /* ══ MAIN ══ */
  .adm-main{grid-area:main;padding:28px;min-width:0;}
  .adm-section{display:none;animation:secIn .35s ease both;}
  .adm-section.active{display:block;}
  @keyframes secIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

  /* ══ HERO ══ */
  .adm-hero{position:relative;overflow:hidden;border-radius:var(--r-xl);padding:28px 32px;background:linear-gradient(135deg,#0a1f3d,#1a1000,#0d2a1a);margin-bottom:24px;border:1px solid rgba(218,165,32,.2);}
  .ah-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(218,165,32,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(218,165,32,.04) 1px,transparent 1px);background-size:40px 40px;}
  .ah-orb{position:absolute;border-radius:50%;filter:blur(80px);}
  .aho1{width:300px;height:300px;background:radial-gradient(circle,rgba(218,165,32,.18),transparent 70%);top:-80px;right:-60px;animation:aho 9s ease-in-out infinite;}
  .aho2{width:250px;height:250px;background:radial-gradient(circle,rgba(40,166,128,.12),transparent 70%);bottom:-60px;left:-40px;animation:aho 11s ease-in-out infinite reverse;}
  @keyframes aho{0%,100%{transform:translate(0,0)}50%{transform:translate(15px,-15px)}}
  .ah-content{position:relative;z-index:1;display:flex;align-items:center;gap:22px;}
  .ah-av{width:66px;height:66px;border-radius:50%;object-fit:cover;border:3px solid var(--gold);box-shadow:0 0 24px rgba(218,165,32,.4);flex-shrink:0;}
  .ah-name{font-family:var(--font-d);font-size:1.3rem;font-weight:900;color:var(--txt);letter-spacing:1px;margin-bottom:3px;}
  .ah-role{font-size:.78rem;color:var(--gold-lt);font-weight:700;letter-spacing:1px;margin-bottom:8px;}
  .ah-chips{display:flex;flex-wrap:wrap;gap:6px;}
  .ah-chip{padding:3px 10px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:99px;font-size:.65rem;color:var(--muted);}
  .ah-stats{margin-left:auto;display:flex;gap:20px;flex-shrink:0;}
  .ah-stat-n{font-family:var(--font-d);font-size:1.6rem;font-weight:900;color:var(--gold);}
  .ah-stat-l{font-size:.6rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

  /* ══ STATS GRID ══ */
  .stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(155px,1fr));gap:13px;margin-bottom:24px;}
  .stat-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px 18px;display:flex;align-items:center;gap:13px;transition:transform .25s,border-color .25s;cursor:pointer;}
  .stat-card:hover{transform:translateY(-4px);}
  .sc-ico{width:42px;height:42px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
  .sci-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);}
  .sci-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);}
  .sci-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);}
  .sci-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);}
  .sci-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);}
  .sci-orange{background:var(--orange-dim);border:1px solid rgba(249,115,22,.3);}
  .sci-teal{background:var(--teal-dim);border:1px solid rgba(20,184,166,.3);}
  .sc-num{font-family:var(--font-d);font-size:1.5rem;font-weight:900;color:var(--gold);line-height:1;}
  .sc-lbl{font-size:.65rem;color:var(--muted);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

  /* ══ SECCIÓN HEADERS ══ */
  .sec-hd{display:flex;align-items:center;gap:12px;margin-bottom:16px;}
  .sec-hd h2{font-family:var(--font-d);font-size:.9rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .sec-hd-line{flex:1;height:1px;background:linear-gradient(to right,rgba(218,165,32,.3),transparent);}
  .sec-hd-btn{display:flex;align-items:center;gap:6px;padding:6px 14px;border-radius:99px;font-size:.75rem;font-weight:700;transition:all .2s;cursor:pointer;}
  .shb-gold{background:var(--gold);color:#000;}
  .shb-gold:hover{background:var(--gold-lt);}
  .shb-green{background:var(--green);color:#fff;}
  .shb-green:hover{background:var(--green-lt);}
  .shb-ghost{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .shb-ghost:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .shb-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .shb-red:hover{background:var(--red);color:#fff;}

  /* ══ CARD BASE ══ */
  .card-base{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);transition:border-color .2s;}
  .card-base:hover{border-color:rgba(218,165,32,.2);}
  .card-p{padding:18px 20px;}

  /* ══ TABLA ══ */
  .tbl-wrap{overflow-x:auto;}
  .tbl{width:100%;border-collapse:collapse;}
  .tbl th{padding:10px 14px;text-align:left;font-size:.6rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.02);}
  .tbl td{padding:11px 14px;font-size:.82rem;color:var(--muted);border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle;}
  .tbl tr:hover td{background:rgba(255,255,255,.03);}
  .tbl tr:last-child td{border-bottom:none;}

  /* Badges */
  .badge{padding:3px 10px;border-radius:99px;font-size:.63rem;font-weight:700;display:inline-flex;align-items:center;gap:4px;}
  .b-superadmin{background:var(--purple-dim);color:var(--purple-lt);border:1px solid rgba(139,92,246,.3);}
  .b-admin{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-empleado{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-creador{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-cliente{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.1);}
  .b-consultor{background:var(--orange-dim);color:#fdba74;border:1px solid rgba(249,115,22,.3);}
  .b-activo{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-inactivo{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
  .b-verificado{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-pendiente{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-pagado{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-cancelado{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
  .b-urgente{background:var(--red-dim);color:var(--red-lt);border:1px solid rgba(239,68,68,.3);}
  .b-alta{background:var(--orange-dim);color:#fdba74;border:1px solid rgba(249,115,22,.3);}
  .b-normal{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-baja{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-abierto{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-en_proceso{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-resuelto{background:var(--teal-dim);color:#5eead4;border:1px solid rgba(20,184,166,.3);}
  .b-cerrado{background:rgba(255,255,255,.06);color:var(--muted);border:1px solid rgba(255,255,255,.1);}
  .b-activo_proy{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}
  .b-planeado{background:var(--blue-dim);color:var(--blue-lt);border:1px solid rgba(59,130,246,.3);}
  .b-pausado{background:var(--gold-dim);color:var(--gold-lt);border:1px solid rgba(218,165,32,.3);}
  .b-completado{background:var(--teal-dim);color:#5eead4;border:1px solid rgba(20,184,166,.3);}

  /* Botones acción */
  .act-btn{display:inline-flex;align-items:center;gap:4px;padding:5px 10px;border-radius:var(--r-sm);font-size:.7rem;font-weight:700;transition:all .2s;cursor:pointer;}
  .ab-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
  .ab-gold:hover{background:var(--gold);color:#000;}
  .ab-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
  .ab-green:hover{background:var(--green);color:#fff;}
  .ab-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .ab-red:hover{background:var(--red);color:#fff;}
  .ab-view{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .ab-view:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .ab-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);color:var(--purple-lt);}
  .ab-purple:hover{background:var(--purple);color:#fff;}

  /* ══ USUARIO MINI ══ */
  .usr-mini{display:flex;align-items:center;gap:8px;}
  .usr-av{width:30px;height:30px;border-radius:50%;object-fit:cover;border:1.5px solid var(--gold-dim);}
  .usr-av-ph{width:30px;height:30px;border-radius:50%;background:var(--gold-dim);display:flex;align-items:center;justify-content:center;font-size:.7rem;font-weight:700;color:var(--gold-lt);}
  .usr-name{font-size:.78rem;font-weight:600;color:var(--txt);}
  .usr-email{font-size:.65rem;color:var(--dim);}

  /* ══ PROYECTOS GRID ══ */
  .proy-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;}
  .proy-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);overflow:hidden;transition:transform .25s,border-color .25s,box-shadow .25s;cursor:pointer;}
  .proy-card:hover{transform:translateY(-4px);border-color:rgba(218,165,32,.3);box-shadow:var(--sh-md);}
  .proy-band{height:5px;}
  .proy-body{padding:16px 18px;}
  .proy-top{display:flex;align-items:flex-start;gap:10px;margin-bottom:10px;}
  .proy-ico{width:40px;height:40px;border-radius:var(--r-md);background:var(--n600);display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
  .proy-title{font-size:.9rem;font-weight:800;color:var(--txt);margin-bottom:3px;}
  .proy-creador{font-size:.65rem;color:var(--muted);}
  .proy-desc{font-size:.75rem;color:var(--muted);line-height:1.55;margin-bottom:10px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
  .proy-prog-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;margin-bottom:8px;}
  .proy-prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;}
  .proy-footer{display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.06);}
  .proy-meta{font-size:.65rem;color:var(--dim);display:flex;align-items:center;gap:4px;}

  /* ══ PQRS ══ */
  .pqrs-item{padding:14px 18px;border-radius:var(--r-md);background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);margin-bottom:8px;cursor:pointer;transition:all .2s;}
  .pqrs-item:hover{border-color:rgba(218,165,32,.2);background:rgba(255,255,255,.05);}
  .pqrs-item.urgente{border-left:3px solid var(--red);}
  .pqrs-item.alta{border-left:3px solid var(--orange);}
  .pqrs-item.normal{border-left:3px solid var(--blue);}
  .pqrs-item.baja{border-left:3px solid var(--green);}
  .pi-top{display:flex;align-items:center;gap:10px;margin-bottom:6px;}
  .pi-folio{font-family:var(--font-d);font-size:.65rem;color:var(--gold);}
  .pi-title{font-size:.85rem;font-weight:700;color:var(--txt);flex:1;}
  .pi-desc{font-size:.75rem;color:var(--muted);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
  .pi-meta{display:flex;gap:8px;margin-top:6px;flex-wrap:wrap;}

  /* ══ LOG ACCESOS ══ */
  .log-item{display:flex;align-items:center;gap:12px;padding:8px 14px;border-radius:var(--r-md);background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);margin-bottom:6px;font-size:.78rem;}
  .log-ico{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.75rem;flex-shrink:0;}
  .li-ok{background:var(--green-dim);color:var(--green-lt);}
  .li-fail{background:var(--red-dim);color:var(--red-lt);}
  .li-out{background:var(--blue-dim);color:var(--blue-lt);}
  .log-usuario{font-weight:600;color:var(--txt);flex:1;}
  .log-accion{font-size:.68rem;color:var(--muted);}
  .log-ip{font-size:.62rem;color:var(--dim);font-family:monospace;}
  .log-fecha{font-size:.62rem;color:var(--dim);flex-shrink:0;}

  /* ══ GRÁFICOS ══ */
  .chart-wrap{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px;margin-bottom:16px;}
  .chart-title{font-size:.78rem;font-weight:700;color:var(--txt);margin-bottom:14px;display:flex;align-items:center;gap:6px;}
  .bar-chart{display:flex;align-items:flex-end;gap:5px;height:80px;}
  .bar-col{display:flex;flex-direction:column;align-items:center;gap:4px;flex:1;}
  .bar{width:100%;border-radius:4px 4px 0 0;background:linear-gradient(to top,var(--gold),rgba(218,165,32,.3));min-height:4px;transition:height .8s ease;cursor:pointer;}
  .bar:hover{background:linear-gradient(to top,var(--green),rgba(40,166,128,.3));}
  .bar-lbl{font-size:.55rem;color:var(--dim);text-align:center;}
  .bar-val{font-size:.6rem;font-weight:700;color:var(--gold);}

  /* ══ CONFIG ══ */
  .config-section{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:20px;margin-bottom:14px;}
  .config-title{font-size:.75rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;}
  .config-row{display:flex;align-items:center;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.05);}
  .config-row:last-child{border-bottom:none;}
  .config-label{font-size:.82rem;font-weight:600;color:var(--txt);margin-bottom:2px;}
  .config-sub{font-size:.68rem;color:var(--muted);}
  .config-val{display:flex;align-items:center;gap:8px;}
  .config-input{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-sm);color:var(--txt);font-family:var(--font-b);font-size:.8rem;padding:6px 10px;outline:none;width:180px;transition:border-color .2s;}
  .config-input:focus{border-color:var(--gold);}
  .config-save{padding:5px 12px;background:var(--gold);color:#000;border-radius:var(--r-sm);font-size:.72rem;font-weight:700;transition:all .2s;cursor:pointer;}
  .config-save:hover{background:var(--gold-lt);}

  /* ══ TOGGLE ══ */
  .toggle{position:relative;width:40px;height:22px;flex-shrink:0;}
  .toggle input{display:none;}
  .toggle-sl{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:.3s;}
  .toggle-sl::before{content:'';position:absolute;width:16px;height:16px;background:#fff;border-radius:50%;top:3px;left:3px;transition:.3s;box-shadow:0 1px 3px rgba(0,0,0,.4);}
  .toggle input:checked + .toggle-sl{background:var(--green);}
  .toggle input:checked + .toggle-sl::before{transform:translateX(18px);}

  /* ══ QUICK ACTIONS ══ */
  .quick-actions{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:22px;}
  .qa-card{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 10px;background:var(--n800);border:1.5px dashed rgba(255,255,255,.1);border-radius:var(--r-lg);cursor:pointer;transition:all .25s;text-align:center;}
  .qa-card:hover{background:var(--gold-dim);border-color:var(--gold);transform:translateY(-4px);}
  .qa-ico{font-size:1.7rem;}
  .qa-lbl{font-size:.73rem;font-weight:700;color:var(--muted);}
  .qa-card:hover .qa-lbl{color:var(--gold-lt);}

  /* ══ KPI ══ */
  .kpi-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:22px;}
  .kpi-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:15px 17px;}
  .kpi-label{font-size:.6rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px;}
  .kpi-val{font-family:var(--font-d);font-size:1.7rem;font-weight:900;color:var(--gold);line-height:1;}
  .kpi-sub{font-size:.7rem;color:var(--muted);margin-top:4px;}
  .kpi-bar{height:4px;background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden;margin-top:8px;}
  .kpi-bar-fill{height:100%;background:linear-gradient(to right,var(--gold),var(--green));border-radius:99px;}

  /* ══ NOTIF / NOVEDAD ══ */
  .nov-item{display:flex;align-items:flex-start;gap:12px;padding:12px 16px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);margin-bottom:8px;}
  .nov-tipo{width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.85rem;flex-shrink:0;}
  .nov-nuevo{background:var(--green-dim);} .nov-mejora{background:var(--blue-dim);} .nov-mantenimiento{background:var(--gold-dim);} .nov-alerta{background:var(--red-dim);}
  .nov-body{flex:1;}
  .nov-title{font-size:.84rem;font-weight:700;color:var(--txt);}
  .nov-desc{font-size:.75rem;color:var(--muted);}
  .nov-fecha{font-size:.62rem;color:var(--dim);margin-top:3px;}

  /* ══ MSG ══ */
  .msg-item{display:flex;align-items:flex-start;gap:12px;padding:13px 16px;border-radius:var(--r-md);background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);cursor:pointer;transition:all .2s;margin-bottom:6px;}
  .msg-item:hover{background:rgba(255,255,255,.06);border-color:rgba(218,165,32,.2);}
  .msg-item.unread{border-left:3px solid var(--gold);background:rgba(218,165,32,.04);}
  .msg-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:1.5px solid var(--gold-dim);flex-shrink:0;}
  .msg-av-ph{width:34px;height:34px;border-radius:50%;background:var(--gold-dim);display:flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:700;color:var(--gold-lt);flex-shrink:0;}
  .msg-body{flex:1;min-width:0;}
  .msg-sender{font-size:.82rem;font-weight:700;color:var(--txt);}
  .msg-asunto{font-size:.75rem;color:var(--muted);}
  .msg-prev{font-size:.7rem;color:var(--dim);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .msg-meta{display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;}
  .msg-date{font-size:.62rem;color:var(--dim);}
  .msg-dot{width:8px;height:8px;border-radius:50%;background:var(--gold);}

  /* ══ EMPTY STATE ══ */
  .empty-state{text-align:center;padding:40px 20px;color:var(--dim);}
  .es-ico{font-size:2.8rem;margin-bottom:10px;opacity:.3;}
  .es-txt{font-size:.85rem;}

  /* ══ MODAL ══ */
  .adm-modal{position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;}
  .adm-modal.open{display:flex;}
  .am-box{background:var(--n800);border:1px solid rgba(218,165,32,.25);border-radius:var(--r-xl);width:100%;max-width:560px;box-shadow:var(--sh-lg);animation:amIn .3s ease both;}
  .am-box.wide{max-width:720px;}
  @keyframes amIn{from{opacity:0;transform:scale(.95) translateY(16px)}to{opacity:1;transform:none}}
  .am-header{display:flex;align-items:center;justify-content:space-between;padding:18px 22px;border-bottom:1px solid rgba(255,255,255,.07);}
  .am-title{font-family:var(--font-d);font-size:.86rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .am-close{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;}
  .am-close:hover{background:rgba(239,68,68,.2);color:#f87171;}
  .am-body{padding:18px 22px;}
  .am-footer{padding:14px 22px;border-top:1px solid rgba(255,255,255,.07);display:flex;gap:8px;justify-content:flex-end;}

  /* Inputs modal */
  .em-group{margin-bottom:13px;}
  .em-label{display:block;font-size:.68rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:5px;}
  .em-input{width:100%;padding:9px 13px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.86rem;transition:all .2s;outline:none;}
  .em-input:focus{border-color:var(--gold);background:rgba(218,165,32,.05);}
  textarea.em-input{resize:vertical;min-height:75px;line-height:1.6;}
  select.em-input option{background:var(--n700);}
  .em-btn{padding:9px 20px;border-radius:var(--r-md);font-weight:700;font-size:.82rem;transition:all .2s;cursor:pointer;}
  .em-btn-gold{background:var(--gold);color:#000;}
  .em-btn-gold:hover{background:var(--gold-lt);}
  .em-btn-green{background:var(--green);color:#fff;}
  .em-btn-green:hover{background:var(--green-lt);}
  .em-btn-cancel{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .em-btn-cancel:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .em-btn-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .em-btn-red:hover{background:var(--red);color:#fff;}

  /* ══ TOAST ══ */
  .toast-wrap{position:fixed;bottom:24px;right:24px;z-index:10000;display:flex;flex-direction:column;gap:8px;}
  .toast{display:flex;align-items:center;gap:10px;padding:11px 18px;border-radius:var(--r-md);font-size:.82rem;font-weight:600;animation:toastIn .3s ease both;max-width:320px;box-shadow:var(--sh-md);}
  @keyframes toastIn{from{opacity:0;transform:translateX(20px)}to{opacity:1;transform:none}}
  .t-ok{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
  .t-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:var(--red-lt);}
  .t-info{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}

  /* ══ RESPONSIVE ══ */
  @media(max-width:1024px){.proy-grid{grid-template-columns:1fr 1fr;}}
  @media(max-width:820px){
    .adm-wrap{grid-template-columns:1fr;grid-template-areas:"topbar""main";}
    .adm-sidebar{transform:translateX(-100%);}
    .adm-sidebar.open{transform:translateX(0);}
    .adm-main{padding:16px;}
    .tb-burger{display:flex;}
    .ah-stats{display:none;}
    .stats-grid{grid-template-columns:repeat(2,1fr);}
    .proy-grid{grid-template-columns:1fr;}
    .kpi-row{grid-template-columns:1fr 1fr;}
  }
  @media(max-width:480px){
    .stats-grid{grid-template-columns:1fr 1fr;}
    .quick-actions{grid-template-columns:repeat(2,1fr);}
  }
  </style>
</head>
<body>
<div class="adm-wrap" id="admWrap">

<!-- ══════════════════ SIDEBAR ══════════════════ -->
<aside class="adm-sidebar" id="admSidebar">
  <div class="sb-brand">
    <div class="sb-brand-ico">AD</div>
    <span class="sb-brand-name">ContainerRz</span>
    <span class="sb-badge <?= $es_super ? 'super' : '' ?>">
      <?= $es_super ? 'SUPER' : 'ADMIN' ?>
    </span>
  </div>
  <div class="sb-profile">
    <img src="<?= $avatar ?>" alt="Avatar" class="sb-av" onerror="this.src='../assets/Anzhet.png'">
    <div>
      <div class="sb-uname"><?= $nombre ?></div>
      <div class="sb-urole"><?= $es_super ? 'SuperAdministrador' : 'Administrador' ?></div>
      <div class="sb-status"><div class="sb-dot"></div><span class="sb-status-txt">En línea</span></div>
    </div>
  </div>
  <nav class="sb-nav">
    <div class="sb-sec-lbl">Principal</div>
    <div class="sb-item active" onclick="showSec('dashboard',this)"><span class="sb-ico"><i class="fa fa-gauge-high"></i></span>Dashboard</div>
    <div class="sb-item" onclick="showSec('usuarios',this)">
      <span class="sb-ico"><i class="fa fa-users"></i></span>Usuarios
      <?php if (count($sin_verificar)>0): ?><span class="sb-badge-cnt"><?= count($sin_verificar) ?></span><?php endif; ?>
    </div>
    <div class="sb-item" onclick="showSec('empleados',this)"><span class="sb-ico"><i class="fa fa-user-tie"></i></span>Empleados & Roles</div>
    <div class="sb-item" onclick="showSec('proyectos',this)">
      <span class="sb-ico"><i class="fa fa-diagram-project"></i></span>Proyectos
    </div>
    <div class="sb-sep"></div>
    <div class="sb-sec-lbl">Operaciones</div>
    <div class="sb-item" onclick="showSec('servicios',this)">
      <span class="sb-ico"><i class="fa fa-store"></i></span>Servicios
      <?php if ($stats['servicios_pend']>0): ?><span class="sb-badge-cnt"><?= $stats['servicios_pend'] ?></span><?php endif; ?>
    </div>
    <div class="sb-item" onclick="showSec('pqrs',this)">
      <span class="sb-ico"><i class="fa fa-clipboard-list"></i></span>PQRS
      <?php if ($stats['pqrs_abiertas']>0): ?><span class="sb-badge-cnt gold"><?= $stats['pqrs_abiertas'] ?></span><?php endif; ?>
    </div>
    <div class="sb-item" onclick="showSec('mensajes',this)">
      <span class="sb-ico"><i class="fa fa-envelope"></i></span>Mensajes
      <?php if ($stats['msgs_sin_leer']>0): ?><span class="sb-badge-cnt"><?= $stats['msgs_sin_leer'] ?></span><?php endif; ?>
    </div>
    <div class="sb-sep"></div>
    <div class="sb-sec-lbl">Analítica & Sistema</div>
    <div class="sb-item" onclick="showSec('reportes',this)"><span class="sb-ico"><i class="fa fa-chart-bar"></i></span>Reportes</div>
    <div class="sb-item" onclick="showSec('actividad',this)"><span class="sb-ico"><i class="fa fa-shield-halved"></i></span>Log de Actividad</div>
    <div class="sb-item" onclick="showSec('novedades',this)"><span class="sb-ico"><i class="fa fa-bell"></i></span>Novedades</div>
    <?php if ($es_super): ?>
    <div class="sb-item" onclick="showSec('config',this)"><span class="sb-ico"><i class="fa fa-gear"></i></span>Configuración</div>
    <?php endif; ?>
    <div class="sb-sep"></div>
    <div class="sb-sec-lbl">Plataforma</div>
    <div class="sb-item" onclick="window.location.href='../index.php'"><span class="sb-ico"><i class="fa fa-house"></i></span>Inicio VIROX</div>
    <div class="sb-item" onclick="window.location.href='../IA.php'"><span class="sb-ico"><i class="fa fa-robot"></i></span>Asistente IA</div>
  </nav>
  <div class="sb-footer">
    <a href="../logout.php" class="sb-foot-btn sfb-logout"><i class="fa fa-right-from-bracket"></i> Salir</a>
  </div>
</aside>


<!-- ══════════════════ TOPBAR ══════════════════ -->
<header class="adm-topbar">
  <button class="tb-burger" id="tbBurger" onclick="toggleSidebar()"><i class="fa fa-bars"></i></button>
  <div><div class="tb-title">Panel Administrativo</div><div class="tb-sec-name" id="tbSecName">Dashboard</div></div>
  <div class="tb-search">
    <i class="fa fa-search" style="color:var(--dim);font-size:.8rem;"></i>
    <input type="text" placeholder="Buscar usuario, proyecto, servicio..." id="globalSearch">
  </div>
  <div class="tb-actions">
    <button class="tb-action-btn" onclick="showSec('mensajes')" title="Mensajes">
      <i class="fa fa-envelope"></i>
      <?php if($stats['msgs_sin_leer']>0): ?><span class="tb-notif-dot"></span><?php endif; ?>
    </button>
    <button class="tb-action-btn" onclick="showSec('servicios')" title="Servicios pendientes">
      <i class="fa fa-bell"></i>
      <?php if($stats['servicios_pend']>0): ?><span class="tb-notif-dot"></span><?php endif; ?>
    </button>
    <img src="<?= $avatar ?>" alt="Avatar" class="tb-av"
         onclick="window.location.href='../perfil.php'"
         onerror="this.src='../assets/Anzhet.png'">
  </div>
</header>


<!-- ══════════════════ MAIN ══════════════════ -->
<main class="adm-main">


<!-- ████████████ DASHBOARD ████████████ -->
<div class="adm-section active" id="sec-dashboard">

  <!-- Hero -->
  <div class="adm-hero">
    <div class="ah-grid"></div><div class="ah-orb aho1"></div><div class="ah-orb aho2"></div>
    <div class="ah-content">
      <img src="<?= $avatar ?>" alt="" class="ah-av" onerror="this.src='../assets/Anzhet.png'">
      <div>
        <div style="font-size:.78rem;color:var(--muted);margin-bottom:2px;">👑 Bienvenido,</div>
        <div class="ah-name"><?= $nombre ?></div>
        <div class="ah-role"><?= $es_super ? '⭐ SuperAdministrador' : '🔑 Administrador' ?> — Team VIROX</div>
        <div class="ah-chips">
          <span class="ah-chip">Gestión de usuarios</span>
          <span class="ah-chip">Control de proyectos</span>
          <span class="ah-chip">Analítica del sistema</span>
        </div>
      </div>
      <div class="ah-stats">
        <div><div class="ah-stat-n"><?= $stats['usuarios_total'] ?></div><div class="ah-stat-l">Usuarios</div></div>
        <div><div class="ah-stat-n"><?= $stats['proyectos_activos'] ?></div><div class="ah-stat-l">Proyectos</div></div>
        <div><div class="ah-stat-n"><?= $stats['servicios_pend'] ?></div><div class="ah-stat-l">Pendientes</div></div>
        <div><div class="ah-stat-n">$<?= number_format($stats['ingresos_mes']/1000,0) ?>K</div><div class="ah-stat-l">Ingresos/mes</div></div>
      </div>
    </div>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card" onclick="showSec('usuarios')"><div class="sc-ico sci-blue"><i class="fa fa-users"></i></div><div><div class="sc-num"><?= $stats['usuarios_total'] ?></div><div class="sc-lbl">Usuarios totales</div></div></div>
    <div class="stat-card" onclick="showSec('empleados')"><div class="sc-ico sci-green"><i class="fa fa-user-tie"></i></div><div><div class="sc-num"><?= $stats['empleados'] ?></div><div class="sc-lbl">Empleados activos</div></div></div>
    <div class="stat-card" onclick="showSec('proyectos')"><div class="sc-ico sci-purple"><i class="fa fa-diagram-project"></i></div><div><div class="sc-num"><?= $stats['proyectos_activos'] ?></div><div class="sc-lbl">Proyectos activos</div></div></div>
    <div class="stat-card" onclick="showSec('servicios')"><div class="sc-ico sci-gold"><i class="fa fa-store"></i></div><div><div class="sc-num"><?= $stats['servicios_pend'] ?></div><div class="sc-lbl">Servicios pendientes</div></div></div>
    <div class="stat-card" onclick="showSec('pqrs')"><div class="sc-ico sci-orange"><i class="fa fa-clipboard-list"></i></div><div><div class="sc-num"><?= $stats['pqrs_abiertas'] ?></div><div class="sc-lbl">PQRS abiertas</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-teal"><i class="fa fa-dollar-sign"></i></div><div><div class="sc-num">$<?= number_format($stats['ingresos_mes'],0,',','.') ?></div><div class="sc-lbl">Ingresos este mes</div></div></div>
    <div class="stat-card"><div class="sc-ico sci-blue"><i class="fa fa-user-plus"></i></div><div><div class="sc-num"><?= $stats['usuarios_nuevos'] ?></div><div class="sc-lbl">Nuevos (7 días)</div></div></div>
    <div class="stat-card" onclick="showSec('actividad')"><div class="sc-ico sci-green"><i class="fa fa-right-to-bracket"></i></div><div><div class="sc-num"><?= $stats['logins_hoy'] ?></div><div class="sc-lbl">Logins hoy</div></div></div>
  </div>

  <!-- Quick actions -->
  <div class="sec-hd"><h2>⚡ Acciones Rápidas</h2><div class="sec-hd-line"></div></div>
  <div class="quick-actions">
    <div class="qa-card" onclick="openModalCrearProyecto()"><div class="qa-ico">🚀</div><div class="qa-lbl">Nuevo Proyecto</div></div>
    <div class="qa-card" onclick="showSec('usuarios')"><div class="qa-ico">👥</div><div class="qa-lbl">Gestionar Usuarios</div></div>
    <div class="qa-card" onclick="showSec('servicios')"><div class="qa-ico">✅</div><div class="qa-lbl">Aprobar Servicios</div></div>
    <div class="qa-card" onclick="showSec('pqrs')"><div class="qa-ico">📋</div><div class="qa-lbl">Atender PQRS</div></div>
    <div class="qa-card" onclick="openModalNovedad()"><div class="qa-ico">📢</div><div class="qa-lbl">Publicar Novedad</div></div>
    <div class="qa-card" onclick="openModalMensaje()"><div class="qa-ico">💬</div><div class="qa-lbl">Enviar Mensaje</div></div>
    <div class="qa-card" onclick="showSec('reportes')"><div class="qa-ico">📊</div><div class="qa-lbl">Ver Reportes</div></div>
    <div class="qa-card" onclick="showSec('actividad')"><div class="qa-ico">🛡</div><div class="qa-lbl">Log Seguridad</div></div>
  </div>

  <!-- Dos columnas -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">
    <!-- Servicios pendientes recientes -->
    <div class="card-base card-p">
      <div class="sec-hd" style="margin-bottom:12px;"><h2>🛒 Servicios Pendientes</h2><div class="sec-hd-line"></div><button class="sec-hd-btn shb-ghost" onclick="showSec('servicios')">Ver todos</button></div>
      <?php if (empty($adq_pendientes)): ?>
        <div class="empty-state"><div class="es-ico">✅</div><p class="es-txt">Sin servicios pendientes</p></div>
      <?php else: ?>
        <?php foreach (array_slice(array_values($adq_pendientes),0,5) as $a): ?>
        <div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);">
          <span style="font-size:1.1rem;"><?= htmlspecialchars($a['srv_icono']??'🛠') ?></span>
          <div style="flex:1;min-width:0;">
            <p style="font-size:.8rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($a['srv_titulo']) ?></p>
            <p style="font-size:.65rem;color:var(--muted);"><?= htmlspecialchars($a['cli_nombre'].' '.$a['cli_apellido']) ?> · $<?= number_format($a['monto'],0,',','.') ?></p>
          </div>
          <div style="display:flex;gap:4px;">
            <button class="act-btn ab-green" onclick="rapido_aprobar(<?= $a['id'] ?>)"><i class="fa fa-check"></i></button>
            <button class="act-btn ab-red" onclick="rapido_rechazar(<?= $a['id'] ?>)"><i class="fa fa-xmark"></i></button>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <!-- PQRS urgentes -->
    <div class="card-base card-p">
      <div class="sec-hd" style="margin-bottom:12px;"><h2>🚨 PQRS Urgentes</h2><div class="sec-hd-line"></div><button class="sec-hd-btn shb-ghost" onclick="showSec('pqrs')">Ver todas</button></div>
      <?php $urgentes = array_filter($pqrs_lista, fn($p) => in_array($p['prioridad'],['urgente','alta']) && in_array($p['estado'],['abierto','en_proceso'])); ?>
      <?php if (empty($urgentes)): ?>
        <div class="empty-state"><div class="es-ico">✅</div><p class="es-txt">Sin PQRS urgentes</p></div>
      <?php else: ?>
        <?php foreach (array_slice(array_values($urgentes),0,4) as $pq): ?>
        <div class="pqrs-item <?= $pq['prioridad'] ?>" style="margin-bottom:6px;" onclick="openModalPqrs(<?= $pq['id'] ?>,'<?= htmlspecialchars($pq['folio'],ENT_QUOTES) ?>','<?= htmlspecialchars($pq['asunto'],ENT_QUOTES) ?>','<?= htmlspecialchars($pq['descripcion'],ENT_QUOTES) ?>','<?= $pq['estado'] ?>')">
          <div class="pi-top">
            <span class="pi-folio"><?= $pq['folio'] ?></span>
            <span class="pi-title" style="font-size:.8rem;"><?= htmlspecialchars(mb_substr($pq['asunto'],0,50)) ?></span>
            <span class="badge b-<?= $pq['prioridad'] ?>"><?= ucfirst($pq['prioridad']) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- Últimos accesos -->
  <div style="margin-top:18px;">
    <div class="sec-hd"><h2>🔐 Actividad Reciente</h2><div class="sec-hd-line"></div><button class="sec-hd-btn shb-ghost" onclick="showSec('actividad')">Ver todo</button></div>
    <div class="card-base card-p">
      <?php foreach (array_slice($log_accesos,0,6) as $log):
        $ico_cls = match($log['accion']) { 'login_ok'=>'li-ok', 'login_fail'=>'li-fail', default=>'li-out' };
        $ico_fa  = match($log['accion']) { 'login_ok'=>'fa-right-to-bracket', 'login_fail'=>'fa-triangle-exclamation', default=>'fa-right-from-bracket' };
      ?>
      <div class="log-item">
        <div class="log-ico <?= $ico_cls ?>"><i class="fa <?= $ico_fa ?>"></i></div>
        <span class="log-usuario"><?= htmlspecialchars(($log['nombre']??'?').' '.($log['apellido']??'')) ?></span>
        <span class="log-accion"><?= str_replace('_',' ', $log['accion']) ?></span>
        <span class="log-ip"><?= htmlspecialchars($log['ip'] ?? '—') ?></span>
        <span class="log-fecha"><?= date('d M H:i', strtotime($log['fecha'])) ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

</div><!-- /dashboard -->


<!-- ████████████ USUARIOS ████████████ -->
<div class="adm-section" id="sec-usuarios">
  <div class="sec-hd">
    <h2>👥 Gestión de Usuarios</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:8px;">
      <button class="sec-hd-btn shb-ghost" id="fu-todos" onclick="filtrarUsuarios('todos',this)">Todos (<?= count($todos_usuarios) ?>)</button>
      <button class="sec-hd-btn shb-ghost" id="fu-sin-ver" onclick="filtrarUsuarios('sin_ver',this)">⚠️ Sin verificar (<?= count($sin_verificar) ?>)</button>
      <button class="sec-hd-btn shb-ghost" id="fu-inactivos" onclick="filtrarUsuarios('inactivos',this)">❌ Inactivos</button>
    </div>
  </div>
  <div class="card-base" style="overflow:hidden;">
    <div class="tbl-wrap">
      <table class="tbl" id="usrTable">
        <thead><tr>
          <th>#</th><th>Usuario</th><th>Correo</th><th>Rol</th>
          <th>Estado</th><th>Verificado</th><th>Último acceso</th><th>Acciones</th>
        </tr></thead>
        <tbody>
        <?php foreach ($todos_usuarios as $u):
          $av = !empty($u['avatar']) ? htmlspecialchars($u['avatar']) : '';
          $ini = mb_substr($u['nombre']??'U',0,1);
          $correo = htmlspecialchars($u['correo']??'—');
        ?>
        <tr data-activo="<?= $u['activo'] ?>" data-verificado="<?= $u['verificado'] ?>">
          <td style="color:var(--dim);font-size:.7rem;"><?= $u['id'] ?></td>
          <td>
            <div class="usr-mini">
              <?php if ($av): ?><img src="<?= $av ?>" class="usr-av" alt="" onerror="this.style.display='none'"><?php else: ?><div class="usr-av-ph"><?= $ini ?></div><?php endif; ?>
              <div>
                <div class="usr-name"><?= htmlspecialchars($u['nombre'].' '.$u['apellido']) ?></div>
                <div class="usr-email">@<?= htmlspecialchars($u['username']) ?></div>
              </div>
            </div>
          </td>
          <td style="font-size:.75rem;color:var(--muted);"><?= $correo ?></td>
          <td>
            <select onchange="cambiarRol(<?= $u['id'] ?>,this.value,this)"
                    style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:6px;color:var(--txt);font-family:var(--font-b);font-size:.72rem;padding:3px 6px;outline:none;"
                    <?= $u['id']==$uid ? 'disabled' : '' ?>>
              <?php foreach (['cliente','consultor','creador','empleado','admin'] as $r): ?>
              <option value="<?= $r ?>" <?= $u['rol']===$r?'selected':'' ?>><?= ucfirst($r) ?></option>
              <?php endforeach; ?>
              <?php if ($es_super): ?><option value="superadmin" <?= $u['rol']==='superadmin'?'selected':'' ?>>SuperAdmin</option><?php endif; ?>
            </select>
          </td>
          <td>
            <button onclick="toggleActivo(<?= $u['id'] ?>,<?= $u['activo']?0:1 ?>,this)"
                    class="badge <?= $u['activo'] ? 'b-activo' : 'b-inactivo' ?>"
                    style="cursor:pointer;">
              <?= $u['activo'] ? '✅ Activo' : '❌ Inactivo' ?>
            </button>
          </td>
          <td>
            <button onclick="verificarUsuario(<?= $u['id'] ?>,<?= $u['verificado']?0:1 ?>,this)"
                    class="badge <?= $u['verificado'] ? 'b-verificado' : 'b-pendiente' ?>"
                    style="cursor:pointer;">
              <?= $u['verificado'] ? '🔵 Verificado' : '⏳ Pendiente' ?>
            </button>
          </td>
          <td style="font-size:.7rem;color:var(--dim);"><?= !empty($u['ultimo_acceso']) ? date('d M Y',strtotime($u['ultimo_acceso'])) : '—' ?></td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="act-btn ab-view" onclick="window.open('../perfil.php?id=<?= $u['id'] ?>')"><i class="fa fa-eye"></i></button>
              <button class="act-btn ab-gold" onclick="openModalMensaje(<?= $u['id'] ?>,'<?= htmlspecialchars($u['nombre'],ENT_QUOTES) ?>')"><i class="fa fa-envelope"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████████████ EMPLEADOS & ROLES ████████████ -->
<div class="adm-section" id="sec-empleados">
  <div class="sec-hd">
    <h2>👔 Empleados & Asignación de Roles</h2><div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-gold" onclick="openModalAsignarProy()"><i class="fa fa-plus"></i> Asignar a proyecto</button>
  </div>

  <!-- KPIs empleados -->
  <div class="kpi-row" style="margin-bottom:20px;">
    <div class="kpi-card"><div class="kpi-label">Total empleados</div><div class="kpi-val"><?= $stats['empleados'] ?></div><div class="kpi-sub">Roles activos en equipo</div><div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= min(100,($stats['empleados']/$stats['usuarios_total'])*100) ?>%"></div></div></div>
    <div class="kpi-card"><div class="kpi-label">Tasa de ocupación</div><div class="kpi-val"><?= $stats['proyectos_activos'] > 0 ? min(100,round($stats['empleados']/$stats['proyectos_activos']*10)) : 0 ?>%</div><div class="kpi-sub">Empleados por proyecto activo</div><div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= min(100,($stats['empleados']/max(1,$stats['proyectos_activos'])*10)) ?>%"></div></div></div>
    <div class="kpi-card"><div class="kpi-label">Sin verificar</div><div class="kpi-val"><?= count($sin_verificar) ?></div><div class="kpi-sub">Requieren revisión manual</div><div class="kpi-bar"><div class="kpi-bar-fill" style="background:linear-gradient(to right,var(--red),var(--orange));width:<?= min(100,(count($sin_verificar)/max(1,$stats['usuarios_total']))*100) ?>%"></div></div></div>
    <div class="kpi-card"><div class="kpi-label">Clientes</div><div class="kpi-val"><?= $stats['clientes'] ?></div><div class="kpi-sub">Usuarios activos</div><div class="kpi-bar"><div class="kpi-bar-fill" style="width:<?= min(100,($stats['clientes']/$stats['usuarios_total'])*100) ?>%"></div></div></div>
  </div>

  <!-- Tabla empleados -->
  <div class="card-base" style="overflow:hidden;">
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Empleado</th><th>Área</th><th>Cargo</th><th>Rol actual</th><th>Disponible</th><th>Proyectos</th><th>Calificación</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach ($empleados as $e):
          $av  = !empty($e['avatar']) ? htmlspecialchars($e['avatar']) : '';
          $ini = mb_substr($e['nombre']??'E',0,1);
          $proyectos_emp = (int)qval($conexion,"SELECT COUNT(*) FROM proyecto_usuarios WHERE usuario_id=?","i",$e['id']);
          $calif = (float)qval($conexion,"SELECT COALESCE(calificacion,0) FROM equipo WHERE usuario_id=? LIMIT 1","i",$e['id']);
          $disp  = (int)qval($conexion,"SELECT COALESCE(disponible,1) FROM equipo WHERE usuario_id=? LIMIT 1","i",$e['id']);
        ?>
        <tr>
          <td>
            <div class="usr-mini">
              <?php if ($av): ?><img src="<?= $av ?>" class="usr-av" alt="" onerror="this.style.display='none'"><?php else: ?><div class="usr-av-ph"><?= $ini ?></div><?php endif; ?>
              <div><div class="usr-name"><?= htmlspecialchars($e['nombre'].' '.$e['apellido']) ?></div><div class="usr-email"><?= htmlspecialchars($e['correo']??'') ?></div></div>
            </div>
          </td>
          <td style="font-size:.75rem;color:var(--muted);"><?= htmlspecialchars($e['area_tecnologica']??'—') ?></td>
          <td style="font-size:.75rem;color:var(--muted);"><?= htmlspecialchars($e['cargo_equipo']??'—') ?></td>
          <td><span class="badge b-<?= $e['rol'] ?>"><?= ucfirst($e['rol']) ?></span></td>
          <td><span style="font-size:.75rem;color:<?= $disp ? 'var(--green-lt)' : 'var(--red-lt)' ?>;"><?= $disp ? '🟢 Sí' : '🔴 No' ?></span></td>
          <td><span style="font-family:var(--font-d);font-size:.8rem;color:var(--gold);"><?= $proyectos_emp ?></span></td>
          <td>
            <div style="display:flex;align-items:center;gap:4px;">
              <span style="color:var(--gold);font-size:.75rem;"><?= str_repeat('★',min(5,round($calif))) ?><?= str_repeat('☆',5-min(5,round($calif))) ?></span>
              <span style="font-size:.65rem;color:var(--dim);">(<?= number_format($calif,1) ?>)</span>
            </div>
          </td>
          <td>
            <div style="display:flex;gap:4px;">
              <button class="act-btn ab-gold" onclick="openModalAsignarProy(<?= $e['id'] ?>,'<?= htmlspecialchars($e['nombre'],ENT_QUOTES) ?>')"><i class="fa fa-diagram-project"></i> Asignar</button>
              <button class="act-btn ab-view" onclick="openModalMensaje(<?= $e['id'] ?>,'<?= htmlspecialchars($e['nombre'],ENT_QUOTES) ?>')"><i class="fa fa-envelope"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($empleados)): ?>
        <tr><td colspan="8"><div class="empty-state"><div class="es-ico">👔</div><p class="es-txt">No hay empleados registrados aún.</p></div></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████████████ PROYECTOS ████████████ -->
<div class="adm-section" id="sec-proyectos">
  <div class="sec-hd">
    <h2>🚀 Gestión de Proyectos</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:8px;">
      <button class="sec-hd-btn shb-ghost" onclick="filtrarProyectos('todos',this)">Todos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarProyectos('activo',this)">Activos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarProyectos('planeado',this)">Planeados</button>
      <button class="sec-hd-btn shb-gold" onclick="openModalCrearProyecto()"><i class="fa fa-plus"></i> Nuevo</button>
    </div>
  </div>
  <div class="proy-grid" id="proyGrid">
    <?php
    $band_cols = ['activo'=>'linear-gradient(to right,#28A680,transparent)','planeado'=>'linear-gradient(to right,#3b82f6,transparent)','pausado'=>'linear-gradient(to right,#DAA520,transparent)','completado'=>'linear-gradient(to right,#14b8a6,transparent)','cancelado'=>'linear-gradient(to right,#ef4444,transparent)'];
    foreach ($proyectos as $p):
      $band = $band_cols[$p['estado']] ?? $band_cols['planeado'];
      $prog = (int)$p['progreso'];
      $techs = array_filter(explode(',', $p['tecnologias']??''));
    ?>
    <div class="proy-card" data-estado="<?= $p['estado'] ?>" onclick="openModalAsignarProy(null,null,<?= $p['id'] ?>)">
      <div class="proy-band" style="background:<?= $band ?>"></div>
      <div class="proy-body">
        <div class="proy-top">
          <div class="proy-ico"><?= htmlspecialchars($p['icono']??'🚀') ?></div>
          <div>
            <div class="proy-title"><?= htmlspecialchars($p['titulo']) ?></div>
            <div class="proy-creador">por <?= htmlspecialchars($p['creador_nombre']??'Admin') ?></div>
          </div>
          <span class="badge b-<?= $p['estado']==='activo'?'activo_proy':$p['estado'] ?>" style="margin-left:auto;"><?= ucfirst($p['estado']) ?></span>
        </div>
        <?php if (!empty($p['descripcion'])): ?>
        <p class="proy-desc"><?= htmlspecialchars($p['descripcion']) ?></p>
        <?php endif; ?>
        <?php if (!empty($techs)): ?>
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px;">
          <?php foreach (array_slice($techs,0,4) as $t): ?>
          <span style="padding:2px 7px;background:rgba(255,255,255,.05);border-radius:99px;font-size:.6rem;color:var(--dim);"><?= htmlspecialchars(trim($t)) ?></span>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="proy-prog-bar"><div class="proy-prog-fill" style="width:<?= $prog ?>%"></div></div>
        <div class="proy-footer">
          <div class="proy-meta"><i class="fa fa-users"></i> <?= $p['miembros'] ?></div>
          <div class="proy-meta"><i class="fa fa-list-check"></i> <?= $p['avances'] ?> avances</div>
          <div class="proy-meta" style="font-family:var(--font-d);color:var(--gold);"><?= $prog ?>%</div>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($proyectos)): ?>
    <div style="grid-column:1/-1;"><div class="empty-state"><div class="es-ico">🚀</div><p class="es-txt">No hay proyectos. Crea el primero.</p></div></div>
    <?php endif; ?>
  </div>
</div>


<!-- ████████████ SERVICIOS ████████████ -->
<div class="adm-section" id="sec-servicios">
  <div class="sec-hd">
    <h2>🛒 Control de Servicios</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="sec-hd-btn shb-ghost" id="sf-todos" onclick="filtrarAdq('todos',this)">Todos</button>
      <button class="sec-hd-btn shb-ghost" id="sf-pendiente" onclick="filtrarAdq('pendiente',this)">⏳ Pendientes (<?= $stats['servicios_pend'] ?>)</button>
      <button class="sec-hd-btn shb-ghost" id="sf-pagado" onclick="filtrarAdq('pagado',this)">✅ Pagados</button>
      <button class="sec-hd-btn shb-ghost" id="sf-cancelado" onclick="filtrarAdq('cancelado',this)">❌ Cancelados</button>
    </div>
  </div>
  <div class="card-base" style="overflow:hidden;">
    <div class="tbl-wrap">
      <table class="tbl" id="adqTable">
        <thead><tr><th>#</th><th>Servicio</th><th>Cliente</th><th>Monto</th><th>Método</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody>
        <?php foreach ($adquisiciones as $a): ?>
        <tr data-estado="<?= $a['estado'] ?>">
          <td style="color:var(--dim);font-size:.68rem;">#<?= $a['id'] ?></td>
          <td>
            <div style="display:flex;align-items:center;gap:7px;">
              <span style="font-size:1rem;"><?= htmlspecialchars($a['srv_icono']??'🛠') ?></span>
              <div><p style="font-size:.8rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($a['srv_titulo']) ?></p><p style="font-size:.63rem;color:var(--dim);"><?= htmlspecialchars($a['srv_cat']??'') ?></p></div>
            </div>
          </td>
          <td>
            <div class="usr-mini">
              <div class="usr-av-ph"><?= mb_substr($a['cli_nombre']??'U',0,1) ?></div>
              <span class="usr-name"><?= htmlspecialchars($a['cli_nombre'].' '.($a['cli_apellido']??'')) ?></span>
            </div>
          </td>
          <td style="font-family:var(--font-d);color:var(--gold);font-size:.78rem;">$<?= number_format($a['monto'],0,',','.') ?></td>
          <td style="font-size:.7rem;color:var(--muted);"><?= htmlspecialchars($a['metodo_pago']??'—') ?></td>
          <td style="font-size:.7rem;color:var(--dim);"><?= date('d M Y',strtotime($a['fecha'])) ?></td>
          <td><span class="badge b-<?= $a['estado'] ?>"><?= ucfirst($a['estado']) ?></span></td>
          <td>
            <div style="display:flex;gap:4px;">
              <?php if ($a['estado']==='pendiente'): ?>
              <button class="act-btn ab-green" onclick="gestionarAdq(<?= $a['id'] ?>,'pagado')"><i class="fa fa-check"></i> OK</button>
              <button class="act-btn ab-red"   onclick="gestionarAdq(<?= $a['id'] ?>,'cancelado')"><i class="fa fa-xmark"></i></button>
              <?php else: ?>
              <button class="act-btn ab-view"><i class="fa fa-eye"></i></button>
              <?php endif; ?>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if (empty($adquisiciones)): ?>
        <tr><td colspan="8"><div class="empty-state"><div class="es-ico">🛒</div><p class="es-txt">Sin adquisiciones registradas.</p></div></td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>


<!-- ████████████ PQRS ████████████ -->
<div class="adm-section" id="sec-pqrs">
  <div class="sec-hd">
    <h2>📋 Gestión de PQRS</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="sec-hd-btn shb-ghost" onclick="filtrarPqrs('todos',this)">Todos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarPqrs('abierto',this)">🔴 Abiertos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarPqrs('en_proceso',this)">🔵 En proceso</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarPqrs('resuelto',this)">🟢 Resueltos</button>
    </div>
  </div>
  <div id="pqrsList">
    <?php if (empty($pqrs_lista)): ?>
    <div class="empty-state"><div class="es-ico">📋</div><p class="es-txt">Sin PQRS registradas.</p></div>
    <?php else: ?>
    <?php foreach ($pqrs_lista as $pq):
      $desc_esc = htmlspecialchars($pq['descripcion'],ENT_QUOTES);
      $asunto_esc = htmlspecialchars($pq['asunto'],ENT_QUOTES);
    ?>
    <div class="pqrs-item <?= $pq['prioridad'] ?>" data-estado="<?= $pq['estado'] ?>"
         onclick="openModalPqrs(<?= $pq['id'] ?>,'<?= $pq['folio'] ?>','<?= $asunto_esc ?>','<?= $desc_esc ?>','<?= $pq['estado'] ?>')">
      <div class="pi-top">
        <span class="pi-folio"><?= $pq['folio'] ?></span>
        <span class="pi-title"><?= htmlspecialchars($pq['asunto']) ?></span>
        <span class="badge b-<?= $pq['prioridad'] ?>"><?= ucfirst($pq['prioridad']) ?></span>
        <span class="badge b-<?= $pq['estado'] ?>"><?= str_replace('_',' ',ucfirst($pq['estado'])) ?></span>
      </div>
      <div class="pi-desc"><?= htmlspecialchars($pq['descripcion']) ?></div>
      <div class="pi-meta">
        <span style="font-size:.65rem;color:var(--muted);"><i class="fa fa-user"></i> <?= htmlspecialchars($pq['nombre']??($pq['usr_nombre']??'Anónimo')) ?></span>
        <span style="font-size:.65rem;color:var(--muted);"><i class="fa fa-tag"></i> <?= ucfirst($pq['categoria']) ?></span>
        <span style="font-size:.65rem;color:var(--dim);"><?= date('d M Y',strtotime($pq['fecha'])) ?></span>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>


<!-- ████████████ MENSAJES ████████████ -->
<div class="adm-section" id="sec-mensajes">
  <div class="sec-hd">
    <h2>💬 Centro de Mensajes</h2><div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-gold" onclick="openModalMensaje()"><i class="fa fa-pen"></i> Nuevo mensaje</button>
  </div>
  <?php if ($stats['msgs_sin_leer']>0): ?>
  <div style="background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);border-radius:var(--r-md);padding:10px 16px;margin-bottom:14px;font-size:.82rem;color:var(--gold-lt);display:flex;gap:8px;">
    <i class="fa fa-envelope"></i> Tienes <strong><?= $stats['msgs_sin_leer'] ?></strong> mensajes sin leer.
  </div>
  <?php endif; ?>
  <div>
    <?php if (empty($mensajes)): ?>
    <div class="empty-state"><div class="es-ico">💬</div><p class="es-txt">No tienes mensajes aún.</p></div>
    <?php else: ?>
    <?php foreach ($mensajes as $msg):
      $esNuevo = !$msg['leido'];
      $av_r = !empty($msg['rem_avatar']) ? htmlspecialchars($msg['rem_avatar']) : '';
      $ini = mb_substr($msg['rem_nombre']??'U',0,1);
    ?>
    <div class="msg-item <?= $esNuevo?'unread':'' ?>"
         onclick="verMensaje(<?= $msg['id'] ?>,'<?= htmlspecialchars($msg['asunto'],ENT_QUOTES) ?>','<?= htmlspecialchars($msg['mensaje'],ENT_QUOTES) ?>','<?= htmlspecialchars($msg['rem_nombre'].' '.($msg['rem_apellido']??''),ENT_QUOTES) ?>')">
      <?php if ($av_r): ?><img src="<?= $av_r ?>" class="msg-av" alt=""><?php else: ?><div class="msg-av-ph"><?= $ini ?></div><?php endif; ?>
      <div class="msg-body">
        <div class="msg-sender"><?= htmlspecialchars($msg['rem_nombre'].' '.($msg['rem_apellido']??'')) ?></div>
        <div class="msg-asunto"><?= htmlspecialchars($msg['asunto']) ?></div>
        <div class="msg-prev"><?= htmlspecialchars($msg['mensaje']) ?></div>
      </div>
      <div class="msg-meta">
        <div class="msg-date"><?= date('d M',strtotime($msg['fecha'])) ?></div>
        <?php if ($esNuevo): ?><div class="msg-dot"></div><?php endif; ?>
      </div>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>


<!-- ████████████ REPORTES ████████████ -->
<div class="adm-section" id="sec-reportes">
  <div class="sec-hd"><h2>📊 Reportes & Analítica</h2><div class="sec-hd-line"></div></div>

  <div class="kpi-row">
    <div class="kpi-card"><div class="kpi-label">Ingresos este mes</div><div class="kpi-val">$<?= number_format($stats['ingresos_mes'],0,',','.') ?></div><div class="kpi-sub">COP</div></div>
    <div class="kpi-card"><div class="kpi-label">Servicios aprobados</div><div class="kpi-val"><?= count(array_filter($adquisiciones,fn($a)=>$a['estado']==='pagado')) ?></div><div class="kpi-sub">de <?= count($adquisiciones) ?> totales</div></div>
    <div class="kpi-card"><div class="kpi-label">Proyectos completados</div><div class="kpi-val"><?= count(array_filter($proyectos,fn($p)=>$p['estado']==='completado')) ?></div><div class="kpi-sub">de <?= count($proyectos) ?> totales</div></div>
    <div class="kpi-card"><div class="kpi-label">PQRS resueltos</div><div class="kpi-val"><?= count(array_filter($pqrs_lista,fn($p)=>in_array($p['estado'],['resuelto','cerrado']))) ?></div><div class="kpi-sub">de <?= count($pqrs_lista) ?> totales</div></div>
  </div>

  <!-- Gráficos -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">
    <div class="chart-wrap">
      <div class="chart-title"><i class="fa fa-dollar-sign" style="color:var(--gold);"></i> Ingresos últimos 7 días</div>
      <?php
        // Preparar datos para 7 días
        $dias_labels = [];
        $dias_vals   = [];
        $ing_map = [];
        foreach ($ingresos_7d as $d) $ing_map[$d['dia']] = $d['total'];
        $max_ing = max(1, max(array_values($ing_map) ?: [1]));
        for ($i=6;$i>=0;$i--) {
          $dia = date('Y-m-d', strtotime("-{$i} days"));
          $dias_labels[] = date('d M', strtotime($dia));
          $dias_vals[]   = $ing_map[$dia] ?? 0;
        }
      ?>
      <div class="bar-chart">
        <?php foreach ($dias_vals as $idx => $val): ?>
        <div class="bar-col">
          <div class="bar-val">$<?= $val>1000 ? round($val/1000).'K' : $val ?></div>
          <div class="bar" style="height:<?= max(4,round($val/$max_ing*70)) ?>px" title="$<?= number_format($val,0,',','.') ?>"></div>
          <div class="bar-lbl"><?= $dias_labels[$idx] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="chart-wrap">
      <div class="chart-title"><i class="fa fa-user-plus" style="color:var(--green);"></i> Usuarios nuevos (7 días)</div>
      <?php
        $usr_map = [];
        foreach ($usuarios_7d as $d) $usr_map[$d['dia']] = $d['cnt'];
        $max_usr = max(1, max(array_values($usr_map) ?: [1]));
        $usr_labels = []; $usr_vals = [];
        for ($i=6;$i>=0;$i--) {
          $dia = date('Y-m-d', strtotime("-{$i} days"));
          $usr_labels[] = date('d M', strtotime($dia));
          $usr_vals[]   = $usr_map[$dia] ?? 0;
        }
      ?>
      <div class="bar-chart">
        <?php foreach ($usr_vals as $idx => $val): ?>
        <div class="bar-col">
          <div class="bar-val"><?= $val ?></div>
          <div class="bar" style="height:<?= max(4,round($val/$max_usr*70)) ?>px;background:linear-gradient(to top,var(--green),rgba(40,166,128,.3));" title="<?= $val ?> usuarios"></div>
          <div class="bar-lbl"><?= $usr_labels[$idx] ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <!-- Distribución roles -->
  <div style="margin-top:18px;">
    <div class="sec-hd"><h2>👥 Distribución de Roles</h2><div class="sec-hd-line"></div></div>
    <?php
      $rol_counts = array_count_values(array_column($todos_usuarios,'rol'));
      $roles_order = ['superadmin','admin','empleado','creador','consultor','cliente'];
    ?>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;">
      <?php foreach ($roles_order as $r):
        $cnt = $rol_counts[$r] ?? 0;
        if (!$cnt) continue;
        $pct = round($cnt/max(1,$stats['usuarios_total'])*100);
      ?>
      <div class="card-base card-p" style="text-align:center;">
        <div class="kpi-label"><?= ucfirst($r) ?></div>
        <div class="kpi-val"><?= $cnt ?></div>
        <div class="kpi-bar" style="margin-top:6px;"><div class="kpi-bar-fill" style="width:<?= $pct ?>%"></div></div>
        <div style="font-size:.62rem;color:var(--dim);margin-top:3px;"><?= $pct ?>%</div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>


<!-- ████████████ LOG ACTIVIDAD ████████████ -->
<div class="adm-section" id="sec-actividad">
  <div class="sec-hd"><h2>🛡 Log de Actividad y Seguridad</h2><div class="sec-hd-line"></div>
    <div style="display:flex;gap:6px;">
      <button class="sec-hd-btn shb-ghost" onclick="filtrarLog('todos',this)">Todos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarLog('login_ok',this)">✅ Logins OK</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarLog('login_fail',this)">❌ Fallos</button>
      <button class="sec-hd-btn shb-ghost" onclick="filtrarLog('logout',this)">🚪 Logout</button>
    </div>
  </div>
  <div class="card-base card-p" id="logList">
    <?php foreach ($log_accesos as $log):
      $ico_cls = match($log['accion']) { 'login_ok'=>'li-ok','login_fail'=>'li-fail',default=>'li-out' };
      $ico_fa  = match($log['accion']) { 'login_ok'=>'fa-right-to-bracket','login_fail'=>'fa-triangle-exclamation',default=>'fa-right-from-bracket' };
    ?>
    <div class="log-item" data-accion="<?= $log['accion'] ?>">
      <div class="log-ico <?= $ico_cls ?>"><i class="fa <?= $ico_fa ?>"></i></div>
      <div style="flex:1;">
        <div class="log-usuario"><?= htmlspecialchars(($log['nombre']??'?').' '.($log['apellido']??'')) ?></div>
        <div class="log-accion"><?= htmlspecialchars($log['correo']??'') ?></div>
      </div>
      <span class="badge b-<?= $log['accion']==='login_ok'?'activo':($log['accion']==='login_fail'?'cancelado':'en_proceso') ?>" style="font-size:.6rem;"><?= str_replace('_',' ',$log['accion']) ?></span>
      <span class="log-ip"><?= htmlspecialchars($log['ip']??'—') ?></span>
      <span class="log-fecha"><?= date('d M Y H:i',strtotime($log['fecha'])) ?></span>
    </div>
    <?php endforeach; ?>
  </div>
</div>


<!-- ████████████ NOVEDADES ████████████ -->
<div class="adm-section" id="sec-novedades">
  <div class="sec-hd"><h2>📢 Novedades del Sistema</h2><div class="sec-hd-line"></div>
    <button class="sec-hd-btn shb-gold" onclick="openModalNovedad()"><i class="fa fa-plus"></i> Publicar novedad</button>
  </div>
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:18px;">
    <div>
      <?php if (empty($novedades)): ?>
      <div class="empty-state"><div class="es-ico">📢</div><p class="es-txt">No hay novedades publicadas.</p></div>
      <?php else: ?>
      <?php foreach ($novedades as $nov):
        $ico_tipos = ['nuevo'=>'🆕','mejora'=>'⬆️','mantenimiento'=>'🔧','alerta'=>'⚠️'];
        $ico = $ico_tipos[$nov['tipo']] ?? '📣';
      ?>
      <div class="nov-item">
        <div class="nov-tipo nov-<?= $nov['tipo'] ?>"><?= $ico ?></div>
        <div class="nov-body">
          <div class="nov-title"><?= htmlspecialchars($nov['titulo']) ?></div>
          <div class="nov-desc"><?= htmlspecialchars($nov['descripcion']??'') ?></div>
          <div class="nov-fecha"><?= date('d M Y H:i',strtotime($nov['fecha'])) ?></div>
        </div>
        <span class="badge b-<?= $nov['tipo']==='nuevo'?'activo':($nov['tipo']==='alerta'?'cancelado':'en_proceso') ?>"><?= ucfirst($nov['tipo']) ?></span>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
    <!-- Formulario rápido -->
    <div class="card-base card-p">
      <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">✏️ Publicar rápido</p>
      <div class="em-group"><label class="em-label">Título</label><input type="text" class="em-input" id="qnov_titulo" placeholder="Título de la novedad"></div>
      <div class="em-group"><label class="em-label">Descripción</label><textarea class="em-input" id="qnov_desc" rows="3" placeholder="Descripción..."></textarea></div>
      <div class="em-group"><label class="em-label">Tipo</label>
        <select class="em-input" id="qnov_tipo">
          <option value="nuevo">🆕 Nuevo</option>
          <option value="mejora">⬆️ Mejora</option>
          <option value="mantenimiento">🔧 Mantenimiento</option>
          <option value="alerta">⚠️ Alerta</option>
        </select>
      </div>
      <button class="sec-hd-btn shb-gold" style="width:100%;justify-content:center;" onclick="publicarNovedad()"><i class="fa fa-paper-plane"></i> Publicar</button>
    </div>
  </div>
</div>


<!-- ████████████ CONFIGURACIÓN (solo SuperAdmin) ████████████ -->
<?php if ($es_super): ?>
<div class="adm-section" id="sec-config">
  <div class="sec-hd"><h2>⚙️ Configuración del Sistema</h2><div class="sec-hd-line"></div></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">
    <?php
      $config_grupos = [];
      foreach ($config_sistema as $c) $config_grupos[$c['grupo']][] = $c;
      foreach ($config_grupos as $grupo => $items):
    ?>
    <div class="config-section">
      <div class="config-title">📁 <?= strtoupper($grupo) ?></div>
      <?php foreach ($items as $cfg): ?>
      <div class="config-row">
        <div><div class="config-label"><?= htmlspecialchars(str_replace('_',' ',ucfirst($cfg['clave']))) ?></div><div class="config-sub"><?= htmlspecialchars($cfg['clave']) ?></div></div>
        <div class="config-val">
          <input type="<?= $cfg['tipo']==='booleano'?'checkbox':($cfg['tipo']==='numero'?'number':'text') ?>"
                 class="config-input" value="<?= htmlspecialchars($cfg['valor']) ?>"
                 id="cfg_<?= htmlspecialchars($cfg['clave']) ?>">
          <button class="config-save" onclick="guardarConfig('<?= htmlspecialchars($cfg['clave'],ENT_QUOTES) ?>')">Guardar</button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>


</main>
</div><!-- /adm-wrap -->


<!-- ═══════════════════ MODALES ═══════════════════ -->

<!-- Modal: Crear Proyecto -->
<div class="adm-modal" id="modalCrearProyecto">
  <div class="am-box">
    <div class="am-header"><span class="am-title">🚀 Nuevo Proyecto</span><button class="am-close" onclick="cerrarModal('modalCrearProyecto')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div class="em-group" style="grid-column:1/-1;"><label class="em-label">Título del proyecto *</label><input type="text" class="em-input" id="cp_titulo" placeholder="Nombre del proyecto"></div>
        <div class="em-group"><label class="em-label">Tipo</label><select class="em-input" id="cp_tipo"><option value="propio">Propio</option><option value="comunidad">Comunidad</option><option value="cliente">Cliente</option><option value="academico">Académico</option></select></div>
        <div class="em-group"><label class="em-label">Icono (emoji)</label><input type="text" class="em-input" id="cp_icono" value="🚀" maxlength="4"></div>
        <div class="em-group" style="grid-column:1/-1;"><label class="em-label">Descripción</label><textarea class="em-input" id="cp_desc" rows="3" placeholder="Descripción del proyecto..."></textarea></div>
        <div class="em-group"><label class="em-label">Áreas (CSV)</label><input type="text" class="em-input" id="cp_areas" placeholder="Backend, Seguridad, IA..."></div>
        <div class="em-group"><label class="em-label">Tecnologías (CSV)</label><input type="text" class="em-input" id="cp_tecn" placeholder="PHP, MySQL, React..."></div>
        <div class="em-group"><label class="em-label">Fecha de inicio</label><input type="date" class="em-input" id="cp_fecha" value="<?= date('Y-m-d') ?>"></div>
      </div>
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalCrearProyecto')">Cancelar</button>
      <button class="em-btn em-btn-gold" onclick="crearProyecto()"><i class="fa fa-save"></i> Crear proyecto</button>
    </div>
  </div>
</div>

<!-- Modal: Asignar empleado a proyecto -->
<div class="adm-modal" id="modalAsignar">
  <div class="am-box">
    <div class="am-header"><span class="am-title">👔 Asignar Empleado a Proyecto</span><button class="am-close" onclick="cerrarModal('modalAsignar')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <div class="em-group"><label class="em-label">Proyecto</label>
        <select class="em-input" id="as_proyecto">
          <option value="">Seleccionar proyecto...</option>
          <?php foreach ($proyectos as $p): ?>
          <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['icono']??'🚀') ?> <?= htmlspecialchars($p['titulo']) ?> (<?= ucfirst($p['estado']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="em-group"><label class="em-label">Empleado</label>
        <select class="em-input" id="as_empleado">
          <option value="">Seleccionar empleado...</option>
          <?php foreach ($empleados_lista as $e): ?>
          <option value="<?= $e['id'] ?>"><?= htmlspecialchars($e['nombre'].' '.$e['apellido']) ?> — <?= htmlspecialchars($e['area_tecnologica']??$e['rol']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="em-group"><label class="em-label">Rol en el proyecto</label><input type="text" class="em-input" id="as_rol" placeholder="Colaborador, Líder técnico, QA..." value="Colaborador"></div>
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalAsignar')">Cancelar</button>
      <button class="em-btn em-btn-gold" onclick="asignarEmpleado()"><i class="fa fa-user-plus"></i> Asignar</button>
    </div>
  </div>
</div>

<!-- Modal: Gestionar PQRS -->
<div class="adm-modal" id="modalPqrs">
  <div class="am-box wide">
    <div class="am-header"><span class="am-title">📋 Gestionar PQRS — <span id="pqrs_folio"></span></span><button class="am-close" onclick="cerrarModal('modalPqrs')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:14px;margin-bottom:14px;">
        <p style="font-size:.78rem;font-weight:700;color:var(--txt);margin-bottom:6px;" id="pqrs_asunto"></p>
        <p style="font-size:.78rem;color:var(--muted);line-height:1.6;" id="pqrs_desc"></p>
      </div>
      <div class="em-group"><label class="em-label">Cambiar estado</label>
        <select class="em-input" id="pqrs_estado_sel">
          <option value="abierto">🔴 Abierto</option>
          <option value="en_proceso">🔵 En proceso</option>
          <option value="resuelto">🟢 Resuelto</option>
          <option value="cerrado">⚫ Cerrado</option>
        </select>
      </div>
      <div class="em-group"><label class="em-label">Respuesta al usuario *</label><textarea class="em-input" id="pqrs_respuesta" rows="4" placeholder="Escribe la respuesta que verá el usuario..."></textarea></div>
      <input type="hidden" id="pqrs_id_sel">
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalPqrs')">Cancelar</button>
      <button class="em-btn em-btn-gold" onclick="guardarPqrs()"><i class="fa fa-paper-plane"></i> Guardar respuesta</button>
    </div>
  </div>
</div>

<!-- Modal: Enviar mensaje -->
<div class="adm-modal" id="modalMensaje">
  <div class="am-box">
    <div class="am-header"><span class="am-title">💬 Enviar Mensaje</span><button class="am-close" onclick="cerrarModal('modalMensaje')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <div class="em-group"><label class="em-label">Destinatario</label>
        <select class="em-input" id="msg_dest">
          <option value="">Seleccionar usuario...</option>
          <?php foreach ($todos_usuarios as $u): ?>
          <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['nombre'].' '.$u['apellido']) ?> (<?= ucfirst($u['rol']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="em-group"><label class="em-label">Asunto *</label><input type="text" class="em-input" id="msg_asunto" placeholder="Asunto del mensaje"></div>
      <div class="em-group"><label class="em-label">Mensaje *</label><textarea class="em-input" id="msg_texto" rows="4" placeholder="Escribe tu mensaje..."></textarea></div>
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalMensaje')">Cancelar</button>
      <button class="em-btn em-btn-gold" onclick="enviarMensaje()"><i class="fa fa-paper-plane"></i> Enviar</button>
    </div>
  </div>
</div>

<!-- Modal: Ver mensaje -->
<div class="adm-modal" id="modalVerMsg">
  <div class="am-box">
    <div class="am-header"><span class="am-title">📨 Mensaje recibido</span><button class="am-close" onclick="cerrarModal('modalVerMsg')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <p style="font-size:.65rem;color:var(--dim);margin-bottom:3px;">De:</p><p id="vm_de" style="font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:12px;"></p>
      <p style="font-size:.65rem;color:var(--dim);margin-bottom:3px;">Asunto:</p><p id="vm_asunto" style="font-size:.88rem;font-weight:700;color:var(--gold);margin-bottom:14px;"></p>
      <p style="font-size:.65rem;color:var(--dim);margin-bottom:6px;">Mensaje:</p>
      <div id="vm_texto" style="font-size:.85rem;color:var(--muted);line-height:1.7;background:rgba(255,255,255,.03);padding:14px;border-radius:var(--r-md);border:1px solid rgba(255,255,255,.07);"></div>
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalVerMsg')">Cerrar</button>
      <button class="em-btn em-btn-gold" onclick="cerrarModal('modalVerMsg');openModalMensaje()"><i class="fa fa-reply"></i> Responder</button>
    </div>
  </div>
</div>

<!-- Modal: Publicar novedad -->
<div class="adm-modal" id="modalNovedad">
  <div class="am-box">
    <div class="am-header"><span class="am-title">📢 Publicar Novedad</span><button class="am-close" onclick="cerrarModal('modalNovedad')"><i class="fa fa-times"></i></button></div>
    <div class="am-body">
      <div class="em-group"><label class="em-label">Título *</label><input type="text" class="em-input" id="nov_titulo" placeholder="Título de la novedad"></div>
      <div class="em-group"><label class="em-label">Descripción</label><textarea class="em-input" id="nov_desc" rows="3"></textarea></div>
      <div class="em-group"><label class="em-label">Tipo</label>
        <select class="em-input" id="nov_tipo">
          <option value="nuevo">🆕 Nuevo</option><option value="mejora">⬆️ Mejora</option>
          <option value="mantenimiento">🔧 Mantenimiento</option><option value="alerta">⚠️ Alerta</option>
        </select>
      </div>
    </div>
    <div class="am-footer">
      <button class="em-btn em-btn-cancel" onclick="cerrarModal('modalNovedad')">Cancelar</button>
      <button class="em-btn em-btn-gold" onclick="guardarNovedad()"><i class="fa fa-paper-plane"></i> Publicar</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast-wrap" id="toastWrap"></div>


<!-- ═══════════════════ JAVASCRIPT ═══════════════════ -->
<script>
/* ══ NAVEGACIÓN ══ */
const SEC_NAMES = {dashboard:'Dashboard',usuarios:'Usuarios',empleados:'Empleados & Roles',proyectos:'Proyectos',servicios:'Servicios',pqrs:'PQRS',mensajes:'Mensajes',reportes:'Reportes',actividad:'Log Actividad',novedades:'Novedades',config:'Configuración'};

function showSec(id, el) {
  document.querySelectorAll('.adm-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.sb-item').forEach(i => i.classList.remove('active'));
  document.getElementById('sec-'+id)?.classList.add('active');
  if (el) el.classList.add('active');
  else document.querySelector(`.sb-item[onclick*="'${id}'"]`)?.classList.add('active');
  document.getElementById('tbSecName').textContent = SEC_NAMES[id] || id;
  document.querySelector('.adm-main')?.scrollTo({top:0,behavior:'smooth'});
  if (window.innerWidth < 820) closeSidebar();
}

/* ══ SIDEBAR ══ */
function toggleSidebar(){document.getElementById('admSidebar').classList.toggle('open');}
function closeSidebar(){document.getElementById('admSidebar').classList.remove('open');}

/* ══ MODALES ══ */
function abrirModal(id){document.getElementById(id).classList.add('open');document.body.style.overflow='hidden';}
function cerrarModal(id){document.getElementById(id).classList.remove('open');document.body.style.overflow='';}
document.querySelectorAll('.adm-modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m){m.classList.remove('open');document.body.style.overflow=''}}));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelectorAll('.adm-modal.open').forEach(m=>m.classList.remove('open'));document.body.style.overflow=''}});

/* ══ TOAST ══ */
function toast(msg,tipo='ok',dur=3500){
  const w=document.getElementById('toastWrap'),t=document.createElement('div');
  const icons={ok:'fa-circle-check',err:'fa-triangle-exclamation',info:'fa-circle-info'};
  t.className=`toast t-${tipo}`;
  t.innerHTML=`<i class="fa ${icons[tipo]}"></i>${msg}`;
  w.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transform='translateX(20px)';t.style.transition='all .3s';setTimeout(()=>t.remove(),300);},dur);
}

/* ══ FETCH HELPER ══ */
async function postAction(data){
  const fd=new FormData();
  Object.entries(data).forEach(([k,v])=>fd.append(k,v));
  try{const r=await fetch('',{method:'POST',body:fd});return await r.json();}
  catch(e){return{ok:false,error:'Error de conexión'};}
}

/* ══ CAMBIAR ROL ══ */
async function cambiarRol(userId, rol, el){
  const r=await postAction({accion:'cambiar_rol',user_id:userId,rol});
  if(r.ok){toast(`✅ Rol actualizado a <strong>${rol}</strong>`,'ok');}
  else{toast('Error: '+r.error,'err');el.value=el.dataset.original;}
}

/* ══ TOGGLE ACTIVO ══ */
async function toggleActivo(userId, nuevoActivo, btn){
  const r=await postAction({accion:'toggle_activo',user_id:userId,activo:nuevoActivo});
  if(r.ok){
    btn.textContent=nuevoActivo?'✅ Activo':'❌ Inactivo';
    btn.className='badge '+(nuevoActivo?'b-activo':'b-inactivo');
    btn.setAttribute('onclick',`toggleActivo(${userId},${nuevoActivo?0:1},this)`);
    toast(nuevoActivo?'✅ Usuario activado':'❌ Usuario desactivado','ok');
  }else toast('Error: '+r.error,'err');
}

/* ══ VERIFICAR USUARIO ══ */
async function verificarUsuario(userId, nuevoVer, btn){
  const r=await postAction({accion:'verificar_usuario',user_id:userId,verificado:nuevoVer});
  if(r.ok){
    btn.textContent=nuevoVer?'🔵 Verificado':'⏳ Pendiente';
    btn.className='badge '+(nuevoVer?'b-verificado':'b-pendiente');
    btn.setAttribute('onclick',`verificarUsuario(${userId},${nuevoVer?0:1},this)`);
    toast(nuevoVer?'🔵 Usuario verificado':'⚠️ Verificación removida','ok');
  }else toast('Error: '+r.error,'err');
}

/* ══ GESTIONAR ADQUISICIÓN ══ */
async function gestionarAdq(id, estado){
  const r=await postAction({accion:'gestionar_adquisicion',adq_id:id,estado});
  if(r.ok){toast(estado==='pagado'?'✅ Servicio aprobado':'❌ Servicio rechazado',estado==='pagado'?'ok':'err');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
function rapido_aprobar(id){gestionarAdq(id,'pagado');}
function rapido_rechazar(id){gestionarAdq(id,'cancelado');}

/* ══ FILTROS ══ */
function filtrarAdq(estado, btn){
  document.querySelectorAll('[id^="sf-"]').forEach(b=>{b.className='sec-hd-btn shb-ghost';});
  if(btn){btn.className='sec-hd-btn shb-gold';}
  document.querySelectorAll('#adqTable tbody tr').forEach(tr=>{
    tr.style.display=(estado==='todos'||tr.dataset.estado===estado)?'':'none';
  });
}
function filtrarPqrs(estado, btn){
  document.querySelectorAll('#pqrsList .pqrs-item').forEach(el=>{
    el.style.display=(estado==='todos'||el.dataset.estado===estado)?'':'none';
  });
}
function filtrarLog(accion, btn){
  document.querySelectorAll('#logList .log-item').forEach(el=>{
    el.style.display=(accion==='todos'||el.dataset.accion===accion)?'':'none';
  });
}
function filtrarUsuarios(tipo, btn){
  document.querySelectorAll('#usrTable tbody tr').forEach(tr=>{
    const activo=tr.dataset.activo==='1', ver=tr.dataset.verificado==='1';
    if(tipo==='todos') tr.style.display='';
    else if(tipo==='sin_ver') tr.style.display=(!ver&&activo)?'':'none';
    else if(tipo==='inactivos') tr.style.display=(!activo)?'':'none';
  });
}
function filtrarProyectos(estado, btn){
  document.querySelectorAll('#proyGrid .proy-card').forEach(c=>{
    c.style.display=(estado==='todos'||c.dataset.estado===estado)?'':'none';
  });
}

/* ══ CREAR PROYECTO ══ */
function openModalCrearProyecto(){abrirModal('modalCrearProyecto');}
async function crearProyecto(){
  const titulo=document.getElementById('cp_titulo').value.trim();
  if(!titulo){toast('El título es obligatorio','err');return;}
  const r=await postAction({
    accion:'crear_proyecto',titulo,
    descripcion:document.getElementById('cp_desc').value,
    tipo:document.getElementById('cp_tipo').value,
    icono:document.getElementById('cp_icono').value||'🚀',
    areas:document.getElementById('cp_areas').value,
    tecnologias:document.getElementById('cp_tecn').value,
    fecha_inicio:document.getElementById('cp_fecha').value,
  });
  if(r.ok){toast('🚀 Proyecto creado exitosamente','ok');cerrarModal('modalCrearProyecto');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ ASIGNAR EMPLEADO ══ */
function openModalAsignarProy(empId=null, empNombre=null, proyId=null){
  if(empId) document.getElementById('as_empleado').value=empId;
  if(proyId) document.getElementById('as_proyecto').value=proyId;
  abrirModal('modalAsignar');
}
async function asignarEmpleado(){
  const proy=document.getElementById('as_proyecto').value;
  const emp=document.getElementById('as_empleado').value;
  const rol=document.getElementById('as_rol').value||'Colaborador';
  if(!proy||!emp){toast('Selecciona proyecto y empleado','err');return;}
  const r=await postAction({accion:'asignar_empleado',proyecto_id:proy,empleado_id:emp,rol_proyecto:rol});
  if(r.ok){toast('✅ Empleado asignado al proyecto','ok');cerrarModal('modalAsignar');}
  else toast('Error: '+r.error,'err');
}

/* ══ PQRS ══ */
function openModalPqrs(id, folio, asunto, desc, estado){
  document.getElementById('pqrs_id_sel').value=id;
  document.getElementById('pqrs_folio').textContent=folio;
  document.getElementById('pqrs_asunto').textContent=asunto;
  document.getElementById('pqrs_desc').textContent=desc;
  document.getElementById('pqrs_estado_sel').value=estado;
  document.getElementById('pqrs_respuesta').value='';
  abrirModal('modalPqrs');
}
async function guardarPqrs(){
  const id=document.getElementById('pqrs_id_sel').value;
  const estado=document.getElementById('pqrs_estado_sel').value;
  const resp=document.getElementById('pqrs_respuesta').value.trim();
  if(!resp){toast('Escribe una respuesta para el usuario','err');return;}
  const r=await postAction({accion:'gestionar_pqrs',pqrs_id:id,estado,respuesta:resp});
  if(r.ok){toast('✅ PQRS respondida correctamente','ok');cerrarModal('modalPqrs');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ MENSAJES ══ */
function openModalMensaje(destId=null,destNombre=null){
  if(destId) document.getElementById('msg_dest').value=destId;
  else document.getElementById('msg_dest').value='';
  document.getElementById('msg_asunto').value='';
  document.getElementById('msg_texto').value='';
  abrirModal('modalMensaje');
}
async function enviarMensaje(){
  const dest=document.getElementById('msg_dest').value;
  const asunto=document.getElementById('msg_asunto').value.trim();
  const mensaje=document.getElementById('msg_texto').value.trim();
  if(!dest||!asunto||!mensaje){toast('Completa todos los campos','err');return;}
  const r=await postAction({accion:'enviar_mensaje',destinatario_id:dest,asunto,mensaje});
  if(r.ok){toast('📨 Mensaje enviado','ok');cerrarModal('modalMensaje');}
  else toast('Error: '+r.error,'err');
}
async function verMensaje(id,asunto,texto,de){
  document.getElementById('vm_de').textContent=de;
  document.getElementById('vm_asunto').textContent=asunto;
  document.getElementById('vm_texto').textContent=texto;
  abrirModal('modalVerMsg');
  await postAction({accion:'marcar_leido',msg_id:id});
}

/* ══ NOVEDADES ══ */
function openModalNovedad(){
  document.getElementById('nov_titulo').value='';
  document.getElementById('nov_desc').value='';
  abrirModal('modalNovedad');
}
async function guardarNovedad(){
  const titulo=document.getElementById('nov_titulo').value.trim();
  if(!titulo){toast('El título es obligatorio','err');return;}
  const r=await postAction({accion:'publicar_novedad',titulo,descripcion:document.getElementById('nov_desc').value,tipo:document.getElementById('nov_tipo').value});
  if(r.ok){toast('📢 Novedad publicada','ok');cerrarModal('modalNovedad');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}
async function publicarNovedad(){
  const titulo=document.getElementById('qnov_titulo').value.trim();
  if(!titulo){toast('El título es obligatorio','err');return;}
  const r=await postAction({accion:'publicar_novedad',titulo,descripcion:document.getElementById('qnov_desc').value,tipo:document.getElementById('qnov_tipo').value});
  if(r.ok){toast('📢 Novedad publicada','ok');setTimeout(()=>location.reload(),1200);}
  else toast('Error: '+r.error,'err');
}

/* ══ CONFIGURACIÓN ══ */
async function guardarConfig(clave){
  const valor=document.getElementById('cfg_'+clave).value;
  const r=await postAction({accion:'update_config',clave,valor});
  if(r.ok)toast('⚙️ Configuración guardada: '+clave,'ok');
  else toast('Error: '+r.error,'err');
}

/* ══ BÚSQUEDA GLOBAL ══ */
document.getElementById('globalSearch').addEventListener('keydown',e=>{
  if(e.key!=='Enter')return;
  const q=e.target.value.toLowerCase();if(!q)return;
  ['usrTable','adqTable'].forEach(id=>{
    document.querySelectorAll('#'+id+' tbody tr').forEach(tr=>{
      tr.style.display=tr.textContent.toLowerCase().includes(q)?'':'none';
    });
  });
  toast(`🔍 Filtrado: "${q}"`,'info');
});

/* ══ ANIMACIONES ══ */
const ro=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting){e.target.style.opacity='1';e.target.style.transform='translateY(0)';}});},{threshold:.05});
document.querySelectorAll('.stat-card,.proy-card,.kpi-card,.pqrs-item,.log-item,.msg-item').forEach((el,i)=>{
  el.style.opacity='0';el.style.transform='translateY(14px)';
  el.style.transition=`opacity .4s ease ${i*.035}s,transform .4s ease ${i*.035}s`;
  ro.observe(el);
});

/* ══ INIT ══ */
const urlSec=new URLSearchParams(location.search).get('sec');
if(urlSec)showSec(urlSec);
</script>
</body>
</html>