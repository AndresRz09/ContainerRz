<?php
include 'conexion.php';
session_start();

$uid    = (int)($_SESSION['user_id'] ?? 0);
$rol    = $_SESSION['rol']        ?? 'invitado';
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'Invitado');
$avatar = htmlspecialchars($_SESSION['avatar']     ?? 'assets/avatar-default.png');

// ── Sección activa ──────────────────────────────────────────────────
$seccion = $_GET['sec'] ?? 'principal';
$allowed = ['principal','suscripciones','objetivos','cursos','herramientas','canal','comunidad'];
if (!in_array($seccion, $allowed)) $seccion = 'principal';

// ── Helper: query segura con fallback a array vacío ─────────────────
function qdb($conexion, $sql, $types = '', ...$params): array {
    if (!isset($conexion)) return [];
    $stmt = $conexion->prepare($sql);
    if (!$stmt) return [];
    if ($types) $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $r = $stmt->get_result();
    $rows = [];
    while ($row = $r->fetch_assoc()) $rows[] = $row;
    $stmt->close();
    return $rows;
}

// ── Helper: leer clave de configuracion ────────────────────────────
function cfg_val(string $clave, $default = null) {
    global $conexion;
    if (!isset($conexion)) return $default;
    $stmt = $conexion->prepare("SELECT valor FROM configuracion WHERE clave = ? LIMIT 1");
    if (!$stmt) return $default;
    $stmt->bind_param("s", $clave);
    $stmt->execute();
    $r = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $r ? $r['valor'] : $default;
}

// ── Helper: leer JSON de configuracion con fallback ─────────────────
function cfg_json(string $clave, array $fallback = []): array {
    $val = cfg_val($clave);
    if (!$val) return $fallback;
    $decoded = json_decode($val, true);
    return is_array($decoded) ? $decoded : $fallback;
}

// ══════════════════════════════════════════════════════════════════════
//  DATOS DESDE BD (con fallbacks demo idénticos al original)
// ══════════════════════════════════════════════════════════════════════

// ── Feed de videos/contenido principal ─────────────────────────────
$videos_feed = qdb($conexion,
    "SELECT co.*, ca.nombre AS canal_nombre,
            u.nombre AS autor, u.apellido AS autor_apellido, u.avatar AS autor_avatar
     FROM contenido_ad co
     LEFT JOIN canales_ad ca ON ca.id = co.canal_id
     LEFT JOIN usuarios   u  ON u.id  = co.usuario_id
     WHERE co.publicado = 1
     ORDER BY co.fecha_publicacion DESC LIMIT 24"
);

// ── Suscripciones del usuario ───────────────────────────────────────
$suscripciones = $uid ? qdb($conexion,
    "SELECT ca.*, u.nombre AS propietario, COUNT(s2.id) AS total_subs
     FROM suscripciones_ad s
     JOIN canales_ad ca ON s.canal_id    = ca.id
     JOIN usuarios   u  ON ca.usuario_id = u.id
     LEFT JOIN suscripciones_ad s2 ON s2.canal_id = ca.id
     WHERE s.usuario_id = ?
     GROUP BY ca.id ORDER BY ca.nombre", "i", $uid
) : [];

// ── Canales recomendados (comunidad + suscripciones demo) ───────────
$canales_recomendados = qdb($conexion,
    "SELECT ca.id, ca.nombre, ca.avatar, ca.verificado,
            COUNT(s.id) AS total_subs
     FROM canales_ad ca
     LEFT JOIN suscripciones_ad s ON s.canal_id = ca.id
     WHERE ca.activo = 1
     GROUP BY ca.id ORDER BY total_subs DESC LIMIT 6"
);
// Fallback demo si la BD no tiene datos
if (empty($canales_recomendados)) {
    $canales_recomendados = [
        ['nombre'=>'VIROX Tech', 'avatar'=>'🔬', 'total_subs'=>4200, 'verificado'=>1],
        ['nombre'=>'SecLab',     'avatar'=>'🛡',  'total_subs'=>8100, 'verificado'=>1],
        ['nombre'=>'DataVIROX',  'avatar'=>'📊',  'total_subs'=>2900, 'verificado'=>0],
        ['nombre'=>'AI VIROX',   'avatar'=>'🤖',  'total_subs'=>11500,'verificado'=>1],
        ['nombre'=>'CloudVIROX', 'avatar'=>'☁️', 'total_subs'=>6300, 'verificado'=>0],
        ['nombre'=>'GameDev',    'avatar'=>'🎮',  'total_subs'=>9700, 'verificado'=>0],
    ];
}

// ── Cursos (catálogo) ───────────────────────────────────────────────
$cursos = qdb($conexion,
    "SELECT c.*,
            cfg_nom.valor AS instructor_nombre,
            COUNT(DISTINCT m.id) AS total_modulos,
            COUNT(DISTINCT l.id) AS total_lecciones
     FROM cursos c
     LEFT JOIN configuracion cfg_nom ON cfg_nom.clave = CONCAT('instructor_curso_', c.id)
     LEFT JOIN modulos_curso  m ON m.curso_id  = c.id
     LEFT JOIN lecciones_curso l ON l.modulo_id = m.id
     WHERE c.publicado = 1 AND c.activo = 1
     GROUP BY c.id ORDER BY c.destacado DESC, c.id ASC LIMIT 16"
);

// Fallback demo cursos
if (empty($cursos)) {
    $cursos = [
        ['id'=>1,'icono'=>'🛡','titulo'=>'Ciberseguridad desde Cero',         'instructor_nombre'=>'Carlos R.','nivel'=>'avanzado', 'total_lecciones'=>45,'duracion'=>'40h','rating'=>4.9,'total_subs'=>152,'categoria'=>'seguridad', 'tipo'=>'MOOC'],
        ['id'=>2,'icono'=>'💻','titulo'=>'Programación Web Full Stack',        'instructor_nombre'=>'Ana M.',   'nivel'=>'intermedio','total_lecciones'=>68,'duracion'=>'80h','rating'=>4.8,'total_subs'=>234,'categoria'=>'desarrollo','tipo'=>'MOOC'],
        ['id'=>3,'icono'=>'🤖','titulo'=>'Machine Learning Aplicado',          'instructor_nombre'=>'Luis P.',  'nivel'=>'avanzado', 'total_lecciones'=>52,'duracion'=>'60h','rating'=>4.7,'total_subs'=>189,'categoria'=>'ia',        'tipo'=>'MOOC'],
        ['id'=>4,'icono'=>'🗄','titulo'=>'Bases de Datos SQL & NoSQL',         'instructor_nombre'=>'Sofia K.', 'nivel'=>'basico',   'total_lecciones'=>38,'duracion'=>'35h','rating'=>4.9,'total_subs'=>321,'categoria'=>'datos',     'tipo'=>'MOOC'],
        ['id'=>5,'icono'=>'☁️','titulo'=>'Cloud Computing AWS',               'instructor_nombre'=>'Marco A.', 'nivel'=>'intermedio','total_lecciones'=>44,'duracion'=>'50h','rating'=>4.8,'total_subs'=>267,'categoria'=>'cloud',     'tipo'=>'MOOC'],
        ['id'=>6,'icono'=>'🐧','titulo'=>'Linux y DevOps',                    'instructor_nombre'=>'Javier M.','nivel'=>'intermedio','total_lecciones'=>56,'duracion'=>'65h','rating'=>4.7,'total_subs'=>198,'categoria'=>'linux',     'tipo'=>'MOOC'],
        ['id'=>7,'icono'=>'🎮','titulo'=>'Desarrollo de Videojuegos Unity',   'instructor_nombre'=>'Diana S.', 'nivel'=>'basico',   'total_lecciones'=>60,'duracion'=>'70h','rating'=>4.8,'total_subs'=>145,'categoria'=>'videojuegos','tipo'=>'MOOC'],
        ['id'=>8,'icono'=>'📱','titulo'=>'Flutter y Dart Completo',           'instructor_nombre'=>'Rodrigo A.','nivel'=>'intermedio','total_lecciones'=>55,'duracion'=>'60h','rating'=>4.6,'total_subs'=>178,'categoria'=>'desarrollo','tipo'=>'MOOC'],
        ['id'=>9,'icono'=>'🔐','titulo'=>'Criptografía Aplicada',             'instructor_nombre'=>'Elena V.', 'nivel'=>'avanzado', 'total_lecciones'=>32,'duracion'=>'30h','rating'=>4.8,'total_subs'=>121,'categoria'=>'seguridad', 'tipo'=>'NOOC'],
        ['id'=>10,'icono'=>'📊','titulo'=>'Ciencia de Datos con Python',      'instructor_nombre'=>'Pablo N.', 'nivel'=>'intermedio','total_lecciones'=>48,'duracion'=>'55h','rating'=>4.7,'total_subs'=>289,'categoria'=>'ia',        'tipo'=>'MOOC'],
        ['id'=>11,'icono'=>'🏗','titulo'=>'Arquitectura de Software',         'instructor_nombre'=>'Carmen O.','nivel'=>'avanzado', 'total_lecciones'=>42,'duracion'=>'45h','rating'=>4.9,'total_subs'=>167,'categoria'=>'desarrollo','tipo'=>'SPOC'],
        ['id'=>12,'icono'=>'🌐','titulo'=>'Redes y Conectividad',             'instructor_nombre'=>'Miguel T.','nivel'=>'basico',   'total_lecciones'=>36,'duracion'=>'40h','rating'=>4.7,'total_subs'=>234,'categoria'=>'linux',     'tipo'=>'MOOC'],
    ];
}

// ── Progreso cursos del usuario ─────────────────────────────────────
$prog_map = [];
if ($uid) {
    $rows = qdb($conexion,
        "SELECT curso_id, progreso, completado FROM progreso_cursos WHERE usuario_id = ?", "i", $uid
    );
    foreach ($rows as $r) $prog_map[$r['curso_id']] = $r;
}

// ── Objetivos del usuario ───────────────────────────────────────────
$objetivos_activos    = [];
$objetivos_completados = [];
if ($uid) {
    $all_obj = qdb($conexion,
        "SELECT * FROM objetivos_ad WHERE usuario_id = ? ORDER BY completado ASC, fecha_limite ASC LIMIT 20", "i", $uid
    );
    foreach ($all_obj as $o) {
        if ($o['completado']) $objetivos_completados[] = $o;
        else                  $objetivos_activos[]     = $o;
    }
}
// Fallback demo objetivos
if (empty($objetivos_activos)) {
    $objetivos_activos = [
        ['id'=>1,'titulo'=>'Completar curso de Ciberseguridad',  'descripcion'=>'Terminar los módulos 3 y 4 del curso de Ethical Hacking','fecha_limite'=>date('Y-m-d', strtotime('+14 days')),'categoria'=>'seguridad', 'progreso'=>65],
        ['id'=>2,'titulo'=>'Practicar 50 problemas en LeetCode', 'descripcion'=>'Mejorar habilidades en algoritmos y estructuras de datos', 'fecha_limite'=>date('Y-m-d', strtotime('+30 days')),'categoria'=>'algoritmos','progreso'=>30],
        ['id'=>3,'titulo'=>'Aprender Kubernetes',                'descripcion'=>'Completar laboratorio de K8s en entorno local',           'fecha_limite'=>date('Y-m-d', strtotime('+7 days')), 'categoria'=>'cloud',      'progreso'=>80],
    ];
}
if (empty($objetivos_completados)) {
    $objetivos_completados = [
        ['titulo'=>'Instalar y configurar XAMPP',  'descripcion'=>'Entorno de desarrollo local listo', 'categoria'=>'desarrollo'],
        ['titulo'=>'Completar módulo 1 de POO',    'descripcion'=>'Encapsulamiento y herencia aplicados','categoria'=>'programacion'],
    ];
}

// ── Mi canal ────────────────────────────────────────────────────────
$mi_canal    = null;
$canal_stats = [];
if ($uid) {
    $row = qdb($conexion,
        "SELECT ca.*, COUNT(s.id) AS suscriptores,
                (SELECT COUNT(*) FROM contenido_ad WHERE canal_id = ca.id) AS total_videos
         FROM canales_ad ca
         LEFT JOIN suscripciones_ad s ON s.canal_id = ca.id
         WHERE ca.usuario_id = ? GROUP BY ca.id LIMIT 1", "i", $uid
    );
    if (!empty($row)) {
        $mi_canal    = $row[0];
        $canal_stats = [
            'vistas_mes'   => qdb($conexion, "SELECT COALESCE(SUM(vistas),0) AS t FROM contenido_ad WHERE canal_id = ? AND fecha_publicacion >= DATE_SUB(NOW(),INTERVAL 30 DAY)", "i", $mi_canal['id'])[0]['t'] ?? 0,
            'videos_mes'   => qdb($conexion, "SELECT COUNT(*) AS t FROM contenido_ad WHERE canal_id = ? AND fecha_publicacion >= DATE_SUB(NOW(),INTERVAL 30 DAY)", "i", $mi_canal['id'])[0]['t'] ?? 0,
            'ingresos_mes' => qdb($conexion, "SELECT COALESCE(SUM(monto),0) AS t FROM ingresos_canal WHERE canal_id = ? AND MONTH(fecha)=MONTH(NOW())", "i", $mi_canal['id'])[0]['t'] ?? 0,
        ];
    }
}

// ── Videos del propio canal (demo si no tiene) ──────────────────────
$mis_videos = [];
if ($mi_canal) {
    $mis_videos = qdb($conexion,
        "SELECT * FROM contenido_ad WHERE canal_id = ? ORDER BY fecha_publicacion DESC LIMIT 4",
        "i", $mi_canal['id']
    );
}
if (empty($mis_videos)) {
    $mis_videos = [
        ['icono'=>'💻','titulo'=>'Tutorial: Estructuras de Datos en Python','vistas'=>2100,'fecha_publicacion'=>date('Y-m-d', strtotime('-3 days')), 'tipo'=>'video',     'publicado'=>1],
        ['icono'=>'🛡','titulo'=>'Análisis: OWASP Top 10 - 2024',           'vistas'=>5800,'fecha_publicacion'=>date('Y-m-d', strtotime('-7 days')), 'tipo'=>'video',     'publicado'=>1],
        ['icono'=>'📊','titulo'=>'Infografía: Big-O Notation',              'vistas'=>1300,'fecha_publicacion'=>date('Y-m-d', strtotime('-14 days')),'tipo'=>'infografia','publicado'=>1],
        ['icono'=>'🤖','titulo'=>'Cómo funciona un LLM',                    'vistas'=>4200,'fecha_publicacion'=>date('Y-m-d', strtotime('-30 days')),'tipo'=>'video',     'publicado'=>1],
    ];
}

// ── Playlists del canal ─────────────────────────────────────────────
$playlists = $mi_canal ? qdb($conexion,
    "SELECT pl.*, COUNT(pc.id) AS total FROM playlists_ad pl
     LEFT JOIN playlist_contenido pc ON pc.playlist_id = pl.id
     WHERE pl.canal_id = ? GROUP BY pl.id ORDER BY pl.orden ASC LIMIT 4",
    "i", $mi_canal['id']
) : [];
if (empty($playlists)) {
    $playlists = [
        ['titulo'=>'📚 Fundamentos TI',    'total'=>12, 'is_playing'=>true],
        ['titulo'=>'🛡 Seguridad Ofensiva','total'=>8,  'is_playing'=>false],
        ['titulo'=>'🤖 IA Aplicada',       'total'=>15, 'is_playing'=>false],
        ['titulo'=>'💻 Desarrollo Web',    'total'=>20, 'is_playing'=>false],
    ];
}

// ── Publicaciones comunidad ─────────────────────────────────────────
$publicaciones_feed = qdb($conexion,
    "SELECT p.*, u.nombre AS autor_nombre, u.apellido AS autor_apellido,
             u.avatar AS autor_avatar
     FROM publicaciones p
     LEFT JOIN usuarios u ON u.id = p.usuario_id
     WHERE p.publicado = 1
     ORDER BY p.fecha_pub DESC LIMIT 6"
);
if (empty($publicaciones_feed)) {
    $publicaciones_feed = [
        ['autor_nombre'=>'Ana M.', 'autor_apellido'=>'',
         'titulo'=>'Compartiendo mi progreso en ciberseguridad 🛡',
         'resumen'=>'Acabo de completar el módulo de XSS y CSRF en el curso de Ethical Hacking. ¡Los laboratorios prácticos son increíbles! ¿Alguien más está haciendo este curso?',
         'tags'=>'ciberseguridad,aprendizaje','fecha_pub'=>date('Y-m-d H:i:s', strtotime('-2 hours'))],
        ['autor_nombre'=>'Carlos R.','autor_apellido'=>'',
         'titulo'=>'¿Cuál es la mejor forma de aprender algoritmos?',
         'resumen'=>'Llevo 3 semanas practicando en LeetCode y siento que avanzo lento. ¿Qué recursos recomiendan para mejorar en complejidad temporal?',
         'tags'=>'algoritmos,programacion','fecha_pub'=>date('Y-m-d H:i:s', strtotime('-5 hours'))],
        ['autor_nombre'=>'Sofia K.','autor_apellido'=>'',
         'titulo'=>'Recurso gratuito: 50 ejercicios SQL con soluciones',
         'resumen'=>'He compilado 50 ejercicios de SQL desde básico hasta avanzado con sus respectivas soluciones. ¡Espero que les ayude en sus estudios!',
         'tags'=>'sql,recursos','fecha_pub'=>date('Y-m-d H:i:s', strtotime('-1 day'))],
    ];
}

// ── Herramientas desde BD (configuracion) ──────────────────────────
$herramientas_data_bd = [
    'editores'     => cfg_json('ad_herramientas_editores',     [['VSCode','💻','Editor de código profesional'],['Vim','⌨️','Editor modal de terminal'],['Sublime Text','✨','Editor rápido y elegante'],['IntelliJ IDEA','🧠','IDE completo para Java/Kotlin'],['PyCharm','🐍','IDE especializado en Python'],['Cursor','🤖','Editor con IA integrada']]),
    'compiladores' => cfg_json('ad_herramientas_compiladores', [['GCC','⚙️','Compilador C/C++ GNU'],['Python 3','🐍','Intérprete Python'],['Node.js','💚','Runtime JavaScript'],['JDK 21','☕','Java Development Kit'],['Rust Compiler','🦀','Compilador Rust'],['Go Compiler','🐹','Compilador Go']]),
    'audiovisuales'=> cfg_json('ad_herramientas_audiovisuales',[['Infografías','📊','Crea y visualiza datos'],['Videos','🎬','Contenido audiovisual HD'],['Audios','🎧','Podcasts y lecciones de audio'],['Podcast','🎙️','Grabación y edición'],['Imágenes','🖼️','Banco de recursos visuales'],['Presentaciones','📑','Slides interactivos']]),
    'word_excel'   => cfg_json('ad_herramientas_word_excel',   [['Word / Docs','📝','Documentos y reportes'],['Excel / Sheets','📊','Hojas de cálculo'],['SQL Playground','🗄️','Consultas SQL online'],['Markdown','✍️','Editor de texto enriquecido'],['LaTeX','🔢','Fórmulas matemáticas'],['Draw.io','🖊️','Diagramas y flujos']]),
];
$programadores_online = cfg_json('ad_programadores_online',
    [['Python','🐍','Ejecuta Python en el navegador'],['JavaScript','⚡','Consola JS interactiva'],['Java','☕','Compilador Java online'],['C/C++','🔧','Entorno C++ en línea'],['PHP','🐘','Sandbox PHP interactivo'],['SQL','🗄','Playground SQL con datos'],['Bash','🐧','Terminal Linux online'],['R','📊','Estadística con R online']]
);

// ── Plan semanal ────────────────────────────────────────────────────
$plan_semanal = cfg_json('ad_plan_semanal',
    [['Lu','Algoritmos 30min','⚡'],['Ma','Video SQL JOINs','🗄'],['Mi','Práctica LeetCode','💻'],['Ju','Ciberseg lab','🛡'],['Vi','Podcast TI','🎙'],['Sá','Proyecto personal','🚀'],['Do','Repaso semana','📖']]
);

// ── Tags de tendencias ──────────────────────────────────────────────
$tags_tendencias = cfg_json('ad_tags_tendencias',
    ['#ciberseguridad','#python','#machinelearning','#sql','#linux','#cloudcomputing','#videojuegos','#flutter']
);

// ── Tipos crear contenido ───────────────────────────────────────────
$crear_tipos = cfg_json('ad_crear_tipos',
    [['🎬','Video','Sube o graba un video'],['🎙','Podcast','Crea un episodio'],['📊','Infografía','Diseña datos visuales'],['📑','Presentación','Crea slides interactivos'],['🖼','Imagen','Publica un recurso visual'],['📄','Artículo','Escribe una publicación'],['📖','Curso','Crea un módulo MOOC'],['▶','Playlist','Organiza contenido']]
);

// ── Configuración del canal ─────────────────────────────────────────
$canal_configs = cfg_json('ad_canal_configs',
    [['Canal público','Cualquier usuario puede ver tu contenido','checked'],['Permitir comentarios','Los usuarios pueden comentar en tus videos','checked'],['Mostrar suscriptores','Número de suscriptores visible para todos',''],['Notificaciones de actividad','Recibe alertas cuando interactúen con tu canal','checked'],['Monetización activa','Habilitar ingresos a través del canal','']]
);

// ── Barras gráfico vistas 7d ────────────────────────────────────────
$barras_vistas = cfg_json('ad_barras_vistas_7d', [35,62,48,81,55,90,72]);

// ── Contenido reciente de suscripciones (fallback demo) ─────────────
$sub_content_demo = [
    ['🛡','Nuevo: Bypass WAF con técnicas avanzadas',      'SecLab',      '22:41','video','hace 3h'],
    ['🤖','GPT-4o vs Gemini — Comparativa 2025',           'AI VIROX',    '18:22','video','hace 5h'],
    ['🔬','Rust vs Go: ¿Cuál elegir en 2025?',             'VIROX Tech',  '31:15','video','hace 8h'],
    ['📊','Tutorial completo: Window Functions SQL',        'DataVIROX',   '24:33','video','hace 12h'],
    ['🎮','Shaders en Unity 6: Nuevo Render Pipeline',     'GameDev',     '42:10','video','ayer'],
    ['☁️','Terraform desde cero en AWS',                  'CloudVIROX',  '35:48','video','ayer'],
    ['🛡','CTF WriteUp: Buffer Overflow',                  'SecLab',      '19:05','video','hace 2 días'],
    ['🤖','LangChain Agents: Construye tu IA',             'AI VIROX',    '28:37','video','hace 2 días'],
];

// Traer contenido reciente de canales suscritos si hay suscripciones
$sub_content_bd = [];
if (!empty($suscripciones)) {
    $canal_ids = implode(',', array_column($suscripciones, 'id'));
    $sub_content_bd = qdb($conexion,
        "SELECT co.*, ca.nombre AS canal_nombre
         FROM contenido_ad co
         JOIN canales_ad ca ON ca.id = co.canal_id
         WHERE co.canal_id IN ($canal_ids) AND co.publicado = 1
         ORDER BY co.fecha_publicacion DESC LIMIT 8"
    );
}

// ── Cursos en progreso (mis cursos) ─────────────────────────────────
$mis_cursos_en_progreso = [];
if ($uid && !empty($prog_map)) {
    foreach ($cursos as $c) {
        $p = $prog_map[$c['id']] ?? null;
        if ($p && $p['progreso'] > 0 && !$p['completado']) {
            $c['_progreso'] = (int)$p['progreso'];
            $mis_cursos_en_progreso[] = $c;
        }
    }
}
// Fallback demo mis cursos en progreso
if (empty($mis_cursos_en_progreso)) {
    $mis_cursos_en_progreso = [
        ['id'=>1,'icono'=>'🛡','titulo'=>'Ciberseguridad desde Cero', 'instructor_nombre'=>'Carlos R.','nivel'=>'avanzado', 'total_lecciones'=>45,'duracion'=>'40h','categoria'=>'seguridad','tipo'=>'MOOC','_progreso'=>65,'_parte'=>'1/3'],
        ['id'=>5,'icono'=>'☁️','titulo'=>'Cloud Computing AWS',       'instructor_nombre'=>'Marco A.', 'nivel'=>'intermedio','total_lecciones'=>44,'duracion'=>'50h','categoria'=>'cloud',    'tipo'=>'MOOC','_progreso'=>80,'_parte'=>'2/3'],
    ];
}

// ── Stats: totales para hero banner ────────────────────────────────
$total_contenidos = count($videos_feed)  ?: cfg_val('ad_stat_contenidos', '∞');
$total_cursos_bd  = count($cursos)       ?: cfg_val('ad_stat_cursos', '12');
$total_canales_bd = count($canales_recomendados) ?: cfg_val('ad_stat_canales', '12');
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Aprendizaje Digital — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

  <style>
  /* ══════════════════════════════════════════════════════════════
     VARIABLES & RESET
  ══════════════════════════════════════════════════════════════ */
  :root{
    --n950:#010610; --n900:#020817; --n800:#0c1526;
    --n700:#111827; --n600:#182035; --n500:#1e2d47; --n400:#243450;
    --gold:#DAA520;   --gold-lt:#f0c840; --gold-dim:rgba(218,165,32,.13);
    --green:#28A680;  --green-lt:#35d4a8;--green-dim:rgba(40,166,128,.13);
    --blue:#3b82f6;   --blue-lt:#93c5fd; --blue-dim:rgba(59,130,246,.13);
    --purple:#8b5cf6; --purple-lt:#c4b5fd;--purple-dim:rgba(139,92,246,.13);
    --red:#ef4444;    --red-lt:#fca5a5;
    --txt:#f0f4f8;  --muted:#8da0b8; --dim:#526278;
    --sh-sm:0 4px 18px rgba(0,0,0,.4);
    --sh-md:0 10px 40px rgba(0,0,0,.5);
    --sh-lg:0 24px 64px rgba(0,0,0,.65);
    --r-sm:8px; --r-md:14px; --r-lg:22px; --r-xl:32px;
    --font-d:'Orbitron',monospace;
    --font-b:'Syne',sans-serif;
    --sidebar-w:72px;
    --sidebar-exp:240px;
    --topbar-h:60px;
  }
  *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
  html{scroll-behavior:smooth;}
  body{font-family:var(--font-b);background:var(--n950);color:var(--txt);overflow-x:hidden;min-height:100vh;}
  ::-webkit-scrollbar{width:4px;height:4px;}
  ::-webkit-scrollbar-track{background:var(--n800);}
  ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
  a{text-decoration:none;color:inherit;}
  button{cursor:pointer;border:none;font-family:var(--font-b);background:none;}
  img{display:block;max-width:100%;}

  /* ══ LAYOUT ══ */
  .ad-wrap{display:grid;grid-template-columns:var(--sidebar-w) 1fr;grid-template-rows:var(--topbar-h) 1fr;grid-template-areas:"sidebar topbar" "sidebar content";min-height:100vh;}

  /* ══ SIDEBAR ══ */
  .ad-sidebar{grid-area:sidebar;position:fixed;top:0;left:0;bottom:0;width:var(--sidebar-w);background:var(--n900);border-right:1px solid rgba(40,166,128,.12);z-index:200;display:flex;flex-direction:column;transition:width .3s cubic-bezier(.4,0,.2,1);overflow:hidden;}
  .ad-sidebar:hover,.ad-sidebar.expanded{width:var(--sidebar-exp);box-shadow:4px 0 40px rgba(0,0,0,.5);}
  .sb-logo{display:flex;align-items:center;gap:12px;padding:14px 18px;height:var(--topbar-h);border-bottom:1px solid rgba(255,255,255,.05);flex-shrink:0;white-space:nowrap;overflow:hidden;}
  .sb-logo-ico{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--green),#1a7a5e);display:flex;align-items:center;justify-content:center;font-size:1rem;color:#fff;font-family:var(--font-d);font-weight:900;flex-shrink:0;box-shadow:0 0 12px rgba(40,166,128,.4);}
  .sb-logo-txt{font-family:var(--font-d);font-size:.85rem;font-weight:900;color:var(--gold);letter-spacing:3px;opacity:0;transition:opacity .2s .1s;}
  .ad-sidebar:hover .sb-logo-txt,.ad-sidebar.expanded .sb-logo-txt{opacity:1;}
  .sb-nav{flex:1;overflow-y:auto;overflow-x:hidden;padding:12px 0;}
  .sb-nav::-webkit-scrollbar{width:2px;}
  .sb-divider{height:1px;background:rgba(255,255,255,.06);margin:8px 12px;}
  .sb-section-label{font-size:.58rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:0 18px;margin:12px 0 4px;white-space:nowrap;overflow:hidden;opacity:0;transition:opacity .2s;}
  .ad-sidebar:hover .sb-section-label,.ad-sidebar.expanded .sb-section-label{opacity:1;}
  .sb-item{display:flex;align-items:center;gap:14px;padding:11px 18px;cursor:pointer;transition:background .2s,color .2s;white-space:nowrap;overflow:hidden;position:relative;border-left:3px solid transparent;border-radius:0 var(--r-md) var(--r-md) 0;margin:1px 8px 1px 0;}
  .sb-item:hover{background:rgba(255,255,255,.05);color:var(--txt);}
  .sb-item.active{background:var(--green-dim);border-left-color:var(--green);color:var(--green-lt);}
  .sb-item-ico{width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;transition:all .2s;}
  .sb-item.active .sb-item-ico{background:rgba(40,166,128,.2);}
  .sb-item-lbl{font-size:.85rem;font-weight:600;color:var(--muted);overflow:hidden;opacity:0;transition:opacity .2s .05s;}
  .ad-sidebar:hover .sb-item-lbl,.ad-sidebar.expanded .sb-item-lbl{opacity:1;}
  .sb-item:hover .sb-item-lbl,.sb-item.active .sb-item-lbl{color:var(--txt);}
  .sb-item.active .sb-item-lbl{color:var(--green-lt);}
  .sb-badge{margin-left:auto;padding:1px 6px;border-radius:99px;font-size:.6rem;font-weight:700;background:var(--red);color:#fff;flex-shrink:0;opacity:0;transition:opacity .2s;}
  .ad-sidebar:hover .sb-badge,.ad-sidebar.expanded .sb-badge{opacity:1;}
  .sb-user{padding:12px 16px;border-top:1px solid rgba(255,255,255,.06);display:flex;align-items:center;gap:10px;cursor:pointer;transition:background .2s;overflow:hidden;flex-shrink:0;}
  .sb-user:hover{background:rgba(255,255,255,.05);}
  .sb-user-av{width:32px;height:32px;border-radius:50%;object-fit:cover;border:2px solid var(--green);flex-shrink:0;}
  .sb-user-info{overflow:hidden;opacity:0;transition:opacity .2s;}
  .ad-sidebar:hover .sb-user-info,.ad-sidebar.expanded .sb-user-info{opacity:1;}
  .sb-user-name{font-size:.78rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .sb-user-role{font-size:.65rem;color:var(--muted);}

  /* ══ TOPBAR ══ */
  .ad-topbar{grid-area:topbar;position:sticky;top:0;z-index:100;height:var(--topbar-h);background:rgba(2,8,23,.92);backdrop-filter:blur(20px);border-bottom:1px solid rgba(40,166,128,.15);display:flex;align-items:center;gap:12px;padding:0 20px 0 16px;}
  .tb-search{flex:1;max-width:640px;display:flex;align-items:center;gap:0;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:99px;overflow:hidden;transition:border-color .2s,box-shadow .2s;}
  .tb-search:focus-within{border-color:var(--green);box-shadow:0 0 0 3px rgba(40,166,128,.12);}
  .tb-search-input{flex:1;padding:9px 18px;background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.88rem;}
  .tb-search-input::placeholder{color:var(--dim);}
  .tb-search-btn{padding:9px 18px;background:rgba(255,255,255,.07);border-left:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.9rem;transition:background .2s,color .2s;}
  .tb-search-btn:hover{background:var(--green);color:#fff;}
  .tb-actions{display:flex;align-items:center;gap:8px;margin-left:auto;}
  .tb-btn{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.85rem;position:relative;transition:all .2s;}
  .tb-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .tb-btn .notif-dot{position:absolute;top:5px;right:5px;width:8px;height:8px;border-radius:50%;background:var(--red);border:2px solid var(--n900);}
  .tb-tabs{display:flex;gap:2px;align-items:center;}
  .tb-tab{padding:6px 14px;border-radius:99px;font-size:.8rem;font-weight:600;color:var(--muted);transition:all .2s;}
  .tb-tab:hover{color:var(--txt);background:rgba(255,255,255,.06);}
  .tb-tab.on{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.3);}

  /* ══ CONTENIDO ══ */
  .ad-content{grid-area:content;padding:24px 28px;min-width:0;overflow-y:auto;}
  .ad-section{display:none;animation:secIn .4s ease both;}
  .ad-section.on{display:block;}
  @keyframes secIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

  /* ══ COMPONENTES ══ */
  .sec-title{display:flex;align-items:center;gap:12px;margin-bottom:20px;}
  .sec-title h2{font-family:var(--font-d);font-size:1rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
  .sec-title-line{flex:1;height:1px;background:linear-gradient(to right,rgba(40,166,128,.3),transparent);}
  .sec-title-more{font-size:.78rem;color:var(--green);font-weight:600;cursor:pointer;white-space:nowrap;transition:color .2s;}
  .sec-title-more:hover{color:var(--gold);}

  /* Video card */
  .vid-card{background:var(--n800);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);overflow:hidden;cursor:pointer;transition:transform .25s,border-color .25s,box-shadow .25s;}
  .vid-card:hover{transform:translateY(-5px);border-color:rgba(40,166,128,.3);box-shadow:var(--sh-md);}
  .vid-thumb{position:relative;aspect-ratio:16/9;background:var(--n700);overflow:hidden;}
  .vid-thumb img{width:100%;height:100%;object-fit:cover;transition:transform .4s;}
  .vid-card:hover .vid-thumb img{transform:scale(1.05);}
  .vid-thumb-placeholder{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:2.5rem;background:linear-gradient(135deg,var(--n700),var(--n600));}
  .vid-duration{position:absolute;bottom:8px;right:8px;padding:2px 7px;background:rgba(0,0,0,.8);border-radius:4px;font-size:.7rem;font-weight:700;color:#fff;font-family:var(--font-d);}
  .vid-type-badge{position:absolute;top:8px;left:8px;padding:2px 8px;border-radius:99px;font-size:.62rem;font-weight:700;letter-spacing:.5px;}
  .vt-video{background:rgba(239,68,68,.9);color:#fff;} .vt-podcast{background:rgba(139,92,246,.9);color:#fff;} .vt-curso{background:rgba(40,166,128,.9);color:#fff;} .vt-info{background:rgba(218,165,32,.9);color:#000;} .vt-slides{background:rgba(59,130,246,.9);color:#fff;} .vt-audio{background:rgba(20,184,166,.9);color:#fff;}
  .vid-play-ov{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.3);opacity:0;transition:opacity .3s;}
  .vid-play-ov i{font-size:2.5rem;color:#fff;filter:drop-shadow(0 0 12px rgba(0,0,0,.8));}
  .vid-card:hover .vid-play-ov{opacity:1;}
  .vid-body{padding:12px 14px;}
  .vid-author-row{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
  .vid-av{width:28px;height:28px;border-radius:50%;object-fit:cover;border:1.5px solid var(--green);flex-shrink:0;}
  .vid-av-ph{width:28px;height:28px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.75rem;color:var(--green-lt);flex-shrink:0;}
  .vid-canal{font-size:.72rem;font-weight:700;color:var(--muted);transition:color .2s;}
  .vid-card:hover .vid-canal{color:var(--green-lt);}
  .vid-title{font-size:.9rem;font-weight:700;color:var(--txt);line-height:1.4;margin-bottom:6px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
  .vid-meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
  .vid-meta-chip{font-size:.65rem;color:var(--dim);display:flex;align-items:center;gap:3px;}
  .vid-tags{display:flex;gap:4px;margin-top:6px;flex-wrap:wrap;}
  .vid-tag{padding:2px 8px;background:rgba(255,255,255,.05);border-radius:99px;font-size:.62rem;color:var(--dim);}
  .vid-grid{display:grid;gap:16px;}
  .vg-4{grid-template-columns:repeat(auto-fill,minmax(220px,1fr));}
  .vg-3{grid-template-columns:repeat(auto-fill,minmax(280px,1fr));}
  .vg-2{grid-template-columns:repeat(auto-fill,minmax(360px,1fr));}

  /* Hero banner */
  .hero-banner{position:relative;height:220px;border-radius:var(--r-xl);overflow:hidden;margin-bottom:32px;background:linear-gradient(135deg,#0a1f3d,#081528,#0d2a1a);}
  .hb-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.05) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.05) 1px,transparent 1px);background-size:40px 40px;}
  .hb-orb1{position:absolute;width:300px;height:300px;border-radius:50%;filter:blur(80px);background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-80px;left:-60px;animation:hbo 8s ease-in-out infinite;}
  .hb-orb2{position:absolute;width:250px;height:250px;border-radius:50%;filter:blur(80px);background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-60px;right:-40px;animation:hbo 11s ease-in-out infinite reverse;}
  @keyframes hbo{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-15px)}}
  .hb-content{position:relative;z-index:1;padding:32px 36px;height:100%;display:flex;align-items:center;gap:28px;}
  .hb-text h1{font-family:var(--font-d);font-size:clamp(1.4rem,2.5vw,2rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:8px;}
  .hb-text h1 span{color:var(--gold);text-shadow:0 0 20px rgba(218,165,32,.4);}
  .hb-text p{font-size:.88rem;color:var(--muted);line-height:1.6;max-width:480px;}
  .hb-stats{display:flex;gap:20px;margin-top:16px;}
  .hb-stat{text-align:center;}
  .hb-stat-n{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);}
  .hb-stat-l{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;}

  /* Filtros */
  .content-filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px;padding:14px 18px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);}
  .cf-chip{padding:6px 16px;border-radius:99px;font-size:.78rem;font-weight:600;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.09);color:var(--muted);cursor:pointer;transition:all .2s;}
  .cf-chip:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .cf-chip.on{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}
  .cf-chip i{margin-right:5px;}

  /* Canal card */
  .canal-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:20px;display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center;cursor:pointer;transition:transform .25s,border-color .25s,box-shadow .25s;}
  .canal-card:hover{transform:translateY(-5px);border-color:rgba(218,165,32,.3);box-shadow:var(--sh-md);}
  .canal-av{width:70px;height:70px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 16px rgba(40,166,128,.3);}
  .canal-av-ph{width:70px;height:70px;border-radius:50%;background:linear-gradient(135deg,var(--green-dim),var(--green));display:flex;align-items:center;justify-content:center;font-size:1.8rem;border:3px solid var(--green);}
  .canal-name{font-size:.9rem;font-weight:700;color:var(--txt);}
  .canal-subs{font-size:.72rem;color:var(--muted);}
  .canal-verified{color:var(--gold);font-size:.75rem;margin-left:3px;}
  .canal-btn{padding:6px 16px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;font-size:.75rem;font-weight:700;color:var(--green-lt);transition:all .2s;}
  .canal-btn:hover{background:var(--green);color:#fff;}
  .canal-btn.suscrito{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.15);color:var(--muted);}

  /* Curso card */
  .curso-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);overflow:hidden;cursor:pointer;transition:transform .25s,border-color .25s,box-shadow .25s;display:flex;flex-direction:column;}
  .curso-card:hover{transform:translateY(-6px);border-color:rgba(40,166,128,.35);box-shadow:var(--sh-md);}
  .curso-thumb{height:130px;position:relative;overflow:hidden;background:linear-gradient(135deg,var(--n700),var(--n600));display:flex;align-items:center;justify-content:center;}
  .curso-thumb img{width:100%;height:100%;object-fit:cover;}
  .curso-thumb-ico{font-size:3rem;opacity:.7;}
  .curso-nivel-badge{position:absolute;top:8px;right:8px;padding:3px 10px;border-radius:99px;font-size:.62rem;font-weight:700;}
  .cn-basico{background:rgba(40,166,128,.85);color:#fff;} .cn-intermedio{background:rgba(218,165,32,.85);color:#000;} .cn-avanzado{background:rgba(239,68,68,.85);color:#fff;}
  .curso-body{padding:16px 18px;flex:1;display:flex;flex-direction:column;gap:8px;}
  .curso-cat{font-size:.65rem;font-weight:700;color:var(--green-lt);text-transform:uppercase;letter-spacing:1.5px;}
  .curso-title{font-size:.95rem;font-weight:800;color:var(--txt);line-height:1.4;}
  .curso-instructor{display:flex;align-items:center;gap:7px;font-size:.75rem;color:var(--muted);}
  .ci-av{width:20px;height:20px;border-radius:50%;background:var(--green-dim);border:1px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:.55rem;}
  .curso-meta{display:flex;gap:10px;flex-wrap:wrap;}
  .curso-meta-item{font-size:.7rem;color:var(--dim);display:flex;align-items:center;gap:3px;}
  .curso-prog-wrap{margin-top:auto;}
  .curso-prog-hd{display:flex;justify-content:space-between;font-size:.68rem;color:var(--muted);margin-bottom:4px;}
  .curso-prog-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
  .curso-prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}
  .curso-rating{display:flex;align-items:center;gap:5px;}
  .curso-stars{color:var(--gold);font-size:.7rem;}
  .curso-rating-n{font-size:.7rem;color:var(--muted);}

  /* Objetivo card */
  .obj-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px 20px;display:flex;align-items:flex-start;gap:14px;transition:border-color .2s;margin-bottom:10px;}
  .obj-card:hover{border-color:rgba(40,166,128,.3);}
  .obj-check{width:24px;height:24px;border-radius:50%;border:2px solid var(--green);flex-shrink:0;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;margin-top:2px;}
  .obj-check.done{background:var(--green);border-color:var(--green);}
  .obj-check.done::after{content:'✓';font-size:.75rem;color:#fff;font-weight:700;}
  .obj-body{flex:1;}
  .obj-title{font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
  .obj-desc{font-size:.78rem;color:var(--muted);line-height:1.55;margin-bottom:8px;}
  .obj-meta{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
  .obj-deadline{font-size:.7rem;color:var(--gold);display:flex;align-items:center;gap:4px;}
  .obj-category{font-size:.7rem;padding:2px 8px;border-radius:99px;background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.25);}
  .obj-prog-bar{height:3px;background:rgba(255,255,255,.08);border-radius:99px;margin-top:8px;overflow:hidden;}
  .obj-prog-fill{height:100%;background:var(--green);border-radius:99px;}

  /* Calendario */
  .calendar-wrap{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:20px;margin-bottom:24px;}
  .cal-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;}
  .cal-title{font-family:var(--font-d);font-size:.88rem;font-weight:700;color:var(--txt);}
  .cal-nav{display:flex;gap:4px;}
  .cal-nav-btn{width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.75rem;cursor:pointer;transition:all .2s;}
  .cal-nav-btn:hover{background:var(--green-dim);color:var(--green-lt);}
  .cal-days-header{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;margin-bottom:4px;}
  .cal-day-name{text-align:center;font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;padding:4px 0;}
  .cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;}
  .cal-day{aspect-ratio:1;border-radius:var(--r-sm);display:flex;align-items:center;justify-content:center;font-size:.78rem;color:var(--muted);cursor:pointer;transition:all .2s;position:relative;}
  .cal-day:hover{background:rgba(255,255,255,.07);color:var(--txt);}
  .cal-day.today{background:var(--green-dim);color:var(--green-lt);border:1px solid rgba(40,166,128,.4);font-weight:700;}
  .cal-day.has-event::after{content:'';position:absolute;bottom:3px;left:50%;transform:translateX(-50%);width:4px;height:4px;border-radius:50%;background:var(--gold);}
  .cal-day.other-month{opacity:.3;}

  /* Canal studio */
  .canal-studio{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:24px;margin-bottom:24px;}
  .cs-header{display:flex;align-items:center;gap:18px;margin-bottom:20px;padding-bottom:18px;border-bottom:1px solid rgba(255,255,255,.07);}
  .cs-av{width:64px;height:64px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 20px rgba(40,166,128,.3);}
  .cs-av-ph{width:64px;height:64px;border-radius:50%;background:var(--green-dim);border:3px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:1.8rem;}
  .cs-info h3{font-family:var(--font-d);font-size:1rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
  .cs-info p{font-size:.78rem;color:var(--muted);}
  .cs-stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:14px;margin-bottom:20px;}
  .cs-stat{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;text-align:center;}
  .cs-stat-ico{font-size:1.4rem;margin-bottom:6px;}
  .cs-stat-n{font-family:var(--font-d);font-size:1.5rem;font-weight:900;color:var(--gold);}
  .cs-stat-l{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;}
  .cs-chart{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px;margin-bottom:18px;}
  .cs-chart-title{font-size:.8rem;font-weight:700;color:var(--txt);margin-bottom:14px;}
  .cs-bars{display:flex;align-items:flex-end;gap:4px;height:70px;}
  .cs-bar{flex:1;border-radius:3px 3px 0 0;background:linear-gradient(to top,var(--green),rgba(40,166,128,.3));min-height:4px;transition:height .8s ease;cursor:pointer;}
  .cs-bar:hover{background:linear-gradient(to top,var(--gold),rgba(218,165,32,.3));}
  .cs-bar-labels{display:flex;gap:4px;margin-top:4px;}
  .cs-bar-lbl{flex:1;text-align:center;font-size:.55rem;color:var(--dim);}
  .cs-actions{display:flex;gap:10px;flex-wrap:wrap;}
  .cs-action-btn{display:inline-flex;align-items:center;gap:8px;padding:9px 18px;border-radius:var(--r-md);font-size:.82rem;font-weight:700;transition:all .2s;cursor:pointer;}
  .csa-primary{background:var(--green);color:#fff;box-shadow:0 4px 16px rgba(40,166,128,.3);}
  .csa-primary:hover{background:var(--green-lt);transform:translateY(-2px);}
  .csa-secondary{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
  .csa-secondary:hover{background:rgba(255,255,255,.1);color:var(--txt);}
  .csa-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
  .csa-gold:hover{background:var(--gold);color:#000;}

  /* Herramientas */
  .tools-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;}
  .tool-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;cursor:pointer;transition:all .25s;}
  .tool-card:hover{transform:translateY(-4px);border-color:rgba(40,166,128,.35);box-shadow:var(--sh-sm);}
  .tool-ico{font-size:2rem;}
  .tool-name{font-size:.82rem;font-weight:700;color:var(--txt);}
  .tool-desc{font-size:.68rem;color:var(--muted);line-height:1.4;}
  .tool-launch{margin-top:4px;padding:5px 12px;background:var(--green-dim);border:1px solid rgba(40,166,128,.25);border-radius:99px;font-size:.68rem;font-weight:700;color:var(--green-lt);transition:all .2s;}
  .tool-card:hover .tool-launch{background:var(--green);color:#fff;}

  /* Playlist */
  .playlist-panel{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:18px;position:sticky;top:20px;max-height:calc(100vh - 120px);display:flex;flex-direction:column;}
  .pl-header{display:flex;align-items:center;gap:10px;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,.07);}
  .pl-title{font-size:.88rem;font-weight:700;color:var(--txt);flex:1;}
  .pl-count{font-size:.72rem;color:var(--muted);}
  .pl-list{overflow-y:auto;flex:1;}
  .pl-item{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:var(--r-md);cursor:pointer;transition:background .2s;}
  .pl-item:hover{background:rgba(255,255,255,.05);}
  .pl-item.playing{background:var(--green-dim);}
  .pl-item-num{font-size:.68rem;color:var(--dim);width:16px;text-align:center;flex-shrink:0;}
  .pl-item.playing .pl-item-num{color:var(--green-lt);}
  .pl-item-info{flex:1;min-width:0;}
  .pl-item-title{font-size:.75rem;font-weight:600;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
  .pl-item-dur{font-size:.65rem;color:var(--dim);}

  /* Ingresos */
  .ingresos-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:20px;}
  .ingreso-card{background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:18px;text-align:center;}
  .ic-ico{font-size:1.8rem;margin-bottom:6px;}
  .ic-num{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);}
  .ic-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

  /* Publicaciones */
  .pub-card{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:20px;margin-bottom:14px;cursor:pointer;transition:border-color .2s;}
  .pub-card:hover{border-color:rgba(40,166,128,.3);}
  .pub-header{display:flex;align-items:center;gap:10px;margin-bottom:12px;}
  .pub-av{width:36px;height:36px;border-radius:50%;object-fit:cover;border:2px solid var(--green);}
  .pub-autor{font-size:.82rem;font-weight:700;color:var(--txt);}
  .pub-fecha{font-size:.68rem;color:var(--dim);}
  .pub-title{font-size:1rem;font-weight:700;color:var(--txt);margin-bottom:8px;}
  .pub-excerpt{font-size:.85rem;color:var(--muted);line-height:1.65;margin-bottom:12px;}
  .pub-tags{display:flex;gap:6px;flex-wrap:wrap;}
  .pub-tag{padding:2px 10px;background:var(--green-dim);border:1px solid rgba(40,166,128,.2);border-radius:99px;font-size:.68rem;color:var(--green-lt);}

  /* Crear contenido */
  .crear-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-bottom:24px;}
  .crear-item{background:var(--n800);border:2px dashed rgba(255,255,255,.1);border-radius:var(--r-xl);padding:22px 14px;display:flex;flex-direction:column;align-items:center;gap:8px;text-align:center;cursor:pointer;transition:all .25s;}
  .crear-item:hover{background:var(--green-dim);border-color:var(--green);transform:translateY(-4px);}
  .crear-item:hover .crear-ico{color:var(--green-lt);}
  .crear-ico{font-size:2.2rem;color:var(--dim);transition:color .2s;}
  .crear-label{font-size:.82rem;font-weight:700;color:var(--muted);}
  .crear-item:hover .crear-label{color:var(--green-lt);}

  /* Config canal */
  .config-section{background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:22px;margin-bottom:16px;}
  .config-title{font-size:.82rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px;display:flex;align-items:center;gap:8px;}
  .config-row{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.05);}
  .config-row:last-child{border-bottom:none;}
  .config-row-info strong{display:block;font-size:.85rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
  .config-row-info span{font-size:.72rem;color:var(--muted);}
  .toggle{position:relative;width:40px;height:22px;flex-shrink:0;}
  .toggle input{display:none;}
  .toggle-sl{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:background .3s;}
  .toggle-sl::before{content:'';position:absolute;width:16px;height:16px;border-radius:50%;background:#fff;top:3px;left:3px;transition:transform .3s;box-shadow:0 1px 4px rgba(0,0,0,.4);}
  .toggle input:checked + .toggle-sl{background:var(--green);}
  .toggle input:checked + .toggle-sl::before{transform:translateX(18px);}

  /* Empty state */
  .ad-empty{text-align:center;padding:56px 24px;background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);border-radius:var(--r-xl);color:var(--dim);}
  .ad-empty-ico{font-size:3.5rem;margin-bottom:14px;opacity:.3;}
  .ad-empty p{font-size:.9rem;margin-bottom:16px;}
  .ad-empty-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 22px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.85rem;transition:all .2s;cursor:pointer;}
  .ad-empty-btn:hover{background:var(--green-lt);transform:translateY(-2px);}

  /* Modal */
  .ad-modal{position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;display:none;align-items:flex-start;justify-content:center;padding:20px;overflow-y:auto;}
  .ad-modal.open{display:flex;}
  .ad-modal-box{width:100%;max-width:1100px;margin:auto;background:var(--n900);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-xl);box-shadow:var(--sh-lg);animation:modalIn .35s ease both;}
  @keyframes modalIn{from{opacity:0;transform:translateY(28px) scale(.97)}to{opacity:1;transform:none}}
  .ad-modal-close{display:flex;justify-content:flex-end;padding:14px 18px;border-bottom:1px solid rgba(255,255,255,.06);position:sticky;top:0;background:var(--n900);z-index:1;border-radius:var(--r-xl) var(--r-xl) 0 0;}
  .amc-btn{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.12);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.8rem;cursor:pointer;transition:all .2s;}
  .amc-btn:hover{background:rgba(239,68,68,.2);color:#f87171;}
  .ad-modal-body{padding:0 28px 28px;}

  /* Responsive */
  @media(max-width:1024px){.vg-4{grid-template-columns:repeat(auto-fill,minmax(180px,1fr));}.ad-content{padding:16px;}}
  @media(max-width:768px){.ad-wrap{grid-template-columns:0 1fr;}.ad-sidebar{transform:translateX(-100%);}.ad-sidebar.mobile-open{transform:translateX(0);width:var(--sidebar-exp);}.vg-4{grid-template-columns:1fr 1fr;}.vg-3{grid-template-columns:1fr 1fr;}.cs-stats-row{grid-template-columns:1fr 1fr;}.ad-modal-body{padding:0 16px 20px;}.hero-banner{height:auto;}.hb-content{flex-direction:column;padding:20px;}}
  @media(max-width:480px){.vg-4,.vg-3,.vg-2{grid-template-columns:1fr;}.tb-tabs{display:none;}.crear-grid{grid-template-columns:1fr 1fr;}}
  </style>
</head>
<body>
<div class="ad-wrap">

<!-- ══ SIDEBAR ══ -->
<aside class="ad-sidebar" id="adSidebar">
  <div class="sb-logo">
    <div class="sb-logo-ico">AD</div>
    <span class="sb-logo-txt">APRENDIZAJE</span>
  </div>
  <nav class="sb-nav">
    <div class="sb-item <?= $seccion==='principal'?'active':'' ?>" onclick="goSec('principal')">
      <div class="sb-item-ico"><i class="fa fa-house"></i></div>
      <span class="sb-item-lbl">Principal</span>
    </div>
    <div class="sb-item <?= $seccion==='suscripciones'?'active':'' ?>" onclick="goSec('suscripciones')">
      <div class="sb-item-ico"><i class="fa fa-rss"></i></div>
      <span class="sb-item-lbl">Suscripciones</span>
      <?php if (count($suscripciones) > 0): ?>
      <span class="sb-badge"><?= count($suscripciones) ?></span>
      <?php endif; ?>
    </div>
    <div class="sb-item <?= $seccion==='objetivos'?'active':'' ?>" onclick="goSec('objetivos')">
      <div class="sb-item-ico"><i class="fa fa-bullseye"></i></div>
      <span class="sb-item-lbl">Objetivos</span>
    </div>
    <div class="sb-item <?= $seccion==='cursos'?'active':'' ?>" onclick="goSec('cursos')">
      <div class="sb-item-ico"><i class="fa fa-graduation-cap"></i></div>
      <span class="sb-item-lbl">Cursos</span>
    </div>
    <div class="sb-divider"></div>
    <div class="sb-section-label">Herramientas</div>
    <div class="sb-item <?= $seccion==='herramientas'?'active':'' ?>" onclick="goSec('herramientas')">
      <div class="sb-item-ico"><i class="fa fa-toolbox"></i></div>
      <span class="sb-item-lbl">Herramientas</span>
    </div>
    <div class="sb-divider"></div>
    <div class="sb-section-label">Mi Canal</div>
    <div class="sb-item <?= $seccion==='canal'?'active':'' ?>" onclick="goSec('canal')">
      <div class="sb-item-ico"><i class="fa fa-tower-broadcast"></i></div>
      <span class="sb-item-lbl">Mi Canal</span>
    </div>
    <div class="sb-item <?= $seccion==='comunidad'?'active':'' ?>" onclick="goSec('comunidad')">
      <div class="sb-item-ico"><i class="fa fa-users"></i></div>
      <span class="sb-item-lbl">Comunidad</span>
    </div>
    <div class="sb-divider"></div>
    <div class="sb-section-label">Plataforma</div>
    <div class="sb-item" onclick="window.location.href='servicios.php'">
      <div class="sb-item-ico"><i class="fa fa-store"></i></div>
      <span class="sb-item-lbl">Servicios VIROX</span>
    </div>
    <div class="sb-item" onclick="window.location.href='index.php'">
      <div class="sb-item-ico"><i class="fa fa-arrow-left"></i></div>
      <span class="sb-item-lbl">Volver al inicio</span>
    </div>
  </nav>
  <div class="sb-user" onclick="window.location.href='perfil.php'">
    <img src="<?= $avatar ?>" alt="Avatar" class="sb-user-av">
    <div class="sb-user-info">
      <div class="sb-user-name"><?= $nombre ?></div>
      <div class="sb-user-role"><?= ucfirst($rol) ?></div>
    </div>
  </div>
</aside>

<!-- ══ TOPBAR ══ -->
<header class="ad-topbar">
  <button onclick="toggleSidebar()" style="color:var(--muted);font-size:1rem;padding:8px;border-radius:var(--r-sm);background:rgba(255,255,255,.05);transition:all .2s;" onmouseover="this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.background='rgba(255,255,255,.05)'">
    <i class="fa fa-bars"></i>
  </button>
  <div class="tb-search">
    <input type="text" class="tb-search-input" id="globalSearch" placeholder="Buscar cursos, videos, canales...">
    <button class="tb-search-btn"><i class="fa fa-search"></i></button>
  </div>
  <div class="tb-tabs" id="topTabs">
    <button class="tb-tab on"   onclick="goSec('principal',this)">Inicio</button>
    <button class="tb-tab"      onclick="goSec('cursos',this)">Cursos</button>
    <button class="tb-tab"      onclick="goSec('herramientas',this)">Herramientas</button>
    <button class="tb-tab"      onclick="goSec('canal',this)">Mi Canal</button>
  </div>
  <div class="tb-actions">
    <button class="tb-btn" title="Subir contenido" onclick="goSec('canal')" style="background:var(--green);border-color:var(--green);color:#fff;">
      <i class="fa fa-plus"></i>
    </button>
    <button class="tb-btn" title="Notificaciones">
      <i class="fa fa-bell"></i>
      <span class="notif-dot"></span>
    </button>
    <a href="perfil.php" style="display:block;">
      <img src="<?= $avatar ?>" alt="Avatar" style="width:32px;height:32px;border-radius:50%;object-fit:cover;border:2px solid var(--green);cursor:pointer;">
    </a>
  </div>
</header>

<!-- ══ CONTENIDO ══ -->
<main class="ad-content">

  <!-- ▓▓▓▓ PRINCIPAL ▓▓▓▓ -->
  <div class="ad-section on" id="sec-principal">

    <div class="hero-banner">
      <div class="hb-grid"></div><div class="hb-orb1"></div><div class="hb-orb2"></div>
      <div class="hb-content">
        <div class="hb-text">
          <h1>Aprendizaje <span>Digital</span></h1>
          <p>Explora videos, cursos, podcasts, infografías y más contenido educativo de la comunidad VIROX.</p>
          <div class="hb-stats">
            <div class="hb-stat"><div class="hb-stat-n"><?= htmlspecialchars((string)$total_contenidos) ?></div><div class="hb-stat-l">Contenidos</div></div>
            <div class="hb-stat"><div class="hb-stat-n"><?= $total_cursos_bd ?></div><div class="hb-stat-l">Cursos</div></div>
            <div class="hb-stat"><div class="hb-stat-n"><?= count($suscripciones) ?: '0' ?></div><div class="hb-stat-l">Canales</div></div>
          </div>
        </div>
      </div>
    </div>

    <!-- Filtros -->
    <div class="content-filters">
      <span class="cf-chip on" onclick="filterContent('todo',this)"><i class="fa fa-border-all"></i> Todo</span>
      <span class="cf-chip" onclick="filterContent('video',this)"><i class="fa fa-video"></i> Videos</span>
      <span class="cf-chip" onclick="filterContent('infografia',this)"><i class="fa fa-chart-pie"></i> Infografías</span>
      <span class="cf-chip" onclick="filterContent('podcast',this)"><i class="fa fa-podcast"></i> Podcast</span>
      <span class="cf-chip" onclick="filterContent('audio',this)"><i class="fa fa-headphones"></i> Audios</span>
      <span class="cf-chip" onclick="filterContent('presentacion',this)"><i class="fa fa-desktop"></i> Presentaciones</span>
      <span class="cf-chip" onclick="filterContent('imagen',this)"><i class="fa fa-images"></i> Imágenes</span>
      <span class="cf-chip" onclick="filterContent('documento',this)"><i class="fa fa-file-alt"></i> Documentos</span>
    </div>

    <div class="sec-title">
      <h2>🔥 Tendencias hoy</h2>
      <div class="sec-title-line"></div>
      <span class="sec-title-more" onclick="loadMore()">Ver más ›</span>
    </div>

    <!-- Feed de contenido — desde BD o demo -->
    <div class="vid-grid vg-4" id="feedGrid">
      <?php
        $tipos_cls  = ['video'=>'vt-video','podcast'=>'vt-podcast','infografia'=>'vt-info','presentacion'=>'vt-slides','audio'=>'vt-audio'];

        if (!empty($videos_feed)) {
            foreach ($videos_feed as $i => $v):
                $tipo    = $v['tipo'] ?? 'video';
                $tipo_cl = $tipos_cls[$tipo] ?? 'vt-video';
                $av      = !empty($v['autor_avatar']) ? htmlspecialchars($v['autor_avatar']) : '';
      ?>
      <div class="vid-card" data-tipo="<?= htmlspecialchars($tipo) ?>" style="animation-delay:<?= $i*.04 ?>s" onclick="openDemoModal('<?= htmlspecialchars($v['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($v['canal_nombre']??($v['autor']??'Anónimo'),ENT_QUOTES) ?>','<?= htmlspecialchars($v['icono']??'🎬',ENT_QUOTES) ?>','<?= $tipo ?>')">
        <div class="vid-thumb">
          <?php if (!empty($v['thumbnail'])): ?>
            <img src="<?= htmlspecialchars($v['thumbnail']) ?>" alt="<?= htmlspecialchars($v['titulo']) ?>" loading="lazy">
          <?php else: ?>
            <div class="vid-thumb-placeholder"><?= htmlspecialchars($v['icono'] ?? '🎬') ?></div>
          <?php endif; ?>
          <?php if (!empty($v['duracion'])): ?><span class="vid-duration"><?= htmlspecialchars($v['duracion']) ?></span><?php endif; ?>
          <span class="vid-type-badge <?= $tipo_cl ?>"><?= strtoupper($tipo) ?></span>
          <div class="vid-play-ov"><i class="fa fa-play"></i></div>
        </div>
        <div class="vid-body">
          <div class="vid-author-row">
            <?php if ($av): ?>
              <img src="<?= $av ?>" class="vid-av" alt="">
            <?php else: ?>
              <div class="vid-av-ph"><i class="fa fa-user fa-xs"></i></div>
            <?php endif; ?>
            <span class="vid-canal"><?= htmlspecialchars($v['canal_nombre'] ?? ($v['autor'] ?? 'Anónimo')) ?></span>
          </div>
          <div class="vid-title"><?= htmlspecialchars($v['titulo']) ?></div>
          <div class="vid-meta">
            <span class="vid-meta-chip"><i class="fa fa-eye"></i> <?= number_format($v['vistas'] ?? 0) ?></span>
            <span class="vid-meta-chip"><i class="fa fa-clock"></i> <?= !empty($v['fecha_publicacion']) ? date('d M', strtotime($v['fecha_publicacion'])) : '' ?></span>
          </div>
          <?php if (!empty($v['tags'])): ?>
          <div class="vid-tags">
            <?php foreach (array_slice(explode(',', $v['tags']), 0, 3) as $t): ?>
            <span class="vid-tag">#<?= htmlspecialchars(trim($t)) ?></span>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach;

        } else {
            // Demo data exacta del original
            $demo_content = [
                ['💻','Algoritmos y Complejidad O(n)',              'Canal VIROX Tech','12:34','video',    '4.2k vistas','hace 2 días',['algoritmos','cs']],
                ['🛡','Ethical Hacking: Reconocimiento OSINT',      'SecLab VIROX',   '28:15','video',    '8.7k vistas','hace 1 día', ['hacking','seguridad']],
                ['🗄','SQL desde cero: JOINs explicados',            'DataVIROX',      '15:42','video',    '3.1k vistas','hace 3 días',['sql','bases-datos']],
                ['📊','Infografía: Diferencias POO vs Funcional',    'DesignCode',     '–',    'infografia','2.8k vistas','hace 5 días',['poo','programacion']],
                ['🤖','Machine Learning: Regresión lineal',          'AI VIROX',       '35:20','video',    '11.2k vistas','hace 2 días',['ia','ml']],
                ['🐧','Linux para principiantes - Comandos',         'SysAdmin Lab',   '22:10','video',    '5.5k vistas','hace 1 semana',['linux','sistemas']],
                ['☁️','AWS en 20 minutos: EC2 y S3',                'CloudVIROX',     '19:55','video',    '7.3k vistas','hace 4 días',['cloud','aws']],
                ['🎮','Introducción a Unity 2024',                   'GameDev VIROX',  '44:30','video',    '9.1k vistas','hace 6 días',['unity','videojuegos']],
                ['🔐','Criptografía: RSA explicado visual',          'CryptoLab',      '18:07','infografia','4.6k vistas','hace 3 días',['criptografia','seguridad']],
                ['📱','Flutter Widgets: ListView y GridView',        'MobileDev',      '26:44','video',    '6.2k vistas','hace 1 semana',['flutter','mobile']],
                ['🎙','Podcast: Tendencias TI 2025',                 'TechTalk VIROX', '52:00','podcast',  '3.4k vistas','hace 2 días',['tendencias','podcast']],
                ['🌐','HTTP/2 y HTTP/3 diferencias',                 'NetVIROX',       '14:28','video',    '5.8k vistas','hace 5 días',['redes','http']],
            ];
            foreach ($demo_content as $i => [$ico,$titulo,$canal,$dur,$tipo,$vistas,$fecha,$tags]):
                $tc = $tipos_cls[$tipo] ?? 'vt-video';
      ?>
      <div class="vid-card" data-tipo="<?= $tipo ?>" style="animation-delay:<?= $i*0.04 ?>s" onclick="openDemoModal('<?= htmlspecialchars($titulo,ENT_QUOTES) ?>','<?= htmlspecialchars($canal,ENT_QUOTES) ?>','<?= $ico ?>','<?= $tipo ?>')">
        <div class="vid-thumb">
          <div class="vid-thumb-placeholder"><?= $ico ?></div>
          <?php if ($dur !== '–'): ?><span class="vid-duration"><?= $dur ?></span><?php endif; ?>
          <span class="vid-type-badge <?= $tc ?>"><?= strtoupper($tipo) ?></span>
          <div class="vid-play-ov"><i class="fa fa-play"></i></div>
        </div>
        <div class="vid-body">
          <div class="vid-author-row">
            <div class="vid-av-ph"><?= mb_substr($canal,0,1) ?></div>
            <span class="vid-canal"><?= htmlspecialchars($canal) ?></span>
          </div>
          <div class="vid-title"><?= htmlspecialchars($titulo) ?></div>
          <div class="vid-meta">
            <span class="vid-meta-chip"><i class="fa fa-eye"></i> <?= $vistas ?></span>
            <span class="vid-meta-chip"><i class="fa fa-clock"></i> <?= $fecha ?></span>
          </div>
          <div class="vid-tags">
            <?php foreach ($tags as $t): ?><span class="vid-tag">#<?= $t ?></span><?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endforeach; } ?>
    </div><!-- /feedGrid -->

    <!-- Cursos recomendados -->
    <div class="sec-title" style="margin-top:36px;">
      <h2>🎓 Cursos recomendados</h2>
      <div class="sec-title-line"></div>
      <span class="sec-title-more" onclick="goSec('cursos')">Ver todos ›</span>
    </div>
    <div class="vid-grid vg-3">
      <?php foreach (array_slice($cursos, 0, 6) as $c):
          $prog    = (int)($prog_map[$c['id']]['progreso'] ?? 0);
          $niv     = $c['nivel'] ?? 'basico';
          $niv_cl  = match(strtolower($niv)) { 'avanzado','advanced'=>'cn-avanzado','intermedio','intermediate'=>'cn-intermedio', default=>'cn-basico' };
          $rat     = (float)($c['rating'] ?? 4.7);
          $subs    = (int)($c['total_subs'] ?? 0);
          $inst    = htmlspecialchars($c['instructor_nombre'] ?? ($c['instructor'] ?? ''));
      ?>
      <div class="curso-card" onclick="openCursoModal('<?= htmlspecialchars($c['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['icono']??'📚',ENT_QUOTES) ?>')">
        <div class="curso-thumb">
          <div class="curso-thumb-ico"><?= htmlspecialchars($c['icono'] ?? '📚') ?></div>
          <span class="curso-nivel-badge <?= $niv_cl ?>"><?= ucfirst($niv) ?></span>
        </div>
        <div class="curso-body">
          <div class="curso-cat"><?= strtoupper(htmlspecialchars($c['categoria'] ?? '')) ?></div>
          <div class="curso-title"><?= htmlspecialchars($c['titulo']) ?></div>
          <div class="curso-instructor"><div class="ci-av"><i class="fa fa-user fa-xs"></i></div><?= $inst ?></div>
          <div class="curso-rating">
            <div class="curso-stars"><?= str_repeat('★', (int)$rat) ?></div>
            <span class="curso-rating-n"><?= number_format($rat,1) ?> (<?= $subs ?>)</span>
          </div>
          <div class="curso-meta">
            <span class="curso-meta-item"><i class="fa fa-play-circle"></i> <?= $c['total_lecciones'] ?? '–' ?> lec.</span>
            <span class="curso-meta-item"><i class="fa fa-clock"></i> <?= htmlspecialchars($c['duracion'] ?? '') ?></span>
          </div>
          <?php if ($prog > 0): ?>
          <div class="curso-prog-wrap">
            <div class="curso-prog-hd"><span>Progreso</span><span><?= $prog ?>%</span></div>
            <div class="curso-prog-bar"><div class="curso-prog-fill" style="width:<?= $prog ?>%"></div></div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div><!-- /sec-principal -->


  <!-- ▓▓▓▓ SUSCRIPCIONES ▓▓▓▓ -->
  <div class="ad-section" id="sec-suscripciones">
    <div class="sec-title"><h2>📡 Mis Suscripciones</h2><div class="sec-title-line"></div></div>

    <div class="vid-grid" style="grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:14px;margin-bottom:32px;">
      <?php if (!empty($suscripciones)):
          foreach ($suscripciones as $s):
              $av = !empty($s['avatar']) ? htmlspecialchars($s['avatar']) : '';
      ?>
      <div class="canal-card">
        <?php if ($av && !preg_match('/[\p{Emoji}]/u', $av)): ?>
          <img src="<?= $av ?>" class="canal-av" alt="<?= htmlspecialchars($s['nombre']) ?>">
        <?php else: ?>
          <div class="canal-av-ph"><?= htmlspecialchars($s['avatar'] ?? '📺') ?></div>
        <?php endif; ?>
        <div class="canal-name"><?= htmlspecialchars($s['nombre']) ?><?php if ($s['verificado'] ?? 0): ?><span class="canal-verified"><i class="fa fa-circle-check"></i></span><?php endif; ?></div>
        <div class="canal-subs"><?= number_format($s['total_subs'] ?? 0) ?> subs</div>
        <button class="canal-btn suscrito"><i class="fa fa-check"></i> Suscrito</button>
      </div>
      <?php endforeach;
      else:
          foreach ($canales_recomendados as $s):
      ?>
      <div class="canal-card">
        <div class="canal-av-ph"><?= htmlspecialchars($s['avatar'] ?? '📺') ?></div>
        <div class="canal-name"><?= htmlspecialchars($s['nombre']) ?><?php if ($s['verificado'] ?? 0): ?><span class="canal-verified"><i class="fa fa-circle-check"></i></span><?php endif; ?></div>
        <div class="canal-subs"><?= number_format($s['total_subs'] ?? 0) ?> suscriptores</div>
        <button class="canal-btn suscrito"><i class="fa fa-check"></i> Suscrito</button>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <div class="sec-title"><h2>🆕 Contenido reciente</h2><div class="sec-title-line"></div></div>
    <div class="vid-grid vg-4">
      <?php
        $feed_subs = !empty($sub_content_bd) ? $sub_content_bd : null;
        if ($feed_subs):
            foreach ($feed_subs as $v):
                $tipo   = $v['tipo'] ?? 'video';
                $tc     = $tipos_cls[$tipo] ?? 'vt-video';
      ?>
      <div class="vid-card" onclick="openDemoModal('<?= htmlspecialchars($v['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($v['canal_nombre']??'',ENT_QUOTES) ?>','<?= htmlspecialchars($v['icono']??'🎬',ENT_QUOTES) ?>','<?= $tipo ?>')">
        <div class="vid-thumb">
          <?php if (!empty($v['thumbnail'])): ?><img src="<?= htmlspecialchars($v['thumbnail']) ?>" alt="" loading="lazy"><?php else: ?><div class="vid-thumb-placeholder"><?= htmlspecialchars($v['icono'] ?? '🎬') ?></div><?php endif; ?>
          <?php if (!empty($v['duracion'])): ?><span class="vid-duration"><?= htmlspecialchars($v['duracion']) ?></span><?php endif; ?>
          <span class="vid-type-badge <?= $tc ?>"><?= strtoupper($tipo) ?></span>
          <div class="vid-play-ov"><i class="fa fa-play"></i></div>
        </div>
        <div class="vid-body">
          <div class="vid-author-row"><div class="vid-av-ph"><?= mb_substr($v['canal_nombre']??'C',0,1) ?></div><span class="vid-canal"><?= htmlspecialchars($v['canal_nombre']??'') ?></span></div>
          <div class="vid-title"><?= htmlspecialchars($v['titulo']) ?></div>
          <div class="vid-meta"><span class="vid-meta-chip"><i class="fa fa-clock"></i> <?= !empty($v['fecha_publicacion']) ? date('d M',strtotime($v['fecha_publicacion'])) : '' ?></span></div>
        </div>
      </div>
      <?php endforeach;
        else:
            foreach ($sub_content_demo as [$ico,$tit,$canal,$dur,$tipo,$fecha]):
                $tc = $tipos_cls[$tipo] ?? 'vt-video';
      ?>
      <div class="vid-card" onclick="openDemoModal('<?= htmlspecialchars($tit,ENT_QUOTES) ?>','<?= htmlspecialchars($canal,ENT_QUOTES) ?>','<?= $ico ?>','<?= $tipo ?>')">
        <div class="vid-thumb">
          <div class="vid-thumb-placeholder"><?= $ico ?></div>
          <span class="vid-duration"><?= $dur ?></span>
          <span class="vid-type-badge vt-video">VIDEO</span>
          <div class="vid-play-ov"><i class="fa fa-play"></i></div>
        </div>
        <div class="vid-body">
          <div class="vid-author-row"><div class="vid-av-ph"><?= mb_substr($canal,0,1) ?></div><span class="vid-canal"><?= htmlspecialchars($canal) ?></span></div>
          <div class="vid-title"><?= htmlspecialchars($tit) ?></div>
          <div class="vid-meta"><span class="vid-meta-chip"><i class="fa fa-clock"></i> <?= $fecha ?></span></div>
        </div>
      </div>
      <?php endforeach; endif; ?>
    </div>
  </div><!-- /sec-suscripciones -->


  <!-- ▓▓▓▓ OBJETIVOS ▓▓▓▓ -->
  <div class="ad-section" id="sec-objetivos">
    <div class="sec-title"><h2>🎯 Objetivos y Retos</h2><div class="sec-title-line"></div>
      <button class="sec-title-more" onclick="openNuevoObjetivo()" style="background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);padding:6px 14px;border-radius:99px;font-size:.75rem;font-weight:700;"><i class="fa fa-plus"></i> Nuevo</button>
    </div>

    <div style="display:grid;grid-template-columns:1fr 340px;gap:24px;">
      <div>
        <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">🔥 En progreso</p>
        <?php foreach ($objetivos_activos as $obj):
            $db_id = isset($obj['id']) ? (int)$obj['id'] : 0;
        ?>
        <div class="obj-card">
          <div class="obj-check" onclick="toggleObj(<?= $db_id ?>, this)"></div>
          <div class="obj-body">
            <div class="obj-title"><?= htmlspecialchars($obj['titulo']) ?></div>
            <div class="obj-desc"><?= htmlspecialchars($obj['descripcion'] ?? '') ?></div>
            <div class="obj-meta">
              <?php if (!empty($obj['fecha_limite'])): ?>
              <span class="obj-deadline"><i class="fa fa-calendar"></i> <?= date('d M Y', strtotime($obj['fecha_limite'])) ?></span>
              <?php endif; ?>
              <?php if (!empty($obj['categoria'])): ?>
              <span class="obj-category"><?= htmlspecialchars($obj['categoria']) ?></span>
              <?php endif; ?>
            </div>
            <div class="obj-prog-bar"><div class="obj-prog-fill" style="width:<?= $obj['progreso'] ?? 0 ?>%"></div></div>
          </div>
        </div>
        <?php endforeach; ?>

        <p style="font-size:.72rem;font-weight:800;color:var(--green-lt);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;margin-top:20px;">✅ Completados</p>
        <?php foreach ($objetivos_completados as $obj): ?>
        <div class="obj-card" style="opacity:.6;">
          <div class="obj-check done"></div>
          <div class="obj-body">
            <div class="obj-title" style="text-decoration:line-through;color:var(--muted);"><?= htmlspecialchars($obj['titulo']) ?></div>
            <div class="obj-desc"><?= htmlspecialchars($obj['descripcion'] ?? '') ?></div>
            <div class="obj-meta"><span class="obj-category"><?= htmlspecialchars($obj['categoria'] ?? '') ?></span></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Calendario + Plan semanal -->
      <div>
        <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;">📅 Calendario</p>
        <div class="calendar-wrap" id="calendarWrap">
          <div class="cal-header">
            <span class="cal-title" id="calMonthYear"></span>
            <div class="cal-nav">
              <button class="cal-nav-btn" onclick="calNav(-1)"><i class="fa fa-chevron-left"></i></button>
              <button class="cal-nav-btn" onclick="calNav(1)"><i class="fa fa-chevron-right"></i></button>
            </div>
          </div>
          <div class="cal-days-header">
            <?php foreach (['Lu','Ma','Mi','Ju','Vi','Sá','Do'] as $d): ?><div class="cal-day-name"><?= $d ?></div><?php endforeach; ?>
          </div>
          <div class="cal-grid" id="calGrid"></div>
        </div>

        <div style="background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:16px;margin-top:14px;">
          <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:12px;">📅 Plan semanal</p>
          <?php foreach ($plan_semanal as [$dia,$act,$ico]): ?>
          <div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.05);">
            <span style="font-size:.65rem;font-weight:800;color:var(--dim);width:18px;"><?= htmlspecialchars($dia) ?></span>
            <span style="font-size:.75rem;"><?= htmlspecialchars($ico) ?></span>
            <span style="font-size:.78rem;color:var(--muted);"><?= htmlspecialchars($act) ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div><!-- /sec-objetivos -->


  <!-- ▓▓▓▓ CURSOS ▓▓▓▓ -->
  <div class="ad-section" id="sec-cursos">
    <div class="sec-title"><h2>🎓 Cursos MOOC / NOOC / SPOC</h2><div class="sec-title-line"></div></div>

    <div class="content-filters">
      <span class="cf-chip on" onclick="filterCursos('todo',this)">Todos</span>
      <span class="cf-chip" onclick="filterCursos('seguridad',this)"><i class="fa fa-shield"></i> Seguridad</span>
      <span class="cf-chip" onclick="filterCursos('desarrollo',this)"><i class="fa fa-code"></i> Desarrollo</span>
      <span class="cf-chip" onclick="filterCursos('ia',this)"><i class="fa fa-robot"></i> IA & ML</span>
      <span class="cf-chip" onclick="filterCursos('datos',this)"><i class="fa fa-database"></i> Datos</span>
      <span class="cf-chip" onclick="filterCursos('cloud',this)"><i class="fa fa-cloud"></i> Cloud</span>
      <span class="cf-chip" onclick="filterCursos('linux',this)"><i class="fa fa-terminal"></i> Linux</span>
      <span class="cf-chip" onclick="filterCursos('videojuegos',this)"><i class="fa fa-gamepad"></i> Videojuegos</span>
    </div>

    <!-- Mis cursos en progreso -->
    <?php if (!empty($mis_cursos_en_progreso)): ?>
    <div style="margin-bottom:28px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">📖 Mis cursos en progreso</p>
      <div class="vid-grid vg-3">
        <?php foreach (array_slice($mis_cursos_en_progreso, 0, 3) as $c):
            $prog   = (int)($c['_progreso'] ?? $prog_map[$c['id']]['progreso'] ?? 0);
            $parte  = $c['_parte'] ?? '1/3';
            $niv    = $c['nivel'] ?? 'basico';
            $niv_cl = match(strtolower($niv)) { 'avanzado'=>'cn-avanzado','intermedio'=>'cn-intermedio', default=>'cn-basico' };
            $inst   = htmlspecialchars($c['instructor_nombre'] ?? ($c['instructor'] ?? ''));
        ?>
        <div class="curso-card" onclick="openCursoModal('<?= htmlspecialchars($c['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['icono']??'📚',ENT_QUOTES) ?>')">
          <div class="curso-thumb">
            <div class="curso-thumb-ico"><?= htmlspecialchars($c['icono'] ?? '📚') ?></div>
            <span class="curso-nivel-badge <?= $niv_cl ?>"><?= ucfirst($niv) ?></span>
          </div>
          <div class="curso-body">
            <div class="curso-cat"><?= strtoupper(htmlspecialchars($c['categoria'] ?? '')) ?> · Parte <?= $parte ?></div>
            <div class="curso-title"><?= htmlspecialchars($c['titulo']) ?></div>
            <div class="curso-instructor"><div class="ci-av"><i class="fa fa-user fa-xs"></i></div><?= $inst ?></div>
            <div class="curso-meta">
              <span class="curso-meta-item"><i class="fa fa-play-circle"></i> <?= $c['total_lecciones'] ?? '–' ?> lec.</span>
              <span class="curso-meta-item"><i class="fa fa-clock"></i> <?= htmlspecialchars($c['duracion'] ?? '') ?></span>
            </div>
            <div class="curso-prog-wrap">
              <div class="curso-prog-hd"><span>Progreso</span><span style="color:var(--green-lt);font-weight:700;"><?= $prog ?>%</span></div>
              <div class="curso-prog-bar"><div class="curso-prog-fill" style="width:<?= $prog ?>%"></div></div>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <!-- Catálogo completo -->
    <p style="font-size:.72rem;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">📚 Catálogo completo</p>
    <div class="vid-grid vg-3" id="cursosGrid">
      <?php foreach ($cursos as $i => $c):
          $prog   = (int)($prog_map[$c['id']]['progreso'] ?? 0);
          $niv    = $c['nivel'] ?? 'basico';
          $niv_cl = match(strtolower($niv)) { 'avanzado'=>'cn-avanzado','intermedio'=>'cn-intermedio', default=>'cn-basico' };
          $rat    = (float)($c['rating'] ?? 4.7);
          $subs   = (int)($c['total_subs'] ?? 0);
          $inst   = htmlspecialchars($c['instructor_nombre'] ?? ($c['instructor'] ?? ''));
          $cat    = strtolower($c['categoria'] ?? '');
      ?>
      <div class="curso-card" data-cat="<?= $cat ?>" style="animation-delay:<?= $i*.04 ?>s" onclick="openCursoModal('<?= htmlspecialchars($c['titulo'],ENT_QUOTES) ?>','<?= htmlspecialchars($c['icono']??'📚',ENT_QUOTES) ?>')">
        <div class="curso-thumb">
          <div class="curso-thumb-ico"><?= htmlspecialchars($c['icono'] ?? '📚') ?></div>
          <span class="curso-nivel-badge <?= $niv_cl ?>"><?= ucfirst($niv) ?></span>
        </div>
        <div class="curso-body">
          <div class="curso-cat"><?= strtoupper($cat) ?></div>
          <div class="curso-title"><?= htmlspecialchars($c['titulo']) ?></div>
          <div class="curso-instructor"><div class="ci-av"><i class="fa fa-user fa-xs"></i></div><?= $inst ?></div>
          <div class="curso-rating">
            <div class="curso-stars"><?= str_repeat('★', min(5,(int)$rat)) ?></div>
            <span class="curso-rating-n"><?= number_format($rat,1) ?> (<?= $subs ?>)</span>
          </div>
          <div class="curso-meta">
            <span class="curso-meta-item"><i class="fa fa-play-circle"></i> <?= $c['total_lecciones'] ?? '–' ?> lec.</span>
            <span class="curso-meta-item"><i class="fa fa-clock"></i> <?= htmlspecialchars($c['duracion'] ?? '') ?></span>
          </div>
          <?php if ($prog > 0): ?>
          <div class="curso-prog-wrap">
            <div class="curso-prog-hd"><span>Progreso</span><span><?= $prog ?>%</span></div>
            <div class="curso-prog-bar"><div class="curso-prog-fill" style="width:<?= $prog ?>%"></div></div>
          </div>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div><!-- /sec-cursos -->


  <!-- ▓▓▓▓ HERRAMIENTAS ▓▓▓▓ -->
  <div class="ad-section" id="sec-herramientas">
    <div class="sec-title"><h2>🧰 Herramientas del Aprendiz</h2><div class="sec-title-line"></div></div>

    <?php
      $tool_sections = [
        ['💻 Editores de Código',           'editores',     'green'],
        ['⚙️ Compiladores & Runtimes',       'compiladores', 'gold'],
        ['🎬 Audiovisuales',                 'audiovisuales','purple'],
        ['📝 Word, Excel & Productividad',   'word_excel',   'blue'],
      ];
      $cc_map = ['green'=>'var(--green-dim)','gold'=>'var(--gold-dim)','purple'=>'var(--purple-dim)','blue'=>'var(--blue-dim)'];
      $cb_map = ['green'=>'rgba(40,166,128,.3)','gold'=>'rgba(218,165,32,.3)','purple'=>'rgba(139,92,246,.3)','blue'=>'rgba(59,130,246,.3)'];
      $ct_map = ['green'=>'var(--green-lt)','gold'=>'var(--gold-lt)','purple'=>'var(--purple-lt)','blue'=>'var(--blue-lt)'];

      foreach ($tool_sections as [$label,$key,$color]):
        $tools = $herramientas_data_bd[$key] ?? [];
        $cc = $cc_map[$color]; $cb = $cb_map[$color]; $ct = $ct_map[$color];
    ?>
    <div style="margin-bottom:28px;">
      <p style="font-size:.72rem;font-weight:800;color:<?= $ct ?>;text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;"><?= $label ?></p>
      <div class="tools-grid">
        <?php foreach ($tools as [$nm,$ico,$desc]): ?>
        <div class="tool-card">
          <div class="tool-ico"><?= htmlspecialchars($ico) ?></div>
          <div class="tool-name"><?= htmlspecialchars($nm) ?></div>
          <div class="tool-desc"><?= htmlspecialchars($desc) ?></div>
          <div class="tool-launch" style="background:<?= $cc ?>;border-color:<?= $cb ?>;color:<?= $ct ?>;"><i class="fa fa-external-link-alt fa-xs"></i> Abrir</div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endforeach; ?>

    <!-- Programadores Online -->
    <div style="margin-bottom:28px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--green-lt);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">🔢 Programadores Online</p>
      <div class="vid-grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px;">
        <?php foreach ($programadores_online as [$nm,$ico,$desc]): ?>
        <div class="tool-card" style="flex-direction:row;text-align:left;align-items:center;gap:12px;border-radius:var(--r-md);">
          <div class="tool-ico" style="font-size:1.5rem;flex-shrink:0;"><?= htmlspecialchars($ico) ?></div>
          <div>
            <div class="tool-name" style="margin-bottom:2px;"><?= htmlspecialchars($nm) ?></div>
            <div class="tool-desc"><?= htmlspecialchars($desc) ?></div>
          </div>
          <div class="tool-launch" style="margin-top:0;margin-left:auto;flex-shrink:0;"><i class="fa fa-play fa-xs"></i></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div><!-- /sec-herramientas -->


  <!-- ▓▓▓▓ MI CANAL ▓▓▓▓ -->
  <div class="ad-section" id="sec-canal">
    <div class="sec-title"><h2>📡 Mi Canal — Studio</h2><div class="sec-title-line"></div></div>

    <?php if (!$mi_canal && !$uid): ?>
    <div class="ad-empty">
      <div class="ad-empty-ico">📡</div>
      <p>Inicia sesión para acceder a tu canal y crear contenido.</p>
      <a href="login.php" class="ad-empty-btn"><i class="fa fa-sign-in-alt"></i> Iniciar sesión</a>
    </div>
    <?php else: ?>

    <div class="canal-studio">
      <div class="cs-header">
        <?php if ($mi_canal && !empty($mi_canal['avatar']) && !preg_match('/[\p{Emoji}]/u', $mi_canal['avatar'])): ?>
        <img src="<?= htmlspecialchars($mi_canal['avatar']) ?>" class="cs-av" alt="Canal">
        <?php else: ?><div class="cs-av-ph"><?= htmlspecialchars($mi_canal['avatar'] ?? '📺') ?></div><?php endif; ?>
        <div class="cs-info">
          <h3><?= htmlspecialchars($mi_canal['nombre'] ?? 'Mi Canal VIROX') ?></h3>
          <p><?= number_format($mi_canal['suscriptores'] ?? 0) ?> suscriptores · <?= $mi_canal['total_videos'] ?? 0 ?> videos</p>
        </div>
        <div style="margin-left:auto;display:flex;gap:8px;">
          <button class="cs-action-btn csa-secondary"><i class="fa fa-pen"></i> Editar canal</button>
          <button class="cs-action-btn csa-primary"><i class="fa fa-plus"></i> Subir contenido</button>
        </div>
      </div>

      <!-- Stats canal -->
      <div class="cs-stats-row">
        <?php
          $cs_stats = [
            ['👁','Vistas (30 días)', number_format($canal_stats['vistas_mes'] ?? 12847)],
            ['🎬','Videos (30 días)', $canal_stats['videos_mes'] ?? 8],
            ['🔔','Suscriptores',     number_format($mi_canal['suscriptores'] ?? 4231)],
            ['💰','Ingresos mes',     '$'.number_format($canal_stats['ingresos_mes'] ?? 0).' COP'],
          ];
          foreach ($cs_stats as [$ico,$lbl,$val]):
        ?>
        <div class="cs-stat">
          <div class="cs-stat-ico"><?= $ico ?></div>
          <div class="cs-stat-n"><?= $val ?></div>
          <div class="cs-stat-l"><?= $lbl ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Gráfico 7 días -->
      <div class="cs-chart">
        <div class="cs-chart-title">📊 Vistas últimos 7 días</div>
        <div class="cs-bars" id="csBars">
          <?php foreach ($barras_vistas as $bv): ?>
          <div class="cs-bar" style="height:<?= $bv ?>%" title="<?= $bv ?>% del máximo"></div>
          <?php endforeach; ?>
        </div>
        <div class="cs-bar-labels">
          <?php foreach (['Lu','Ma','Mi','Ju','Vi','Sá','Do'] as $d): ?>
          <div class="cs-bar-lbl"><?= $d ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Crear contenido -->
    <div style="margin-bottom:28px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">➕ Crear contenido</p>
      <div class="crear-grid">
        <?php foreach ($crear_tipos as [$ico,$lbl,$desc]): ?>
        <div class="crear-item" onclick="openCrearModal('<?= htmlspecialchars($lbl,ENT_QUOTES) ?>')">
          <div class="crear-ico"><?= htmlspecialchars($ico) ?></div>
          <div class="crear-label"><?= htmlspecialchars($lbl) ?></div>
          <div class="tool-desc"><?= htmlspecialchars($desc) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Videos publicados + Ingresos -->
    <div style="display:grid;grid-template-columns:1fr 300px;gap:20px;">
      <div>
        <p style="font-size:.72rem;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">🎬 Videos publicados</p>
        <?php foreach ($mis_videos as $v):
            $vistas_txt = is_numeric($v['vistas'] ?? '') ? number_format((int)$v['vistas']).' vistas' : ($v['vistas'] ?? '');
            $fecha_txt  = !empty($v['fecha_publicacion']) ? 'hace '.human_date($v['fecha_publicacion']) : '';
            $status_txt = ($v['publicado'] ?? 1) ? 'Publicado' : 'Borrador';
        ?>
        <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.05);cursor:pointer;">
          <div style="width:80px;height:50px;border-radius:var(--r-sm);background:var(--n700);display:flex;align-items:center;justify-content:center;font-size:1.5rem;flex-shrink:0;"><?= htmlspecialchars($v['icono'] ?? '🎬') ?></div>
          <div style="flex:1;min-width:0;">
            <p style="font-size:.85rem;font-weight:700;color:var(--txt);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($v['titulo']) ?></p>
            <p style="font-size:.7rem;color:var(--muted);"><?= $vistas_txt ?> · <?= $fecha_txt ?></p>
          </div>
          <span style="font-size:.68rem;padding:2px 8px;background:var(--green-dim);color:var(--green-lt);border-radius:99px;"><?= $status_txt ?></span>
          <button style="width:28px;height:28px;border-radius:50%;background:rgba(255,255,255,.06);color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:.75rem;cursor:pointer;">⋮</button>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Ingresos + Playlist -->
      <div>
        <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">💰 Ingresos</p>
        <div class="ingresos-grid" style="grid-template-columns:1fr 1fr;">
          <div class="ingreso-card"><div class="ic-ico">💰</div><div class="ic-num">$<?= number_format($canal_stats['ingresos_mes'] ?? 0) ?></div><div class="ic-lbl">Este mes</div></div>
          <div class="ingreso-card"><div class="ic-ico">📈</div><div class="ic-num">$0</div><div class="ic-lbl">Total</div></div>
          <div class="ingreso-card"><div class="ic-ico">👁</div><div class="ic-num">0</div><div class="ic-lbl">Vistas patrocinadas</div></div>
          <div class="ingreso-card"><div class="ic-ico">🎯</div><div class="ic-num">0%</div><div class="ic-lbl">CTR anuncios</div></div>
        </div>

        <div class="playlist-panel" style="margin-top:16px;position:static;max-height:280px;">
          <div class="pl-header">
            <span class="pl-title">Mis playlists</span>
            <button style="padding:4px 10px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);border-radius:99px;font-size:.68rem;font-weight:700;cursor:pointer;"><i class="fa fa-plus"></i></button>
          </div>
          <div class="pl-list">
            <?php foreach ($playlists as $pl): ?>
            <div class="pl-item <?= ($pl['is_playing'] ?? false) ? 'playing' : '' ?>">
              <div style="font-size:.75rem;color:var(--muted);width:16px;text-align:center;">▶</div>
              <div class="pl-item-info">
                <div class="pl-item-title"><?= htmlspecialchars($pl['titulo']) ?></div>
                <div class="pl-item-dur"><?= ($pl['total'] ?? 0) ?> videos</div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Configuración del canal -->
    <div style="margin-top:28px;">
      <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">⚙️ Configuración del Canal</p>
      <div class="config-section">
        <div class="config-title"><i class="fa fa-eye"></i> Visibilidad y Privacidad</div>
        <?php foreach ($canal_configs as [$nm,$desc,$ch]): ?>
        <div class="config-row">
          <div class="config-row-info"><strong><?= htmlspecialchars($nm) ?></strong><span><?= htmlspecialchars($desc) ?></span></div>
          <label class="toggle"><input type="checkbox" <?= htmlspecialchars($ch) ?>><span class="toggle-sl"></span></label>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div><!-- /sec-canal -->


  <!-- ▓▓▓▓ COMUNIDAD ▓▓▓▓ -->
  <div class="ad-section" id="sec-comunidad">
    <div class="sec-title"><h2>👥 Comunidad VIROX</h2><div class="sec-title-line"></div>
      <button class="sec-title-more" style="background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);padding:6px 14px;border-radius:99px;font-size:.75rem;font-weight:700;">
        <i class="fa fa-pen"></i> Publicar
      </button>
    </div>

    <div style="display:grid;grid-template-columns:1fr 300px;gap:24px;">
      <div>
        <?php foreach ($publicaciones_feed as $pub):
            $autor   = htmlspecialchars(trim(($pub['autor_nombre'] ?? '') . ' ' . ($pub['autor_apellido'] ?? '')));
            if (empty(trim($autor))) $autor = 'Comunidad VIROX';
            $inicial = mb_substr($autor, 0, 1);
            $tags_arr = array_filter(explode(',', $pub['tags'] ?? ''));
            $tiempo  = !empty($pub['fecha_pub']) ? time_ago($pub['fecha_pub']) : '';
        ?>
        <div class="pub-card">
          <div class="pub-header">
            <?php if (!empty($pub['autor_avatar'])): ?>
              <img src="<?= htmlspecialchars($pub['autor_avatar']) ?>" class="pub-av" alt="<?= $autor ?>">
            <?php else: ?>
              <div class="pub-av" style="display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:700;color:var(--green-lt);background:var(--green-dim);"><?= $inicial ?></div>
            <?php endif; ?>
            <div>
              <div class="pub-autor"><?= $autor ?></div>
              <div class="pub-fecha"><?= $tiempo ?></div>
            </div>
          </div>
          <div class="pub-title"><?= htmlspecialchars($pub['titulo']) ?></div>
          <div class="pub-excerpt"><?= htmlspecialchars($pub['resumen'] ?? '') ?></div>
          <?php if (!empty($tags_arr)): ?>
          <div class="pub-tags">
            <?php foreach ($tags_arr as $t): ?>
            <span class="pub-tag">#<?= htmlspecialchars(trim($t)) ?></span>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div style="display:flex;gap:12px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.05);">
            <span style="font-size:.72rem;color:var(--muted);cursor:pointer;display:flex;align-items:center;gap:4px;transition:color .2s;" onmouseover="this.style.color='var(--green-lt)'" onmouseout="this.style.color='var(--muted)'"><i class="fa fa-heart"></i> Me gusta</span>
            <span style="font-size:.72rem;color:var(--muted);cursor:pointer;display:flex;align-items:center;gap:4px;transition:color .2s;" onmouseover="this.style.color='var(--green-lt)'" onmouseout="this.style.color='var(--muted)'"><i class="fa fa-comment"></i> Responder</span>
            <span style="font-size:.72rem;color:var(--muted);cursor:pointer;display:flex;align-items:center;gap:4px;transition:color .2s;" onmouseover="this.style.color='var(--green-lt)'" onmouseout="this.style.color='var(--muted)'"><i class="fa fa-share"></i> Compartir</span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Panel lateral comunidad -->
      <div>
        <div style="background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:18px;margin-bottom:14px;">
          <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:12px;">🌟 Canales recomendados</p>
          <?php
            $top3 = array_slice($canales_recomendados, 0, 3);
            foreach ($top3 as $ca):
          ?>
          <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.05);">
            <div style="width:36px;height:36px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:1rem;"><?= htmlspecialchars($ca['avatar'] ?? '📺') ?></div>
            <div style="flex:1;">
              <p style="font-size:.82rem;font-weight:700;color:var(--txt);"><?= htmlspecialchars($ca['nombre']) ?></p>
              <p style="font-size:.68rem;color:var(--muted);"><?= number_format($ca['total_subs'] ?? 0) ?> subs</p>
            </div>
            <button class="canal-btn" style="padding:4px 12px;font-size:.68rem;">+ Seguir</button>
          </div>
          <?php endforeach; ?>
        </div>

        <div style="background:var(--n800);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-xl);padding:18px;">
          <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:12px;">📌 Tendencias</p>
          <?php foreach ($tags_tendencias as $tag): ?>
          <div style="display:inline-block;margin:4px;padding:4px 12px;background:var(--n700);border:1px solid rgba(255,255,255,.07);border-radius:99px;font-size:.72rem;color:var(--muted);cursor:pointer;transition:all .2s;" onmouseover="this.style.background='var(--green-dim)';this.style.color='var(--green-lt)'" onmouseout="this.style.background='var(--n700)';this.style.color='var(--muted)'"><?= htmlspecialchars($tag) ?></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div><!-- /sec-comunidad -->

</main>
</div><!-- /ad-wrap -->


<!-- ══ MODAL ══ -->
<div class="ad-modal" id="adModal">
  <div class="ad-modal-box">
    <div class="ad-modal-close">
      <button class="amc-btn" onclick="closeAdModal()"><i class="fa fa-times"></i></button>
    </div>
    <div class="ad-modal-body" id="adModalBody"></div>
  </div>
</div>

<?php
// ── Helpers PHP ─────────────────────────────────────────────────────
function time_ago(string $fecha): string {
    $diff = time() - strtotime($fecha);
    if ($diff < 3600)      return 'hace ' . floor($diff/60)   . ' min';
    if ($diff < 86400)     return 'hace ' . floor($diff/3600) . 'h';
    if ($diff < 604800)    return 'hace ' . floor($diff/86400) . ' días';
    if ($diff < 2592000)   return 'hace ' . floor($diff/604800) . ' sem.';
    return date('d M Y', strtotime($fecha));
}
function human_date(string $fecha): string {
    $diff = time() - strtotime($fecha);
    if ($diff < 86400)   return floor($diff/3600).'h';
    if ($diff < 604800)  return floor($diff/86400).' días';
    return floor($diff/604800).' sem.';
}
?>

<script>
/* ══ NAVEGACIÓN ══ */
const SECS = ['principal','suscripciones','objetivos','cursos','herramientas','canal','comunidad'];
function goSec(id, tabBtn){
  SECS.forEach(s => {
    document.getElementById('sec-'+s)?.classList.remove('on');
    document.querySelector(`.sb-item[onclick*="${s}"]`)?.classList.remove('active');
  });
  document.getElementById('sec-'+id)?.classList.add('on');
  document.querySelector(`.sb-item[onclick*="${id}"]`)?.classList.add('active');
  if(tabBtn){
    document.querySelectorAll('.tb-tab').forEach(t => t.classList.remove('on'));
    tabBtn.classList.add('on');
  }
  document.querySelector('.ad-content')?.scrollTo({top:0,behavior:'smooth'});
}

/* ══ SIDEBAR TOGGLE ══ */
function toggleSidebar(){
  const sb = document.getElementById('adSidebar');
  sb.classList.toggle('expanded');
  if(window.innerWidth < 768) sb.classList.toggle('mobile-open');
}

/* ══ FILTROS ══ */
function filterContent(tipo, el){
  document.querySelectorAll('.content-filters .cf-chip').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  document.querySelectorAll('#feedGrid .vid-card').forEach(card => {
    card.style.display = (tipo==='todo' || card.dataset.tipo===tipo) ? '' : 'none';
  });
}
function filterCursos(cat, el){
  document.querySelectorAll('#sec-cursos .content-filters .cf-chip').forEach(c => c.classList.remove('on'));
  el.classList.add('on');
  document.querySelectorAll('#cursosGrid .curso-card').forEach(card => {
    card.style.display = (cat==='todo' || card.dataset.cat===cat) ? '' : 'none';
  });
}

/* ══ BÚSQUEDA GLOBAL ══ */
document.getElementById('globalSearch').addEventListener('keydown', function(e){
  if(e.key==='Enter'){
    const q = this.value.toLowerCase();
    if(!q) return;
    document.querySelectorAll('.vid-card').forEach(c => {
      c.style.display = (c.querySelector('.vid-title')?.textContent?.toLowerCase()||'').includes(q) ? '' : 'none';
    });
    document.querySelectorAll('.curso-card').forEach(c => {
      c.style.display = (c.querySelector('.curso-title')?.textContent?.toLowerCase()||'').includes(q) ? '' : 'none';
    });
  }
});

/* ══ MODALES ══ */
function openDemoModal(titulo, canal, ico, tipo){
  const tipos = {video:'🎬 Video',podcast:'🎙 Podcast',infografia:'📊 Infografía',audio:'🎧 Audio',presentacion:'📑 Presentación'};
  document.getElementById('adModalBody').innerHTML = `
    <div style="padding-top:4px;">
      <div style="width:100%;aspect-ratio:16/9;background:linear-gradient(135deg,#020817,#0c1526);border-radius:var(--r-lg);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;margin-bottom:20px;cursor:pointer;border:1px solid rgba(40,166,128,.2);" onclick="this.innerHTML='<div style=\\'width:100%;height:100%;display:flex;align-items:center;justify-content:center;font-size:4rem;\\'>' + ico + '</div>'">
        <i class="fa fa-play" style="font-size:3.5rem;color:var(--green);filter:drop-shadow(0 0 20px rgba(40,166,128,.5));"></i>
        <p style="font-size:.85rem;color:var(--muted);">Clic para reproducir — ${tipos[tipo]||'Contenido'}</p>
      </div>
      <div style="margin-bottom:16px;">
        <h2 style="font-size:1.1rem;font-weight:800;color:var(--txt);margin-bottom:8px;">${titulo}</h2>
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:36px;height:36px;border-radius:50%;background:var(--green-dim);border:2px solid var(--green);display:flex;align-items:center;justify-content:center;font-size:.9rem;">${ico}</div>
            <div><p style="font-size:.85rem;font-weight:700;color:var(--txt);">${canal}</p><p style="font-size:.7rem;color:var(--muted);">Canal VIROX</p></div>
          </div>
          <div style="display:flex;gap:8px;">
            <button onclick="this.classList.toggle('liked');this.style.color=this.classList.contains('liked')?'var(--green-lt)':'var(--muted)'" style="padding:8px 16px;border-radius:99px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.78rem;font-weight:600;cursor:pointer;"><i class="fa fa-thumbs-up"></i> Me gusta</button>
            <button style="padding:8px 16px;border-radius:99px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);color:var(--muted);font-size:.78rem;font-weight:600;cursor:pointer;"><i class="fa fa-share"></i> Compartir</button>
            <button style="padding:8px 16px;border-radius:99px;background:var(--green);color:#fff;font-size:.78rem;font-weight:700;cursor:pointer;"><i class="fa fa-rss"></i> Suscribirse</button>
          </div>
        </div>
      </div>
      <div style="border-top:1px solid rgba(255,255,255,.07);padding-top:16px;">
        <p style="font-size:.78rem;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:1.5px;margin-bottom:14px;">💬 Comentarios</p>
        <div style="display:flex;gap:10px;margin-bottom:16px;">
          <div style="width:32px;height:32px;border-radius:50%;background:var(--green-dim);flex-shrink:0;"></div>
          <input placeholder="Añade un comentario..." style="flex:1;padding:9px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.85rem;outline:none;">
        </div>
        <div style="font-size:.82rem;color:var(--dim);text-align:center;padding:16px 0;">Sé el primero en comentar este contenido.</div>
      </div>
    </div>`;
  document.getElementById('adModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function openCursoModal(titulo, ico){
  document.getElementById('adModalBody').innerHTML = `
    <div style="padding-top:4px;">
      <div style="background:linear-gradient(135deg,#0a1f3d,#0d2a1a);border-radius:var(--r-lg);padding:32px;text-align:center;margin-bottom:24px;border:1px solid rgba(40,166,128,.2);">
        <div style="font-size:4rem;margin-bottom:12px;">${ico}</div>
        <h2 style="font-family:var(--font-d);font-size:1.2rem;font-weight:900;color:var(--txt);letter-spacing:1px;margin-bottom:8px;">${titulo}</h2>
        <p style="font-size:.85rem;color:var(--muted);">Curso completo con materiales interactivos, videos y certificación.</p>
      </div>
      <p style="font-size:.72rem;font-weight:800;color:var(--gold);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;">📚 Módulos del curso</p>
      ${['Introducción y fundamentos','Conceptos intermedios y práctica','Proyectos avanzados','Evaluación y certificado'].map((m,i) => `
        <div style="display:flex;align-items:center;gap:12px;padding:12px 14px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);margin-bottom:8px;cursor:pointer;transition:border-color .2s;" onmouseover="this.style.borderColor='rgba(40,166,128,.3)'" onmouseout="this.style.borderColor='rgba(255,255,255,.06)'">
          <div style="width:28px;height:28px;border-radius:50%;background:${i===0?'var(--green)':'rgba(255,255,255,.08)'};display:flex;align-items:center;justify-content:center;font-size:.75rem;font-weight:700;color:${i===0?'#fff':'var(--dim)'};">${i+1}</div>
          <div style="flex:1;"><p style="font-size:.85rem;font-weight:700;color:var(--txt);">${m}</p><p style="font-size:.7rem;color:var(--muted);">8-12 lecciones · ~2-3 horas</p></div>
          <i class="fa fa-${i===0?'play-circle':'lock'}" style="color:${i===0?'var(--green-lt)':'var(--dim)'};"></i>
        </div>`).join('')}
      <div style="margin-top:20px;display:flex;gap:10px;">
        <button style="flex:1;padding:13px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.9rem;cursor:pointer;border:none;font-family:var(--font-b);" onmouseover="this.style.background='var(--green-lt)'" onmouseout="this.style.background='var(--green)'">
          <i class="fa fa-play"></i> Iniciar curso gratis
        </button>
        <a href="servicios.php" style="flex:1;padding:13px;background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);border-radius:var(--r-md);font-weight:800;font-size:.9rem;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
          <i class="fa fa-certificate"></i> Ver planes y certificación
        </a>
      </div>
    </div>`;
  document.getElementById('adModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function openCrearModal(tipo){
  document.getElementById('adModalBody').innerHTML = `
    <div style="padding:20px 0;">
      <h2 style="font-family:var(--font-d);font-size:1rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:20px;">Subir ${tipo}</h2>
      <div style="border:2px dashed rgba(40,166,128,.3);border-radius:var(--r-xl);padding:40px;text-align:center;cursor:pointer;background:rgba(40,166,128,.04);" onmouseover="this.style.background='rgba(40,166,128,.08)'" onmouseout="this.style.background='rgba(40,166,128,.04)'">
        <i class="fa fa-cloud-upload-alt" style="font-size:3rem;color:var(--green);margin-bottom:16px;display:block;"></i>
        <p style="font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:6px;">Arrastra tu ${tipo.toLowerCase()} aquí</p>
        <p style="font-size:.8rem;color:var(--muted);">o haz clic para seleccionar un archivo</p>
      </div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:20px;">
        <div><label style="font-size:.72rem;font-weight:700;color:var(--muted);display:block;margin-bottom:5px;">TÍTULO</label><input placeholder="Título del contenido" style="width:100%;padding:10px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.85rem;outline:none;"></div>
        <div><label style="font-size:.72rem;font-weight:700;color:var(--muted);display:block;margin-bottom:5px;">CATEGORÍA</label><select style="width:100%;padding:10px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.85rem;outline:none;"><option>Seleccionar...</option><option>Programación</option><option>Ciberseguridad</option><option>Bases de Datos</option><option>IA & ML</option><option>Redes</option></select></div>
      </div>
      <div style="margin-top:12px;"><label style="font-size:.72rem;font-weight:700;color:var(--muted);display:block;margin-bottom:5px;">DESCRIPCIÓN</label><textarea rows="3" placeholder="Describe tu contenido..." style="width:100%;padding:10px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.85rem;outline:none;resize:vertical;"></textarea></div>
      <button style="width:100%;margin-top:16px;padding:13px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.9rem;cursor:pointer;border:none;font-family:var(--font-b);">
        <i class="fa fa-upload"></i> Publicar ${tipo}
      </button>
    </div>`;
  document.getElementById('adModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeAdModal(){ document.getElementById('adModal').classList.remove('open'); document.body.style.overflow=''; }
document.getElementById('adModal').addEventListener('click', function(e){ if(e.target===this) closeAdModal(); });
document.addEventListener('keydown', e => { if(e.key==='Escape') closeAdModal(); });

/* ══ CALENDARIO ══ */
let calYear = new Date().getFullYear(), calMonth = new Date().getMonth();
const calEventDays = [3,8,12,15,22,28];
function renderCalendar(){
  const mn=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  document.getElementById('calMonthYear').textContent = mn[calMonth]+' '+calYear;
  const firstDay=new Date(calYear,calMonth,1).getDay(), offset=firstDay===0?6:firstDay-1;
  const dim=new Date(calYear,calMonth+1,0).getDate(), today=new Date();
  const grid=document.getElementById('calGrid'); grid.innerHTML='';
  const prevDays=new Date(calYear,calMonth,0).getDate();
  for(let i=offset;i>0;i--){ const d=document.createElement('div'); d.className='cal-day other-month'; d.textContent=prevDays-i+1; grid.appendChild(d); }
  for(let d=1;d<=dim;d++){
    const el=document.createElement('div'); el.className='cal-day'; el.textContent=d;
    if(d===today.getDate()&&calMonth===today.getMonth()&&calYear===today.getFullYear()) el.classList.add('today');
    if(calEventDays.includes(d)) el.classList.add('has-event');
    el.onclick=()=>el.classList.toggle('today'); grid.appendChild(el);
  }
  const rem=(offset+dim)%7===0?0:7-((offset+dim)%7);
  for(let d=1;d<=rem;d++){ const el=document.createElement('div'); el.className='cal-day other-month'; el.textContent=d; grid.appendChild(el); }
}
function calNav(dir){ calMonth+=dir; if(calMonth>11){calMonth=0;calYear++;} if(calMonth<0){calMonth=11;calYear--;} renderCalendar(); }
renderCalendar();

/* ══ TOGGLE OBJETIVOS ══ */
function toggleObj(id, el){
  el.classList.toggle('done');
  fetch('api/objetivo_toggle.php',{method:'POST',body:JSON.stringify({id}),headers:{'Content-Type':'application/json'}}).catch(()=>{});
}

/* ══ REVEAL ANIMATIONS ══ */
const revObs = new IntersectionObserver(entries => {
  entries.forEach(e => { if(e.isIntersecting){ e.target.style.opacity='1'; e.target.style.transform='translateY(0)'; }});
},{ threshold:0.06 });
document.querySelectorAll('.vid-card,.curso-card,.canal-card,.tool-card,.obj-card,.pub-card').forEach((c,i)=>{
  c.style.opacity='0'; c.style.transform='translateY(16px)';
  c.style.transition=`opacity .4s ease ${i*0.03}s, transform .4s ease ${i*0.03}s`;
  revObs.observe(c);
});

/* ══ INIT ══ */
window.addEventListener('load', () => {
  const sec = new URLSearchParams(location.search).get('sec') || 'principal';
  if(sec!=='principal') goSec(sec);
});

function loadMore(){ console.log('Cargar más contenido desde BD'); }
function openNuevoObjetivo(){ openCrearModal('Objetivo'); }
</script>
</body>
</html>