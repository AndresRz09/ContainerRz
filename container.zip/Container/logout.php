<?php
include 'conexion.php';
session_start();

// ── Capturar datos del usuario antes de destruir la sesión ──────────────────
$nombre = htmlspecialchars($_SESSION['user_name'] ?? 'Usuario');
$avatar = htmlspecialchars($_SESSION['avatar']    ?? '');
$rol    = htmlspecialchars($_SESSION['rol']        ?? '');

// ── Registrar cierre de sesión en log ───────────────────────────────────────
if (isset($_SESSION['user_id']) && isset($conexion)) {
    $uid = (int)$_SESSION['user_id'];

    $lg = $conexion->prepare(
        "INSERT INTO log_accesos (usuario_id, accion, ip, agente)
         VALUES (?, 'logout', ?, ?)"
    );
    if ($lg) {
        $ip    = $_SERVER['REMOTE_ADDR']     ?? '';
        $agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $lg->bind_param("iss", $uid, $ip, $agent);
        $lg->execute();
        $lg->close();
    }

    // Registrar en actividad_usuario
    $act = $conexion->prepare(
        "INSERT INTO actividad_usuario (usuario_id, tipo, descripcion) VALUES (?,'sesion','Cerró sesión')"
    );
    if ($act) { $act->bind_param("i", $uid); $act->execute(); $act->close(); }
}

// ── Destruir sesión completamente ────────────────────────────────────────────
$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $p["path"], $p["domain"], $p["secure"], $p["httponly"]);
}
session_destroy();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Hasta pronto — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --gold:#DAA520;--green:#28A680;--green-lt:#35d4a8;
      --n900:#020817;--n800:#0c1526;--n700:#111827;
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
    }
    *{margin:0;padding:0;box-sizing:border-box;}
    body{
      font-family:var(--font-b);background:var(--n900);color:var(--txt);
      height:100vh;overflow:hidden;
      display:flex;align-items:center;justify-content:center;
    }

    /* ── Fondo con partículas ── */
    .bye-bg{
      position:fixed;inset:0;z-index:0;
      background:radial-gradient(ellipse 80% 70% at 50% 50%,#071529 0%,var(--n900) 75%);
    }
    .bye-grid{
      position:fixed;inset:0;z-index:0;
      background-image:
        linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),
        linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);
      background-size:52px 52px;
      animation:gridSlide 20s linear infinite;
    }
    @keyframes gridSlide{from{background-position:0 0}to{background-position:52px 52px}}

    /* ── Orbs ── */
    .orb{position:fixed;border-radius:50%;filter:blur(90px);pointer-events:none;z-index:0;}
    .orb-1{width:600px;height:600px;background:radial-gradient(circle,rgba(40,166,128,.15),transparent 70%);
           top:-150px;left:-150px;animation:orbF 10s ease-in-out infinite;}
    .orb-2{width:450px;height:450px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);
           bottom:-100px;right:-100px;animation:orbF 13s ease-in-out infinite reverse;}
    @keyframes orbF{0%,100%{transform:translate(0,0)}50%{transform:translate(40px,-40px)}}

    /* ── Ventana principal ── */
    .bye-window{
      position:relative;z-index:10;
      width:min(520px,94vw);
      background:var(--n800);
      border:1px solid rgba(40,166,128,.25);
      border-radius:24px;
      box-shadow:0 32px 80px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.04);
      overflow:hidden;
      animation:winIn .5s cubic-bezier(.22,.68,0,1.3) both;
    }
    @keyframes winIn{from{opacity:0;transform:scale(.8) translateY(40px)}to{opacity:1;transform:none}}

    /* Barra de título estilo OS */
    .bye-titlebar{
      display:flex;align-items:center;
      padding:14px 20px;
      background:rgba(255,255,255,.04);
      border-bottom:1px solid rgba(255,255,255,.07);
      gap:10px;
    }
    .wm-dots{display:flex;gap:7px;}
    .wm-dot{width:13px;height:13px;border-radius:50%;}
    .wm-dot-r{background:#ff5f57;}
    .wm-dot-y{background:#febc2e;}
    .wm-dot-g{background:#28c840;}
    .wm-title{
      flex:1;text-align:center;
      font-family:var(--font-d);font-size:.72rem;font-weight:700;
      color:var(--dim);letter-spacing:2px;text-transform:uppercase;
      margin-right:38px; /* balance visual */
    }

    /* Cuerpo */
    .bye-body{
      padding:40px 40px 36px;
      text-align:center;
    }

    /* Avatar con ring animado */
    .bye-avatar-wrap{
      position:relative;width:100px;height:100px;margin:0 auto 24px;
    }
    .bye-avatar-ring{
      position:absolute;inset:-6px;border-radius:50%;
      border:2px solid transparent;
      background:linear-gradient(135deg,var(--green),var(--gold)) border-box;
      -webkit-mask:linear-gradient(#fff 0 0) padding-box,linear-gradient(#fff 0 0);
      -webkit-mask-composite:destination-out;
      mask-composite:exclude;
      animation:ringPulse 2s ease-in-out infinite;
    }
    @keyframes ringPulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.5;transform:scale(1.07)}}
    .bye-avatar-img{
      width:100px;height:100px;border-radius:50%;object-fit:cover;
      background:var(--n700);display:flex;align-items:center;justify-content:center;
      font-size:2.6rem;position:relative;z-index:1;
    }
    .bye-avatar-img img{width:100%;height:100%;object-fit:cover;border-radius:50%;}

    /* Badge de check */
    .bye-check{
      position:absolute;bottom:0;right:0;z-index:2;
      width:28px;height:28px;border-radius:50%;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      border:2.5px solid var(--n800);
      display:flex;align-items:center;justify-content:center;
      font-size:.8rem;color:#fff;
      animation:checkBounce .6s .3s cubic-bezier(.22,.68,0,1.6) both;
    }
    @keyframes checkBounce{from{transform:scale(0)}to{transform:scale(1)}}

    /* Texto */
    .bye-greeting{
      font-size:.8rem;font-weight:700;color:var(--green-lt);
      text-transform:uppercase;letter-spacing:2.5px;margin-bottom:10px;
    }
    .bye-name{
      font-family:var(--font-d);font-size:1.7rem;font-weight:900;
      color:var(--txt);letter-spacing:2px;margin-bottom:6px;
      line-height:1.2;
    }
    .bye-name span{color:var(--gold);}
    .bye-rol{
      display:inline-block;padding:4px 16px;
      background:rgba(40,166,128,.12);border:1px solid rgba(40,166,128,.3);
      border-radius:99px;font-size:.75rem;font-weight:700;
      color:var(--green-lt);letter-spacing:1px;text-transform:uppercase;
      margin-bottom:22px;
    }

    /* Mensaje principal */
    .bye-msg{
      font-size:1rem;color:var(--muted);line-height:1.8;margin-bottom:8px;
    }
    .bye-msg strong{color:var(--txt);}

    /* Quote decorativa */
    .bye-quote{
      margin:20px 0 28px;
      padding:14px 20px;
      background:rgba(218,165,32,.07);
      border-left:3px solid var(--gold);
      border-radius:0 10px 10px 0;
      font-size:.85rem;color:var(--muted);
      font-style:italic;text-align:left;line-height:1.6;
    }
    .bye-quote strong{color:var(--gold);font-style:normal;}

    /* Timer bar */
    .bye-timer-bar{
      height:3px;background:rgba(255,255,255,.08);
      border-radius:99px;overflow:hidden;margin-bottom:24px;
    }
    .bye-timer-fill{
      height:100%;width:100%;
      background:linear-gradient(to right,var(--green),var(--gold));
      border-radius:99px;
      animation:drain <?= /* seconds */ 5 ?>s linear forwards;
      transform-origin:left;
    }
    @keyframes drain{from{width:100%}to{width:0%}}

    /* Botones */
    .bye-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;}
    .bye-btn-login{
      padding:12px 28px;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      border:none;border-radius:14px;color:#fff;
      font-family:var(--font-b);font-size:.9rem;font-weight:700;
      cursor:pointer;transition:all .2s;
      box-shadow:0 4px 20px rgba(40,166,128,.4);
      text-decoration:none;display:inline-flex;align-items:center;gap:8px;
    }
    .bye-btn-login:hover{transform:translateY(-2px);box-shadow:0 8px 28px rgba(40,166,128,.5);}
    .bye-btn-home{
      padding:12px 24px;
      background:rgba(255,255,255,.06);
      border:1px solid rgba(255,255,255,.1);
      border-radius:14px;color:var(--muted);
      font-family:var(--font-b);font-size:.9rem;font-weight:600;
      cursor:pointer;transition:all .2s;
      text-decoration:none;display:inline-flex;align-items:center;gap:8px;
    }
    .bye-btn-home:hover{background:rgba(255,255,255,.1);color:var(--txt);}

    /* Contador numérico */
    .bye-countdown{
      font-size:.72rem;color:var(--dim);margin-top:14px;
    }
    .bye-countdown span{color:var(--green-lt);font-weight:700;}
  </style>
</head>
<body>

<div class="bye-bg"></div>
<div class="bye-grid"></div>
<div class="orb orb-1"></div>
<div class="orb orb-2"></div>

<!-- ══ VENTANA DE DESPEDIDA ══════════════════════════════════════════════ -->
<div class="bye-window" id="byeWindow">

  <!-- Barra de título estilo sistema operativo -->
  <div class="bye-titlebar">
    <div class="wm-dots">
      <div class="wm-dot wm-dot-r"></div>
      <div class="wm-dot wm-dot-y"></div>
      <div class="wm-dot wm-dot-g"></div>
    </div>
    <div class="wm-title">⬡ ContainerRz · Sesión cerrada</div>
  </div>

  <!-- Cuerpo -->
  <div class="bye-body">

    <!-- Avatar -->
    <div class="bye-avatar-wrap">
      <div class="bye-avatar-ring"></div>
      <div class="bye-avatar-img">
        <?php if ($avatar && file_exists($avatar)): ?>
          <img src="<?= $avatar ?>" alt="Avatar">
        <?php else: ?>
          👤
        <?php endif; ?>
      </div>
      <div class="bye-check"><i class="fa fa-check"></i></div>
    </div>

    <!-- Texto -->
    <div class="bye-greeting">Hasta pronto</div>
    <div class="bye-name">
      <?php
        $partes = explode(' ', $nombre);
        echo '<span>' . htmlspecialchars($partes[0]) . '</span>';
        if (!empty($partes[1])) echo ' ' . htmlspecialchars($partes[1]);
      ?>
    </div>
    <?php if ($rol): ?>
    <div class="bye-rol"><?= $rol ?></div>
    <?php endif; ?>

    <p class="bye-msg">
      Gracias por usar <strong>ContainerRz</strong>.<br>
      Tu sesión ha sido cerrada de forma segura.
    </p>

    <div class="bye-quote">
      <strong>"</strong> La tecnología es solo una herramienta.
      Lo que importa es cómo la usas para construir el futuro.
      <strong>— Team VIROX"</strong>
    </div>

    <!-- Barra de cuenta regresiva -->
    <div class="bye-timer-bar">
      <div class="bye-timer-fill"></div>
    </div>

    <!-- Botones -->
    <div class="bye-btns">
      <a href="login.php" class="bye-btn-login">
        <i class="fa fa-sign-in-alt"></i> Volver a ingresar
      </a>
      <a href="index.php" class="bye-btn-home">
        <i class="fa fa-home"></i> Inicio
      </a>
    </div>

    <!-- Contador -->
    <div class="bye-countdown">
      Redirigiendo al inicio en <span id="cntDown">5</span> segundos…
    </div>

  </div><!-- /bye-body -->
</div><!-- /bye-window -->


<script>
/* ── Cuenta regresiva y redirección ── */
let n = 5;
const span = document.getElementById('cntDown');
const iv = setInterval(()=>{
  n--;
  span.textContent = n;
  if(n <= 0){ clearInterval(iv); window.location.href = 'index.php'; }
}, 1000);

/* ── Sonido suave al cargar (si el usuario interactuó antes) ── */
/* (solo visual, sin audio para compatibilidad) */

/* ── Animación de partículas flotantes decorativas ── */
function createParticle(){
  const p = document.createElement('div');
  const size = Math.random()*4+2;
  Object.assign(p.style,{
    position:'fixed',
    width:size+'px',height:size+'px',
    borderRadius:'50%',
    background: Math.random()>.5 ? 'rgba(40,166,128,.5)' : 'rgba(218,165,32,.4)',
    left: Math.random()*100+'vw',
    bottom:'-10px',
    pointerEvents:'none',
    zIndex:'5',
    transition:'none',
    animation:`floatUp ${Math.random()*4+4}s ease-out forwards`,
  });
  document.body.appendChild(p);
  p.addEventListener('animationend',()=>p.remove());
}

const style = document.createElement('style');
style.textContent = `@keyframes floatUp{
  from{transform:translateY(0) rotate(0);opacity:.8;}
  to  {transform:translateY(-100vh) rotate(360deg);opacity:0;}
}`;
document.head.appendChild(style);

setInterval(createParticle, 300);
</script>
</body>
</html>