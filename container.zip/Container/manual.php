<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manual del Usuario — ContainerRz</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ══ VARIABLES ══════════════════════════════════════════════ */
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --blue:#3b82f6;--blue-dim:rgba(59,130,246,.14);
      --purple:#8b5cf6;--purple-dim:rgba(139,92,246,.14);
      --red:#ef4444;--red-dim:rgba(239,68,68,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --r-sm:8px;--r-md:14px;--r-lg:22px;--r-xl:32px;
      --font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);overflow:hidden;height:100vh;}
    button{cursor:pointer;border:none;font-family:inherit;}
    a{text-decoration:none;color:inherit;}

    /* ══ LAYOUT PRINCIPAL ═══════════════════════════════════════ */
    .manual{display:grid;grid-template-rows:60px 1fr;height:100vh;overflow:hidden;}

    /* ══ TOPBAR ════════════════════════════════════════════════ */
    .topbar{
      display:flex;align-items:center;justify-content:space-between;
      padding:0 28px;
      background:rgba(2,8,23,.95);
      border-bottom:1px solid rgba(40,166,128,.2);
      backdrop-filter:blur(20px);
      z-index:100;
    }
    .tb-brand{display:flex;align-items:center;gap:10px;}
    .tb-hex{font-size:1.3rem;color:var(--green);}
    .tb-name{font-family:var(--font-d);font-size:1rem;font-weight:900;color:var(--gold);letter-spacing:3px;}
    .tb-title{font-size:.82rem;color:var(--muted);}
    .tb-right{display:flex;align-items:center;gap:12px;}
    .tb-progress{display:flex;align-items:center;gap:8px;}
    .tb-progress-bar{width:120px;height:4px;background:rgba(255,255,255,.1);border-radius:99px;overflow:hidden;}
    .tb-progress-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width .4s ease;}
    .tb-prog-txt{font-size:.72rem;color:var(--muted);white-space:nowrap;}
    .tb-btn{display:flex;align-items:center;gap:6px;padding:7px 14px;border-radius:var(--r-md);font-size:.78rem;font-weight:700;cursor:pointer;transition:all .2s;}
    .tb-btn-outline{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);color:var(--muted);}
    .tb-btn-outline:hover{background:rgba(255,255,255,.12);color:var(--txt);}
    .tb-btn-green{background:var(--green);color:#fff;border:none;}
    .tb-btn-green:hover{background:var(--gold);}

    /* ══ CONTENIDO: nav lateral + slides ═══════════════════════ */
    .manual-body{display:grid;grid-template-columns:260px 1fr;overflow:hidden;}

    /* ══ NAV LATERAL ═══════════════════════════════════════════ */
    .side-nav{
      background:var(--n800);
      border-right:1px solid rgba(255,255,255,.06);
      overflow-y:auto;padding:20px 0;
    }
    .side-nav::-webkit-scrollbar{width:3px;}
    .side-nav::-webkit-scrollbar-thumb{background:rgba(40,166,128,.3);}
    .sn-section{margin-bottom:6px;}
    .sn-section-title{font-size:.62rem;font-weight:800;color:var(--dim);text-transform:uppercase;letter-spacing:2px;padding:8px 20px 4px;}
    .sn-item{
      display:flex;align-items:center;gap:10px;
      padding:9px 20px;cursor:pointer;
      font-size:.8rem;color:var(--muted);
      border-left:2px solid transparent;
      transition:all .2s;
    }
    .sn-item:hover{background:rgba(255,255,255,.04);color:var(--txt);}
    .sn-item.active{background:var(--green-dim);color:var(--green-lt);border-left-color:var(--green);}
    .sn-item.done .sn-check{color:var(--green);}
    .sn-ico{font-size:1rem;width:20px;text-align:center;flex-shrink:0;}
    .sn-check{margin-left:auto;font-size:.7rem;color:var(--dim);transition:color .3s;}
    .sn-num{font-family:var(--font-d);font-size:.6rem;color:var(--dim);margin-left:auto;min-width:16px;text-align:right;}

    /* ══ ÁREA DE SLIDES ════════════════════════════════════════ */
    .slides-area{
      position:relative;overflow:hidden;
      background:radial-gradient(ellipse 60% 50% at 50% 0%,#0a1a38,var(--n900));
    }

    /* Fondo animado */
    .slide-bg{position:absolute;inset:0;z-index:0;}
    .slide-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.03) 1px,transparent 1px);background-size:48px 48px;}
    .slide-orb{position:absolute;border-radius:50%;filter:blur(80px);}
    .sorb1{width:400px;height:400px;background:radial-gradient(circle,rgba(40,166,128,.12),transparent 70%);top:-100px;right:-80px;animation:orbf 12s ease-in-out infinite;}
    .sorb2{width:300px;height:300px;background:radial-gradient(circle,rgba(218,165,32,.08),transparent 70%);bottom:-60px;left:-60px;animation:orbf 9s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(16px,-16px)}}

    /* Slides */
    .slide{
      position:absolute;inset:0;
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      padding:40px 60px;z-index:1;
      opacity:0;transform:translateX(60px);
      transition:opacity .45s ease,transform .45s ease;
      pointer-events:none;overflow-y:auto;
    }
    .slide.active{opacity:1;transform:none;pointer-events:all;}
    .slide.exit{opacity:0;transform:translateX(-60px);}

    /* ── Slide: Portada ── */
    .slide-cover{justify-content:center;}
    .cover-tag{display:inline-block;padding:5px 16px;background:var(--green-dim);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.72rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:20px;}
    .cover-title{font-family:var(--font-d);font-size:clamp(1.8rem,3.5vw,3rem);font-weight:900;color:var(--txt);text-align:center;margin-bottom:12px;line-height:1.1;}
    .cover-title span{color:var(--gold);text-shadow:0 0 24px rgba(218,165,32,.4);}
    .cover-sub{font-size:1rem;color:var(--muted);text-align:center;max-width:560px;line-height:1.7;margin-bottom:32px;}
    .cover-features{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;width:100%;max-width:660px;margin-bottom:32px;}
    .cf-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);padding:16px;text-align:center;}
    .cf-ico{font-size:1.8rem;margin-bottom:8px;}
    .cf-label{font-size:.8rem;font-weight:700;color:var(--txt);}
    .cf-desc{font-size:.7rem;color:var(--muted);margin-top:4px;}
    .cover-btn{display:inline-flex;align-items:center;gap:10px;padding:14px 32px;background:var(--green);color:#fff;border-radius:var(--r-lg);font-weight:800;font-size:.95rem;cursor:pointer;transition:all .2s;border:none;}
    .cover-btn:hover{background:var(--gold);transform:translateY(-3px);}

    /* ── Slide: Sección ── */
    .slide-inner{width:100%;max-width:800px;}
    .slide-tag{display:inline-flex;align-items:center;gap:6px;padding:4px 12px;border-radius:99px;font-size:.68rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:16px;}
    .tag-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);color:var(--green-lt);}
    .tag-gold{background:var(--gold-dim);border:1px solid rgba(218,165,32,.3);color:var(--gold-lt);}
    .tag-blue{background:var(--blue-dim);border:1px solid rgba(59,130,246,.3);color:#93c5fd;}
    .tag-purple{background:var(--purple-dim);border:1px solid rgba(139,92,246,.3);color:#c4b5fd;}
    .tag-red{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);color:#fca5a5;}
    .slide-title{font-family:var(--font-d);font-size:clamp(1.4rem,2.5vw,2rem);font-weight:900;color:var(--txt);margin-bottom:8px;line-height:1.15;}
    .slide-lead{font-size:.92rem;color:var(--muted);line-height:1.7;margin-bottom:24px;max-width:640px;}

    /* ── Paso a paso ── */
    .steps{display:flex;flex-direction:column;gap:12px;}
    .step{
      display:flex;gap:16px;align-items:flex-start;
      padding:16px;background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);
      cursor:pointer;transition:all .25s;
    }
    .step:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.15);transform:translateX(4px);}
    .step.step-done{border-color:rgba(40,166,128,.4);background:var(--green-dim);}
    .step-num{width:36px;height:36px;border-radius:50%;background:var(--n500);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-family:var(--font-d);font-size:.75rem;font-weight:700;color:var(--muted);flex-shrink:0;transition:all .3s;}
    .step-done .step-num{background:var(--green);border-color:var(--green);color:#fff;}
    .step-body{flex:1;}
    .step-title{font-size:.9rem;font-weight:800;color:var(--txt);margin-bottom:4px;}
    .step-desc{font-size:.78rem;color:var(--muted);line-height:1.55;}
    .step-check{margin-left:auto;font-size:1.1rem;color:var(--dim);flex-shrink:0;transition:all .3s;}
    .step-done .step-check{color:var(--green);}

    /* ── Tarjetas de características ── */
    .feature-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
    .feat-card{
      padding:18px;background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);
      cursor:pointer;transition:all .25s;
      position:relative;overflow:hidden;
    }
    .feat-card::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 20% 20%,rgba(40,166,128,.08),transparent 60%);opacity:0;transition:opacity .3s;}
    .feat-card:hover::before{opacity:1;}
    .feat-card:hover{transform:translateY(-3px);border-color:rgba(40,166,128,.3);}
    .feat-card.feat-active{border-color:var(--green);background:var(--green-dim);}
    .feat-ico{font-size:1.6rem;margin-bottom:10px;}
    .feat-title{font-size:.88rem;font-weight:800;color:var(--txt);margin-bottom:6px;}
    .feat-desc{font-size:.75rem;color:var(--muted);line-height:1.55;}
    .feat-detail{margin-top:10px;font-size:.72rem;color:var(--green-lt);display:none;line-height:1.5;}
    .feat-card.feat-active .feat-detail{display:block;}

    /* ── Módulos interactivos ── */
    .modules-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;}
    .mod-card{
      padding:16px 12px;text-align:center;
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-md);cursor:pointer;transition:all .25s;
    }
    .mod-card:hover{transform:translateY(-4px);box-shadow:0 8px 24px rgba(0,0,0,.4);}
    .mod-ico{font-size:1.8rem;margin-bottom:8px;}
    .mod-name{font-size:.78rem;font-weight:800;color:var(--txt);margin-bottom:3px;}
    .mod-desc{font-size:.65rem;color:var(--muted);}

    /* ── Timeline ── */
    .timeline{display:flex;flex-direction:column;gap:0;}
    .tl-item{display:flex;gap:16px;}
    .tl-left{display:flex;flex-direction:column;align-items:center;width:32px;flex-shrink:0;}
    .tl-dot{width:12px;height:12px;border-radius:50%;background:var(--green);border:2px solid var(--n900);box-shadow:0 0 8px var(--green);flex-shrink:0;}
    .tl-line{width:2px;flex:1;background:rgba(40,166,128,.2);min-height:20px;}
    .tl-content{padding-bottom:20px;flex:1;}
    .tl-tag{font-size:.62rem;color:var(--green-lt);font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
    .tl-title{font-size:.88rem;font-weight:800;color:var(--txt);margin-bottom:4px;}
    .tl-desc{font-size:.75rem;color:var(--muted);line-height:1.55;}

    /* ── Accordion FAQ ── */
    .faq-list{display:flex;flex-direction:column;gap:8px;}
    .faq-item{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);overflow:hidden;}
    .faq-q{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;cursor:pointer;font-size:.85rem;font-weight:700;color:var(--txt);transition:background .2s;}
    .faq-q:hover{background:rgba(255,255,255,.06);}
    .faq-q i{transition:transform .3s;color:var(--muted);font-size:.8rem;}
    .faq-item.open .faq-q i{transform:rotate(180deg);color:var(--green);}
    .faq-item.open .faq-q{color:var(--green-lt);}
    .faq-a{max-height:0;overflow:hidden;transition:max-height .35s ease;}
    .faq-item.open .faq-a{max-height:200px;}
    .faq-a p{padding:0 18px 14px;font-size:.8rem;color:var(--muted);line-height:1.65;}

    /* ── Tooltip / Callout ── */
    .callout{display:flex;gap:12px;padding:14px 16px;border-radius:var(--r-md);margin-bottom:16px;}
    .callout-tip{background:var(--green-dim);border:1px solid rgba(40,166,128,.25);}
    .callout-warn{background:var(--gold-dim);border:1px solid rgba(218,165,32,.25);}
    .callout-info{background:var(--blue-dim);border:1px solid rgba(59,130,246,.25);}
    .callout-ico{font-size:1.2rem;flex-shrink:0;margin-top:1px;}
    .callout p{font-size:.8rem;color:var(--txt);line-height:1.6;}
    .callout strong{color:var(--green-lt);}
    .callout-warn strong{color:var(--gold-lt);}
    .callout-info strong{color:#93c5fd;}

    /* ── Hotspot interactivo ── */
    .hotspot-container{position:relative;border-radius:var(--r-lg);overflow:hidden;margin-bottom:16px;}
    .hotspot-img{width:100%;border-radius:var(--r-lg);background:var(--n600);height:220px;display:flex;align-items:center;justify-content:center;font-size:4rem;opacity:.4;}
    .hotspot{position:absolute;width:28px;height:28px;border-radius:50%;background:var(--green);border:3px solid #fff;cursor:pointer;transform:translate(-50%,-50%);transition:transform .2s;z-index:10;}
    .hotspot::after{content:'';position:absolute;inset:-6px;border-radius:50%;background:rgba(40,166,128,.3);animation:pulse 2s ease-in-out infinite;}
    @keyframes pulse{0%,100%{transform:scale(1);opacity:.6}50%{transform:scale(1.5);opacity:0}}
    .hotspot:hover{transform:translate(-50%,-50%) scale(1.3);}
    .hotspot-tooltip{
      position:absolute;background:var(--n600);border:1px solid rgba(255,255,255,.12);
      border-radius:var(--r-md);padding:10px 14px;font-size:.75rem;color:var(--txt);
      width:200px;z-index:20;opacity:0;pointer-events:none;transition:opacity .2s;
      box-shadow:0 8px 24px rgba(0,0,0,.4);
    }
    .hotspot:hover .hotspot-tooltip{opacity:1;}

    /* ── Slide final / CTA ── */
    .slide-end{background:radial-gradient(ellipse 80% 60% at 50% 50%,rgba(40,166,128,.08),transparent);}
    .end-ico{font-size:4rem;margin-bottom:16px;animation:bounce 2s ease-in-out infinite;}
    @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
    .end-title{font-family:var(--font-d);font-size:2rem;font-weight:900;color:var(--gold);text-align:center;margin-bottom:10px;}
    .end-sub{font-size:.92rem;color:var(--muted);text-align:center;max-width:480px;line-height:1.7;margin-bottom:28px;}
    .end-links{display:flex;gap:12px;flex-wrap:wrap;justify-content:center;}
    .end-btn{display:inline-flex;align-items:center;gap:8px;padding:12px 22px;border-radius:var(--r-md);font-weight:700;font-size:.85rem;transition:all .2s;}
    .end-btn-green{background:var(--green);color:#fff;}
    .end-btn-green:hover{background:var(--gold);transform:translateY(-2px);}
    .end-btn-outline{background:transparent;border:1px solid rgba(255,255,255,.15);color:var(--txt);}
    .end-btn-outline:hover{border-color:var(--green);color:var(--green-lt);}

    /* ══ BARRA INFERIOR (navegación entre slides) ════════════════ */
    .slides-nav{
      position:absolute;bottom:0;left:0;right:0;
      display:flex;align-items:center;justify-content:space-between;
      padding:14px 32px;
      background:rgba(2,8,23,.85);backdrop-filter:blur(12px);
      border-top:1px solid rgba(255,255,255,.06);
      z-index:10;
    }
    .nav-btn{display:flex;align-items:center;gap:8px;padding:9px 20px;border-radius:var(--r-md);font-size:.82rem;font-weight:700;cursor:pointer;transition:all .2s;}
    .nav-prev{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:var(--muted);}
    .nav-prev:hover:not(:disabled){background:rgba(255,255,255,.12);color:var(--txt);}
    .nav-prev:disabled{opacity:.3;cursor:not-allowed;}
    .nav-next{background:var(--green);color:#fff;}
    .nav-next:hover{background:var(--gold);}
    .nav-dots{display:flex;gap:6px;}
    .nav-dot{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.2);cursor:pointer;transition:all .2s;border:none;padding:0;}
    .nav-dot.on{background:var(--green);width:20px;border-radius:99px;}
    .slide-counter{font-size:.72rem;color:var(--dim);}

    /* ══ RESPONSIVE ══════════════════════════════════════════════ */
    @media(max-width:900px){
      .manual-body{grid-template-columns:1fr;}
      .side-nav{display:none;}
      .cover-features{grid-template-columns:1fr 1fr;}
      .feature-grid,.modules-grid{grid-template-columns:1fr;}
    }
    @media(max-width:600px){
      .slide{padding:24px 20px 80px;}
      .cover-features{grid-template-columns:1fr;}
      .cover-title{font-size:1.5rem;}
    }
  </style>
</head>
<body>
<div class="manual">

  <!-- ══ TOPBAR ════════════════════════════════════════════════ -->
  <div class="topbar">
    <div class="tb-brand">
      <span class="tb-hex">⬡</span>
      <span class="tb-name">ContainerRz</span>
      <span style="color:var(--dim);margin:0 8px;">·</span>
      <span class="tb-title">Manual del Usuario</span>
    </div>
    <div class="tb-right">
      <div class="tb-progress">
        <div class="tb-progress-bar">
          <div class="tb-progress-fill" id="topProgressFill" style="width:0%"></div>
        </div>
        <span class="tb-prog-txt" id="topProgTxt">0%</span>
      </div>
      <button class="tb-btn tb-btn-outline" onclick="window.location.href='index.php'">
        <i class="fa fa-home"></i> Inicio
      </button>
      <button class="tb-btn tb-btn-green" onclick="resetProgress()">
        <i class="fa fa-rotate-left"></i> Reiniciar
      </button>
    </div>
  </div>

  <!-- ══ CUERPO ════════════════════════════════════════════════ -->
  <div class="manual-body">

    <!-- ── NAV LATERAL ─────────────────────────────────────── -->
    <nav class="side-nav" id="sideNav">
      <div class="sn-section">
        <div class="sn-section-title">Introducción</div>
        <div class="sn-item active" data-slide="0" onclick="goSlide(0)">
          <span class="sn-ico">🏠</span> Bienvenida
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="1" onclick="goSlide(1)">
          <span class="sn-ico">🗺</span> ¿Qué es ContainerRz?
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
      </div>
      <div class="sn-section">
        <div class="sn-section-title">Primeros Pasos</div>
        <div class="sn-item" data-slide="2" onclick="goSlide(2)">
          <span class="sn-ico">🔑</span> Crear tu cuenta
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="3" onclick="goSlide(3)">
          <span class="sn-ico">🚪</span> Iniciar sesión
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="4" onclick="goSlide(4)">
          <span class="sn-ico">👤</span> Tu perfil
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
      </div>
      <div class="sn-section">
        <div class="sn-section-title">Módulos</div>
        <div class="sn-item" data-slide="5" onclick="goSlide(5)">
          <span class="sn-ico">🛠</span> Servicios
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="6" onclick="goSlide(6)">
          <span class="sn-ico">🤖</span> IA ContainerRz
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="7" onclick="goSlide(7)">
          <span class="sn-ico">🚀</span> Proyectos
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="8" onclick="goSlide(8)">
          <span class="sn-ico">💳</span> Pagos
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
      </div>
      <div class="sn-section">
        <div class="sn-section-title">Ayuda</div>
        <div class="sn-item" data-slide="9" onclick="goSlide(9)">
          <span class="sn-ico">❓</span> Preguntas frecuentes
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
        <div class="sn-item" data-slide="10" onclick="goSlide(10)">
          <span class="sn-ico">🏁</span> Finalizar
          <span class="sn-check"><i class="fa fa-check-circle"></i></span>
        </div>
      </div>
    </nav>

    <!-- ── ÁREA DE SLIDES ──────────────────────────────────── -->
    <div class="slides-area">
      <div class="slide-bg">
        <div class="slide-grid"></div>
        <div class="slide-orb sorb1"></div>
        <div class="slide-orb sorb2"></div>
      </div>

      <!-- ══════ SLIDE 0: PORTADA ══════════════════════════════ -->
      <div class="slide slide-cover active" data-index="0">
        <span class="cover-tag">⬡ Manual Interactivo · v1.0</span>
        <h1 class="cover-title">Guía Completa de<br><span>ContainerRz</span></h1>
        <p class="cover-sub">Aprende a usar cada módulo del ecosistema paso a paso. Este manual interactivo te guiará desde el registro hasta las funcionalidades avanzadas.</p>
        <div class="cover-features">
          <div class="cf-item">
            <div class="cf-ico">📖</div>
            <div class="cf-label">11 secciones</div>
            <div class="cf-desc">Guías detalladas</div>
          </div>
          <div class="cf-item">
            <div class="cf-ico">🎯</div>
            <div class="cf-label">Interactivo</div>
            <div class="cf-desc">Haz clic y aprende</div>
          </div>
          <div class="cf-item">
            <div class="cf-ico">⚡</div>
            <div class="cf-label">Paso a paso</div>
            <div class="cf-desc">Fácil de seguir</div>
          </div>
        </div>
        <button class="cover-btn" onclick="goSlide(1)">
          Comenzar <i class="fa fa-arrow-right"></i>
        </button>
      </div>

      <!-- ══════ SLIDE 1: ¿QUÉ ES CONTAINERRZ? ════════════════ -->
      <div class="slide" data-index="1">
        <div class="slide-inner">
          <span class="slide-tag tag-green"><i class="fa fa-info-circle"></i> Introducción</span>
          <h2 class="slide-title">¿Qué es ContainerRz?</h2>
          <p class="slide-lead">ContainerRz es una plataforma educativa modular enfocada en tecnología, ciberseguridad e inteligencia artificial. Haz clic en cada módulo para conocerlo.</p>

          <div class="modules-grid">
            <?php
              $mods=[
                ['🛠','Servicios','Catálogo de servicios digitales con planes y pagos','#5eead4'],
                ['🤖','IA','Asistente de inteligencia artificial integrado','#a5b4fc'],
                ['🚀','Proyectos','Gestión y seguimiento de proyectos tecnológicos','#fdba74'],
                ['👥','Equipo','Directorio de miembros y colaboradores','#93c5fd'],
                ['📚','Aprendizaje','Cursos MOOC, NOOC y SPOC interactivos','#f9a8d4'],
                ['📊','PQRS','Sistema de peticiones, quejas y sugerencias','#fde68a'],
                ['🌐','SIG','Mapa de ubicación y distribución geográfica','#6ee7b7'],
                ['🏆','Gamificación','Puntos, logros y recompensas por participación','#fca5a5'],
                ['📰','Publicaciones','Blog técnico y artículos educativos','#c4b5fd'],
              ];
              foreach($mods as [$ico,$nom,$desc,$col]):
            ?>
            <div class="mod-card" style="border-color:<?= $col ?>33;"
                 onmouseover="this.style.borderColor='<?= $col ?>88';this.style.background='<?= $col ?>11'"
                 onmouseout="this.style.borderColor='<?= $col ?>33';this.style.background=''">
              <div class="mod-ico"><?= $ico ?></div>
              <div class="mod-name"><?= $nom ?></div>
              <div class="mod-desc"><?= $desc ?></div>
            </div>
            <?php endforeach; ?>
          </div>

          <div class="callout callout-tip" style="margin-top:16px;">
            <span class="callout-ico">💡</span>
            <p><strong>Tip:</strong> Navega por las secciones de este manual usando el menú lateral o los botones de abajo.</p>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 2: CREAR CUENTA ═════════════════════════ -->
      <div class="slide" data-index="2">
        <div class="slide-inner">
          <span class="slide-tag tag-blue"><i class="fa fa-user-plus"></i> Primeros Pasos</span>
          <h2 class="slide-title">Crear tu cuenta</h2>
          <p class="slide-lead">Regístrate en ContainerRz para acceder a todos los módulos. Haz clic en cada paso para marcarlo como completado.</p>

          <div class="steps" id="steps-register">
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">1</div>
              <div class="step-body">
                <div class="step-title">Ir a la página de registro</div>
                <div class="step-desc">Haz clic en el botón <strong>"Regístrate gratis"</strong> que aparece en el login o en el menú de navegación superior.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">2</div>
              <div class="step-body">
                <div class="step-title">Completa tus datos personales</div>
                <div class="step-desc">Ingresa tu nombre completo, número de identificación, fecha de nacimiento y fecha de expedición del documento.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">3</div>
              <div class="step-body">
                <div class="step-title">Crea tus credenciales de acceso</div>
                <div class="step-desc">Define tu nombre de usuario único, correo electrónico y una contraseña segura (mínimo 8 caracteres con mayúsculas y números).</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">4</div>
              <div class="step-body">
                <div class="step-title">Alternativa: Registro con Google</div>
                <div class="step-desc">Puedes registrarte directamente con tu cuenta de Google haciendo clic en el botón "Continuar con Google". Tu perfil se crea automáticamente.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">5</div>
              <div class="step-body">
                <div class="step-title">¡Listo! Inicia sesión</div>
                <div class="step-desc">Una vez registrado, serás redirigido al login. Usa tus credenciales para ingresar y verás la pantalla de bienvenida animada.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 3: INICIAR SESIÓN ═══════════════════════ -->
      <div class="slide" data-index="3">
        <div class="slide-inner">
          <span class="slide-tag tag-green"><i class="fa fa-sign-in-alt"></i> Primeros Pasos</span>
          <h2 class="slide-title">Iniciar sesión</h2>
          <p class="slide-lead">ContainerRz ofrece múltiples métodos de autenticación. Haz clic en cada opción para ver los detalles.</p>

          <div class="feature-grid">
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">👤</div>
              <div class="feat-title">Con nombre de usuario</div>
              <div class="feat-desc">Usa el nombre de usuario que registraste + tu contraseña.</div>
              <div class="feat-detail">Ve al login → selecciona la pestaña "Usuario" → escribe tu username y contraseña → clic en "Ingresar". Es el método más rápido si recuerdas tu username.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">📧</div>
              <div class="feat-title">Con correo electrónico</div>
              <div class="feat-desc">Ingresa tu correo registrado y contraseña.</div>
              <div class="feat-detail">Selecciona la pestaña "Correo" en el login → escribe tu email y contraseña. Útil si olvidaste tu username pero recuerdas el correo.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">📱</div>
              <div class="feat-title">Con teléfono</div>
              <div class="feat-desc">Usa tu número de teléfono registrado.</div>
              <div class="feat-detail">Selecciona "Tel." en el login → escribe tu número con prefijo internacional (Ej: +57 300...) → ingresa tu contraseña.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">🔵</div>
              <div class="feat-title">Con Google OAuth</div>
              <div class="feat-desc">Un solo clic con tu cuenta de Google.</div>
              <div class="feat-detail">Haz clic en "Continuar con Google" → selecciona tu cuenta → autoriza el acceso. ContainerRz vincula tu cuenta automáticamente. No necesitas contraseña.</div>
            </div>
          </div>

          <div class="callout callout-warn" style="margin-top:16px;">
            <span class="callout-ico">⚠️</span>
            <p><strong>Seguridad:</strong> Después de 5 intentos fallidos, tu cuenta se bloquea 30 minutos. Usa "¿Olvidaste tu contraseña?" para recuperar el acceso.</p>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 4: TU PERFIL ═════════════════════════════ -->
      <div class="slide" data-index="4">
        <div class="slide-inner">
          <span class="slide-tag tag-purple"><i class="fa fa-id-card"></i> Perfil</span>
          <h2 class="slide-title">Configura tu perfil</h2>
          <p class="slide-lead">Tu perfil es tu identidad en ContainerRz. Complétalo para acceder a todas las funcionalidades. Usa las pestañas en "Editar perfil".</p>

          <div class="timeline">
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Pestaña 1</div>
                <div class="tl-title">📋 Datos Personales</div>
                <div class="tl-desc">Nombre, apellido, documento, fecha de nacimiento, género, país y ciudad. Esta información es tu identidad base en el sistema.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Pestaña 2</div>
                <div class="tl-title">💼 Perfil Profesional</div>
                <div class="tl-desc">Ocupación, institución, nivel educativo, experiencia en ciberseguridad, certificaciones e intereses tecnológicos.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Pestaña 3</div>
                <div class="tl-title">🎓 Aprendizaje (MOOC/NOOC/SPOC)</div>
                <div class="tl-desc">Configura tu ruta de aprendizaje, tipo de curso preferido y objetivos educativos dentro de la plataforma.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Pestaña 4</div>
                <div class="tl-title">🌐 Redes Sociales</div>
                <div class="tl-desc">Vincula tu LinkedIn, GitHub, Twitter/X y otras plataformas para mostrarlas en tu perfil público.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Pestaña 5</div>
                <div class="tl-title">🔒 Seguridad</div>
                <div class="tl-desc">Cambia tu contraseña, activa la autenticación de dos factores (2FA) y revisa los accesos recientes a tu cuenta.</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 5: SERVICIOS ═════════════════════════════ -->
      <div class="slide" data-index="5">
        <div class="slide-inner">
          <span class="slide-tag tag-green"><i class="fa fa-tools"></i> Módulo</span>
          <h2 class="slide-title">Módulo de Servicios</h2>
          <p class="slide-lead">El catálogo de servicios te permite explorar y adquirir más de 21 áreas de conocimiento tecnológico. Haz clic en cada paso.</p>

          <div class="steps">
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">1</div>
              <div class="step-body">
                <div class="step-title">Explorar el catálogo</div>
                <div class="step-desc">Ve a <strong>Servicios</strong> en el menú. Usa los filtros de categoría (Desarrollo, Seguridad, IA & Datos...) o la búsqueda para encontrar lo que necesitas.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">2</div>
              <div class="step-body">
                <div class="step-title">Ver el detalle del servicio</div>
                <div class="step-desc">Haz clic en cualquier tarjeta para abrir el modal con: Definición, Conceptos clave, Parámetros del servicio, Foto, Video de referencia y Links.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">3</div>
              <div class="step-body">
                <div class="step-title">Seleccionar un plan</div>
                <div class="step-desc">En la pestaña "Planes & Pagos" encontrarás 3 niveles (Básico, Estándar, Premium) con diferentes precios e incluidos. Haz clic en "Adquirir" para continuar.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">4</div>
              <div class="step-body">
                <div class="step-title">Realizar el pago</div>
                <div class="step-desc">Elige entre <strong>Mercado Pago</strong> (tarjeta, PSE, Nequi, Daviplata) o <strong>ePayco</strong> (PSE, Nequi, Efecty, Baloto). Serás redirigido a la pasarela seleccionada.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
          </div>

          <div class="callout callout-info" style="margin-top:14px;">
            <span class="callout-ico">ℹ️</span>
            <p><strong>¿Necesitas algo personalizado?</strong> Todos los servicios tienen opción de cotización personalizada para empresas y grupos con descuentos especiales.</p>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 6: IA ════════════════════════════════════ -->
      <div class="slide" data-index="6">
        <div class="slide-inner">
          <span class="slide-tag tag-purple"><i class="fa fa-robot"></i> Módulo</span>
          <h2 class="slide-title">IA ContainerRz</h2>
          <p class="slide-lead">El asistente de inteligencia artificial integrado tiene 10 herramientas especializadas. Haz clic en cada una para ver su función.</p>

          <div class="feature-grid">
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">🤖</div>
              <div class="feat-title">Asistente General</div>
              <div class="feat-desc">Resuelve dudas generales sobre tecnología.</div>
              <div class="feat-detail">Responde preguntas técnicas, explica conceptos, ayuda con investigación y actúa como un tutor digital disponible 24/7.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">🛡</div>
              <div class="feat-title">Ciberseguridad</div>
              <div class="feat-desc">Análisis de vulnerabilidades y defensa.</div>
              <div class="feat-detail">Analiza logs, explica técnicas de hacking ético, ayuda a identificar vulnerabilidades y sugiere estrategias de defensa adaptadas a tu contexto.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">💻</div>
              <div class="feat-title">Código</div>
              <div class="feat-desc">Genera, depura y optimiza código.</div>
              <div class="feat-detail">Soporta PHP, Python, JavaScript, SQL, Bash y más. Genera código limpio, explica errores, propone optimizaciones y revisa tu lógica.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)">
              <div class="feat-ico">📊</div>
              <div class="feat-title">Análisis de Datos</div>
              <div class="feat-desc">Interpreta datos y genera insights.</div>
              <div class="feat-detail">Analiza datasets, propone visualizaciones, explica métricas de seguridad y genera reportes ejecutivos sobre los datos que le compartas.</div>
            </div>
          </div>

          <div class="steps" style="margin-top:16px;">
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">→</div>
              <div class="step-body">
                <div class="step-title">Cómo usar la IA</div>
                <div class="step-desc">Ve al módulo IA → selecciona la herramienta especializada → escribe tu consulta o usa las sugerencias rápidas → presiona Enter o el botón enviar.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 7: PROYECTOS ═════════════════════════════ -->
      <div class="slide" data-index="7">
        <div class="slide-inner">
          <span class="slide-tag tag-gold"><i class="fa fa-rocket"></i> Módulo</span>
          <h2 class="slide-title">Gestión de Proyectos</h2>
          <p class="slide-lead">ContainerRz incluye un sistema completo de gestión de proyectos con seguimiento de KPIs, avances y documentos.</p>

          <div class="timeline">
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot" style="background:var(--gold);box-shadow:0 0 8px var(--gold);"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Paso 1</div>
                <div class="tl-title">Crear un proyecto</div>
                <div class="tl-desc">Ve a Proyectos → "Nuevo Proyecto" → define título, descripción, tipo (propio/comunidad/cliente), tecnologías y área. Establece fechas de inicio y fin.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot" style="background:var(--gold);box-shadow:0 0 8px var(--gold);"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Paso 2</div>
                <div class="tl-title">Invitar miembros</div>
                <div class="tl-desc">Desde el proyecto, ve a "Equipo" → busca usuarios por username → asigna roles (colaborador, editor, admin) y permisos de acceso.</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot" style="background:var(--gold);box-shadow:0 0 8px var(--gold);"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Paso 3</div>
                <div class="tl-title">Seguimiento de avances</div>
                <div class="tl-desc">Registra avances periódicos con descripción y fecha. El sistema calcula automáticamente el porcentaje de progreso (0-100%).</div>
              </div>
            </div>
            <div class="tl-item">
              <div class="tl-left"><div class="tl-dot" style="background:var(--gold);box-shadow:0 0 8px var(--gold);"></div><div class="tl-line"></div></div>
              <div class="tl-content">
                <div class="tl-tag">Paso 4</div>
                <div class="tl-title">KPIs y métricas</div>
                <div class="tl-desc">Define indicadores clave de rendimiento para tu proyecto. El dashboard muestra el estado de cada KPI en tiempo real.</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 8: PAGOS ═════════════════════════════════ -->
      <div class="slide" data-index="8">
        <div class="slide-inner">
          <span class="slide-tag tag-green"><i class="fa fa-credit-card"></i> Módulo</span>
          <h2 class="slide-title">Sistema de Pagos</h2>
          <p class="slide-lead">ContainerRz integra dos pasarelas de pago certificadas para Colombia. Los pagos son procesados externamente con cifrado SSL.</p>

          <div class="feature-grid" style="margin-bottom:16px;">
            <div class="feat-card" onclick="toggleFeat(this)" style="border-color:#009FE333;">
              <div class="feat-ico">💙</div>
              <div class="feat-title" style="color:#00CFFF;">Mercado Pago</div>
              <div class="feat-desc">La pasarela más popular de Colombia y Latinoamérica.</div>
              <div class="feat-detail">Acepta: Tarjeta Visa/Mastercard, PSE, Nequi, Daviplata, Efecty y pagos en efectivo. Disponible 24/7. Procesamiento inmediato.</div>
            </div>
            <div class="feat-card" onclick="toggleFeat(this)" style="border-color:#00A65133;">
              <div class="feat-ico">🟢</div>
              <div class="feat-title" style="color:#00d471;">ePayco</div>
              <div class="feat-desc">Pasarela colombiana con múltiples métodos locales.</div>
              <div class="feat-detail">Acepta: PSE, Nequi, Efecty, Baloto, tarjetas de crédito y débito. Ideal para pagos locales en Colombia. Soporte en español.</div>
            </div>
          </div>

          <div class="steps">
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">1</div>
              <div class="step-body">
                <div class="step-title">Selecciona el plan</div>
                <div class="step-desc">En el modal del servicio, pestaña "Planes & Pagos" → haz clic en "Adquirir [Plan]".</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">2</div>
              <div class="step-body">
                <div class="step-title">Elige la pasarela</div>
                <div class="step-desc">Aparecen los botones de Mercado Pago y ePayco. Selecciona tu preferida — serás redirigido automáticamente.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
            <div class="step" onclick="toggleStep(this)">
              <div class="step-num">3</div>
              <div class="step-body">
                <div class="step-title">Completa el pago externo</div>
                <div class="step-desc">En la pasarela seleccionada, elige tu método de pago (PSE, tarjeta, etc.) y sigue los pasos. El proceso dura menos de 3 minutos.</div>
              </div>
              <span class="step-check"><i class="fa fa-circle"></i></span>
            </div>
          </div>

          <div class="callout callout-warn">
            <span class="callout-ico">🔒</span>
            <p><strong>Seguridad:</strong> ContainerRz nunca almacena datos de tarjetas. Todos los pagos son procesados por las pasarelas certificadas PCI DSS.</p>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 9: FAQ ═══════════════════════════════════ -->
      <div class="slide" data-index="9">
        <div class="slide-inner">
          <span class="slide-tag tag-blue"><i class="fa fa-question-circle"></i> Ayuda</span>
          <h2 class="slide-title">Preguntas Frecuentes</h2>
          <p class="slide-lead">Haz clic en cada pregunta para ver la respuesta.</p>

          <div class="faq-list">
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿Puedo usar ContainerRz gratis?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>Sí. El registro es gratuito y tienes acceso al módulo de IA, publicaciones, galería y equipo sin costo. Los servicios premium requieren pago según el plan seleccionado.</p>
              </div>
            </div>
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿Cómo recupero mi contraseña?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>En el login, haz clic en "¿Olvidaste tu contraseña?" → ingresa tu correo registrado → recibirás un email con un enlace de recuperación válido por 30 minutos.</p>
              </div>
            </div>
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿Qué pasa si mi pago falla?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>Si el pago falla, no se realiza ningún cargo a tu cuenta. Puedes intentarlo nuevamente o contactarnos en contacto@teamvirox.com para asistencia personalizada.</p>
              </div>
            </div>
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿Puedo cambiar mi plan después de adquirirlo?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>Sí. Puedes hacer upgrade a un plan superior en cualquier momento pagando la diferencia. Para downgrades, contáctanos directamente ya que cada caso se evalúa individualmente.</p>
              </div>
            </div>
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿La IA guarda mis conversaciones?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>Sí, el historial de conversaciones se guarda en tu cuenta para que puedas continuar donde lo dejaste. Puedes eliminar conversaciones individuales desde el módulo IA.</p>
              </div>
            </div>
            <div class="faq-item">
              <div class="faq-q" onclick="toggleFaq(this.parentElement)">
                ¿Cómo envío una PQRS?
                <i class="fa fa-chevron-down"></i>
              </div>
              <div class="faq-a">
                <p>Ve a Contacto → pestaña PQRS → selecciona el tipo (petición, queja, reclamo, sugerencia) → completa el formulario → califica tu experiencia con estrellas (suma puntos de bonificación).</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ══════ SLIDE 10: FINAL ════════════════════════════════ -->
      <div class="slide slide-end" data-index="10">
        <div class="end-ico">🎓</div>
        <div class="end-title">¡Manual completado!</div>
        <p class="end-sub">Ya conoces las funcionalidades principales de ContainerRz. Recuerda que puedes volver a este manual en cualquier momento desde el botón "Ver Manual" en la página principal.</p>

        <!-- Resumen de lo aprendido -->
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:28px;width:100%;max-width:600px;">
          <?php
            $learned=[['🔑','Cuenta','Registro y login'],['🛠','Servicios','Catálogo y pagos'],['🤖','IA','Asistente inteligente'],['🚀','Proyectos','Gestión completa']];
            foreach($learned as [$i,$t,$d]):
          ?>
          <div style="text-align:center;padding:14px 8px;background:rgba(255,255,255,.04);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-md);">
            <div style="font-size:1.5rem;margin-bottom:6px;"><?=$i?></div>
            <div style="font-size:.78rem;font-weight:800;color:var(--green-lt);"><?=$t?></div>
            <div style="font-size:.65rem;color:var(--dim);margin-top:2px;"><?=$d?></div>
          </div>
          <?php endforeach; ?>
        </div>

        <div class="end-links">
          <a href="index.php" class="end-btn end-btn-green">
            <i class="fa fa-home"></i> Ir al inicio
          </a>
          <a href="servicios.php" class="end-btn end-btn-outline">
            <i class="fa fa-tools"></i> Ver servicios
          </a>
          <a href="IA.php" class="end-btn end-btn-outline">
            <i class="fa fa-robot"></i> Explorar IA
          </a>
          <button class="end-btn end-btn-outline" onclick="goSlide(0)">
            <i class="fa fa-rotate-left"></i> Repetir manual
          </button>
        </div>
      </div>

      <!-- ══ BARRA DE NAVEGACIÓN INFERIOR ═════════════════════ -->
      <div class="slides-nav">
        <button class="nav-btn nav-prev" id="btnPrev" onclick="prevSlide()" disabled>
          <i class="fa fa-chevron-left"></i> Anterior
        </button>
        <div style="display:flex;flex-direction:column;align-items:center;gap:6px;">
          <div class="nav-dots" id="navDots"></div>
          <span class="slide-counter" id="slideCounter">1 / 11</span>
        </div>
        <button class="nav-btn nav-next" id="btnNext" onclick="nextSlide()">
          Siguiente <i class="fa fa-chevron-right"></i>
        </button>
      </div>

    </div><!-- /slides-area -->
  </div><!-- /manual-body -->
</div><!-- /manual -->

<script>
/* ═══════════════════════════════════════════════════════════════
   ESTADO
═══════════════════════════════════════════════════════════════ */
const TOTAL  = 11;
let current  = 0;
let visited  = new Set([0]);
let done     = JSON.parse(localStorage.getItem('manual_done') || '[]');

/* ═══════════════════════════════════════════════════════════════
   INICIALIZACIÓN
═══════════════════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  buildDots();
  updateUI();
  markVisited(0);
});

function buildDots() {
  const container = document.getElementById('navDots');
  for (let i = 0; i < TOTAL; i++) {
    const d = document.createElement('button');
    d.className = 'nav-dot' + (i === 0 ? ' on' : '');
    d.title = `Slide ${i+1}`;
    d.onclick = () => goSlide(i);
    container.appendChild(d);
  }
}

/* ═══════════════════════════════════════════════════════════════
   NAVEGACIÓN
═══════════════════════════════════════════════════════════════ */
function goSlide(idx) {
  if (idx < 0 || idx >= TOTAL) return;

  // Salida de slide actual
  const slides = document.querySelectorAll('.slide');
  slides[current].classList.remove('active');
  slides[current].classList.add('exit');
  setTimeout(() => slides[current].classList.remove('exit'), 450);

  current = idx;
  visited.add(idx);
  markVisited(idx);

  // Entrada
  slides[current].classList.add('active');

  updateUI();
  updateSideNav();
}

function nextSlide() { goSlide(current + 1); }
function prevSlide() { goSlide(current - 1); }

function updateUI() {
  // Botones prev/next
  document.getElementById('btnPrev').disabled = current === 0;
  const btnNext = document.getElementById('btnNext');
  btnNext.innerHTML = current === TOTAL - 1
    ? '<i class="fa fa-home"></i> Inicio'
    : 'Siguiente <i class="fa fa-chevron-right"></i>';
  btnNext.onclick = current === TOTAL - 1
    ? () => window.location.href = 'index.php'
    : nextSlide;

  // Puntos
  document.querySelectorAll('.nav-dot').forEach((d, i) => {
    d.classList.toggle('on', i === current);
  });

  // Contador
  document.getElementById('slideCounter').textContent = `${current + 1} / ${TOTAL}`;

  // Progress bar
  const pct = Math.round((visited.size / TOTAL) * 100);
  document.getElementById('topProgressFill').style.width = pct + '%';
  document.getElementById('topProgTxt').textContent = pct + '%';

  // Scroll al inicio del slide
  document.querySelectorAll('.slide')[current].scrollTop = 0;
}

function updateSideNav() {
  document.querySelectorAll('.sn-item').forEach(item => {
    const idx = +item.dataset.slide;
    item.classList.toggle('active', idx === current);
    item.classList.toggle('done', done.includes(idx));
  });
}

function markVisited(idx) {
  visited.add(idx);
  if (!done.includes(idx)) {
    done.push(idx);
    localStorage.setItem('manual_done', JSON.stringify(done));
  }
  updateSideNav();
}

function resetProgress() {
  done = [];
  visited = new Set([current]);
  localStorage.removeItem('manual_done');
  // Desmarcar todos los steps
  document.querySelectorAll('.step').forEach(s => s.classList.remove('step-done'));
  document.querySelectorAll('.faq-item').forEach(f => f.classList.remove('open'));
  document.querySelectorAll('.feat-card').forEach(f => f.classList.remove('feat-active'));
  updateUI();
  updateSideNav();
}

/* ═══════════════════════════════════════════════════════════════
   INTERACCIONES DE CONTENIDO
═══════════════════════════════════════════════════════════════ */
// Toggle paso checklist
function toggleStep(el) {
  el.classList.toggle('step-done');
  const ico = el.querySelector('.step-check i');
  ico.className = el.classList.contains('step-done')
    ? 'fa fa-check-circle'
    : 'fa fa-circle';
  // Número animado
  const num = el.querySelector('.step-num');
  if (el.classList.contains('step-done')) {
    num.textContent = '✓';
  } else {
    num.textContent = el.parentElement.querySelectorAll('.step').length > 0
      ? Array.from(el.parentElement.querySelectorAll('.step')).indexOf(el) + 1
      : '';
  }
}

// Toggle tarjeta de característica
function toggleFeat(el) {
  const wasActive = el.classList.contains('feat-active');
  document.querySelectorAll('.feat-card').forEach(c => c.classList.remove('feat-active'));
  if (!wasActive) el.classList.add('feat-active');
}

// Toggle FAQ
function toggleFaq(item) {
  const isOpen = item.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(f => f.classList.remove('open'));
  if (!isOpen) item.classList.add('open');
}

/* ═══════════════════════════════════════════════════════════════
   TECLADO
═══════════════════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  if (e.key === 'ArrowRight' || e.key === ' ') { e.preventDefault(); nextSlide(); }
  if (e.key === 'ArrowLeft')                   { e.preventDefault(); prevSlide(); }
});

/* ═══════════════════════════════════════════════════════════════
   SWIPE TÁCTIL
═══════════════════════════════════════════════════════════════ */
let touchX = 0;
const slidesArea = document.querySelector('.slides-area');
slidesArea.addEventListener('touchstart', e => touchX = e.touches[0].clientX, {passive:true});
slidesArea.addEventListener('touchend',   e => {
  const dx = e.changedTouches[0].clientX - touchX;
  if (Math.abs(dx) > 60) { dx < 0 ? nextSlide() : prevSlide(); }
}, {passive:true});
</script>
</body>
</html>