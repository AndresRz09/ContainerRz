<?php
include 'conexion.php';
session_start();


if(isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$error = '';
$nuevo = isset($_GET['nuevo']) ? true : false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {

    $input    = trim($_POST['user']    ?? '');
    $password = trim($_POST['password'] ?? '');

    // Anti SQL injection — solo prepared statements, sin concatenación
    if($input === '' || $password === '') {
        $error = "Por favor completa todos los campos.";
    } else {
        // Determinar tipo de entrada
        $isEmail  = filter_var($input, FILTER_VALIDATE_EMAIL);
        $isPhone  = preg_match('/^[\+0-9\s\-]{7,15}$/', $input);

        // Buscar en tabla de seguridad por correo, identificación o teléfono
        $sql = "SELECT us.*, u.nombre, u.apellido, u.rol, u.avatar, u.activo
                FROM usuarios_seguridad us
                INNER JOIN usuarios u ON us.usuario_id = u.id
                WHERE us.correo = ? OR us.identificacion = ? OR us.telefono = ?
                LIMIT 1";

        $stmt = $conexion->prepare($sql);
        if(!$stmt) {
            $error = "Error interno. Intenta de nuevo.";
        } else {
            $stmt->bind_param("sss", $input, $input, $input);
            $stmt->execute();
            $result = $stmt->get_result();
            $stmt->close();

            if($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();

                if(!$row['activo']) {
                    $error = "Tu cuenta está desactivada. Contacta al soporte.";
                } else {
                    $pw_ok = false;
                    $rehash = false;

                    // Caso A: hash bcrypt
                    if(!empty($row['password_hash']) && password_verify($password, $row['password_hash'])) {
                        $pw_ok = true;
                        if(password_needs_rehash($row['password_hash'], PASSWORD_BCRYPT, ['cost'=>12]))
                            $rehash = true;
                    }
                    // Caso B: texto plano legacy
                    elseif($row['password_hash'] === $password) {
                        $pw_ok = true;
                        $rehash = true;
                    }

                    if($pw_ok) {
                        // Rehash automático
                        if($rehash) {
                            $nuevo_hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>12]);
                            $upd = $conexion->prepare("UPDATE usuarios_seguridad SET password_hash=? WHERE id=?");
                            if($upd) { $upd->bind_param("si",$nuevo_hash,$row['id']); $upd->execute(); $upd->close(); }
                        }

                        // Registrar último acceso
                        $upd2 = $conexion->prepare("UPDATE usuarios SET ultimo_acceso=NOW() WHERE id=?");
                        if($upd2) { $upd2->bind_param("i",$row['usuario_id']); $upd2->execute(); $upd2->close(); }

                        // Sesión
                        session_regenerate_id(true);
                        $_SESSION['user_id']    = $row['usuario_id'];
                        $_SESSION['user_name']  = $row['nombre'] . ' ' . $row['apellido'];
                        $_SESSION['rol']        = $row['rol'];
                        $_SESSION['avatar']     = $row['avatar'] ?: 'assets/avatar-default.png';
                        $_SESSION['correo']     = $row['correo'];
                        $_SESSION['show_intro'] = true;

                        // Novedades para el intro
                        $novedades = [];
                        $qn = $conexion->prepare("SELECT titulo, descripcion FROM novedades ORDER BY fecha DESC LIMIT 4");
                        if($qn){ $qn->execute(); $rn=$qn->get_result(); while($nov=$rn->fetch_assoc()) $novedades[]=$nov; $qn->close(); }

                        $_SESSION['novedades'] = $novedades;

                        // Datos para la animación intro (pasar como JSON a la vista)
                        $intro_data = json_encode([
                            'nombre' => $row['nombre'],
                            'avatar' => $row['avatar'] ?: 'assets/avatar-default.png',
                            'rol'    => $row['rol'],
                            'novedades' => $novedades,
                        ]);

                        // Redirección según rol — se hace desde JS después del intro
                        $redirect = match($row['rol']) {
                          'superadmin'            => 'superadmin/index.php',
                            'admin'               => 'admin/index.php',
                            'empleado'            => 'empleado/index.php',
                            'creador'             => 'creador/index.php',
                            default               => 'index.php',
                        };
                        ?>
                        
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Bienvenido — Team VIROX</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{--gold:#DAA520;--green:#28A680;--green-lt:#35d4a8;--n900:#020817;--n800:#0c1526;--n600:#182035;--txt:#f0f4f8;--muted:#8da0b8;--font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;}
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);height:100vh;overflow:hidden;display:flex;align-items:center;justify-content:center;}

    /* ── Fondo animado ── */
    .intro-bg{position:fixed;inset:0;z-index:0;}
    .ibg-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:56px 56px;}
    .ibg-orb{position:absolute;border-radius:50%;filter:blur(100px);}
    .iorb1{width:600px;height:600px;background:radial-gradient(circle,rgba(40,166,128,.15),transparent 70%);top:-150px;left:-150px;animation:iorf 10s ease-in-out infinite;}
    .iorb2{width:500px;height:500px;background:radial-gradient(circle,rgba(218,165,32,.1),transparent 70%);bottom:-100px;right:-100px;animation:iorf 13s ease-in-out infinite reverse;}
    @keyframes iorf{0%,100%{transform:translate(0,0)}50%{transform:translate(30px,-30px)}}

    /* ── Pantalla lock (Windows-style) ── */
    .lock-screen{
      position:fixed;inset:0;z-index:10;
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      background:rgba(2,8,23,.95);
      backdrop-filter:blur(20px);
      animation:lockFadeIn .8s ease both;
    }
    @keyframes lockFadeIn{from{opacity:0}to{opacity:1}}

    .lock-time{
      font-family:var(--font-d);font-size:5rem;font-weight:900;
      color:var(--txt);letter-spacing:4px;line-height:1;
      margin-bottom:8px;text-shadow:0 0 40px rgba(40,166,128,.3);
    }
    .lock-date{font-size:1rem;color:var(--muted);letter-spacing:2px;margin-bottom:48px;}

    .lock-avatar-wrap{
      position:relative;width:100px;height:100px;margin-bottom:16px;cursor:pointer;
    }
    .lock-avatar{width:100%;height:100%;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 30px rgba(40,166,128,.4);}
    .lock-ring{position:absolute;inset:-6px;border-radius:50%;border:1px dashed rgba(40,166,128,.4);animation:lspin 8s linear infinite;}
    @keyframes lspin{to{transform:rotate(360deg)}}

    .lock-name{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .lock-role{font-size:.78rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;margin-bottom:32px;}
    .lock-hint{font-size:.82rem;color:var(--muted);animation:pulse 2s ease-in-out infinite;}
    @keyframes pulse{0%,100%{opacity:.5}50%{opacity:1}}

    /* ── Pantalla Intro (Netflix-style) ── */
    .intro-screen{
      position:fixed;inset:0;z-index:20;
      background:var(--n900);
      display:none;flex-direction:column;align-items:center;justify-content:center;
      padding:48px 24px;
    }
    .intro-screen.show{display:flex;}

    .intro-logo{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);letter-spacing:4px;margin-bottom:40px;opacity:0;animation:introEl .6s ease .2s both;}
    .intro-avatar-big{width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid var(--green);box-shadow:0 0 40px rgba(40,166,128,.5);margin-bottom:20px;opacity:0;animation:introEl .6s ease .4s both;}
    .intro-welcome{font-family:var(--font-d);font-size:1.5rem;font-weight:700;color:var(--txt);margin-bottom:6px;opacity:0;animation:introEl .6s ease .6s both;}
    .intro-name{font-family:var(--font-d);font-size:2.2rem;font-weight:900;color:var(--gold);margin-bottom:8px;opacity:0;animation:introEl .6s ease .7s both;text-shadow:0 0 24px rgba(218,165,32,.5);}
    .intro-role{font-size:.85rem;color:var(--green-lt);letter-spacing:3px;text-transform:uppercase;margin-bottom:48px;opacity:0;animation:introEl .6s ease .85s both;}

    @keyframes introEl{from{opacity:0;transform:translateY(18px)}to{opacity:1;transform:none}}

    /* Novedades */
    .intro-news{width:100%;max-width:680px;opacity:0;animation:introEl .6s ease 1s both;}
    .intro-news-title{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:2px;margin-bottom:14px;text-align:center;}
    .news-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;}
    .news-card{
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      border-radius:14px;padding:14px;text-align:center;
      animation:introEl .5s ease both;
    }
    .news-card:nth-child(1){animation-delay:1.1s}
    .news-card:nth-child(2){animation-delay:1.2s}
    .news-card:nth-child(3){animation-delay:1.3s}
    .news-card:nth-child(4){animation-delay:1.4s}
    .news-card-ico{font-size:1.6rem;margin-bottom:6px;}
    .news-card-ttl{font-size:.78rem;font-weight:700;color:var(--txt);line-height:1.3;}

    /* Loading bar */
    .intro-loader{
      position:fixed;bottom:0;left:0;right:0;height:3px;
      background:rgba(255,255,255,.06);
      z-index:30;
    }
    .intro-loader-fill{
      height:100%;background:linear-gradient(to right,var(--green),var(--gold));
      width:0%;transition:width 3s ease;
      box-shadow:0 0 10px var(--green);
    }
    .intro-skip{
      position:fixed;bottom:24px;right:24px;z-index:30;
      padding:8px 18px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
      border-radius:99px;font-size:.78rem;color:var(--muted);cursor:pointer;
      transition:all .2s;font-family:var(--font-b);
    }
    .intro-skip:hover{background:rgba(255,255,255,.12);color:var(--txt);}
  </style>
</head>
<body>
  <div class="intro-bg">
    <div class="ibg-grid"></div>
    <div class="ibg-orb iorb1"></div>
    <div class="ibg-orb iorb2"></div>
  </div>

  <!-- Pantalla de bloqueo estilo Windows -->
  <div class="lock-screen" id="lockScreen">
    <div class="lock-time" id="lockTime">--:--</div>
    <div class="lock-date" id="lockDate">--</div>
    <div class="lock-avatar-wrap" onclick="unlockScreen()">
      <img src="<?= htmlspecialchars($row['avatar'] ?: 'assets/avatar-default.png') ?>" class="lock-avatar" alt="Avatar">
      <div class="lock-ring"></div>
    </div>
    <div class="lock-name"><?= htmlspecialchars($row['nombre']) ?></div>
    <div class="lock-role"><?= htmlspecialchars(ucfirst($row['rol'])) ?></div>
    <div class="lock-hint"><i class="fa fa-hand-pointer"></i> Haz clic para ingresar</div>
  </div>

  <!-- Pantalla intro estilo Netflix -->
  <div class="intro-screen" id="introScreen">
    <div class="intro-logo">⬡ VIROX</div>
    <img src="<?= htmlspecialchars($row['avatar'] ?: 'assets/avatar-default.png') ?>" class="intro-avatar-big" alt="Avatar">
    <div class="intro-welcome">Bienvenido de nuevo,</div>
    <div class="intro-name"><?= htmlspecialchars($row['nombre']) ?></div>
    <div class="intro-role"><?= htmlspecialchars(ucfirst($row['rol'])) ?> — Team VIROX</div>

    <?php if(!empty($novedades)): ?>
    <div class="intro-news">
      <div class="intro-news-title">📌 Novedades para ti</div>
      <div class="news-cards">
        <?php foreach($novedades as $nov): ?>
        <div class="news-card">
          <div class="news-card-ico">🔔</div>
          <div class="news-card-ttl"><?= htmlspecialchars($nov['titulo']) ?></div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="intro-loader"><div class="intro-loader-fill" id="loaderFill"></div></div>
  <button class="intro-skip" onclick="goRedirect()">Omitir →</button>

  <script>
    const REDIRECT = "<?= $redirect ?>";

    // Reloj en la pantalla de bloqueo
    function updateClock(){
      const now = new Date();
      const h = String(now.getHours()).padStart(2,'0');
      const m = String(now.getMinutes()).padStart(2,'0');
      document.getElementById('lockTime').textContent = h+':'+m;
      const days=['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
      const months=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
      document.getElementById('lockDate').textContent = days[now.getDay()]+', '+now.getDate()+' de '+months[now.getMonth()];
    }
    updateClock();
    setInterval(updateClock, 1000);

    function unlockScreen(){
      // Animación de salida pantalla bloqueo
      const lock = document.getElementById('lockScreen');
      lock.style.transition = 'opacity .5s, transform .5s';
      lock.style.opacity = '0';
      lock.style.transform = 'scale(1.05)';
      setTimeout(()=>{
        lock.style.display = 'none';
        showIntro();
      }, 500);
    }

    function showIntro(){
      document.getElementById('introScreen').classList.add('show');
      // Barra de progreso
      setTimeout(()=>{
        document.getElementById('loaderFill').style.width = '100%';
      }, 100);
      // Redirigir después de 3.5s
      setTimeout(goRedirect, 3600);
    }

    function goRedirect(){
      window.location.href = REDIRECT;
    }
  </script>
</body>
</html>
                        <?php
                        exit();
                    } else {
                        // Registrar intentos fallidos
                        $fail = $conexion->prepare("UPDATE usuarios_seguridad SET intentos_fallidos = intentos_fallidos + 1 WHERE correo=? OR identificacion=? OR telefono=?");
                        if($fail){ $fail->bind_param("sss",$input,$input,$input); $fail->execute(); $fail->close(); }
                        $error = "Contraseña incorrecta. Verifica tus credenciales.";
                    }
                }
            } else {
                $error = "No existe una cuenta con esos datos.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Iniciar Sesión — Team VIROX</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --red:#ef4444;--red-dim:rgba(239,68,68,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --r-md:14px;--r-lg:22px;--font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html,body{height:100%;font-family:var(--font-b);background:var(--n900);color:var(--txt);overflow:hidden;}
    a{text-decoration:none;color:inherit;}
    button{cursor:pointer;border:none;font-family:inherit;}

    /* ── Layout ── */
    .login-page{height:100vh;display:grid;grid-template-columns:1fr 1fr;}

    /* ── Panel izquierdo decorativo ── */
    .login-left{
      position:relative;overflow:hidden;
      background:radial-gradient(ellipse 90% 80% at 30% 40%,#0d2244 0%,var(--n900) 70%);
      display:flex;align-items:center;justify-content:center;padding:48px;
    }
    .ll-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.06) 1px,transparent 1px);background-size:52px 52px;mask-image:radial-gradient(ellipse 80% 80% at 40% 50%,black 20%,transparent 100%);}
    .lorb{position:absolute;border-radius:50%;filter:blur(90px);}
    .lorb1{width:450px;height:450px;background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-100px;left:-100px;animation:lorbf 9s ease-in-out infinite;}
    .lorb2{width:350px;height:350px;background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-80px;right:-60px;animation:lorbf 11s ease-in-out infinite reverse;}
    @keyframes lorbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}

    .ll-content{position:relative;z-index:1;text-align:center;}
    .ll-logo{font-family:var(--font-d);font-size:3rem;font-weight:900;color:var(--gold);letter-spacing:5px;text-shadow:0 0 30px rgba(218,165,32,.5);margin-bottom:10px;}
    .ll-sub{font-size:.82rem;color:var(--muted);letter-spacing:3px;text-transform:uppercase;margin-bottom:56px;}

    /* Hex decorativo */
    .ll-hex{
      width:200px;height:200px;margin:0 auto;position:relative;
      display:flex;align-items:center;justify-content:center;
    }
    .hex-ring{position:absolute;border-radius:50%;border:1px solid;}
    .hr1{inset:0;border-color:rgba(40,166,128,.25);animation:hspin 12s linear infinite;}
    .hr2{inset:20px;border-color:rgba(218,165,32,.2);animation:hspin 8s linear infinite reverse;}
    .hr3{inset:40px;border-color:rgba(40,166,128,.15);animation:hspin 5s linear infinite;}
    @keyframes hspin{to{transform:rotate(360deg)}}
    .hex-ico{font-size:3.5rem;position:relative;z-index:1;}

    .ll-features{margin-top:48px;display:flex;flex-direction:column;gap:12px;text-align:left;}
    .llfeat{display:flex;align-items:center;gap:12px;padding:12px 16px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);}
    .llfeat-ico{font-size:1.2rem;flex-shrink:0;}
    .llfeat span{font-size:.82rem;color:var(--muted);}
    .llfeat strong{display:block;font-size:.88rem;color:var(--txt);}

    /* ── Panel derecho (formulario) ── */
    .login-right{
      background:var(--n800);
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      padding:48px 52px;overflow-y:auto;
    }
    .lform-wrap{width:100%;max-width:380px;}
    .lform-title{font-family:var(--font-d);font-size:1.6rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:6px;}
    .lform-sub{font-size:.88rem;color:var(--muted);margin-bottom:32px;}

    /* Selector de método de login */
    .lmethod-tabs{display:flex;gap:6px;margin-bottom:24px;background:rgba(255,255,255,.04);padding:4px;border-radius:var(--r-md);}
    .lmt{flex:1;padding:8px;border-radius:10px;font-size:.75rem;font-weight:700;color:var(--muted);transition:all .2s;text-align:center;cursor:pointer;border:none;background:none;font-family:inherit;}
    .lmt.active{background:var(--green);color:#fff;box-shadow:0 2px 10px rgba(40,166,128,.3);}

    /* Input groups */
    .linput-group{position:relative;margin-bottom:16px;}
    .linput-group label{display:block;font-size:.75rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
    .linput-icon{position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.9rem;pointer-events:none;margin-top:10px;}
    .linput{
      width:100%;padding:12px 14px 12px 40px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
      border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.92rem;
      transition:all .2s;
    }
    .linput:focus{outline:none;border-color:var(--green);background:rgba(40,166,128,.06);box-shadow:0 0 0 3px rgba(40,166,128,.12);}
    .linput.lerror{border-color:var(--red);}

    .pw-toggle{position:absolute;right:14px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;margin-top:10px;}

    /* Opciones adicionales */
    .lextras{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;}
    .remember{display:flex;align-items:center;gap:6px;font-size:.78rem;color:var(--muted);}
    .remember input{accent-color:var(--green);}
    .forgot{font-size:.78rem;color:var(--gold);font-weight:600;transition:color .2s;}
    .forgot:hover{color:var(--gold-lt);}

    /* Botón submit */
    .lbtn{
      width:100%;padding:14px;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.95rem;
      transition:all .2s;box-shadow:0 4px 20px rgba(40,166,128,.35);letter-spacing:.5px;
    }
    .lbtn:hover{background:linear-gradient(135deg,var(--green-lt),var(--green));transform:translateY(-2px);box-shadow:0 8px 30px rgba(40,166,128,.45);}

    /* Divider */
    .ldiv{display:flex;align-items:center;gap:12px;margin:20px 0;}
    .ldiv::before,.ldiv::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.08);}
    .ldiv span{font-size:.75rem;color:var(--dim);}

    /* Google btn */
    .lbtn-google{
      width:100%;padding:12px;display:flex;align-items:center;justify-content:center;gap:12px;
      background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.12);
      border-radius:var(--r-md);color:var(--txt);font-weight:600;font-size:.88rem;
      transition:all .2s;cursor:pointer;
    }
    .lbtn-google:hover{background:rgba(255,255,255,.12);border-color:rgba(255,255,255,.25);}
    .lbtn-google img{width:20px;height:20px;}

    /* Error */
    .lerror-box{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-md);padding:12px 16px;margin-bottom:20px;font-size:.82rem;color:#fca5a5;display:flex;align-items:center;gap:8px;}

    /* Nuevo usuario banner */
    .lnuevo{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);padding:12px 16px;margin-bottom:20px;font-size:.82rem;color:var(--green-lt);display:flex;align-items:center;gap:8px;}

    .lform-footer{margin-top:20px;text-align:center;font-size:.82rem;color:var(--muted);}
    .lform-footer a{color:var(--gold);font-weight:700;}
    .lform-footer a:hover{color:var(--gold-lt);}

    @media(max-width:900px){
      .login-page{grid-template-columns:1fr;}
      .login-left{display:none;}
      .login-right{padding:32px 24px;}
    }
  </style>
</head>
<body>
<div class="login-page">

  <!-- Panel izquierdo -->
  <div class="login-left">
    <div class="ll-grid"></div>
    <div class="lorb lorb1"></div>
    <div class="lorb lorb2"></div>
    <div class="ll-content">
      <div class="ll-logo">⬡ VIROX</div>
      <div class="ll-sub">Plataforma Educativa · Ciberseguridad</div>
      <div class="ll-hex">
        <div class="hex-ring hr1"></div>
        <div class="hex-ring hr2"></div>
        <div class="hex-ring hr3"></div>
        <span class="hex-ico">🔐</span>
      </div>
      <div class="ll-features">
        <div class="llfeat"><span class="llfeat-ico">🎓</span><div><strong>Aprende a tu ritmo</strong><span>Cursos MOOC, NOOC y SPOC disponibles</span></div></div>
        <div class="llfeat"><span class="llfeat-ico">🛡</span><div><strong>Seguridad garantizada</strong><span>Acceso protegido y datos cifrados</span></div></div>
        <div class="llfeat"><span class="llfeat-ico">🤖</span><div><strong>IA personalizada</strong><span>Recomendaciones según tu perfil</span></div></div>
      </div>
    </div>
  </div>

  <!-- Panel formulario -->
  <div class="login-right">
    <div class="lform-wrap">
      <div class="lform-title">Bienvenido</div>
      <div class="lform-sub">Accede a tu cuenta de Team VIROX</div>

      <?php if($nuevo): ?>
        <div class="lnuevo"><i class="fa fa-check-circle"></i> ¡Cuenta creada exitosamente! Ahora inicia sesión.</div>
      <?php endif; ?>

      <?php if($error): ?>
        <div class="lerror-box"><i class="fa fa-triangle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
      <?php endif; ?>

      <!-- Selector de método -->
      <div class="lmethod-tabs">
        <button type="button" class="lmt active" onclick="setMethod('user','👤 Usuario',this)">👤 Usuario</button>
        <button type="button" class="lmt"         onclick="setMethod('email','📧 Correo',this)">📧 Correo</button>
        <button type="button" class="lmt"         onclick="setMethod('phone','📱 Teléfono',this)">📱 Tel.</button>
      </div>

      <form method="POST">
        <div class="linput-group">
          <label id="inputLabel">Usuario</label>
          <i class="fa fa-user linput-icon" id="inputIcon"></i>
          <input class="linput" type="text" name="user" id="userInput"
                 placeholder="nombre_usuario" required
                 autocomplete="username"
                 value="<?= htmlspecialchars($_POST['user'] ?? '') ?>">
        </div>

        <div class="linput-group">
          <label>Contraseña</label>
          <i class="fa fa-lock linput-icon"></i>
          <input class="linput" type="password" name="password" id="loginPw"
                 placeholder="••••••••" required autocomplete="current-password">
          <button type="button" class="pw-toggle" onclick="togglePw()">
            <i class="fa fa-eye" id="pwEye"></i>
          </button>
        </div>

        <div class="lextras">
          <label class="remember">
            <input type="checkbox" name="remember"> Recordarme
          </label>
          <a href="recuperar.php" class="forgot">¿Olvidaste tu contraseña?</a>
        </div>

        <button type="submit" name="login" class="lbtn">
          <i class="fa fa-sign-in-alt"></i> Ingresar
        </button>
      </form>

      <div class="ldiv"><span>o continúa con</span></div>
      <button class="lbtn-google" onclick="window.location.href='auth/google.php'">
        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google">
        Continuar con Google
      </button>

      <div class="lform-footer">
        ¿No tienes cuenta? <a href="register.php">Regístrate gratis</a>
      </div>
    </div>
  </div>
</div>

<script>
const inputEl    = document.getElementById('userInput');
const inputLabel = document.getElementById('inputLabel');
const inputIcon  = document.getElementById('inputIcon');

const methods = {
  user:  { label:'Nombre de Usuario', placeholder:'nombre_usuario',     icon:'fa-user',   type:'text' },
  email: { label:'Correo Electrónico', placeholder:'correo@ejemplo.com', icon:'fa-envelope', type:'email' },
  phone: { label:'Teléfono / WhatsApp', placeholder:'+57 300 000 0000',  icon:'fa-phone',  type:'tel' },
};

function setMethod(method, label, btn){
  const m = methods[method];
  inputLabel.textContent = m.label;
  inputEl.placeholder    = m.placeholder;
  inputEl.type           = m.type;
  inputIcon.className    = 'fa ' + m.icon + ' linput-icon';
  document.querySelectorAll('.lmt').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}

function togglePw(){
  const inp = document.getElementById('loginPw');
  const ico = document.getElementById('pwEye');
  const isText = inp.type==='text';
  inp.type = isText ? 'password' : 'text';
  ico.className = isText ? 'fa fa-eye' : 'fa fa-eye-slash';
}
</script>
</body>
</html>