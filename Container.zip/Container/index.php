<?php

include 'conexion.php';
session_start();

$cfg = [];
if (isset($conexion)) {
    $qcfg = $conexion->query(
        "SELECT clave, valor FROM configuracion
         WHERE grupo IN ('empresa','general','estadisticas','manual','contacto','hero','ia','footer')"
    );
    if ($qcfg) {
        while ($row = $qcfg->fetch_assoc()) {
            $cfg[$row['clave']] = $row['valor'];
        }
    }
}


function cfg(string $key, string $default = '', array &$cfg = []): string {
    return htmlspecialchars($cfg[$key] ?? $default, ENT_QUOTES, 'UTF-8');
}

$nombre_sistema = $cfg['nombre_sistema']  ?? 'ContainerRz';
$nombre_publico = $cfg['nombre_publico']  ?? 'Team VIROX';
$mision         = $cfg['mision']          ?? 'Democratizar el acceso a la educación en ciberseguridad y tecnología.';
$vision         = $cfg['vision']          ?? 'Ser la plataforma educativa de referencia en ciberseguridad para Latinoamérica.';
$acerca         = $cfg['acerca']          ?? 'Proyecto académico enfocado en ciberseguridad educativa, tecnología aplicada y aprendizaje interactivo.';
$manual_url     = $cfg['manual_url']      ?? 'manual.php';
$manual_titulo  = $cfg['manual_titulo']   ?? 'Manual del Usuario';
$manual_sub     = $cfg['manual_subtitulo']?? 'Aprende a usar todas las funcionalidades paso a paso.';
$stat_modulos   = $cfg['stat_modulos']    ?? '9';
$stat_roles     = $cfg['stat_roles']      ?? '7';
$stat_regiones  = $cfg['stat_regiones']   ?? '3';
$footer_copy    = $cfg['footer_copy']     ?? '© 2025 Team VIROX — Todos los derechos reservados';
$ia_titulo      = $cfg['ia_titulo']       ?? 'IA integrada al proyecto';
$ia_desc        = $cfg['ia_descripcion']  ?? 'Herramientas y desarrollos de inteligencia artificial aplicados a ciberseguridad y aprendizaje interactivo.';

// Hero slides desde config
$hero_s1_tag    = $cfg['hero_slide1_tag']    ?? '⬡ Plataforma Educativa · Tecnológica';
$hero_s1_titulo = $cfg['hero_slide1_titulo'] ?? "Bienvenidos a {$nombre_sistema}";
$hero_s1_cuerpo = $cfg['hero_slide1_cuerpo'] ?? 'Tecnología, ciberseguridad y aprendizaje interactivo en un solo ecosistema conectado.';
$hero_s2_tag    = $cfg['hero_slide2_tag']    ?? '🎯 Nuestra Misión';
$hero_s3_tag    = $cfg['hero_slide3_tag']    ?? '🔭 Nuestra Visión';

// Contacto
$email     = $cfg['email']     ?? 'contacto@teamvirox.com';
$web       = $cfg['web']       ?? 'www.teamvirox.com';
$ubicacion = $cfg['ubicacion'] ?? 'Colombia';

$servicios_preview = [];
if (isset($conexion)) {
    $qs = $conexion->query(
        "SELECT icono, titulo, definicion, slug
         FROM servicios
         WHERE activo = 1
         ORDER BY destacado DESC, orden ASC
         LIMIT 6"
    );
    if ($qs) {
        while ($s = $qs->fetch_assoc()) $servicios_preview[] = $s;
    }
}

// ── 3. PROYECTOS (preview — máx. 4) ─────────────────────────
$proyectos_preview = [];
if (isset($conexion)) {
    $qp = $conexion->query(
        "SELECT id, titulo, descripcion, estado, progreso
         FROM proyectos
         WHERE privado = 0
         ORDER BY id DESC
         LIMIT 4"
    );
    if ($qp) {
        while ($p = $qp->fetch_assoc()) $proyectos_preview[] = $p;
    }
}

$equipo_lista = [];
if (isset($conexion)) {
    $qe = $conexion->query(
        "SELECT nombre, rol, imagen
         FROM equipo
         WHERE activo = 1
         ORDER BY orden ASC"
    );
    if ($qe) {
        while ($e = $qe->fetch_assoc()) $equipo_lista[] = $e;
    }
}

$ia_tools = [];
if (isset($conexion)) {
    $qi = $conexion->query(
        "SELECT icono, nombre, descripcion
         FROM ia_herramientas
         WHERE activo = 1
         ORDER BY id ASC
         LIMIT 3"
    );
    if ($qi) {
        while ($h = $qi->fetch_assoc()) $ia_tools[] = $h;
    }
}

$publicaciones = [];
if (isset($conexion)) {
    $qpub = $conexion->query(
        "SELECT id, titulo, resumen, fecha_pub
         FROM publicaciones
         WHERE publicado = 1
         ORDER BY fecha_pub DESC
         LIMIT 3"
    );
    if ($qpub) {
        while ($pub = $qpub->fetch_assoc()) $publicaciones[] = $pub;
    }
}

// ── 7. GALERÍAS (máx. 6) ─────────────────────────────────────
$galerias = [];
if (isset($conexion)) {
    $qg = $conexion->query(
        "SELECT titulo, imagen
         FROM galerias
         WHERE activo = 1
         ORDER BY orden ASC
         LIMIT 6"
    );
    if ($qg) {
        while ($g = $qg->fetch_assoc()) $galerias[] = $g;
    }
}

// ── 8. NOTICIAS SIDEBAR (máx. 3) ─────────────────────────────
$noticias = [];
if (isset($conexion)) {
    $qn = $conexion->query(
        "SELECT titulo, fecha
         FROM noticias
         WHERE activo = 1
         ORDER BY fecha DESC
         LIMIT 3"
    );
    if ($qn) {
        while ($n = $qn->fetch_assoc()) $noticias[] = $n;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($nombre_sistema) ?> — Inicio</title>
  <link rel="stylesheet" href="style.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<!-- ══════════════════════════════════════
     HEADER
═══════════════════════════════════════ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name"><?= htmlspecialchars($nombre_sistema) ?></span>
    </a>

    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link active">Inicio</a>
      <a href="proyecto.php"  class="nav-link">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php"        class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php"        class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>

      <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span class="user-av"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? 'Usuario') ?></span>
            <i class="fa fa-chevron-down fa-xs"></i>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Cerrar sesión</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>

    <button class="burger" id="burger">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>


<!-- ══════════════════════════════════════
     HERO SLIDER — Bienvenida / Misión / Visión
═══════════════════════════════════════ -->
<section class="hero">
  <div class="hero-bg">
    <div class="hgrid"></div>
    <div class="orb orb-a"></div>
    <div class="orb orb-b"></div>
    <div class="orb orb-c"></div>
  </div>

  <div class="hslider" id="hslider">

    <!-- ─ Slide 1: Bienvenida ─ -->
    <div class="hslide hslide--on" data-i="0">
      <div class="hslide-content">
        <span class="htag"><?= htmlspecialchars($hero_s1_tag) ?></span>
        <h1 class="htitle">
          Bienvenidos a<br>
          <em class="haccent"><?= htmlspecialchars($nombre_sistema) ?></em>
        </h1>
        <p class="hsub"><?= htmlspecialchars($hero_s1_cuerpo) ?></p>
        <div class="hbtns">
          <a href="#servicios" class="btn-primary"><i class="fa fa-compass"></i> Explorar</a>
          <a href="proyecto.php" class="btn-outline">Conocer proyecto <i class="fa fa-arrow-right fa-xs"></i></a>
        </div>
        <div class="hstats">
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_modulos ?>">0</span>
            <span class="hst-l">Módulos</span>
          </div>
          <div class="hst-div"></div>
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_roles ?>">0</span>
            <span class="hst-l">Roles</span>
          </div>
          <div class="hst-div"></div>
          <div class="hst">
            <span class="hst-n" data-target="<?= (int)$stat_regiones ?>">0</span>
            <span class="hst-l">Regiones</span>
          </div>
        </div>
      </div>
    </div>

    <!-- ─ Slide 2: Misión ─ -->
    <div class="hslide hslide--mv" data-i="1">
      <div class="hslide-content hslide-content--mv">
        <span class="htag htag--gold"><?= htmlspecialchars($hero_s2_tag) ?></span>
        <h2 class="htitle htitle--mv">Misión</h2>
        <p class="hbody"><?= htmlspecialchars($mision) ?></p>
        <a href="proyecto.php#mision" class="btn-outline btn-outline--gold">
          Leer más <i class="fa fa-arrow-right fa-xs"></i>
        </a>
      </div>
      <div class="hslide-deco">
        <div class="dring dring-a"></div>
        <div class="dring dring-b"></div>
        <span class="dico">🎯</span>
      </div>
    </div>

    <!-- ─ Slide 3: Visión ─ -->
    <div class="hslide hslide--mv" data-i="2">
      <div class="hslide-content hslide-content--mv">
        <span class="htag htag--green"><?= htmlspecialchars($hero_s3_tag) ?></span>
        <h2 class="htitle htitle--mv">Visión</h2>
        <p class="hbody"><?= htmlspecialchars($vision) ?></p>
        <a href="proyecto.php#vision" class="btn-outline btn-outline--green">
          Leer más <i class="fa fa-arrow-right fa-xs"></i>
        </a>
      </div>
      <div class="hslide-deco">
        <div class="dring dring-a dring--green"></div>
        <div class="dring dring-b dring--green"></div>
        <span class="dico">🔭</span>
      </div>
    </div>

  </div>

  <!-- Controles -->
  <div class="hcontrols">
    <button class="hctrl" id="hPrev"><i class="fa fa-chevron-left"></i></button>
    <div class="hdots" id="hdots">
      <button class="hdot hdot--on" data-g="0"></button>
      <button class="hdot" data-g="1"></button>
      <button class="hdot" data-g="2"></button>
    </div>
    <button class="hctrl" id="hNext"><i class="fa fa-chevron-right"></i></button>
  </div>

  <div class="scroll-pill"><div class="scroll-ball"></div></div>
</section>


<!-- ══════════════════════════════════════
     MANUAL DEL USUARIO — Banda
═══════════════════════════════════════ -->
<div class="manual-band">
  <div class="manual-band-inner">
    <div class="mb-icon">📖</div>
    <div class="mb-text">
      <strong><?= htmlspecialchars($manual_titulo) ?></strong>
      <span><?= htmlspecialchars($manual_sub) ?></span>
    </div>
    <a href="<?= htmlspecialchars($manual_url) ?>" class="mb-btn" target="_blank">
      <i class="fa fa-book-open"></i> Ver Manual
    </a>
  </div>
</div>


<!-- ══════════════════════════════════════
     LAYOUT PRINCIPAL
═══════════════════════════════════════ -->
<div class="page-layout">

  <!-- SIDEBAR -->
  <aside class="sidebar" id="sidebar">
    <div class="sb-top">
      <span class="sb-label">Índice</span>
      <div class="sb-rule"></div>
    </div>
    <nav class="snav">
      <?php
        $items = [
          ['#servicios',    '🛠', 'Servicios'],
          ['#proyectos',    '🚀', 'Proyectos'],
          ['#equipo',       '👥', 'Equipo'],
          ['#ia',           '🤖', 'IA'],
          ['#publicaciones','📄', 'Publicaciones'],
          ['#galerias',     '🖼', 'Galerías'],
          ['#contacto',     '📞', 'Contacto'],
          ['#acerca',       'ℹ',  'Acerca de'],
        ];
        foreach ($items as [$href, $ico, $lbl]):
      ?>
      <a href="<?= $href ?>" class="snav-lnk">
        <span class="si"><?= $ico ?></span>
        <span><?= $lbl ?></span>
        <span class="sa">›</span>
      </a>
      <?php endforeach; ?>
    </nav>

    <!-- Noticias desde BD -->
    <div class="sb-news">
      <p class="sb-news-title">📌 Noticias</p>
      <?php if (!empty($noticias)): ?>
        <?php foreach ($noticias as $n): ?>
        <div class="news-row">
          <span class="ndot"></span>
          <div>
            <p class="nttl"><?= htmlspecialchars($n['titulo']) ?></p>
            <span class="ndt"><?= date('d M Y', strtotime($n['fecha'])) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="nempty">Sin noticias recientes.</p>
      <?php endif; ?>
    </div>
  </aside>


  <!-- CONTENIDO PRINCIPAL -->
  <main class="vmain">

    <!-- ════════════════════════════════════
         01 SERVICIOS — desde DB
    ════════════════════════════════════ -->
    <section id="servicios" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">01</span>
        <h2 class="vttl">Servicios</h2>
        <div class="vline"></div>
        <a href="servicios.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="vgrid g3">
        <?php if (!empty($servicios_preview)): ?>
          <?php foreach ($servicios_preview as $s): ?>
          <div class="vcard vc-serv">
            <div class="vc-ico"><?= htmlspecialchars($s['icono'] ?? '🛠') ?></div>
            <h3 class="vc-title"><?= htmlspecialchars($s['titulo']) ?></h3>
            <p class="vc-desc"><?= htmlspecialchars(mb_substr($s['definicion'] ?? '', 0, 120)) ?>...</p>
            <a href="servicios.php#<?= htmlspecialchars($s['slug']) ?>" class="vc-link">Ver servicio ›</a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <!-- Fallback si la BD está vacía -->
          <?php
            $placeholders = [
              ['🔐','Seguridad Ofensiva','Pentesting y análisis de vulnerabilidades.'],
              ['🛡','Defensa Digital',   'Hardening y protección de sistemas.'],
              ['🧠','IA Aplicada',       'Inteligencia artificial en ciberseguridad.'],
              ['🌐','Redes Seguras',     'Auditoría de infraestructuras de red.'],
              ['🔍','Análisis Forense',  'Investigación de evidencia digital.'],
              ['📊','Consultoría',       'Asesoría en seguridad informática.'],
            ];
            foreach ($placeholders as [$ico, $nm, $desc]):
          ?>
          <div class="vcard vc-serv vcard-ph">
            <div class="vc-ico"><?= $ico ?></div>
            <h3 class="vc-title"><?= $nm ?></h3>
            <p class="vc-desc"><?= $desc ?></p>
            <span class="vcbadge">Próximamente</span>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </section>


    <!-- ════════════════════════════════════
         02 PROYECTOS — desde DB
    ════════════════════════════════════ -->
    <section id="proyectos" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">02</span>
        <h2 class="vttl">Proyectos</h2>
        <div class="vline"></div>
        <a href="proyecto.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="vgrid g2">
        <?php if (!empty($proyectos_preview)): ?>
          <?php foreach ($proyectos_preview as $p):
            $estado = htmlspecialchars($p['estado'] ?? 'activo');
            $bc     = ($p['estado'] === 'completado') ? 'vb-green' : 'vb-gold';
            $label  = match($p['estado'] ?? '') {
              'completado' => 'Completado',
              'pausado'    => 'Pausado',
              'planeado'   => 'Planeado',
              default      => 'En progreso',
            };
          ?>
          <div class="proj-card">
            <div class="proj-top">
              <span class="vbadge <?= $bc ?>"><?= $label ?></span>
              <span class="proj-id">#<?= (int)$p['id'] ?></span>
            </div>
            <h3 class="proj-ttl"><?= htmlspecialchars($p['titulo']) ?></h3>
            <p class="proj-desc"><?= htmlspecialchars(mb_substr($p['descripcion'] ?? '', 0, 140)) ?>...</p>
            <a href="proyecto.php?id=<?= (int)$p['id'] ?>" class="vc-link">
              Ver proyecto <i class="fa fa-arrow-right fa-xs"></i>
            </a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty">
            <span>🚀</span>
            <p>Los proyectos se cargarán desde la base de datos.</p>
          </div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ════════════════════════════════════
         03 EQUIPO — desde DB
    ════════════════════════════════════ -->
    <section id="equipo" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">03</span>
        <h2 class="vttl">Equipo</h2>
        <div class="vline"></div>
        <a href="equipo.php" class="vmore">Ver todos ›</a>
      </div>
      <div class="team-row">
        <?php if (!empty($equipo_lista)): ?>
          <?php foreach ($equipo_lista as $e):
            $img = !empty($e['imagen'])
              ? htmlspecialchars($e['imagen'], ENT_QUOTES)
              : 'assets/avatar-default.png';
          ?>
          <div class="tmember">
            <div class="tm-wrap">
              <img src="<?= $img ?>" alt="<?= htmlspecialchars($e['nombre']) ?>" class="tm-img">
              <div class="tm-ring"></div>
              <div class="tm-glow"></div>
            </div>
            <p class="tm-name"><?= htmlspecialchars($e['nombre']) ?></p>
            <span class="tm-role"><?= htmlspecialchars($e['rol']) ?></span>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty">
            <span>👥</span>
            <p>El equipo se cargará desde la base de datos.</p>
          </div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ════════════════════════════════════
         04 IA — desde DB
    ════════════════════════════════════ -->
    <section id="ia" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">04</span>
        <h2 class="vttl">Inteligencia Artificial</h2>
        <div class="vline"></div>
        <a href="ia.php" class="vmore">Explorar ›</a>
      </div>

      <div class="ia-hero">
        <div class="ia-hero-txt">
          <h3><?= htmlspecialchars($ia_titulo) ?></h3>
          <p><?= htmlspecialchars($ia_desc) ?></p>
          <a href="ia.php" class="btn-primary btn-sm">
            <i class="fa fa-robot"></i> Explorar IA
          </a>
        </div>
        <div class="ia-anim">
          <div class="ia-c ia-c1"></div>
          <div class="ia-c ia-c2"></div>
          <div class="ia-c ia-c3"></div>
          <span class="ia-ico">🤖</span>
        </div>
      </div>

      <?php if (!empty($ia_tools)): ?>
      <div class="vgrid g3" style="margin-top:20px">
        <?php foreach ($ia_tools as $h): ?>
        <div class="vcard vc-ia">
          <div class="vc-ico"><?= htmlspecialchars($h['icono'] ?? '🤖') ?></div>
          <h3 class="vc-title"><?= htmlspecialchars($h['nombre']) ?></h3>
          <p class="vc-desc"><?= htmlspecialchars($h['descripcion']) ?></p>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </section>


    <!-- ════════════════════════════════════
         05 PUBLICACIONES — desde DB
    ════════════════════════════════════ -->
    <section id="publicaciones" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">05</span>
        <h2 class="vttl">Publicaciones</h2>
        <div class="vline"></div>
        <a href="publicaciones.php" class="vmore">Ver todas ›</a>
      </div>
      <div class="vgrid g3">
        <?php if (!empty($publicaciones)): ?>
          <?php foreach ($publicaciones as $pub):
            $fecha = !empty($pub['fecha_pub'])
              ? date('d M Y', strtotime($pub['fecha_pub']))
              : '–';
          ?>
          <div class="pub-card">
            <span class="pub-date"><?= $fecha ?></span>
            <h3 class="pub-ttl"><?= htmlspecialchars($pub['titulo']) ?></h3>
            <p class="pub-desc"><?= htmlspecialchars(mb_substr($pub['resumen'] ?? '', 0, 110)) ?>...</p>
            <a href="publicaciones.php?id=<?= (int)$pub['id'] ?>" class="vc-link">Leer más ›</a>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="vempty">
            <span>📄</span>
            <p>Las publicaciones se cargarán desde la base de datos.</p>
          </div>
        <?php endif; ?>
      </div>
    </section>


    <!-- ════════════════════════════════════
         06 GALERÍAS — desde DB
    ════════════════════════════════════ -->
    <section id="galerias" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">06</span>
        <h2 class="vttl">Galerías</h2>
        <div class="vline"></div>
        <a href="galerias.php" class="vmore">Ver todas ›</a>
      </div>
      <div class="gmosaic">
        <?php if (!empty($galerias)): ?>
          <?php foreach ($galerias as $i => $g):
            $img = htmlspecialchars($g['imagen'], ENT_QUOTES);
            $tit = htmlspecialchars($g['titulo'],  ENT_QUOTES);
            $cls = ($i === 0) ? 'gmi gmi-big' : 'gmi';
          ?>
          <div class="<?= $cls ?>" onclick="openGal('<?= $img ?>','<?= $tit ?>')">
            <img src="<?= $img ?>" alt="<?= $tit ?>" loading="lazy">
            <div class="gmi-ov">
              <span class="gmi-tit"><?= $tit ?></span>
              <i class="fa fa-expand"></i>
            </div>
          </div>
          <?php endforeach; ?>
        <?php else: ?>
          <?php for ($i = 0; $i < 6; $i++):
            $cls = ($i === 0) ? 'gmi gmi-big gmi-empty' : 'gmi gmi-empty';
          ?>
          <div class="<?= $cls ?>"><span>🖼</span></div>
          <?php endfor; ?>
        <?php endif; ?>
      </div>
    </section>


    <!-- ════════════════════════════════════
         07 CONTACTO — desde DB
    ════════════════════════════════════ -->
    <section id="contacto" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">07</span>
        <h2 class="vttl">Contacto</h2>
        <div class="vline"></div>
      </div>
      <div class="contact-strip">
        <?php
          $contact_items = [
            ['📧', 'Email',   $email],
            ['🌐', 'Web',     $web],
            ['📍', 'Lugar',   $ubicacion],
          ];
          foreach ($contact_items as [$ico, $lbl, $val]):
        ?>
        <div class="ci">
          <span class="ci-ico"><?= $ico ?></span>
          <div>
            <span class="ci-lbl"><?= $lbl ?></span>
            <span class="ci-val"><?= htmlspecialchars($val) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
        <a href="contacto.php" class="btn-primary">
          <i class="fa fa-paper-plane"></i> Ir a contacto
        </a>
      </div>
    </section>


    <!-- ════════════════════════════════════
         08 ACERCA DE — desde DB
    ════════════════════════════════════ -->
    <section id="acerca" class="vsec">
      <div class="vsec-hd">
        <span class="vnum">08</span>
        <h2 class="vttl">Acerca de</h2>
        <div class="vline"></div>
      </div>
      <div class="about-card">
        <div class="about-hex">⬡</div>
        <div class="about-body">
          <h3><?= htmlspecialchars($nombre_publico) ?></h3>
          <p><?= htmlspecialchars($acerca) ?></p>
        </div>
      </div>
    </section>

  </main>
</div>


<!-- MODAL GALERÍA -->
<div class="vmodal" id="galModal">
  <div class="vmodal-box">
    <button class="vmodal-close" onclick="closeGal()">
      <i class="fa fa-times"></i>
    </button>
    <img id="galImg" src="" alt="">
    <p id="galTitle" class="vmodal-cap"></p>
  </div>
</div>


<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name"><?= htmlspecialchars($nombre_publico) ?></span>
    </div>
    <p class="footer-copy"><?= htmlspecialchars($footer_copy) ?></p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a>
      <a href="proyecto.php">Proyecto</a>
      <a href="contacto.php">Contacto</a>
      <a href="<?= htmlspecialchars($manual_url) ?>">Manual</a>
    </nav>
  </div>
</footer>


<script>
/* ── Header scroll ──────────────────────────────────────────── */
window.addEventListener('scroll', () =>
  document.getElementById('siteHeader').classList.toggle('hdr-on', scrollY > 40));

/* ── Burger ─────────────────────────────────────────────────── */
document.getElementById('burger').addEventListener('click', function () {
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Hero Slider ─────────────────────────────────────────────── */
(function () {
  const slides = document.querySelectorAll('.hslide');
  const dots   = document.querySelectorAll('.hdot');
  let cur = 0, timer;

  function go(n) {
    slides[cur].classList.remove('hslide--on');
    dots[cur].classList.remove('hdot--on');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('hslide--on');
    dots[cur].classList.add('hdot--on');
  }
  function auto()  { timer = setInterval(() => go(cur + 1), 6000); }
  function reset() { clearInterval(timer); auto(); }

  document.getElementById('hNext').onclick = () => { go(cur + 1); reset(); };
  document.getElementById('hPrev').onclick = () => { go(cur - 1); reset(); };
  dots.forEach(d => d.addEventListener('click', () => { go(+d.dataset.g); reset(); }));

  // Swipe táctil
  let tx = 0;
  const sl = document.getElementById('hslider');
  sl.addEventListener('touchstart', e => tx = e.touches[0].clientX, { passive: true });
  sl.addEventListener('touchend',   e => {
    const dx = e.changedTouches[0].clientX - tx;
    if (Math.abs(dx) > 50) { go(dx < 0 ? cur + 1 : cur - 1); reset(); }
  }, { passive: true });

  auto();
})();

/* ── Contadores animados ─────────────────────────────────────── */
document.querySelectorAll('.hst-n').forEach(el => {
  new IntersectionObserver(entries => {
    if (!entries[0].isIntersecting) return;
    const end = +el.dataset.target;
    let n = 0;
    const t = setInterval(() => {
      n += Math.ceil(end / 30);
      if (n >= end) { n = end; clearInterval(t); }
      el.textContent = n;
    }, 40);
  }, { threshold: 1 }).observe(el);
});

/* ── Sidebar activo al hacer scroll ─────────────────────────── */
document.querySelectorAll('section[id]').forEach(sec => {
  new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) {
      document.querySelectorAll('.snav-lnk').forEach(l => l.classList.remove('snav-on'));
      const a = document.querySelector(`.snav-lnk[href="#${sec.id}"]`);
      if (a) a.classList.add('snav-on');
    }
  }, { rootMargin: '-30% 0px -60% 0px' }).observe(sec);
});

/* ── Modal galería ───────────────────────────────────────────── */
function openGal(src, title) {
  document.getElementById('galImg').src = src;
  document.getElementById('galTitle').textContent = title;
  document.getElementById('galModal').classList.add('vmodal-on');
  document.body.style.overflow = 'hidden';
}
function closeGal() {
  document.getElementById('galModal').classList.remove('vmodal-on');
  document.body.style.overflow = '';
}
document.getElementById('galModal').addEventListener('click', function (e) {
  if (e.target === this) closeGal();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeGal(); });

/* ── Reveal de secciones ─────────────────────────────────────── */
document.querySelectorAll('.vsec').forEach(s => {
  new IntersectionObserver(entries => {
    if (entries[0].isIntersecting) s.classList.add('vsec-in');
  }, { threshold: 0.08 }).observe(s);
});
</script>
</body>
</html>