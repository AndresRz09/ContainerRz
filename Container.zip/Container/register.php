<?php
include 'conexion.php';
session_start();

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {

    // ── Sanitización ──────────────────────────────────────────
    $nombre          = htmlspecialchars(trim($_POST['nombre']         ?? ''), ENT_QUOTES);
    $apellido        = htmlspecialchars(trim($_POST['apellido']       ?? ''), ENT_QUOTES);
    $username        = htmlspecialchars(trim($_POST['username']       ?? ''), ENT_QUOTES);
    $tipo_doc        = $_POST['tipo_documento'] ?? '';
    $identificacion  = preg_replace('/[^a-zA-Z0-9\-]/', '', trim($_POST['identificacion'] ?? ''));
    $fecha_exp       = $_POST['fecha_expedicion'] ?? '';
    $fecha_nac       = $_POST['fecha_nacimiento'] ?? '';
    $genero          = $_POST['genero'] ?? '';
    $pais            = htmlspecialchars(trim($_POST['pais']           ?? ''), ENT_QUOTES);
    $ciudad          = htmlspecialchars(trim($_POST['ciudad']         ?? ''), ENT_QUOTES);
    $correo          = filter_var(trim($_POST['correo'] ?? ''), FILTER_SANITIZE_EMAIL);
    $telefono        = preg_replace('/[^0-9\+\-\s]/', '', trim($_POST['telefono'] ?? ''));
    $tipo_usuario    = $_POST['tipo_usuario'] ?? 'cliente';
    $ocupacion       = htmlspecialchars(trim($_POST['ocupacion']      ?? ''), ENT_QUOTES);
    $institucion     = htmlspecialchars(trim($_POST['institucion']    ?? ''), ENT_QUOTES);
    $nivel_edu       = $_POST['nivel_educativo'] ?? '';
    $intereses       = $_POST['intereses']       ?? [];
    $password        = $_POST['password']        ?? '';
    $confirmar       = $_POST['confirmar']        ?? '';
    $terminos        = isset($_POST['terminos']);

    $errores = [];

    // ── Validaciones ──────────────────────────────────────────
    if (!$terminos) $errores[] = "Debes aceptar los términos y condiciones.";
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "El correo electrónico no es válido.";
    if (strlen($username) < 4) $errores[] = "El nombre de usuario debe tener al menos 4 caracteres.";
    if (!preg_match('/^[a-zA-Z0-9_\.]+$/', $username)) $errores[] = "El usuario solo puede contener letras, números, puntos y guiones bajos.";

    // Validación de contraseña robusta
    if ($password !== $confirmar)           $errores[] = "Las contraseñas no coinciden.";
    if (strlen($password) < 8)              $errores[] = "La contraseña debe tener al menos 8 caracteres.";
    if (!preg_match('/[A-Z]/', $password))  $errores[] = "La contraseña debe incluir al menos una mayúscula.";
    if (!preg_match('/[0-9]/', $password))  $errores[] = "La contraseña debe incluir al menos un número.";
    if (!preg_match('/[\W_]/', $password))  $errores[] = "La contraseña debe incluir al menos un símbolo.";

    // Validación de fecha: expedición no puede ser antes del nacimiento
    if ($fecha_nac && $fecha_exp) {
        $fn  = new DateTime($fecha_nac);
        $fe  = new DateTime($fecha_exp);
        $now = new DateTime();
        $edad = $now->diff($fn)->y;

        if ($fe <= $fn)             $errores[] = "La fecha de expedición no puede ser anterior a la fecha de nacimiento.";
        if ($fe > $now)             $errores[] = "La fecha de expedición no puede ser futura.";
        if ($edad < 13)             $errores[] = "Debes tener al menos 13 años para registrarte.";

        // CC solo se expide a mayores de 14
        if ($tipo_doc === 'CC' && $edad < 14) $errores[] = "La Cédula de Ciudadanía solo se expide a mayores de 14 años.";

        // Expedición mínima coherente: al menos 1 año después del nacimiento
        $diff_exp_nac = $fe->diff($fn)->y;
        if ($diff_exp_nac < 1) $errores[] = "La fecha de expedición no es coherente con la fecha de nacimiento.";
    }

    if (empty($errores)) {
        // ── Verificar duplicados ─────────────────────────────
        $check = $conexion->prepare(
            "SELECT id FROM usuarios WHERE identificacion=? OR correo=? OR username=? LIMIT 1"
        );
        $check->bind_param("sss", $identificacion, $correo, $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $errores[] = "Ya existe una cuenta con ese documento, correo o nombre de usuario.";
        } else {
            $hash      = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $intereses_str = implode(',', array_map('htmlspecialchars', $intereses));
            $avatar    = 'assets/avatar-default.png';

            $sql = "INSERT INTO usuarios
                    (nombre, apellido, username, tipo_documento, identificacion,
                     fecha_expedicion, fecha_nacimiento, genero, pais, ciudad,
                     correo, telefono, tipo_usuario, ocupacion, institucion,
                     nivel_educativo, intereses, avatar, rol, activo, fecha_registro)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1, NOW())";

            $rol_default = 'cliente';
            $stmt = $conexion->prepare($sql);
            $stmt->bind_param(
                "sssssssssssssssssss",
                $nombre, $apellido, $username, $tipo_doc, $identificacion,
                $fecha_exp, $fecha_nac, $genero, $pais, $ciudad,
                $correo, $telefono, $tipo_usuario, $ocupacion, $institucion,
                $nivel_edu, $intereses_str, $avatar, $rol_default
            );

            if ($stmt->execute()) {
                $uid = $conexion->insert_id;

                // Insertar seguridad
                $s2 = $conexion->prepare(
                    "INSERT INTO usuarios_seguridad (usuario_id, identificacion, correo, telefono, password_hash)
                     VALUES (?,?,?,?,?)"
                );
                $s2->bind_param("issss", $uid, $identificacion, $correo, $telefono, $hash);
                $s2->execute();

                $_SESSION['user_id']  = $uid;
                $_SESSION['user_name']= $nombre . ' ' . $apellido;
                $_SESSION['rol']      = $rol_default;
                $_SESSION['avatar']   = $avatar;
                $_SESSION['new_user'] = true;

                header("Location: login.php?nuevo=1");
                exit();
            } else {
                $errores[] = "Error al guardar el registro. Intenta de nuevo.";
            }
        }
    }

    if (!empty($errores)) $error = implode('|', $errores);
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Crear Cuenta — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ── Variables ── */
    :root {
      --n900:#020817; --n800:#0c1526; --n700:#111827; --n600:#182035; --n500:#1e2d47;
      --gold:#DAA520; --gold-lt:#f0c840; --gold-dim:rgba(218,165,32,.14);
      --green:#28A680; --green-lt:#35d4a8; --green-dim:rgba(40,166,128,.14);
      --red:#ef4444; --red-dim:rgba(239,68,68,.14);
      --txt:#f0f4f8; --muted:#8da0b8; --dim:#526278;
      --r-md:14px; --r-lg:22px; --r-xl:32px;
      --font-d:'Orbitron',monospace; --font-b:'Syne',sans-serif;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html,body{height:100%;font-family:var(--font-b);background:var(--n900);color:var(--txt);overflow-x:hidden;}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);} ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;}
    button{cursor:pointer;border:none;font-family:inherit;}

    /* ── Layout ── */
    .reg-page {
      min-height:100vh;
      display:grid;
      grid-template-columns:1fr 1fr;
    }

    /* ── Panel izquierdo decorativo ── */
    .reg-side {
      background:radial-gradient(ellipse 90% 80% at 30% 40%, #0d2244 0%, var(--n900) 70%);
      position:relative; overflow:hidden;
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      padding:48px;
    }
    .reg-side-grid {
      position:absolute; inset:0;
      background-image:linear-gradient(rgba(40,166,128,.06) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.06) 1px,transparent 1px);
      background-size:48px 48px;
      mask-image:radial-gradient(ellipse 80% 80% at 40% 50%,black 20%,transparent 100%);
    }
    .reg-side-orb {
      position:absolute; border-radius:50%; filter:blur(80px);
    }
    .orb1{width:400px;height:400px;background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);top:-100px;left:-100px;animation:orbf 8s ease-in-out infinite;}
    .orb2{width:300px;height:300px;background:radial-gradient(circle,rgba(218,165,32,.12),transparent 70%);bottom:-80px;right:-60px;animation:orbf 11s ease-in-out infinite reverse;}
    @keyframes orbf{0%,100%{transform:translate(0,0)}50%{transform:translate(20px,-20px)}}

    .reg-side-content { position:relative; z-index:1; text-align:center; }
    .reg-logo { font-family:var(--font-d); font-size:2.4rem; font-weight:900; color:var(--gold); letter-spacing:4px; text-shadow:0 0 24px rgba(218,165,32,.5); margin-bottom:8px; }
    .reg-logo-sub { font-size:.82rem; color:var(--muted); letter-spacing:3px; text-transform:uppercase; margin-bottom:48px; }

    .reg-steps { display:flex; flex-direction:column; gap:0; width:260px; }
    .rstep {
      display:flex; align-items:center; gap:16px;
      padding:16px 20px;
      border-radius:var(--r-md);
      transition:background .3s;
      cursor:default;
    }
    .rstep.active { background:rgba(40,166,128,.12); border:1px solid rgba(40,166,128,.25); }
    .rstep-n {
      width:36px; height:36px; border-radius:50%; flex-shrink:0;
      display:flex; align-items:center; justify-content:center;
      font-family:var(--font-d); font-size:.78rem; font-weight:700;
      background:var(--n600); border:1.5px solid var(--dim); color:var(--dim);
      transition:all .3s;
    }
    .rstep.active .rstep-n { background:var(--green); border-color:var(--green); color:#fff; box-shadow:0 0 12px rgba(40,166,128,.5); }
    .rstep.done  .rstep-n  { background:var(--gold);  border-color:var(--gold);  color:#000; }
    .rstep-info strong { display:block; font-size:.9rem; font-weight:700; color:var(--txt); }
    .rstep-info span   { font-size:.75rem; color:var(--muted); }
    .rstep.active .rstep-info strong { color:var(--green-lt); }

    .rstep-connector { width:2px; height:20px; background:rgba(255,255,255,.08); margin-left:calc(18px + 8px); }
    .rstep-connector.done-line { background:var(--gold); }

    /* ── Panel derecho (formulario) ── */
    .reg-form-panel {
      background:var(--n800);
      display:flex; flex-direction:column;
      overflow-y:auto;
      padding:48px 52px;
    }
    .reg-form-header { margin-bottom:32px; }
    .reg-form-header h1 { font-family:var(--font-d); font-size:1.5rem; font-weight:700; color:var(--txt); letter-spacing:1px; margin-bottom:6px; }
    .reg-form-header p  { font-size:.88rem; color:var(--muted); }

    /* Progress bar */
    .progress-bar { height:3px; background:rgba(255,255,255,.08); border-radius:99px; margin-bottom:32px; }
    .progress-fill { height:100%; background:linear-gradient(to right,var(--green),var(--gold)); border-radius:99px; transition:width .4s ease; }

    /* ── Pasos del formulario ── */
    .fstep { display:none; animation:stepIn .4s ease both; }
    .fstep.active { display:block; }
    @keyframes stepIn { from{opacity:0;transform:translateX(16px)} to{opacity:1;transform:none} }

    .fstep-title { font-family:var(--font-d); font-size:.88rem; color:var(--green); letter-spacing:2px; text-transform:uppercase; margin-bottom:20px; padding-bottom:10px; border-bottom:1px solid rgba(255,255,255,.07); }

    /* ── Inputs ── */
    .frow { display:grid; gap:14px; margin-bottom:14px; }
    .frow-2 { grid-template-columns:1fr 1fr; }
    .frow-3 { grid-template-columns:1fr 1fr 1fr; }

    .fgroup { display:flex; flex-direction:column; gap:5px; }
    .fgroup label { font-size:.75rem; font-weight:700; color:var(--muted); text-transform:uppercase; letter-spacing:1px; }
    .fgroup label span { color:var(--red); margin-left:2px; }

    .finput {
      padding:11px 14px;
      background:rgba(255,255,255,.05);
      border:1px solid rgba(255,255,255,.1);
      border-radius:var(--r-md);
      color:var(--txt);
      font-family:var(--font-b);
      font-size:.9rem;
      transition:border-color .2s, background .2s, box-shadow .2s;
      width:100%;
    }
    .finput:focus { outline:none; border-color:var(--green); background:rgba(40,166,128,.06); box-shadow:0 0 0 3px rgba(40,166,128,.12); }
    .finput.error { border-color:var(--red); }
    select.finput option { background:var(--n700); }

    /* Password strength */
    .pw-strength { margin-top:6px; }
    .pw-bars { display:flex; gap:4px; margin-bottom:4px; }
    .pw-bar { flex:1; height:3px; border-radius:99px; background:rgba(255,255,255,.1); transition:background .3s; }
    .pw-bar.weak   { background:#ef4444; }
    .pw-bar.medium { background:var(--gold); }
    .pw-bar.strong { background:var(--green); }
    .pw-label { font-size:.7rem; color:var(--muted); }

    /* Checkboxes intereses */
    .interests-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
    .interest-item input { display:none; }
    .interest-item label {
      display:flex; align-items:center; gap:8px;
      padding:8px 12px; border-radius:var(--r-md);
      background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
      font-size:.8rem; cursor:pointer; transition:all .2s;
    }
    .interest-item input:checked + label {
      background:var(--green-dim); border-color:var(--green); color:var(--green-lt);
    }

    /* Radio roles */
    .roles-grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; }
    .role-item input { display:none; }
    .role-item label {
      display:flex; flex-direction:column; align-items:center; gap:6px;
      padding:16px 12px; border-radius:var(--r-lg);
      background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
      text-align:center; cursor:pointer; transition:all .2s;
    }
    .role-item label .role-ico { font-size:1.8rem; }
    .role-item label .role-nm  { font-size:.82rem; font-weight:700; color:var(--txt); }
    .role-item label .role-desc{ font-size:.72rem; color:var(--muted); }
    .role-item input:checked + label { background:var(--green-dim); border-color:var(--green); }
    .role-item input:checked + label .role-nm { color:var(--green-lt); }

    /* File upload */
    .file-zone {
      border:2px dashed rgba(255,255,255,.15); border-radius:var(--r-lg);
      padding:24px; text-align:center; cursor:pointer;
      transition:border-color .2s, background .2s;
    }
    .file-zone:hover { border-color:var(--green); background:var(--green-dim); }
    .file-zone input { display:none; }
    .file-zone-ico { font-size:2rem; margin-bottom:8px; }
    .file-zone p    { font-size:.82rem; color:var(--muted); }
    .file-zone small{ font-size:.72rem; color:var(--dim); }
    #avatar-preview { width:80px; height:80px; border-radius:50%; object-fit:cover; border:3px solid var(--green); display:none; margin:10px auto 0; }

    /* Terms */
    .terms-row { display:flex; align-items:flex-start; gap:10px; margin-top:8px; }
    .terms-row input[type=checkbox] { width:16px; height:16px; accent-color:var(--green); flex-shrink:0; margin-top:2px; }
    .terms-row label { font-size:.8rem; color:var(--muted); line-height:1.5; }
    .terms-row a { color:var(--gold); font-weight:600; }

    /* ── Botones de navegación ── */
    .fnav { display:flex; gap:12px; margin-top:24px; }
    .btn-prev { flex:1; padding:13px; background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.1); color:var(--muted); border-radius:var(--r-md); font-weight:700; font-size:.9rem; transition:all .2s; }
    .btn-prev:hover { background:rgba(255,255,255,.1); color:var(--txt); }
    .btn-next { flex:2; padding:13px; background:var(--green); color:#fff; border-radius:var(--r-md); font-weight:700; font-size:.9rem; transition:all .2s; box-shadow:0 4px 18px rgba(40,166,128,.3); }
    .btn-next:hover { background:var(--green-lt); transform:translateY(-2px); }
    .btn-submit { flex:2; padding:13px; background:linear-gradient(135deg,var(--green),var(--gold)); color:#fff; border-radius:var(--r-md); font-weight:800; font-size:.9rem; transition:all .2s; box-shadow:0 4px 24px rgba(40,166,128,.35); }
    .btn-submit:hover { transform:translateY(-2px); box-shadow:0 8px 32px rgba(40,166,128,.45); }

    /* Google btn */
    .google-divider { display:flex; align-items:center; gap:12px; margin:20px 0; }
    .google-divider::before,.google-divider::after { content:''; flex:1; height:1px; background:rgba(255,255,255,.08); }
    .google-divider span { font-size:.78rem; color:var(--dim); white-space:nowrap; }
    .btn-google {
      width:100%; padding:12px; display:flex; align-items:center; justify-content:center; gap:12px;
      background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.12);
      border-radius:var(--r-md); color:var(--txt); font-weight:600; font-size:.9rem;
      transition:all .2s; cursor:pointer;
    }
    .btn-google:hover { background:rgba(255,255,255,.12); border-color:rgba(255,255,255,.25); }
    .btn-google img { width:20px; height:20px; }

    /* ── Errores ── */
    .error-box {
      background:var(--red-dim); border:1px solid rgba(239,68,68,.3);
      border-radius:var(--r-md); padding:14px 16px; margin-bottom:20px;
    }
    .error-box ul { list-style:none; display:flex; flex-direction:column; gap:5px; }
    .error-box li { font-size:.82rem; color:#fca5a5; display:flex; align-items:flex-start; gap:6px; }
    .error-box li::before { content:'✕'; color:var(--red); flex-shrink:0; }

    /* ── Footer del form ── */
    .reg-footer { margin-top:20px; text-align:center; font-size:.82rem; color:var(--muted); }
    .reg-footer a { color:var(--gold); font-weight:700; }
    .reg-footer a:hover { color:var(--gold-lt); }

    /* Responsive */
    @media(max-width:900px){
      .reg-page { grid-template-columns:1fr; }
      .reg-side  { display:none; }
      .reg-form-panel { padding:32px 24px; }
    }
  </style>
</head>
<body>

<div class="reg-page">

  <!-- ══ PANEL IZQUIERDO ══ -->
  <div class="reg-side">
    <div class="reg-side-grid"></div>
    <div class="reg-side-orb orb1"></div>
    <div class="reg-side-orb orb2"></div>
    <div class="reg-side-content">
      <div class="reg-logo">⬡ VIROX</div>
      <div class="reg-logo-sub">Plataforma Educativa</div>

      <div class="reg-steps" id="sideSteps">
        <div class="rstep active" data-step="0">
          <div class="rstep-n">01</div>
          <div class="rstep-info">
            <strong>Información Personal</strong>
            <span>Datos de identificación</span>
          </div>
        </div>
        <div class="rstep-connector"></div>

        <div class="rstep" data-step="1">
          <div class="rstep-n">02</div>
          <div class="rstep-info">
            <strong>Información Profesional</strong>
            <span>Ocupación y educación</span>
          </div>
        </div>
        <div class="rstep-connector"></div>

        <div class="rstep" data-step="2">
          <div class="rstep-n">03</div>
          <div class="rstep-info">
            <strong>Rol e Intereses</strong>
            <span>Tipo de cuenta y temas</span>
          </div>
        </div>
        <div class="rstep-connector"></div>

        <div class="rstep" data-step="3">
          <div class="rstep-n">04</div>
          <div class="rstep-info">
            <strong>Redes y Contacto</strong>
            <span>Perfil en redes sociales</span>
          </div>
        </div>
        <div class="rstep-connector"></div>

        <div class="rstep" data-step="4">
          <div class="rstep-n">05</div>
          <div class="rstep-info">
            <strong>Seguridad y Acceso</strong>
            <span>Credenciales y foto</span>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- ══ PANEL FORMULARIO ══ -->
  <div class="reg-form-panel">
    <div class="reg-form-header">
      <h1>Crear cuenta</h1>
      <p>Paso <span id="stepLabel">1</span> de 5</p>
    </div>

    <div class="progress-bar">
      <div class="progress-fill" id="progressFill" style="width:20%"></div>
    </div>

    <?php if (!empty($error)): ?>
      <div class="error-box">
        <ul>
          <?php foreach(explode('|', $error) as $e): ?>
            <li><?= htmlspecialchars($e) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="POST" id="regForm" enctype="multipart/form-data">

      <!-- ── PASO 1: Información Personal ── -->
      <div class="fstep active" id="step-0">
        <div class="fstep-title">① Información Personal</div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Nombre(s) <span>*</span></label>
            <input class="finput" type="text" name="nombre" placeholder="Ej: Andrés Felipe" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label>Apellido(s) <span>*</span></label>
            <input class="finput" type="text" name="apellido" placeholder="Ej: Rozo Garzón" required value="<?= htmlspecialchars($_POST['apellido'] ?? '') ?>">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Tipo de Documento <span>*</span></label>
            <select class="finput" name="tipo_documento" id="tipoDoc" required>
              <option value="">Seleccionar...</option>
              <option value="CC">Cédula de Ciudadanía</option>
              <option value="TI">Tarjeta de Identidad</option>
              <option value="CE">Cédula de Extranjería</option>
              <option value="NIT">NIT (Empresa)</option>
              <option value="PASAPORTE">Pasaporte</option>
              <option value="DNI">DNI</option>
            </select>
          </div>
          <div class="fgroup">
            <label>Número de Documento <span>*</span></label>
            <input class="finput" type="text" name="identificacion" placeholder="Ej: 1072642850" required value="<?= htmlspecialchars($_POST['identificacion'] ?? '') ?>">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Fecha de Nacimiento <span>*</span></label>
            <input class="finput" type="date" name="fecha_nacimiento" id="fechaNac" required max="<?= date('Y-m-d', strtotime('-13 years')) ?>" value="<?= htmlspecialchars($_POST['fecha_nacimiento'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label>Fecha de Expedición <span>*</span></label>
            <input class="finput" type="date" name="fecha_expedicion" id="fechaExp" required max="<?= date('Y-m-d') ?>" value="<?= htmlspecialchars($_POST['fecha_expedicion'] ?? '') ?>">
          </div>
        </div>

        <div class="frow frow-3">
          <div class="fgroup">
            <label>Género</label>
            <select class="finput" name="genero">
              <option value="">Prefiero no decir</option>
              <option value="M">Masculino</option>
              <option value="F">Femenino</option>
              <option value="NB">No binario</option>
              <option value="O">Otro</option>
            </select>
          </div>
          <div class="fgroup">
            <label>País <span>*</span></label>
            <input class="finput" type="text" name="pais" placeholder="Colombia" required value="<?= htmlspecialchars($_POST['pais'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label>Ciudad</label>
            <input class="finput" type="text" name="ciudad" placeholder="Bogotá" value="<?= htmlspecialchars($_POST['ciudad'] ?? '') ?>">
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Correo Electrónico <span>*</span></label>
            <input class="finput" type="email" name="correo" placeholder="correo@ejemplo.com" required value="<?= htmlspecialchars($_POST['correo'] ?? '') ?>">
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Teléfono / WhatsApp</label>
            <input class="finput" type="tel" name="telefono" placeholder="+57 300 000 0000" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
          </div>
        </div>

        <div class="fnav">
          <button type="button" class="btn-next" onclick="nextStep(0)">Continuar <i class="fa fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- ── PASO 2: Información Profesional ── -->
      <div class="fstep" id="step-1">
        <div class="fstep-title">② Información Profesional</div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Ocupación</label>
            <input class="finput" type="text" name="ocupacion" placeholder="Ej: Ingeniero de Sistemas" value="<?= htmlspecialchars($_POST['ocupacion'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label>Institución / Empresa</label>
            <input class="finput" type="text" name="institucion" placeholder="Ej: UNIMINUTO" value="<?= htmlspecialchars($_POST['institucion'] ?? '') ?>">
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Nivel Educativo</label>
            <select class="finput" name="nivel_educativo">
              <option value="">Seleccionar...</option>
              <option value="primaria">Primaria</option>
              <option value="bachillerato">Bachillerato</option>
              <option value="tecnico">Técnico / Tecnólogo</option>
              <option value="universitario">Universitario (en curso)</option>
              <option value="pregrado">Pregrado completo</option>
              <option value="especializacion">Especialización</option>
              <option value="maestria">Maestría</option>
              <option value="doctorado">Doctorado</option>
            </select>
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Experiencia en Ciberseguridad</label>
            <select class="finput" name="experiencia_cyber">
              <option value="ninguna">Ninguna — soy principiante</option>
              <option value="basica">Básica — conozco conceptos generales</option>
              <option value="intermedia">Intermedia — he trabajado en el área</option>
              <option value="avanzada">Avanzada — soy profesional</option>
            </select>
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Descripción / Bio profesional</label>
            <textarea class="finput" name="bio" rows="3" placeholder="Cuéntanos brevemente sobre ti y tus objetivos..."><?= htmlspecialchars($_POST['bio'] ?? '') ?></textarea>
          </div>
        </div>

        <!-- Certificaciones actuales -->
        <div class="frow">
          <div class="fgroup">
            <label>Certificaciones actuales (si tienes)</label>
            <input class="finput" type="text" name="certificaciones" placeholder="Ej: CompTIA Security+, CEH, OSCP..." value="<?= htmlspecialchars($_POST['certificaciones'] ?? '') ?>">
          </div>
        </div>

        <div class="fnav">
          <button type="button" class="btn-prev" onclick="prevStep(1)"><i class="fa fa-arrow-left"></i> Atrás</button>
          <button type="button" class="btn-next" onclick="nextStep(1)">Continuar <i class="fa fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- ── PASO 3: Rol e Intereses ── -->
      <div class="fstep" id="step-2">
        <div class="fstep-title">③ Rol e Intereses</div>

        <div class="fgroup" style="margin-bottom:18px">
          <label>Tipo de cuenta <span>*</span></label>
          <div class="roles-grid">
            <?php
              $roles = [
                ['cliente',   '🎓', 'Estudiante / Aprendiz', 'Accede a cursos y contenido educativo'],
                ['empresa',   '🏢', 'Empresa / Organización', 'Gestiona equipos y proyectos'],
                ['creador',   '✍️', 'Creador de Contenido', 'Publica cursos y materiales'],
                ['consultor', '🔍', 'Consultor / Freelancer', 'Ofrece servicios especializados'],
              ];
              foreach($roles as [$val,$ico,$nm,$desc]):
                $checked = ($_POST['tipo_usuario'] ?? 'cliente') === $val ? 'checked' : '';
            ?>
            <div class="role-item">
              <input type="radio" name="tipo_usuario" value="<?= $val ?>" id="rol_<?= $val ?>" <?= $checked ?>>
              <label for="rol_<?= $val ?>">
                <span class="role-ico"><?= $ico ?></span>
                <span class="role-nm"><?= $nm ?></span>
                <span class="role-desc"><?= $desc ?></span>
              </label>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="fgroup">
          <label>Áreas de interés (MOOC / NOOC)</label>
          <div class="interests-grid">
            <?php
              $areas = [
                ['hacking',       '🔴', 'Ethical Hacking'],
                ['redes',         '🌐', 'Redes y Protocolos'],
                ['criptografia',  '🔐', 'Criptografía'],
                ['ia_security',   '🤖', 'IA en Seguridad'],
                ['forense',       '🔍', 'Análisis Forense'],
                ['malware',       '🦠', 'Malware & Virus'],
                ['cloud',         '☁️', 'Cloud Security'],
                ['web_security',  '🌍', 'Seguridad Web'],
                ['programacion',  '💻', 'Programación'],
              ];
              $sel = $_POST['intereses'] ?? [];
              foreach($areas as [$v,$ico,$lbl]):
                $c = in_array($v,$sel)?'checked':'';
            ?>
            <div class="interest-item">
              <input type="checkbox" name="intereses[]" value="<?= $v ?>" id="int_<?= $v ?>" <?= $c ?>>
              <label for="int_<?= $v ?>"><?= $ico ?> <?= $lbl ?></label>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="fnav">
          <button type="button" class="btn-prev" onclick="prevStep(2)"><i class="fa fa-arrow-left"></i> Atrás</button>
          <button type="button" class="btn-next" onclick="nextStep(2)">Continuar <i class="fa fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- ── PASO 4: Redes y Contacto ── -->
      <div class="fstep" id="step-3">
        <div class="fstep-title">④ Redes y Contacto</div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa-brands fa-linkedin" style="color:#0A66C2"></i> LinkedIn</label>
            <input class="finput" type="url" name="linkedin" placeholder="https://linkedin.com/in/..." value="<?= htmlspecialchars($_POST['linkedin'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label><i class="fa-brands fa-github" style="color:#fff"></i> GitHub</label>
            <input class="finput" type="url" name="github" placeholder="https://github.com/..." value="<?= htmlspecialchars($_POST['github'] ?? '') ?>">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa-brands fa-twitter" style="color:#1DA1F2"></i> Twitter / X</label>
            <input class="finput" type="url" name="twitter" placeholder="https://twitter.com/..." value="<?= htmlspecialchars($_POST['twitter'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label><i class="fa-solid fa-globe" style="color:var(--green)"></i> Sitio Web</label>
            <input class="finput" type="url" name="website" placeholder="https://mipagina.com" value="<?= htmlspecialchars($_POST['website'] ?? '') ?>">
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Dirección (opcional)</label>
            <input class="finput" type="text" name="direccion" placeholder="Calle, Barrio, Municipio" value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>">
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Zona Horaria</label>
            <select class="finput" name="zona_horaria">
              <option value="America/Bogota">Colombia (UTC-5)</option>
              <option value="America/Mexico_City">México (UTC-6)</option>
              <option value="America/Guayaquil">Ecuador (UTC-5)</option>
              <option value="America/Lima">Perú (UTC-5)</option>
              <option value="America/Buenos_Aires">Argentina (UTC-3)</option>
              <option value="Europe/Madrid">España (UTC+1/2)</option>
            </select>
          </div>
        </div>

        <div class="fnav">
          <button type="button" class="btn-prev" onclick="prevStep(3)"><i class="fa fa-arrow-left"></i> Atrás</button>
          <button type="button" class="btn-next" onclick="nextStep(3)">Continuar <i class="fa fa-arrow-right"></i></button>
        </div>
      </div>

      <!-- ── PASO 5: Seguridad, Foto y Acceso ── -->
      <div class="fstep" id="step-4">
        <div class="fstep-title">⑤ Seguridad y Acceso</div>

        <div class="frow">
          <div class="fgroup">
            <label>Nombre de usuario <span>*</span></label>
            <input class="finput" type="text" name="username" id="usernameInput" placeholder="Ej: andres_virox" required minlength="4" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
            <small style="color:var(--dim);font-size:.7rem;">Solo letras, números, puntos y guiones bajos.</small>
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Contraseña <span>*</span></label>
            <div style="position:relative;">
              <input class="finput" type="password" name="password" id="pwInput" placeholder="Mínimo 8 caracteres" required>
              <button type="button" onclick="togglePw('pwInput','eyeA')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;">
                <i class="fa fa-eye" id="eyeA"></i>
              </button>
            </div>
            <div class="pw-strength">
              <div class="pw-bars">
                <div class="pw-bar" id="pb1"></div>
                <div class="pw-bar" id="pb2"></div>
                <div class="pw-bar" id="pb3"></div>
                <div class="pw-bar" id="pb4"></div>
              </div>
              <span class="pw-label" id="pwLabel">Escribe tu contraseña</span>
            </div>
          </div>
          <div class="fgroup">
            <label>Confirmar Contraseña <span>*</span></label>
            <div style="position:relative;">
              <input class="finput" type="password" name="confirmar" id="pwConfirm" placeholder="Repite la contraseña" required>
              <button type="button" onclick="togglePw('pwConfirm','eyeB')" style="position:absolute;right:12px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;">
                <i class="fa fa-eye" id="eyeB"></i>
              </button>
            </div>
            <small id="matchMsg" style="font-size:.72rem;"></small>
          </div>
        </div>

        <!-- Foto de perfil -->
        <div class="fgroup" style="margin-bottom:14px;">
          <label>Foto de Perfil</label>
          <div class="file-zone" onclick="document.getElementById('avatarInput').click()">
            <div class="file-zone-ico">📷</div>
            <p>Haz clic para subir tu foto</p>
            <small>JPG, PNG o GIF — máx. 2MB</small>
            <input type="file" id="avatarInput" name="avatar" accept=".jpg,.jpeg,.png,.gif">
          </div>
          <img id="avatar-preview" src="" alt="Preview">
        </div>

        <!-- Documento PDF/JPG -->
        <div class="fgroup" style="margin-bottom:14px;">
          <label>Documento de Identidad (opcional)</label>
          <div class="file-zone" onclick="document.getElementById('docInput').click()">
            <div class="file-zone-ico">📄</div>
            <p>Sube tu documento (PDF, JPG, JPE)</p>
            <small>Para verificación de identidad</small>
            <input type="file" id="docInput" name="documento_identidad" accept=".pdf,.jpg,.jpeg,.jpe">
          </div>
        </div>

        <div class="terms-row">
          <input type="checkbox" name="terminos" id="terminos" required>
          <label for="terminos">Acepto los <a href="terminos.php" target="_blank">Términos y Condiciones</a> y la <a href="privacidad.php" target="_blank">Política de Privacidad</a> de Team VIROX.</label>
        </div>

        <div class="fnav" style="margin-top:20px;">
          <button type="button" class="btn-prev" onclick="prevStep(4)"><i class="fa fa-arrow-left"></i> Atrás</button>
          <button type="submit" name="register" class="btn-submit">
            <i class="fa fa-check-circle"></i> Crear mi cuenta
          </button>
        </div>

        <div class="google-divider"><span>o regístrate con</span></div>
        <button type="button" class="btn-google" onclick="window.location.href='auth/google.php'">
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google">
          Continuar con Google
        </button>
      </div>

    </form>

    <div class="reg-footer">
      ¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a>
    </div>
  </div>
</div>

<script>
let currentStep = 0;
const totalSteps = 5;

function updateUI(step){
  // Formulario
  document.querySelectorAll('.fstep').forEach((s,i) => s.classList.toggle('active', i===step));
  // Barra progreso
  document.getElementById('progressFill').style.width = ((step+1)/totalSteps*100) + '%';
  // Label
  document.getElementById('stepLabel').textContent = step+1;
  // Pasos laterales
  document.querySelectorAll('.rstep').forEach((s,i) => {
    s.classList.toggle('active', i===step);
    s.classList.toggle('done', i<step);
  });
  document.querySelectorAll('.rstep-connector').forEach((c,i) => {
    c.classList.toggle('done-line', i<step);
  });
}

function nextStep(from){
  if(!validateStep(from)) return;
  currentStep = from+1;
  updateUI(currentStep);
  window.scrollTo({top:0,behavior:'smooth'});
}

function prevStep(from){
  currentStep = from-1;
  updateUI(currentStep);
  window.scrollTo({top:0,behavior:'smooth'});
}

function validateStep(step){
  if(step===0){
    const fechaNac = new Date(document.querySelector('[name=fecha_nacimiento]').value);
    const fechaExp = new Date(document.querySelector('[name=fecha_expedicion]').value);
    const now      = new Date();
    if(fechaExp >= now){ alert('La fecha de expedición no puede ser futura.'); return false; }
    if(fechaExp <= fechaNac){ alert('La fecha de expedición debe ser posterior a la de nacimiento.'); return false; }
    const edad = Math.floor((now - fechaNac)/(365.25*24*3600*1000));
    if(edad < 13){ alert('Debes tener al menos 13 años para registrarte.'); return false; }
  }
  if(step===4){
    const pw = document.getElementById('pwInput').value;
    const pc = document.getElementById('pwConfirm').value;
    if(pw !== pc){ alert('Las contraseñas no coinciden.'); return false; }
  }
  return true;
}

/* Password strength */
document.getElementById('pwInput')?.addEventListener('input', function(){
  const v = this.value;
  let s = 0;
  if(v.length >= 8) s++;
  if(/[A-Z]/.test(v)) s++;
  if(/[0-9]/.test(v)) s++;
  if(/[\W_]/.test(v)) s++;
  const bars  = ['pb1','pb2','pb3','pb4'];
  const labels = ['Muy débil','Débil','Buena','Fuerte'];
  const colors = ['weak','weak','medium','strong'];
  bars.forEach((id,i) => {
    const el = document.getElementById(id);
    el.className = 'pw-bar';
    if(i < s) el.classList.add(colors[s-1]);
  });
  document.getElementById('pwLabel').textContent = v.length ? labels[s-1]||'Fuerte' : 'Escribe tu contraseña';
});

/* Confirm match */
document.getElementById('pwConfirm')?.addEventListener('input', function(){
  const pw = document.getElementById('pwInput').value;
  const msg = document.getElementById('matchMsg');
  if(!this.value) { msg.textContent=''; return; }
  if(this.value === pw){ msg.style.color='var(--green)'; msg.textContent='✓ Las contraseñas coinciden'; }
  else                 { msg.style.color='var(--red)';   msg.textContent='✕ No coinciden'; }
});

/* Toggle password visibility */
function togglePw(inputId, iconId){
  const inp = document.getElementById(inputId);
  const ico = document.getElementById(iconId);
  const isText = inp.type === 'text';
  inp.type = isText ? 'password' : 'text';
  ico.className = isText ? 'fa fa-eye' : 'fa fa-eye-slash';
}

/* Avatar preview */
document.getElementById('avatarInput')?.addEventListener('change', function(){
  const file = this.files[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    const img = document.getElementById('avatar-preview');
    img.src = e.target.result;
    img.style.display = 'block';
  };
  reader.readAsDataURL(file);
});

/* Fecha expedición mínima = fecha nacimiento + 1 año */
document.getElementById('fechaNac')?.addEventListener('change', function(){
  const fn = new Date(this.value);
  fn.setFullYear(fn.getFullYear()+1);
  document.getElementById('fechaExp').min = fn.toISOString().split('T')[0];
});
</script>
</body>
</html>