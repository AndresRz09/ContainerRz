n_estudents=[]
nts_st=[]

estudiantes=0
while estudiantes <= 8:
    nms=str(input("Ingrese nombre del estudiante: "))
    n_estudents.append(nms)
    
    for i in range (8):
        nts=float(input("Ingrese Nota: "))
    estudiantes += 1