def sumar(a, b):
    return a + b

def restar(a, b):
    return a - b

def multiplicar(a, b):
    return a * b

def dividir(a, b):
    if b == 0:
        return "Error: División por cero"
    return a / b

class ProcesadorDatos:
    def __init__(self, lista_numeros):
        self.datos = lista_numeros

    def obtener_promedio(self):
        return sum(self.datos) / len(self.datos)
    
# Importamos las funciones específicas y la clase del módulo creado
from Calculadora import sumar, multiplicar, ProcesadorDatos

# 1. Uso de funciones modulares
n1, n2 = 15, 5
resultado_suma = sumar(n1, n2)
resultado_mult = multiplicar(n1, n2)

print(f"--- Resultados de Funciones ---")
print(f"La suma de {n1} + {n2} es: {resultado_suma}")
print(f"La multiplicación de {n1} * {n2} es: {resultado_mult}")

# 2. Uso de clases dentro del módulo
mis_notas = [4.5, 3.8, 5.0, 4.2]
procesador = ProcesadorDatos(mis_notas)
promedio = procesador.obtener_promedio()

print(f"\n--- Resultados de Clase ---")
print(f"El promedio de las notas {mis_notas} es: {promedio:.2f}")