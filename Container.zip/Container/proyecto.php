<?php
include 'conexion.php';
session_start();

// ── Traer proyectos propios desde DB ──
$proyectos_propios = [];
if(isset($conexion)){
  $qp = $conexion->query("SELECT * FROM proyectos WHERE tipo='propio' ORDER BY fecha_inicio DESC");
  if($qp) while($p = $qp->fetch_assoc()) $proyectos_propios[] = $p;
}

// ── Traer proyectos de otros (filtrados) ──
$filtro_cat = $_GET['cat'] ?? '';
$filtro_tipo = $_GET['tipo'] ?? '';

$donde = "WHERE tipo != 'propio'";
if($filtro_cat)  $donde .= " AND categoria = '" . $conexion->real_escape_string($filtro_cat) . "'";
if($filtro_tipo) $donde .= " AND subtipo = '"   . $conexion->real_escape_string($filtro_tipo) . "'";

$proyectos_otros = [];
if(isset($conexion)){
  $qo = $conexion->query("SELECT * FROM proyectos $donde ORDER BY fecha_inicio DESC");
  if($qo) while($p = $qo->fetch_assoc()) $proyectos_otros[] = $p;
}

// ── Categorías para filtro ──
$categorias = [];
if(isset($conexion)){
  $qc = $conexion->query("SELECT DISTINCT categoria FROM proyectos WHERE tipo != 'propio' AND categoria IS NOT NULL");
  if($qc) while($c = $qc->fetch_assoc()) $categorias[] = $c['categoria'];
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Proyectos — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
    /* ── Variables locales ── */
    :root{
      --hh:68px;
      --idx-w:280px;
    }

    /* ── Layout general ── */
    .proy-layout{
      display:grid;
      grid-template-columns:var(--idx-w) 1fr;
      max-width:1480px;
      margin:0 auto;
      padding:36px 28px;
      gap:32px;
      align-items:start;
    }

    /* ══════════════════════════════════
       ÍNDICE LATERAL STICKY
    ══════════════════════════════════ */
    .proy-index{
      position:sticky;
      top:calc(var(--hh) + 20px);
      background:var(--n800);
      border:1px solid rgba(40,166,128,.2);
      border-radius:var(--r-xl);
      padding:24px 18px;
      box-shadow:var(--sh-md);
      max-height:calc(100vh - var(--hh) - 60px);
      overflow-y:auto;
    }
    .proy-index::-webkit-scrollbar{width:3px;}

    .idx-brand{
      display:flex;align-items:center;gap:8px;
      margin-bottom:20px;padding-bottom:14px;
      border-bottom:1px solid rgba(255,255,255,.07);
    }
    .idx-brand-ico{font-size:1.3rem;color:var(--green);}
    .idx-brand-txt{font-family:var(--font-d);font-size:.8rem;font-weight:700;color:var(--gold);letter-spacing:2px;text-transform:uppercase;}

    /* Buscador en índice */
    .idx-search{
      display:flex;align-items:center;gap:8px;
      background:rgba(255,255,255,.05);
      border:1px solid rgba(255,255,255,.09);
      border-radius:var(--r-md);
      padding:8px 12px;
      margin-bottom:16px;
    }
    .idx-search i{color:var(--muted);font-size:.85rem;flex-shrink:0;}
    .idx-search input{
      background:none;border:none;outline:none;
      color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:100%;
    }
    .idx-search input::placeholder{color:var(--dim);}

    /* Sección en el índice */
    .idx-section-title{
      font-size:.65rem;font-weight:800;color:var(--dim);
      text-transform:uppercase;letter-spacing:2px;
      padding:0 6px;margin-bottom:6px;margin-top:16px;
    }
    .idx-item{
      display:flex;align-items:center;gap:10px;
      padding:9px 10px;border-radius:var(--r-md);
      color:var(--muted);font-size:.82rem;font-weight:500;
      cursor:pointer;transition:all .2s;
      border-left:2px solid transparent;
    }
    .idx-item:hover,.idx-item.on{
      background:var(--green-dim);color:var(--green-lt);
      border-left-color:var(--green);
    }
    .idx-item i{width:16px;text-align:center;font-size:.8rem;flex-shrink:0;}
    .idx-item-badge{
      margin-left:auto;padding:1px 7px;
      background:rgba(255,255,255,.08);border-radius:99px;
      font-size:.65rem;color:var(--dim);
    }
    .idx-item.on .idx-item-badge{background:rgba(40,166,128,.2);color:var(--green-lt);}

    /* Stats mini */
    .idx-stats{
      display:grid;grid-template-columns:1fr 1fr;gap:8px;
      margin-top:20px;padding-top:16px;
      border-top:1px solid rgba(255,255,255,.06);
    }
    .idx-stat{
      background:rgba(255,255,255,.04);border-radius:var(--r-md);
      padding:10px 8px;text-align:center;
    }
    .idx-stat-n{font-family:var(--font-d);font-size:1.3rem;font-weight:900;color:var(--gold);}
    .idx-stat-l{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:2px;}

    /* ══════════════════════════════════
       CONTENIDO PRINCIPAL
    ══════════════════════════════════ */
    .proy-main{min-width:0;}

    /* Header de módulo */
    .mod-header{
      display:flex;align-items:center;justify-content:space-between;
      gap:16px;margin-bottom:28px;flex-wrap:wrap;
    }
    .mod-header-left{display:flex;align-items:center;gap:14px;}
    .mod-num{
      font-family:var(--font-d);font-size:.65rem;font-weight:900;
      color:var(--green);letter-spacing:2px;opacity:.6;
    }
    .mod-title{
      font-family:var(--font-d);font-size:1.4rem;font-weight:700;
      color:var(--txt);letter-spacing:1px;
    }
    .mod-line{flex:1;height:1px;background:linear-gradient(to right,rgba(40,166,128,.35),transparent);}
    .mod-btn{
      display:inline-flex;align-items:center;gap:7px;
      padding:9px 18px;background:var(--green);color:#fff;
      border-radius:var(--r-md);font-weight:700;font-size:.82rem;
      transition:all .2s;flex-shrink:0;border:none;cursor:pointer;
      font-family:var(--font-b);
    }
    .mod-btn:hover{background:var(--green-lt);transform:translateY(-2px);}
    .mod-btn-outline{
      background:transparent;border:1.5px solid rgba(40,166,128,.4);color:var(--green-lt);
    }
    .mod-btn-outline:hover{background:var(--green-dim);border-color:var(--green);}

    /* Módulo separador */
    .proy-module{margin-bottom:72px;}

    /* ══════════════════════════════════
       TARJETA PROYECTO PROPIO
    ══════════════════════════════════ */
    .proy-card{
      background:var(--n700);
      border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-xl);
      margin-bottom:24px;
      overflow:hidden;
      transition:border-color .3s,box-shadow .3s;
    }
    .proy-card:hover{border-color:rgba(40,166,128,.35);box-shadow:var(--sh-md);}

    /* Banner superior */
    .pc-banner{
      height:160px;
      background:linear-gradient(135deg,#0b1f40,#162640,#0e2a1f);
      position:relative;overflow:hidden;
      display:flex;align-items:flex-end;padding:20px 28px;
    }
    .pc-banner-bg{
      position:absolute;inset:0;
      background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);
      background-size:32px 32px;
    }
    .pc-banner-orb{
      position:absolute;width:280px;height:280px;border-radius:50%;
      filter:blur(70px);pointer-events:none;
      background:radial-gradient(circle,rgba(40,166,128,.2),transparent 70%);
      right:-60px;top:-80px;
    }
    .pc-banner-content{position:relative;z-index:1;flex:1;}
    .pc-status{
      display:inline-flex;align-items:center;gap:6px;
      padding:4px 12px;border-radius:99px;font-size:.7rem;font-weight:700;
      letter-spacing:.5px;margin-bottom:8px;
    }
    .st-active  {background:rgba(40,166,128,.2);border:1px solid var(--green);color:var(--green-lt);}
    .st-pause   {background:rgba(218,165,32,.15);border:1px solid var(--gold);color:var(--gold-lt);}
    .st-done    {background:rgba(59,130,246,.15);border:1px solid #3b82f6;color:#93c5fd;}
    .st-planned {background:rgba(139,92,246,.15);border:1px solid #8b5cf6;color:#c4b5fd;}
    .pc-name{
      font-family:var(--font-d);font-size:1.2rem;font-weight:700;
      color:var(--txt);letter-spacing:1px;
    }
    .pc-actions{
      position:relative;z-index:1;display:flex;gap:8px;align-self:flex-start;margin-top:8px;
    }
    .pc-act-btn{
      width:32px;height:32px;border-radius:50%;
      background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
      color:var(--muted);display:flex;align-items:center;justify-content:center;
      font-size:.8rem;cursor:pointer;transition:all .2s;
    }
    .pc-act-btn:hover{background:rgba(40,166,128,.2);color:var(--green-lt);border-color:var(--green);}

    /* Cuerpo de la tarjeta */
    .pc-body{padding:24px 28px;}

    /* Tabs dentro de la tarjeta */
    .pc-tabs{
      display:flex;gap:2px;margin-bottom:22px;
      background:rgba(255,255,255,.04);
      padding:3px;border-radius:var(--r-md);
      width:fit-content;
    }
    .pc-tab{
      padding:7px 16px;border-radius:10px;font-size:.78rem;
      font-weight:600;color:var(--muted);cursor:pointer;transition:all .2s;
      border:none;background:none;font-family:var(--font-b);
    }
    .pc-tab:hover{color:var(--txt);}
    .pc-tab.on{background:var(--green);color:#fff;box-shadow:0 2px 10px rgba(40,166,128,.3);}

    /* Contenido de tabs */
    .pc-tab-content{display:none;}
    .pc-tab-content.on{display:block;animation:tabIn .3s ease both;}
    @keyframes tabIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}

    /* Info general */
    .pc-info-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:18px;}
    .pc-info-item{
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-md);padding:12px 14px;
    }
    .pc-info-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
    .pc-info-val{font-size:.88rem;color:var(--txt);font-weight:600;}

    .pc-desc{font-size:.88rem;color:var(--muted);line-height:1.75;margin-bottom:16px;}

    /* Tags */
    .pc-tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px;}
    .pc-tag{
      padding:3px 12px;background:rgba(40,166,128,.1);
      border:1px solid rgba(40,166,128,.25);border-radius:99px;
      font-size:.72rem;color:var(--green-lt);font-weight:600;
    }
    .pc-tag-tech{background:rgba(218,165,32,.1);border-color:rgba(218,165,32,.25);color:var(--gold-lt);}

    /* Progreso */
    .pc-progress{margin-bottom:16px;}
    .pc-prog-hd{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;}
    .pc-prog-lbl{font-size:.75rem;color:var(--muted);font-weight:600;}
    .pc-prog-pct{font-family:var(--font-d);font-size:.82rem;font-weight:700;color:var(--gold);}
    .pc-prog-bar{height:6px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
    .pc-prog-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}

    /* KPIs */
    .pc-kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:4px;}
    .kpi-card{
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-md);padding:14px 12px;text-align:center;
      transition:border-color .2s;
    }
    .kpi-card:hover{border-color:rgba(218,165,32,.3);}
    .kpi-ico{font-size:1.4rem;margin-bottom:6px;}
    .kpi-val{font-family:var(--font-d);font-size:1.1rem;font-weight:700;color:var(--gold);}
    .kpi-lbl{font-size:.65rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;margin-top:3px;}

    /* Avances timeline */
    .pc-timeline{display:flex;flex-direction:column;gap:0;}
    .tl-item{display:flex;gap:16px;padding-bottom:20px;position:relative;}
    .tl-item:not(:last-child)::before{
      content:'';position:absolute;left:11px;top:24px;
      width:2px;height:calc(100% - 24px);
      background:rgba(255,255,255,.08);
    }
    .tl-dot{
      width:24px;height:24px;border-radius:50%;flex-shrink:0;
      display:flex;align-items:center;justify-content:center;
      font-size:.7rem;z-index:1;
      border:2px solid var(--green);background:var(--n700);color:var(--green);
    }
    .tl-dot.done{background:var(--green);color:#fff;}
    .tl-dot.pending{border-color:rgba(255,255,255,.15);color:var(--dim);}
    .tl-content{flex:1;padding-top:1px;}
    .tl-date{font-size:.68rem;color:var(--dim);margin-bottom:3px;}
    .tl-title{font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .tl-desc{font-size:.8rem;color:var(--muted);line-height:1.55;}

    /* Documentos */
    .pc-docs{display:flex;flex-direction:column;gap:8px;}
    .doc-item{
      display:flex;align-items:center;gap:12px;
      padding:12px 16px;
      background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-md);transition:border-color .2s;
    }
    .doc-item:hover{border-color:rgba(40,166,128,.3);}
    .doc-ico{
      width:36px;height:36px;border-radius:var(--r-sm);
      display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0;
    }
    .doc-ico.pdf{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.25);}
    .doc-ico.img{background:rgba(59,130,246,.15);border:1px solid rgba(59,130,246,.25);}
    .doc-ico.doc{background:rgba(40,166,128,.15);border:1px solid rgba(40,166,128,.25);}
    .doc-name{font-size:.85rem;font-weight:600;color:var(--txt);flex:1;}
    .doc-size{font-size:.72rem;color:var(--dim);}
    .doc-dl{
      width:28px;height:28px;border-radius:50%;
      background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
      display:flex;align-items:center;justify-content:center;
      font-size:.75rem;color:var(--muted);cursor:pointer;transition:all .2s;
    }
    .doc-dl:hover{background:var(--green-dim);color:var(--green-lt);}

    /* Equipo del proyecto */
    .pc-team{display:flex;gap:10px;flex-wrap:wrap;}
    .pc-member{
      display:flex;align-items:center;gap:8px;
      padding:8px 14px;background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.07);border-radius:99px;
      cursor:pointer;transition:all .2s;
    }
    .pc-member:hover{background:var(--green-dim);border-color:var(--green);}
    .pc-member img{width:26px;height:26px;border-radius:50%;object-fit:cover;border:1.5px solid var(--green);}
    .pc-member-name{font-size:.78rem;font-weight:600;color:var(--txt);}
    .pc-member-role{font-size:.65rem;color:var(--muted);}

    /* Galería imágenes del proyecto */
    .pc-gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;}
    .pc-gal-item{
      aspect-ratio:1;border-radius:var(--r-md);overflow:hidden;
      border:1px solid rgba(255,255,255,.07);cursor:pointer;position:relative;
    }
    .pc-gal-item img{width:100%;height:100%;object-fit:cover;transition:transform .3s;}
    .pc-gal-item:hover img{transform:scale(1.08);}
    .pc-gal-item .gal-ov{
      position:absolute;inset:0;background:rgba(0,0,0,.5);
      display:flex;align-items:center;justify-content:center;
      opacity:0;transition:opacity .3s;font-size:1.2rem;color:#fff;
    }
    .pc-gal-item:hover .gal-ov{opacity:1;}

    /* ══════════════════════════════════
       MÓDULO OTROS PROYECTOS
    ══════════════════════════════════ */
    /* Barra de filtros */
    .filter-bar{
      display:flex;align-items:center;gap:10px;
      flex-wrap:wrap;margin-bottom:24px;
      padding:16px 20px;
      background:rgba(255,255,255,.03);
      border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);
    }
    .filter-label{font-size:.72rem;color:var(--muted);font-weight:700;text-transform:uppercase;letter-spacing:1px;flex-shrink:0;}
    .filter-chips{display:flex;gap:6px;flex-wrap:wrap;flex:1;}
    .fchip{
      padding:5px 14px;border-radius:99px;
      background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);
      color:var(--muted);font-size:.78rem;font-weight:600;cursor:pointer;transition:all .2s;
    }
    .fchip:hover{background:rgba(40,166,128,.1);border-color:rgba(40,166,128,.3);color:var(--green-lt);}
    .fchip.on{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}

    /* Vista toggle */
    .view-toggle{display:flex;gap:4px;background:rgba(255,255,255,.05);padding:3px;border-radius:var(--r-sm);}
    .vtbtn{
      width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;
      font-size:.8rem;color:var(--muted);cursor:pointer;transition:all .2s;border:none;background:none;
    }
    .vtbtn.on{background:var(--green);color:#fff;}

    /* Grid de otros proyectos */
    .otros-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px;}
    .otros-grid.list-view{grid-template-columns:1fr;}

    /* Tarjeta otros proyectos */
    .otro-card{
      background:var(--n700);border:1px solid rgba(255,255,255,.07);
      border-radius:var(--r-lg);overflow:hidden;
      transition:transform .25s,border-color .25s,box-shadow .25s;
      cursor:pointer;
    }
    .otro-card:hover{transform:translateY(-5px);border-color:rgba(218,165,32,.35);box-shadow:0 8px 30px rgba(0,0,0,.4);}
    .otro-card-banner{
      height:110px;position:relative;overflow:hidden;
      display:flex;align-items:center;justify-content:center;
    }
    .otro-card-ico-big{font-size:3rem;position:relative;z-index:1;}
    .otro-card-body{padding:18px 20px;}
    .otro-card-cat{
      font-size:.65rem;font-weight:700;color:var(--gold);
      text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px;
    }
    .otro-card-title{font-size:.98rem;font-weight:700;color:var(--txt);margin-bottom:8px;line-height:1.4;}
    .otro-card-desc{font-size:.82rem;color:var(--muted);line-height:1.6;margin-bottom:12px;}
    .otro-card-footer{
      display:flex;align-items:center;justify-content:space-between;
      padding-top:12px;border-top:1px solid rgba(255,255,255,.06);
    }
    .otro-card-prog{display:flex;align-items:center;gap:8px;flex:1;}
    .ocp-bar{flex:1;height:3px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
    .ocp-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;}
    .ocp-pct{font-size:.7rem;color:var(--muted);font-weight:600;white-space:nowrap;}
    .otro-card-actions{display:flex;gap:6px;}
    .oca-btn{
      width:28px;height:28px;border-radius:50%;
      background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);
      display:flex;align-items:center;justify-content:center;
      font-size:.72rem;color:var(--muted);cursor:pointer;transition:all .2s;
    }
    .oca-btn:hover{background:var(--green-dim);color:var(--green-lt);}

    /* Lista view */
    .list-view .otro-card{display:flex;flex-direction:row;}
    .list-view .otro-card-banner{width:100px;height:auto;flex-shrink:0;}
    .list-view .otro-card-body{flex:1;}
    .list-view .otro-card-banner{border-radius:var(--r-lg) 0 0 var(--r-lg);}

    /* Empty state */
    .proy-empty{
      text-align:center;padding:64px 24px;
      background:rgba(255,255,255,.02);border:1px dashed rgba(255,255,255,.08);
      border-radius:var(--r-xl);color:var(--dim);
    }
    .proy-empty-ico{font-size:3.5rem;margin-bottom:16px;opacity:.35;}
    .proy-empty p{font-size:.9rem;margin-bottom:16px;}

    /* Modal detalle proyecto */
    .proy-modal{
      position:fixed;inset:0;background:rgba(0,0,0,.85);
      z-index:9999;display:none;align-items:center;justify-content:center;
      padding:24px;
    }
    .proy-modal.open{display:flex;}
    .proy-modal-box{
      background:var(--n800);border:1px solid rgba(40,166,128,.25);
      border-radius:var(--r-xl);width:90%;max-width:860px;
      max-height:88vh;overflow-y:auto;
      box-shadow:var(--sh-lg);animation:mdin .35s ease both;
    }
    @keyframes mdin{from{opacity:0;transform:scale(.95) translateY(20px)}to{opacity:1;transform:none}}
    .proy-modal-close{
      position:sticky;top:0;z-index:1;
      display:flex;justify-content:flex-end;
      padding:14px 20px;background:var(--n800);
      border-bottom:1px solid rgba(255,255,255,.06);
    }
    .pm-close-btn{
      width:32px;height:32px;border-radius:50%;
      background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);
      color:var(--muted);display:flex;align-items:center;justify-content:center;
      cursor:pointer;transition:all .2s;font-size:.85rem;
    }
    .pm-close-btn:hover{background:rgba(239,68,68,.2);color:#f87171;}
    .proy-modal-content{padding:28px 32px;}

    /* Colores de fondo por categoría */
    .bcat-tech{background:linear-gradient(135deg,#0b1f40,#091a30);}
    .bcat-edu {background:linear-gradient(135deg,#1a1440,#120e30);}
    .bcat-social{background:linear-gradient(135deg,#0f2a1a,#091a10);}
    .bcat-arte{background:linear-gradient(135deg,#2a0f1a,#1a0910);}
    .bcat-default{background:linear-gradient(135deg,#111827,#0c1526);}

    /* Add project btn flotante */
    .fab-add{
      position:fixed;bottom:32px;right:32px;z-index:100;
      width:52px;height:52px;border-radius:50%;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      color:#fff;display:flex;align-items:center;justify-content:center;
      font-size:1.3rem;box-shadow:0 6px 24px rgba(40,166,128,.45);
      cursor:pointer;transition:all .2s;border:none;
    }
    .fab-add:hover{transform:scale(1.1) rotate(90deg);box-shadow:0 10px 32px rgba(40,166,128,.55);}

    /* Responsive */
    @media(max-width:1024px){
      .proy-layout{grid-template-columns:240px 1fr;gap:24px;padding:24px 16px;}
      .pc-info-grid{grid-template-columns:1fr 1fr;}
    }
    @media(max-width:820px){
      .proy-layout{grid-template-columns:1fr;}
      .proy-index{position:static;max-height:none;}
      .pc-tabs{overflow-x:auto;width:100%;}
      .otros-grid{grid-template-columns:1fr;}
    }
    @media(max-width:560px){
      .pc-info-grid{grid-template-columns:1fr;}
      .pc-kpis{grid-template-columns:1fr 1fr;}
    }
  </style>
</head>
<body>

<!-- ══════════════════════════════════════
     HEADER
═══════════════════════════════════════ -->
<header class="site-header" id="siteHeader">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="main-nav" id="mainNav">
      <a href="index.php"     class="nav-link">Inicio</a>
      <a href="proyecto.php"  class="nav-link active">Proyecto</a>
      <a href="equipo.php"    class="nav-link">Equipo</a>
      <a href="servicios.php" class="nav-link">Servicios</a>
      <a href="AD.php" class="nav-link">Aprendizaje Digital</a>
      <a href="IA.php" class="nav-link">IA</a>
      <a href="contacto.php"  class="nav-link">Contacto</a>
      <?php if(!isset($_SESSION['user_id'])): ?>
        <a href="login.php" class="nav-cta"><i class="fa fa-sign-in-alt"></i> Ingresar</a>
      <?php else: ?>
        <div class="user-wrap">
          <button class="user-pill">
            <span class="user-av"><i class="fa fa-user"></i></span>
            <span><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span>
          </button>
          <div class="user-drop">
            <a href="perfil.php"><i class="fa fa-id-card"></i> Mi perfil</a>
            <a href="logout.php" class="drop-danger"><i class="fa fa-sign-out-alt"></i> Salir</a>
          </div>
        </div>
      <?php endif; ?>
    </nav>
    <button class="burger" id="burger"><span></span><span></span><span></span></button>
  </div>
</header>


<!-- ══════════════════════════════════════
     HERO MINI
═══════════════════════════════════════ -->
<div style="background:radial-gradient(ellipse 80% 60% at 50% 0%,#0a1f3d 0%,#020817 70%);padding:52px 28px 40px;text-align:center;position:relative;overflow:hidden;border-bottom:1px solid rgba(40,166,128,.15);">
  <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:48px 48px;"></div>
  <div style="position:relative;z-index:1;max-width:700px;margin:auto;">
    <span style="display:inline-block;padding:4px 14px;background:rgba(40,166,128,.12);border:1px solid rgba(40,166,128,.35);border-radius:99px;font-size:.75rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;font-weight:700;margin-bottom:16px;">⬡ Proyectos — Team VIROX</span>
    <h1 style="font-family:var(--font-d);font-size:clamp(1.8rem,3.5vw,3rem);font-weight:900;color:var(--txt);letter-spacing:2px;margin-bottom:10px;">Nuestros <span style="color:var(--gold);text-shadow:0 0 30px rgba(218,165,32,.4);">Proyectos</span></h1>
    <p style="font-size:.95rem;color:var(--muted);line-height:1.7;">Exploración, desarrollo y colaboración en proyectos propios y de la comunidad.</p>
  </div>
</div>


<!-- ══════════════════════════════════════
     LAYOUT PRINCIPAL
═══════════════════════════════════════ -->
<div class="proy-layout">

  <!-- ─── ÍNDICE LATERAL ─────────────────────────────────────────── -->
  <aside class="proy-index" id="proyIndex">
    <div class="idx-brand">
      <span class="idx-brand-ico">🚀</span>
      <span class="idx-brand-txt">Índice</span>
    </div>

    <!-- Buscador -->
    <div class="idx-search">
      <i class="fa fa-search"></i>
      <input type="text" id="idxSearch" placeholder="Buscar proyecto...">
    </div>

    <!-- Módulo 1 -->
    <div class="idx-section-title">Proyectos Propios</div>
    <?php if(empty($proyectos_propios)): ?>
      <div class="idx-item" onclick="scrollTo('#mod-propios')">
        <i class="fa fa-folder-open"></i>
        <span>Sin proyectos aún</span>
        <span class="idx-item-badge">0</span>
      </div>
    <?php else:
      foreach($proyectos_propios as $p):
        $est = $p['estado'] ?? 'activo';
        $ico = match($est){ 'completado'=>'fa-check-circle','pausado'=>'fa-pause-circle','planeado'=>'fa-clock', default=>'fa-circle-dot' };
    ?>
    <div class="idx-item" onclick="scrollToProject('pp-<?= $p['id'] ?>')" data-name="<?= htmlspecialchars(strtolower($p['titulo']??'')) ?>">
      <i class="fa <?= $ico ?>"></i>
      <span><?= htmlspecialchars($p['titulo'] ?? 'Sin título') ?></span>
      <span class="idx-item-badge"><?= (int)($p['progreso'] ?? 0) ?>%</span>
    </div>
    <?php endforeach; endif; ?>

    <!-- Módulo 2 -->
    <div class="idx-section-title" style="margin-top:18px;">Otros Proyectos</div>
    <?php
      $cats_display = !empty($categorias) ? $categorias : ['Tecnología','Educación','Social','Arte'];
      foreach($cats_display as $cat):
    ?>
    <div class="idx-item" onclick="filterCat('<?= htmlspecialchars($cat) ?>')" data-name="<?= htmlspecialchars(strtolower($cat)) ?>">
      <i class="fa fa-layer-group"></i>
      <span><?= htmlspecialchars($cat) ?></span>
    </div>
    <?php endforeach; ?>
    <div class="idx-item" onclick="filterCat('')">
      <i class="fa fa-border-all"></i>
      <span>Ver todos</span>
    </div>

    <!-- Stats -->
    <div class="idx-stats">
      <div class="idx-stat">
        <div class="idx-stat-n"><?= count($proyectos_propios) ?></div>
        <div class="idx-stat-l">Propios</div>
      </div>
      <div class="idx-stat">
        <div class="idx-stat-n"><?= count($proyectos_otros) ?></div>
        <div class="idx-stat-l">Comunidad</div>
      </div>
      <div class="idx-stat">
        <div class="idx-stat-n"><?= count($proyectos_propios) + count($proyectos_otros) ?></div>
        <div class="idx-stat-l">Total</div>
      </div>
      <div class="idx-stat">
        <?php
          $completados = count(array_filter($proyectos_propios, fn($p) => ($p['estado']??'') === 'completado'));
          echo "<div class='idx-stat-n'>{$completados}</div>";
        ?>
        <div class="idx-stat-l">Listos</div>
      </div>
    </div>
  </aside>


  <!-- ─── CONTENIDO ──────────────────────────────────────────────── -->
  <main class="proy-main">

    <!-- ══════════════════════════════
         MÓDULO 1 — PROYECTOS PROPIOS
    ══════════════════════════════ -->
    <div class="proy-module" id="mod-propios">
      <div class="mod-header">
        <div class="mod-header-left">
          <span class="mod-num">01</span>
          <h2 class="mod-title">Proyectos Propios</h2>
          <div class="mod-line"></div>
        </div>
        <?php if(isset($_SESSION['rol']) && in_array($_SESSION['rol'],['admin','superadmin','empleado'])): ?>
        <button class="mod-btn" onclick="window.location.href='nuevo-proyecto.php'">
          <i class="fa fa-plus"></i> Nuevo Proyecto
        </button>
        <?php endif; ?>
      </div>

      <?php if(empty($proyectos_propios)): ?>
        <div class="proy-empty">
          <div class="proy-empty-ico">🚀</div>
          <p>Aún no hay proyectos propios registrados.</p>
          <?php if(isset($_SESSION['rol']) && in_array($_SESSION['rol'],['admin','superadmin','empleado'])): ?>
          <button class="mod-btn" onclick="window.location.href='nuevo-proyecto.php'"><i class="fa fa-plus"></i> Agregar primer proyecto</button>
          <?php endif; ?>
        </div>
      <?php else:
        foreach($proyectos_propios as $p):
          $pid     = $p['id'];
          $titulo  = htmlspecialchars($p['titulo'] ?? 'Sin título');
          $desc    = htmlspecialchars($p['descripcion'] ?? '');
          $estado  = $p['estado'] ?? 'activo';
          $prog    = (int)($p['progreso'] ?? 0);
          $cat     = htmlspecialchars($p['categoria'] ?? '');
          $fini    = !empty($p['fecha_inicio']) ? date('d M Y', strtotime($p['fecha_inicio'])) : '–';
          $ffin    = !empty($p['fecha_fin'])    ? date('d M Y', strtotime($p['fecha_fin']))    : 'En curso';
          $tags    = explode(',', $p['tecnologias'] ?? '');
          $areaTags= explode(',', $p['areas'] ?? '');

          $stClass = match($estado){ 'completado'=>'st-done','pausado'=>'st-pause','planeado'=>'st-planned', default=>'st-active' };
          $stLabel = match($estado){ 'completado'=>'Completado','pausado'=>'En pausa','planeado'=>'Planeado', default=>'Activo' };
          $stDot   = match($estado){ 'completado'=>'●','pausado'=>'⏸','planeado'=>'◌', default=>'●' };
      ?>
      <div class="proy-card" id="pp-<?= $pid ?>">
        <!-- Banner -->
        <div class="pc-banner">
          <div class="pc-banner-bg"></div>
          <div class="pc-banner-orb"></div>
          <div class="pc-banner-content">
            <span class="pc-status <?= $stClass ?>"><?= $stDot ?> <?= $stLabel ?></span>
            <div class="pc-name"><?= $titulo ?></div>
            <?php if($cat): ?>
            <div style="font-size:.72rem;color:var(--muted);margin-top:4px;letter-spacing:1px;"><?= $cat ?></div>
            <?php endif; ?>
          </div>
          <?php if(isset($_SESSION['rol']) && in_array($_SESSION['rol'],['admin','superadmin','empleado'])): ?>
          <div class="pc-actions">
            <div class="pc-act-btn" title="Editar" onclick="window.location.href='editar-proyecto.php?id=<?= $pid ?>'"><i class="fa fa-pen"></i></div>
            <div class="pc-act-btn" title="Compartir"><i class="fa fa-share-nodes"></i></div>
            <div class="pc-act-btn" title="Archivar"><i class="fa fa-archive"></i></div>
          </div>
          <?php endif; ?>
        </div>

        <!-- Cuerpo -->
        <div class="pc-body">
          <!-- Tabs -->
          <div class="pc-tabs" id="tabs-<?= $pid ?>">
            <button class="pc-tab on" onclick="pcTab(<?=$pid?>,'info',this)">📋 Info</button>
            <button class="pc-tab"    onclick="pcTab(<?=$pid?>,'kpis',this)">📊 KPIs</button>
            <button class="pc-tab"    onclick="pcTab(<?=$pid?>,'avances',this)">📈 Avances</button>
            <button class="pc-tab"    onclick="pcTab(<?=$pid?>,'docs',this)">📄 Docs</button>
            <button class="pc-tab"    onclick="pcTab(<?=$pid?>,'equipo',this)">👥 Equipo</button>
            <button class="pc-tab"    onclick="pcTab(<?=$pid?>,'galeria',this)">🖼 Galería</button>
          </div>

          <!-- TAB: Info -->
          <div class="pc-tab-content on" id="tc-<?=$pid?>-info">
            <div class="pc-info-grid">
              <div class="pc-info-item">
                <div class="pc-info-lbl">Inicio</div>
                <div class="pc-info-val"><?= $fini ?></div>
              </div>
              <div class="pc-info-item">
                <div class="pc-info-lbl">Fin estimado</div>
                <div class="pc-info-val"><?= $ffin ?></div>
              </div>
              <div class="pc-info-item">
                <div class="pc-info-lbl">Progreso</div>
                <div class="pc-info-val" style="color:var(--gold)"><?= $prog ?>%</div>
              </div>
            </div>

            <?php if($desc): ?>
            <p class="pc-desc"><?= $desc ?></p>
            <?php endif; ?>

            <!-- Progreso visual -->
            <div class="pc-progress">
              <div class="pc-prog-hd">
                <span class="pc-prog-lbl">Progreso general</span>
                <span class="pc-prog-pct"><?= $prog ?>%</span>
              </div>
              <div class="pc-prog-bar">
                <div class="pc-prog-fill" style="width:<?= $prog ?>%"></div>
              </div>
            </div>

            <!-- Tags tecnologías -->
            <?php if(!empty(array_filter($tags))): ?>
            <div class="pc-tags">
              <?php foreach($tags as $t): if(!trim($t)) continue; ?>
              <span class="pc-tag pc-tag-tech"><?= htmlspecialchars(trim($t)) ?></span>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Tags áreas -->
            <?php if(!empty(array_filter($areaTags))): ?>
            <div class="pc-tags">
              <?php foreach($areaTags as $a): if(!trim($a)) continue; ?>
              <span class="pc-tag"><?= htmlspecialchars(trim($a)) ?></span>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- TAB: KPIs -->
          <div class="pc-tab-content" id="tc-<?=$pid?>-kpis">
            <?php
              $kpis = [];
              if(isset($conexion)){
                $qk = $conexion->prepare("SELECT * FROM proyecto_kpis WHERE proyecto_id=?");
                if($qk){ $qk->bind_param("i",$pid); $qk->execute(); $rk=$qk->get_result(); while($k=$rk->fetch_assoc()) $kpis[]=$k; $qk->close(); }
              }
            ?>
            <?php if(empty($kpis)): ?>
              <div style="text-align:center;padding:32px;color:var(--dim);">
                <div style="font-size:2.5rem;margin-bottom:10px;opacity:.3;">📊</div>
                <p style="font-size:.85rem;">No hay KPIs registrados para este proyecto.</p>
              </div>
            <?php else: ?>
            <div class="pc-kpis">
              <?php foreach($kpis as $k): ?>
              <div class="kpi-card">
                <div class="kpi-ico"><?= htmlspecialchars($k['icono'] ?? '📌') ?></div>
                <div class="kpi-val"><?= htmlspecialchars($k['valor'] ?? '–') ?></div>
                <div class="kpi-lbl"><?= htmlspecialchars($k['nombre'] ?? '') ?></div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- TAB: Avances -->
          <div class="pc-tab-content" id="tc-<?=$pid?>-avances">
            <?php
              $avances = [];
              if(isset($conexion)){
                $qa2 = $conexion->prepare("SELECT * FROM proyecto_avances WHERE proyecto_id=? ORDER BY fecha DESC");
                if($qa2){ $qa2->bind_param("i",$pid); $qa2->execute(); $ra2=$qa2->get_result(); while($av=$ra2->fetch_assoc()) $avances[]=$av; $qa2->close(); }
              }
            ?>
            <?php if(empty($avances)): ?>
              <div style="text-align:center;padding:32px;color:var(--dim);">
                <div style="font-size:2.5rem;margin-bottom:10px;opacity:.3;">📈</div>
                <p style="font-size:.85rem;">Sin avances registrados.</p>
              </div>
            <?php else: ?>
            <div class="pc-timeline">
              <?php foreach($avances as $av):
                $isDone = ($av['completado'] ?? 0) == 1;
              ?>
              <div class="tl-item">
                <div class="tl-dot <?= $isDone ? 'done' : '' ?>">
                  <?= $isDone ? '<i class="fa fa-check fa-xs"></i>' : '<i class="fa fa-circle fa-xs"></i>' ?>
                </div>
                <div class="tl-content">
                  <div class="tl-date"><?= !empty($av['fecha']) ? date('d M Y', strtotime($av['fecha'])) : '' ?></div>
                  <div class="tl-title"><?= htmlspecialchars($av['titulo'] ?? '') ?></div>
                  <div class="tl-desc"><?= htmlspecialchars($av['descripcion'] ?? '') ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- TAB: Docs -->
          <div class="pc-tab-content" id="tc-<?=$pid?>-docs">
            <?php
              $docs = [];
              if(isset($conexion)){
                $qd = $conexion->prepare("SELECT * FROM proyecto_documentos WHERE proyecto_id=?");
                if($qd){ $qd->bind_param("i",$pid); $qd->execute(); $rd=$qd->get_result(); while($d=$rd->fetch_assoc()) $docs[]=$d; $qd->close(); }
              }
            ?>
            <?php if(empty($docs)): ?>
              <div style="text-align:center;padding:32px;color:var(--dim);">
                <div style="font-size:2.5rem;margin-bottom:10px;opacity:.3;">📄</div>
                <p style="font-size:.85rem;">Sin documentos adjuntos.</p>
              </div>
            <?php else: ?>
            <div class="pc-docs">
              <?php foreach($docs as $d):
                $ext = strtolower(pathinfo($d['archivo'] ?? '', PATHINFO_EXTENSION));
                $icoClass = match($ext){ 'pdf'=>'pdf', 'jpg','jpeg','png','gif'=>'img', default=>'doc' };
                $icoEmoji = match($ext){ 'pdf'=>'📕', 'jpg','jpeg','png','gif'=>'🖼', default=>'📄' };
              ?>
              <div class="doc-item">
                <div class="doc-ico <?= $icoClass ?>"><?= $icoEmoji ?></div>
                <div style="flex:1;">
                  <div class="doc-name"><?= htmlspecialchars($d['nombre'] ?? 'Documento') ?></div>
                  <div class="doc-size"><?= strtoupper($ext) ?> · <?= htmlspecialchars($d['descripcion'] ?? '') ?></div>
                </div>
                <a href="<?= htmlspecialchars($d['archivo'] ?? '#') ?>" download class="doc-dl"><i class="fa fa-download"></i></a>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- TAB: Equipo -->
          <div class="pc-tab-content" id="tc-<?=$pid?>-equipo">
            <?php
              $miembros = [];
              if(isset($conexion)){
                $qm2 = $conexion->prepare("SELECT u.id, u.nombre, u.apellido, u.avatar, u.rol, pu.rol_proyecto FROM proyecto_usuarios pu JOIN usuarios u ON pu.usuario_id=u.id WHERE pu.proyecto_id=?");
                if($qm2){ $qm2->bind_param("i",$pid); $qm2->execute(); $rm2=$qm2->get_result(); while($m=$rm2->fetch_assoc()) $miembros[]=$m; $qm2->close(); }
              }
            ?>
            <?php if(empty($miembros)): ?>
              <div style="text-align:center;padding:32px;color:var(--dim);">
                <div style="font-size:2.5rem;margin-bottom:10px;opacity:.3;">👥</div>
                <p style="font-size:.85rem;">Sin miembros asignados.</p>
              </div>
            <?php else: ?>
            <div class="pc-team">
              <?php foreach($miembros as $m):
                $av = !empty($m['avatar']) ? htmlspecialchars($m['avatar']) : 'assets/avatar-default.png';
              ?>
              <a href="perfil.php?id=<?= $m['id'] ?>" class="pc-member">
                <img src="<?= $av ?>" alt="<?= htmlspecialchars($m['nombre']) ?>">
                <div>
                  <div class="pc-member-name"><?= htmlspecialchars($m['nombre'].' '.$m['apellido']) ?></div>
                  <div class="pc-member-role"><?= htmlspecialchars($m['rol_proyecto'] ?? $m['rol'] ?? '') ?></div>
                </div>
              </a>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

          <!-- TAB: Galería -->
          <div class="pc-tab-content" id="tc-<?=$pid?>-galeria">
            <?php
              $imgs = [];
              if(isset($conexion)){
                $qi = $conexion->prepare("SELECT * FROM proyecto_imagenes WHERE proyecto_id=?");
                if($qi){ $qi->bind_param("i",$pid); $qi->execute(); $ri=$qi->get_result(); while($img=$ri->fetch_assoc()) $imgs[]=$img; $qi->close(); }
              }
            ?>
            <?php if(empty($imgs)): ?>
              <div style="text-align:center;padding:32px;color:var(--dim);">
                <div style="font-size:2.5rem;margin-bottom:10px;opacity:.3;">🖼</div>
                <p style="font-size:.85rem;">Sin imágenes del proyecto.</p>
              </div>
            <?php else: ?>
            <div class="pc-gallery">
              <?php foreach($imgs as $img):
                $isrc = htmlspecialchars($img['imagen'], ENT_QUOTES);
                $itit = htmlspecialchars($img['titulo'] ?? '', ENT_QUOTES);
              ?>
              <div class="pc-gal-item" onclick="openImg('<?= $isrc ?>','<?= $itit ?>')">
                <img src="<?= $isrc ?>" alt="<?= $itit ?>" loading="lazy">
                <div class="gal-ov"><i class="fa fa-expand"></i></div>
              </div>
              <?php endforeach; ?>
            </div>
            <?php endif; ?>
          </div>

        </div><!-- /pc-body -->
      </div><!-- /proy-card -->
      <?php endforeach; endif; ?>
    </div><!-- /mod-propios -->


    <!-- ══════════════════════════════
         MÓDULO 2 — OTROS PROYECTOS
    ══════════════════════════════ -->
    <div class="proy-module" id="mod-otros">
      <div class="mod-header">
        <div class="mod-header-left">
          <span class="mod-num">02</span>
          <h2 class="mod-title">Proyectos de la Comunidad</h2>
          <div class="mod-line"></div>
        </div>
        <div style="display:flex;gap:8px;">
          <div class="view-toggle">
            <button class="vtbtn on" id="vGrid" onclick="setView('grid',this)" title="Cuadrícula"><i class="fa fa-th-large"></i></button>
            <button class="vtbtn"    id="vList" onclick="setView('list',this)" title="Lista"><i class="fa fa-list"></i></button>
          </div>
          <?php if(isset($_SESSION['rol']) && in_array($_SESSION['rol'],['admin','superadmin','empleado'])): ?>
          <button class="mod-btn mod-btn-outline" onclick="window.location.href='nuevo-proyecto.php?tipo=otros'">
            <i class="fa fa-plus"></i> Agregar
          </button>
          <?php endif; ?>
        </div>
      </div>

      <!-- Filtros -->
      <div class="filter-bar">
        <span class="filter-label"><i class="fa fa-filter"></i> Filtrar</span>
        <div class="filter-chips" id="filterChips">
          <span class="fchip on" onclick="filterCat('')">Todos</span>
          <?php foreach($cats_display as $cat): ?>
          <span class="fchip" onclick="filterCat('<?= htmlspecialchars($cat) ?>')"><?= htmlspecialchars($cat) ?></span>
          <?php endforeach; ?>
        </div>
        <div style="display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.09);border-radius:var(--r-md);padding:7px 12px;">
          <i class="fa fa-search" style="color:var(--muted);font-size:.8rem;"></i>
          <input type="text" id="otrosSearch" placeholder="Buscar..." style="background:none;border:none;outline:none;color:var(--txt);font-family:var(--font-b);font-size:.82rem;width:130px;">
        </div>
      </div>

      <!-- Grid de proyectos -->
      <div class="otros-grid" id="otrosGrid">
        <?php if(empty($proyectos_otros)):
          // Placeholder cards
          $placeholders = [
            ['🌍','Tecnología','Plataforma de Inclusión Digital','Sistema educativo accesible para comunidades rurales','#0b1f40','45'],
            ['🎓','Educación','Red de Aprendizaje STEM','Conexión entre estudiantes y mentores en STEM','#1a1440','72'],
            ['🌱','Social','Proyecto Verde Digital','Sensibilización ambiental a través de tecnología','#0f2a1a','30'],
            ['🔐','Tecnología','Ciberseguridad Comunitaria','Herramientas gratuitas para proteger a usuarios vulnerables','#0b1f40','88'],
            ['🎨','Arte','Arte y Código','Intersección entre arte digital y programación creativa','#2a0f1a','55'],
            ['🤖','IA','IA para el Bien','Proyectos de IA con impacto social positivo','#0b1f40','20'],
          ];
          foreach($placeholders as [$ico,$cat,$nom,$desc,$bg,$pct]):
        ?>
          <div class="otro-card" onclick="openProyModal('<?= $nom ?>','<?= $desc ?>','<?= $cat ?>')">
            <div class="otro-card-banner" style="background:linear-gradient(135deg,<?= $bg ?>,#020817);">
              <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:24px 24px;"></div>
              <span class="otro-card-ico-big"><?= $ico ?></span>
            </div>
            <div class="otro-card-body">
              <div class="otro-card-cat"><?= $cat ?></div>
              <div class="otro-card-title"><?= $nom ?></div>
              <div class="otro-card-desc"><?= $desc ?></div>
              <div class="otro-card-footer">
                <div class="otro-card-prog">
                  <div class="ocp-bar"><div class="ocp-fill" style="width:<?= $pct ?>%"></div></div>
                  <span class="ocp-pct"><?= $pct ?>%</span>
                </div>
                <div class="otro-card-actions">
                  <div class="oca-btn" title="Ver detalle"><i class="fa fa-eye"></i></div>
                  <div class="oca-btn" title="Colaborar"><i class="fa fa-handshake"></i></div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach;
        else:
          foreach($proyectos_otros as $p):
            $bg = match(strtolower($p['categoria'] ?? '')){ 'tecnología','tecnologia'=>'bcat-tech','educación','educacion'=>'bcat-edu','social'=>'bcat-social','arte'=>'bcat-arte',default=>'bcat-default'};
            $prog = (int)($p['progreso'] ?? 0);
        ?>
          <div class="otro-card" data-cat="<?= htmlspecialchars($p['categoria'] ?? '') ?>" onclick="openProyModal('<?= htmlspecialchars($p['titulo'] ?? '', ENT_QUOTES) ?>','<?= htmlspecialchars($p['descripcion'] ?? '', ENT_QUOTES) ?>','<?= htmlspecialchars($p['categoria'] ?? '', ENT_QUOTES) ?>')">
            <div class="otro-card-banner <?= $bg ?>">
              <div style="position:absolute;inset:0;background-image:linear-gradient(rgba(40,166,128,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(40,166,128,.04) 1px,transparent 1px);background-size:24px 24px;"></div>
              <span class="otro-card-ico-big"><?= htmlspecialchars($p['icono'] ?? '🚀') ?></span>
            </div>
            <div class="otro-card-body">
              <div class="otro-card-cat"><?= htmlspecialchars($p['categoria'] ?? '') ?></div>
              <div class="otro-card-title"><?= htmlspecialchars($p['titulo'] ?? '') ?></div>
              <div class="otro-card-desc"><?= htmlspecialchars(substr($p['descripcion'] ?? '', 0, 100)).(strlen($p['descripcion'] ?? '') > 100 ? '…' : '') ?></div>
              <div class="otro-card-footer">
                <div class="otro-card-prog">
                  <div class="ocp-bar"><div class="ocp-fill" style="width:<?= $prog ?>%"></div></div>
                  <span class="ocp-pct"><?= $prog ?>%</span>
                </div>
                <div class="otro-card-actions">
                  <div class="oca-btn" title="Ver detalle"><i class="fa fa-eye"></i></div>
                  <div class="oca-btn" title="Colaborar"><i class="fa fa-handshake"></i></div>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div><!-- /mod-otros -->

  </main>
</div><!-- /proy-layout -->


<!-- ══════════════════════════════════════
     MODAL — DETALLE PROYECTO OTROS
═══════════════════════════════════════ -->
<div class="proy-modal" id="proyModal">
  <div class="proy-modal-box">
    <div class="proy-modal-close">
      <button class="pm-close-btn" onclick="closeModal()"><i class="fa fa-times"></i></button>
    </div>
    <div class="proy-modal-content" id="proyModalContent">
      <!-- Contenido dinámico -->
    </div>
  </div>
</div>


<!-- ══════════════════════════════════════
     MODAL — IMAGEN GALERÍA
═══════════════════════════════════════ -->
<div class="proy-modal" id="imgModal">
  <div class="proy-modal-box" style="max-width:720px;text-align:center;">
    <div class="proy-modal-close">
      <button class="pm-close-btn" onclick="closeImgModal()"><i class="fa fa-times"></i></button>
    </div>
    <div style="padding:24px;">
      <img id="imgModalSrc" src="" alt="" style="width:100%;border-radius:var(--r-lg);margin-bottom:12px;">
      <p id="imgModalTitle" style="font-size:.88rem;color:var(--muted);"></p>
    </div>
  </div>
</div>


<!-- FAB -->
<?php if(isset($_SESSION['rol']) && in_array($_SESSION['rol'],['admin','superadmin','empleado'])): ?>
<button class="fab-add" onclick="window.location.href='nuevo-proyecto.php'" title="Nuevo Proyecto">
  <i class="fa fa-plus"></i>
</button>
<?php endif; ?>


<!-- FOOTER -->
<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand"><span class="brand-hex">⬡</span><span class="brand-name">VIROX</span></div>
    <p class="footer-copy">© 2025 Team VIROX</p>
    <nav class="footer-nav">
      <a href="index.php">Inicio</a><a href="equipo.php">Equipo</a><a href="contacto.php">Contacto</a>
    </nav>
  </div>
</footer>


<script>
/* ── Header scroll ── */
window.addEventListener('scroll',()=>
  document.getElementById('siteHeader').classList.toggle('hdr-on',scrollY>40));

/* ── Burger ── */
document.getElementById('burger').addEventListener('click',function(){
  this.classList.toggle('burger-x');
  document.getElementById('mainNav').classList.toggle('nav-open');
});

/* ── Tabs dentro de tarjeta proyecto ── */
function pcTab(pid, tab, btn){
  document.querySelectorAll(`[id^="tc-${pid}-"]`).forEach(t=>t.classList.remove('on'));
  document.querySelectorAll(`#tabs-${pid} .pc-tab`).forEach(b=>b.classList.remove('on'));
  document.getElementById(`tc-${pid}-${tab}`).classList.add('on');
  btn.classList.add('on');
}

/* ── Scroll a proyecto ── */
function scrollToProject(id){
  const el = document.getElementById(id);
  if(el){ el.scrollIntoView({behavior:'smooth',block:'start'}); }
}
function scrollTo(sel){
  const el = document.querySelector(sel);
  if(el) el.scrollIntoView({behavior:'smooth',block:'start'});
}

/* ── Filtro categoría otros proyectos ── */
function filterCat(cat){
  document.querySelectorAll('.fchip').forEach(c=>{
    c.classList.toggle('on', c.textContent.trim() === (cat || 'Todos'));
  });
  document.querySelectorAll('.idx-item').forEach(i=>{
    if(cat) i.classList.toggle('on', i.dataset.name === cat.toLowerCase());
  });
  document.querySelectorAll('.otro-card').forEach(c=>{
    const ccat = c.dataset.cat || '';
    c.style.display = (!cat || ccat === cat) ? '' : 'none';
  });
}

/* ── Vista grid/list ── */
function setView(v, btn){
  document.querySelectorAll('.vtbtn').forEach(b=>b.classList.remove('on'));
  btn.classList.add('on');
  const g = document.getElementById('otrosGrid');
  g.classList.toggle('list-view', v === 'list');
}

/* ── Búsqueda en índice ── */
document.getElementById('idxSearch').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  document.querySelectorAll('.idx-item').forEach(i=>{
    i.style.display = (!q || (i.dataset.name||'').includes(q)) ? '' : 'none';
  });
});

/* ── Búsqueda en otros proyectos ── */
document.getElementById('otrosSearch').addEventListener('input', function(){
  const q = this.value.toLowerCase();
  document.querySelectorAll('.otro-card').forEach(c=>{
    const t = (c.querySelector('.otro-card-title')?.textContent||'').toLowerCase();
    c.style.display = (!q || t.includes(q)) ? '' : 'none';
  });
});

/* ── Modal proyecto otros ── */
function openProyModal(titulo, desc, cat){
  document.getElementById('proyModalContent').innerHTML = `
    <div style="margin-bottom:20px;">
      <div style="font-size:.72rem;color:var(--gold);text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:8px;">${cat}</div>
      <h2 style="font-family:var(--font-d);font-size:1.3rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:12px;">${titulo}</h2>
      <p style="font-size:.9rem;color:var(--muted);line-height:1.75;">${desc}</p>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:20px;">
      <button onclick="window.location.href='contacto.php'" style="padding:11px;background:var(--green);color:#fff;border-radius:var(--r-md);font-weight:700;font-size:.85rem;border:none;cursor:pointer;font-family:var(--font-b);">
        <i class="fa fa-handshake"></i> Colaborar
      </button>
      <button onclick="closeModal()" style="padding:11px;background:rgba(255,255,255,.06);color:var(--muted);border-radius:var(--r-md);font-weight:600;font-size:.85rem;border:1px solid rgba(255,255,255,.1);cursor:pointer;font-family:var(--font-b);">
        Cerrar
      </button>
    </div>`;
  document.getElementById('proyModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal(){
  document.getElementById('proyModal').classList.remove('open');
  document.body.style.overflow = '';
}

/* ── Modal imagen ── */
function openImg(src, title){
  document.getElementById('imgModalSrc').src = src;
  document.getElementById('imgModalTitle').textContent = title;
  document.getElementById('imgModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeImgModal(){
  document.getElementById('imgModal').classList.remove('open');
  document.body.style.overflow = '';
}

/* Cerrar con Escape */
document.addEventListener('keydown', e=>{
  if(e.key==='Escape'){ closeModal(); closeImgModal(); }
});

/* Cerrar al hacer clic fuera */
['proyModal','imgModal'].forEach(id=>{
  document.getElementById(id).addEventListener('click', function(e){
    if(e.target===this){ closeModal(); closeImgModal(); }
  });
});

/* ── Animación barras al cargar ── */
document.addEventListener('DOMContentLoaded',()=>{
  const fills = document.querySelectorAll('.pc-prog-fill');
  setTimeout(()=>fills.forEach(f=>{ const w=f.style.width; f.style.width='0'; setTimeout(()=>f.style.width=w,50); }),200);
});
</script>
</body>
</html>