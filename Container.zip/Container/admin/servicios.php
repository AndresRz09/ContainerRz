<?php
// admin/servicios.php
require_once __DIR__ . '/admin_template.php'; // incluye conexion y session_start()
/*
  Estructura esperada:
  - servicios: id, nombre, descripcion, caracteristicas, icono
  - servicio_detalle: id, servicio_id, descripcion_larga, imagen_url, video_url, precio, enlace_extra
  - planes_servicio: id, servicio_id, nombre_plan, descripcion, precio
*/

// ---------- ACL rápido (si admin_template no lo hace) ----------
if (!isset($_SESSION['user_id']) || ($_SESSION['rol'] ?? '') !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// ---------- ACCIONES (POST) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ---------- SERVICIO: CREAR ----------
    if ($action === 'crear_servicio') {
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $caracteristicas = trim($_POST['caracteristicas'] ?? '');
        $icono = trim($_POST['icono'] ?? '');

        if ($nombre !== '') {
            $stmt = $conexion->prepare("INSERT INTO servicios (nombre, descripcion, caracteristicas, icono) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nombre, $descripcion, $caracteristicas, $icono);
            $stmt->execute(); $insert_id = $stmt->insert_id; $stmt->close();

            registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Creó servicio ID $insert_id - $nombre");
            $_SESSION['flash_success'] = "Servicio creado correctamente.";
        } else {
            $_SESSION['flash_error'] = "El nombre del servicio es obligatorio.";
        }

        header('Location: servicios.php');
        exit;
    }

    // ---------- SERVICIO: EDITAR ----------
    if ($action === 'editar_servicio') {
        $id = intval($_POST['id'] ?? 0);
        $nombre = trim($_POST['nombre'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $caracteristicas = trim($_POST['caracteristicas'] ?? '');
        $icono = trim($_POST['icono'] ?? '');

        if ($id > 0 && $nombre !== '') {
            $stmt = $conexion->prepare("UPDATE servicios SET nombre=?, descripcion=?, caracteristicas=?, icono=? WHERE id=?");
            $stmt->bind_param("ssssi", $nombre, $descripcion, $caracteristicas, $icono, $id);
            $stmt->execute(); $stmt->close();

            registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Editó servicio ID $id");
            $_SESSION['flash_success'] = "Servicio actualizado.";
        } else {
            $_SESSION['flash_error'] = "Datos inválidos para actualizar servicio.";
        }

        header('Location: servicios.php?id=' . $id . '&view=manage');
        exit;
    }

    // ---------- SERVICIO: ELIMINAR ----------
    if ($action === 'eliminar_servicio') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            // eliminar detalle y planes asociados (si existen)
            $conexion->begin_transaction();
            try {
                $stmt = $conexion->prepare("DELETE FROM servicio_detalle WHERE servicio_id=?");
                $stmt->bind_param("i", $id); $stmt->execute(); $stmt->close();

                $stmt = $conexion->prepare("DELETE FROM planes_servicio WHERE servicio_id=?");
                $stmt->bind_param("i", $id); $stmt->execute(); $stmt->close();

                $stmt = $conexion->prepare("DELETE FROM servicios WHERE id=?");
                $stmt->bind_param("i", $id); $stmt->execute(); $stmt->close();

                $conexion->commit();
                registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Eliminó servicio ID $id y sus datos asociados");
                $_SESSION['flash_success'] = "Servicio y sus datos asociados eliminados.";
            } catch (Exception $e) {
                $conexion->rollback();
                $_SESSION['flash_error'] = "Error al eliminar servicio: " . $e->getMessage();
            }
        }
        header('Location: servicios.php');
        exit;
    }

    // ---------- DETALLE: CREAR / ACTUALIZAR (uno por servicio) ----------
    if ($action === 'guardar_detalle') {
        $servicio_id = intval($_POST['servicio_id'] ?? 0);
        $descripcion_larga = trim($_POST['descripcion_larga'] ?? '');
        $imagen_url = trim($_POST['imagen_url'] ?? '');
        $video_url = trim($_POST['video_url'] ?? '');
        $precio = trim($_POST['precio'] ?? '');
        $enlace_extra = trim($_POST['enlace_extra'] ?? '');

        if ($servicio_id > 0) {
            // comprobar si ya existe detalle
            $res = $conexion->prepare("SELECT id FROM servicio_detalle WHERE servicio_id = ?");
            $res->bind_param("i", $servicio_id); $res->execute();
            $r = $res->get_result()->fetch_assoc(); $res->close();

            if ($r) {
                // actualizar
                $stmt = $conexion->prepare("UPDATE servicio_detalle SET descripcion_larga=?, imagen_url=?, video_url=?, precio=?, enlace_extra=? WHERE servicio_id=?");
                $stmt->bind_param("sssssi", $descripcion_larga, $imagen_url, $video_url, $precio, $enlace_extra, $servicio_id);
                $stmt->execute(); $stmt->close();
                registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Editó detalle del servicio ID $servicio_id");
                $_SESSION['flash_success'] = "Detalle actualizado.";
            } else {
                // insertar
                $stmt = $conexion->prepare("INSERT INTO servicio_detalle (servicio_id, descripcion_larga, imagen_url, video_url, precio, enlace_extra) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("isssss", $servicio_id, $descripcion_larga, $imagen_url, $video_url, $precio, $enlace_extra);
                $stmt->execute(); $stmt->close();
                registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Creó detalle del servicio ID $servicio_id");
                $_SESSION['flash_success'] = "Detalle creado.";
            }
        } else {
            $_SESSION['flash_error'] = "Servicio inválido para detalle.";
        }

        header('Location: servicios.php?id=' . $servicio_id . '&view=manage');
        exit;
    }

    // ---------- PLANES: CREAR ----------
    if ($action === 'crear_plan') {
        $servicio_id = intval($_POST['servicio_id'] ?? 0);
        $nombre_plan = trim($_POST['nombre_plan'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $precio = trim($_POST['precio'] ?? '');

        if ($servicio_id > 0 && $nombre_plan !== '') {
            $stmt = $conexion->prepare("INSERT INTO planes_servicio (servicio_id, nombre_plan, descripcion, precio) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $servicio_id, $nombre_plan, $descripcion, $precio);
            $stmt->execute(); $stmt->close();
            registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Creó plan '$nombre_plan' para servicio ID $servicio_id");
            $_SESSION['flash_success'] = "Plan creado.";
        } else {
            $_SESSION['flash_error'] = "Datos inválidos para crear plan.";
        }

        header('Location: servicios.php?id=' . $servicio_id . '&view=manage&tab=planes');
        exit;
    }

    // ---------- PLANES: EDITAR ----------
    if ($action === 'editar_plan') {
        $plan_id = intval($_POST['plan_id'] ?? 0);
        $nombre_plan = trim($_POST['nombre_plan'] ?? '');
        $descripcion = trim($_POST['descripcion'] ?? '');
        $precio = trim($_POST['precio'] ?? '');

        if ($plan_id > 0 && $nombre_plan !== '') {
            $stmt = $conexion->prepare("UPDATE planes_servicio SET nombre_plan=?, descripcion=?, precio=? WHERE id=?");
            $stmt->bind_param("sssi", $nombre_plan, $descripcion, $precio, $plan_id);
            $stmt->execute(); $stmt->close();
            registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Editó plan ID $plan_id");
            $_SESSION['flash_success'] = "Plan actualizado.";
        } else {
            $_SESSION['flash_error'] = "Datos inválidos para editar plan.";
        }

        // redirect a la misma vista del servicio (necesitamos servicio_id)
        $svc = $conexion->query("SELECT servicio_id FROM planes_servicio WHERE id = $plan_id")->fetch_assoc();
        $svc_id = $svc['servicio_id'] ?? 0;
        header('Location: servicios.php?id=' . $svc_id . '&view=manage&tab=planes');
        exit;
    }

    // ---------- PLANES: ELIMINAR ----------
    if ($action === 'eliminar_plan') {
        $plan_id = intval($_POST['plan_id'] ?? 0);
        if ($plan_id > 0) {
            $svc_id = $conexion->query("SELECT servicio_id FROM planes_servicio WHERE id = $plan_id")->fetch_assoc()['servicio_id'] ?? 0;
            $stmt = $conexion->prepare("DELETE FROM planes_servicio WHERE id = ?");
            $stmt->bind_param("i", $plan_id); $stmt->execute(); $stmt->close();
            registrar_log($conexion, $_SESSION['identificacion'], $_SESSION['rol'], "Eliminó plan ID $plan_id");
            $_SESSION['flash_success'] = "Plan eliminado.";
            header('Location: servicios.php?id=' . intval($svc_id) . '&view=manage&tab=planes');
            exit;
        }
    }
}

// ---------- VISTA: listado o gestión de un servicio ----------
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$view = $_GET['view'] ?? 'list'; // list | manage
$tab = $_GET['tab'] ?? 'basic'; // dentro de manage: basic | detalle | planes

// ---------- Consultas para listado con paginación ligera ----------
$limit = 15;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

$total = $conexion->query("SELECT COUNT(*) AS c FROM servicios")->fetch_assoc()['c'] ?? 0;
$total_pages = max(1, ceil($total / $limit));

$list_sql = "SELECT * FROM servicios ORDER BY id DESC LIMIT $offset, $limit";
$list_res = $conexion->query($list_sql);

// ---------- Si se está gestionando un servicio, obtener datos detallados ----------
$service = null;
$detalle = null;
$planes = [];

if ($view === 'manage' && $id > 0) {
    $service = $conexion->query("SELECT * FROM servicios WHERE id = " . intval($id))->fetch_assoc();
    $detalle = $conexion->query("SELECT * FROM servicio_detalle WHERE servicio_id = " . intval($id))->fetch_assoc();
    $plans_res = $conexion->query("SELECT * FROM planes_servicio WHERE servicio_id = " . intval($id) . " ORDER BY id ASC");
    while ($p = $plans_res->fetch_assoc()) $planes[] = $p;
}

// ---------- RENDER ----------
admin_header("Servicios");
?>

<!-- FLASH -->
<?php if (!empty($_SESSION['flash_success'])): ?>
  <div class="card" style="border-left:4px solid var(--accent); margin-bottom:12px;">
    <strong><?php echo htmlspecialchars($_SESSION['flash_success']); ?></strong>
  </div>
  <?php unset($_SESSION['flash_success']); ?>
<?php endif; ?>
<?php if (!empty($_SESSION['flash_error'])): ?>
  <div class="card" style="border-left:4px solid #b91c1c; margin-bottom:12px;">
    <strong><?php echo htmlspecialchars($_SESSION['flash_error']); ?></strong>
  </div>
  <?php unset($_SESSION['flash_error']); ?>
<?php endif; ?>

<!-- TOP -->
<div class="card" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
  <div>
    <h3>Servicios</h3>
    <div class="kv">Gestiona servicios, su detalle extendido y planes asociados.</div>
  </div>
  <div>
    <button class="btn" onclick="document.getElementById('form-new').classList.add('show')">➕ Nuevo Servicio</button>
    <a href="servicios.php" class="btn ghost">Volver al listado</a>
  </div>
</div>

<?php if ($view === 'list'): ?>

  <!-- LISTADO -->
  <div class="card" style="margin-bottom:14px;">
    <table class="table" style="width:100%;">
      <thead>
        <tr>
          <th>ID</th>
          <th>Icono</th>
          <th>Nombre</th>
          <th>Descripción</th>
          <th>Caracteristicas</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($s = $list_res->fetch_assoc()): ?>
        <tr>
          <td><?= $s['id'] ?></td>
          <td><?= htmlspecialchars($s['icono']) ?></td>
          <td><?= htmlspecialchars($s['nombre']) ?></td>
          <td><?= htmlspecialchars(strlen($s['descripcion'])>120 ? substr($s['descripcion'],0,120).'...' : $s['descripcion']) ?></td>
          <td><?= htmlspecialchars(strlen($s['caracteristicas'])>80 ? substr($s['caracteristicas'],0,80).'...' : $s['caracteristicas']) ?></td>
          <td style="white-space:nowrap;">
            <a class="btn small" href="servicios.php?view=manage&id=<?= $s['id'] ?>">Administrar</a>

            <form method="post" style="display:inline" onsubmit="return confirm('Eliminar servicio y sus datos asociados?');">
              <input type="hidden" name="action" value="eliminar_servicio">
              <input type="hidden" name="id" value="<?= $s['id'] ?>">
              <button class="btn danger small" type="submit">Eliminar</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>

    <!-- paginación -->
    <div style="margin-top:12px; display:flex; justify-content:space-between; align-items:center">
      <div class="kv">Mostrando página <?= $page ?> de <?= $total_pages ?> (<?= $total ?> servicios)</div>
      <div style="display:flex; gap:8px; align-items:center;">
        <?php if ($page > 1): ?><a class="btn ghost" href="servicios.php?page=<?= $page-1 ?>">« Anterior</a><?php endif; ?>
        <?php if ($page < $total_pages): ?><a class="btn" href="servicios.php?page=<?= $page+1 ?>">Siguiente »</a><?php endif; ?>
      </div>
    </div>
  </div>

<?php elseif ($view === 'manage' && $service): ?>

  <!-- GESTIÓN DE 1 SERVICIO: pestañas -->
  <div class="card" style="margin-bottom:12px;">
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <div>
        <h3><?= htmlspecialchars($service['nombre']) ?> <span class="kv">ID <?= $service['id'] ?></span></h3>
        <div class="kv"><?= htmlspecialchars($service['descripcion']) ?></div>
      </div>
      <div style="display:flex; gap:8px; align-items:center;">
        <a class="btn ghost" href="servicios.php">Cerrar</a>
        <form method="post" onsubmit="return confirm('Eliminar servicio y todo su contenido?');" style="display:inline;">
          <input type="hidden" name="action" value="eliminar_servicio">
          <input type="hidden" name="id" value="<?= $service['id'] ?>">
          <button class="btn danger">Eliminar Servicio</button>
        </form>
      </div>
    </div>
  </div>

  <!-- TAB SWITCH -->
  <div class="card" style="margin-bottom:14px;">
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <button class="btn <?php if($tab==='basic') echo 'ghost'; ?>" onclick="location.href='servicios.php?view=manage&id=<?= $service['id'] ?>&tab=basic'">Información básica</button>
      <button class="btn <?php if($tab==='detalle') echo 'ghost'; ?>" onclick="location.href='servicios.php?view=manage&id=<?= $service['id'] ?>&tab=detalle'">Detalle multimedia</button>
      <button class="btn <?php if($tab==='planes') echo 'ghost'; ?>" onclick="location.href='servicios.php?view=manage&id=<?= $service['id'] ?>&tab=planes'">Planes (<?= count($planes) ?>)</button>
    </div>
  </div>

  <!-- TAB: BASIC -->
  <?php if ($tab === 'basic'): ?>
    <div class="card" style="margin-bottom:14px;">
      <h4>Editar información básica</h4>
      <form method="post">
        <input type="hidden" name="action" value="editar_servicio">
        <input type="hidden" name="id" value="<?= $service['id'] ?>">

        <div class="form-row"><label>Icono</label><input type="text" name="icono" value="<?= htmlspecialchars($service['icono']) ?>"></div>
        <div class="form-row"><label>Nombre</label><input type="text" name="nombre" value="<?= htmlspecialchars($service['nombre']) ?>" required></div>
        <div class="form-row"><label>Descripción</label><textarea name="descripcion"><?= htmlspecialchars($service['descripcion']) ?></textarea></div>
        <div class="form-row"><label>Características (lista o texto)</label><textarea name="caracteristicas"><?= htmlspecialchars($service['caracteristicas']) ?></textarea></div>

        <div style="display:flex; gap:8px; justify-content:flex-end; margin-top:8px;">
          <a class="btn ghost" href="servicios.php?view=manage&id=<?= $service['id'] ?>">Cancelar</a>
          <button class="btn" type="submit">Guardar cambios</button>
        </div>
      </form>
    </div>
  <?php endif; ?>

  <!-- TAB: DETALLE -->
  <?php if ($tab === 'detalle'): ?>
    <div class="card" style="margin-bottom:14px;">
      <h4>Detalle extendido</h4>

      <form method="post">
        <input type="hidden" name="action" value="guardar_detalle">
        <input type="hidden" name="servicio_id" value="<?= $service['id'] ?>">

        <div class="form-row"><label>Descripción larga</label><textarea name="descripcion_larga"><?= htmlspecialchars($detalle['descripcion_larga'] ?? '') ?></textarea></div>
        <div class="form-row"><label>URL imagen (preview abajo)</label><input type="text" name="imagen_url" id="imagen_url" value="<?= htmlspecialchars($detalle['imagen_url'] ?? '') ?>"></div>
        <div class="form-row"><label>URL video (YouTube / Vimeo)</label><input type="text" name="video_url" value="<?= htmlspecialchars($detalle['video_url'] ?? '') ?>"></div>
        <div class="form-row"><label>Precio</label><input type="text" name="precio" value="<?= htmlspecialchars($detalle['precio'] ?? '') ?>"></div>
        <div class="form-row"><label>Enlace extra</label><input type="text" name="enlace_extra" value="<?= htmlspecialchars($detalle['enlace_extra'] ?? '') ?>"></div>

        <div style="display:flex; gap:8px; justify-content:flex-end; margin-top:8px;">
          <a class="btn ghost" href="servicios.php?view=manage&id=<?= $service['id'] ?>&tab=detalle">Cancelar</a>
          <button class="btn" type="submit">Guardar detalle</button>
        </div>
      </form>

      <?php if (!empty($detalle['imagen_url'])): ?>
        <div style="margin-top:12px;">
          <strong>Preview imagen:</strong>
          <div style="margin-top:8px;"><img src="<?= htmlspecialchars($detalle['imagen_url']) ?>" alt="" style="max-width:280px; border-radius:8px;"></div>
        </div>
      <?php endif; ?>
      <?php if (!empty($detalle['video_url'])): ?>
        <div style="margin-top:12px;">
          <strong>Preview video:</strong>
          <div style="margin-top:8px;">
            <!-- intenta convertir link youtube a embed -->
            <?php
              $v = $detalle['video_url'];
              if (stripos($v,'youtube')!==false || stripos($v,'youtu.be')!==false) {
                preg_match('/(v=|youtu\.be\/|embed\/)([A-Za-z0-9_\-]+)/', $v, $m);
                $vid = $m[2] ?? '';
                if ($vid) {
                  echo '<iframe width="420" height="236" src="https://www.youtube.com/embed/'.htmlspecialchars($vid).'" frameborder="0" allowfullscreen></iframe>';
                } else {
                  echo '<a href="'.htmlspecialchars($v).'" target="_blank">Ver video</a>';
                }
              } else {
                echo '<a href="'.htmlspecialchars($v).'" target="_blank">Ver video</a>';
              }
            ?>
          </div>
        </div>
      <?php endif; ?>

    </div>
  <?php endif; ?>

  <!-- TAB: PLANES -->
  <?php if ($tab === 'planes'): ?>
    <div class="card" style="margin-bottom:14px;">
      <h4>Planes del servicio</h4>

      <!-- Form para crear plan -->
      <form method="post" style="margin-bottom:12px;">
        <input type="hidden" name="action" value="crear_plan">
        <input type="hidden" name="servicio_id" value="<?= $service['id'] ?>">
        <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:8px;">
          <input name="nombre_plan" placeholder="Nombre del plan" required>
          <input name="precio" placeholder="Precio (ej: 150000)" >
          <button class="btn" type="submit">Agregar plan</button>
        </div>
        <div style="margin-top:8px;">
          <input name="descripcion" placeholder="Descripción breve del plan" style="width:100%; margin-top:6px;">
        </div>
      </form>

      <!-- Lista de planes -->
      <?php if (count($planes) === 0): ?>
        <div class="kv">No hay planes aún.</div>
      <?php else: ?>
        <table class="table" style="width:100%; margin-top:8px;">
          <thead><tr><th>ID</th><th>Nombre</th><th>Descripción</th><th>Precio</th><th>Acciones</th></tr></thead>
          <tbody>
            <?php foreach ($planes as $pl): ?>
              <tr>
                <td><?= $pl['id'] ?></td>
                <td><?= htmlspecialchars($pl['nombre_plan']) ?></td>
                <td><?= htmlspecialchars(strlen($pl['descripcion'])>140 ? substr($pl['descripcion'],0,140).'...' : $pl['descripcion']) ?></td>
                <td><?= htmlspecialchars($pl['precio']) ?></td>
                <td style="white-space:nowrap;">
                  <!-- editar abre modal -->
                  <button class="btn small" onclick='openPlanEdit(<?= json_encode($pl, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>Editar</button>

                  <form method="post" style="display:inline" onsubmit="return confirm('Eliminar plan?');">
                    <input type="hidden" name="action" value="eliminar_plan">
                    <input type="hidden" name="plan_id" value="<?= $pl['id'] ?>">
                    <button class="btn danger small" type="submit">Eliminar</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  <?php endif; ?>

<?php else: ?>
  <div class="card"><strong>Servicio no encontrado o vista inválida.</strong></div>
<?php endif; ?>


<!-- -----------------------
     MODAL: NUEVO SERVICIO
------------------------- -->
<div class="modal" id="form-new">
  <div class="modal-card">
    <span class="modal-close" onclick="document.getElementById('form-new').classList.remove('show')">×</span>
    <h3 style="color:var(--gold)">Crear servicio</h3>

    <form method="post">
      <input type="hidden" name="action" value="crear_servicio">
      <div class="form-row"><label>Icono</label><input type="text" name="icono"></div>
      <div class="form-row"><label>Nombre</label><input type="text" name="nombre" required></div>
      <div class="form-row"><label>Descripción</label><textarea name="descripcion"></textarea></div>
      <div class="form-row"><label>Características</label><textarea name="caracteristicas" placeholder="Lista o texto separado por comas"></textarea></div>

      <div style="display:flex; gap:8px; justify-content:flex-end; margin-top:8px;">
        <button type="button" class="btn ghost" onclick="document.getElementById('form-new').classList.remove('show')">Cancelar</button>
        <button class="btn" type="submit">Crear</button>
      </div>
    </form>
  </div>
</div>

<!-- -----------------------
     MODAL: EDITAR PLAN
------------------------- -->
<div class="modal" id="modal-plan-edit">
  <div class="modal-card">
    <span class="modal-close" onclick="closePlanModal()">×</span>
    <h3 style="color:var(--gold)">Editar plan</h3>

    <form method="post" id="form-plan-edit">
      <input type="hidden" name="action" value="editar_plan">
      <input type="hidden" name="plan_id" id="plan_id">
      <div class="form-row"><label>Nombre plan</label><input type="text" name="nombre_plan" id="plan_nombre" required></div>
      <div class="form-row"><label>Precio</label><input type="text" name="precio" id="plan_precio"></div>
      <div class="form-row"><label>Descripción</label><textarea name="descripcion" id="plan_descripcion"></textarea></div>

      <div style="display:flex; gap:8px; justify-content:flex-end; margin-top:8px;">
        <button type="button" class="btn ghost" onclick="closePlanModal()">Cancelar</button>
        <button class="btn" type="submit">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
// utilidad para abrir edición de plan
function openPlanEdit(plan) {
  document.getElementById('plan_id').value = plan.id || '';
  document.getElementById('plan_nombre').value = plan.nombre_plan || '';
  document.getElementById('plan_precio').value = plan.precio || '';
  document.getElementById('plan_descripcion').value = plan.descripcion || '';
  document.getElementById('modal-plan-edit').classList.add('show');
}
function closePlanModal(){
  document.getElementById('modal-plan-edit').classList.remove('show');
}

// Cerrar modales con ESC o click fuera
document.addEventListener('keydown', function(e){ if (e.key === 'Escape') { document.querySelectorAll('.modal.show').forEach(m=>m.classList.remove('show')); }});
document.addEventListener('click', function(e){
  const modal = e.target.closest('.modal.show');
  if (modal && !modal.querySelector('.modal-card').contains(e.target) && !e.target.closest('.btn')) {
    modal.classList.remove('show');
  }
});
</script>

<?php admin_footer(); ?>