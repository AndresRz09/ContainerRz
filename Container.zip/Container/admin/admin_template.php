<?php
require_once __DIR__ . '/../conexion.php';
session_start();

/* ============================================================
   VERIFICAR ACCESO
   ============================================================ */
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

/* ============================================================
   CONSULTAR PEDIDOS PAGADOS / FINALIZADOS
   ============================================================ */
$sql_pedidos = "
    SELECT 
        p.id,
        p.usuario_identificacion,
        u.nombre_completo,
        u.correo,
        u.pais,
        s.nombre AS servicio,
        ps.nombre_plan AS plan,
        p.titulo,
        p.monto,
        p.estado,
        p.fecha_creacion,
        p.fecha_actualizacion
    FROM pedidos p
    LEFT JOIN usuarios u ON u.identificacion = p.usuario_identificacion
    LEFT JOIN servicios s ON s.id = p.servicio_id
    LEFT JOIN planes_servicio ps ON ps.id = p.plan_id
    WHERE p.estado IN ('finalizado','pagado','aceptado')
    ORDER BY p.fecha_creacion DESC
";
$pedidos = $conexion->query($sql_pedidos);

/* ============================================================
   CONSULTA DE REPORTES GENERADOS
   ============================================================ */
$sql_reportes = "
    SELECT 
        r.*, 
        u.nombre_completo AS generado_por_nombre
    FROM reportes r
    LEFT JOIN usuarios u ON u.identificacion = r.generado_por
    ORDER BY r.fecha_generado DESC
";
$reportes = $conexion->query($sql_reportes);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reportes — Administración</title>
<link rel="stylesheet" href="../style.css">

<style>
.card { background:#fff; padding:20px; margin-bottom:20px; border-radius:10px; }
.table { width:100%; border-collapse:collapse; margin-top:10px; }
.table th, .table td { border:1px solid #ddd; padding:10px; }
.table th { background:#f5f5f5; }
.btn { padding:6px 12px; background:#2563eb; color:#fff; border-radius:5px; text-decoration:none; }
.btn:hover { background:#1d4ed8; }
</style>

</head>
<body>

<main class="container section">

<h1>📊 Reportes del Sistema</h1>

<!-- BOTÓN REPORTE GENERAL -->
<div style="margin-bottom:20px;">
    <a class="btn" href="reporte_general_generar.php" target="_blank">📄 Generar Informe Contable General</a>
</div>


<!-- ============================================================
     TABLA DE PEDIDOS PAGADOS
     ============================================================ -->
<div class="card">
    <h2>🟦 Pedidos Pagados / Finalizados</h2>

    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Usuario</th>
                <th>Servicio</th>
                <th>Plan</th>
                <th>Valor</th>
                <th>Estado</th>
                <th>Fecha</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
        <?php while($p = $pedidos->fetch_assoc()): ?>
            <tr>
                <td><?= $p['id'] ?></td>

                <td>
                    <strong><?= htmlspecialchars($p['nombre_completo']) ?></strong><br>
                    <small><?= $p['correo'] ?></small><br>
                    <small><?= $p['usuario_identificacion'] ?></small>
                </td>

                <td><?= htmlspecialchars($p['servicio']) ?></td>
                <td><?= htmlspecialchars($p['plan']) ?></td>

                <td>$<?= number_format($p['monto'], 0, ',', '.') ?></td>

                <td style="text-transform:capitalize;">
                    <?= htmlspecialchars($p['estado']) ?>
                </td>

                <td>
                    <?= date("Y-m-d", strtotime($p['fecha_creacion'])) ?><br>
                    <small><?= date("H:i", strtotime($p['fecha_creacion'])) ?></small>
                </td>

                <td>
                    <a class="btn" href="reporte_generar.php?pedido=<?= $p['id'] ?>" target="_blank">
                        Generar PDF
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>


<!-- ============================================================
     TABLA DE REPORTES GENERADOS Y ALMACENADOS
     ============================================================ -->
<div class="card">
    <h2>📁 Reportes Generados</h2>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Pedido</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>PDF</th>
                <th>Generado Por</th>
                <th>Fecha</th>
            </tr>
        </thead>

        <tbody>
        <?php while($r = $reportes->fetch_assoc()): ?>
            <tr>
                <td><?= $r['id'] ?></td>

                <td>
                    <?php if ($r['pedido_id']): ?>
                        Pedido #<?= $r['pedido_id'] ?>
                    <?php else: ?>
                        <i>General</i>
                    <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($r['nombre_reporte']) ?></td>
                <td><?= nl2br(htmlspecialchars($r['descripcion'])) ?></td>

                <td>
                    <?php if (!empty($r['archivo_pdf'])): ?>
                        <a class="btn" target="_blank" href="../uploads/reportes/<?= $r['archivo_pdf'] ?>">
                            Ver PDF
                        </a>
                    <?php else: ?>
                        <span>No almacenado</span>
                    <?php endif; ?>
                </td>

                <td><?= htmlspecialchars($r['generado_por_nombre']) ?></td>

                <td><?= $r['fecha_generado'] ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

</main>
</body>
</html>