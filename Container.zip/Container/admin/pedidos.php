<?php
// admin/pedidos.php
require_once __DIR__ . '/admin_template.php'; // incluye conexion, session_start() y control de rol (admin)

// ---------- ACCIONES POST ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // CAMBIAR ESTADO
    if ($action === 'cambiar_estado') {
        $pedido_id = intval($_POST['pedido_id'] ?? 0);
        $nuevo_estado = $_POST['estado'] ?? '';
        $nota = trim($_POST['nota'] ?? '');

        if ($pedido_id > 0 && $nuevo_estado !== '') {
            $stmt = $conexion->prepare("UPDATE pedidos SET estado = ?, fecha_actualizacion = NOW() WHERE id = ?");
            $stmt->bind_param("si", $nuevo_estado, $pedido_id);
            $stmt->execute();
            $stmt->close();

            // Insertar en historial
            $actor = $_SESSION['identificacion'] ?? ($_SESSION['user_id'] ?? 'admin');
            $stmt2 = $conexion->prepare("INSERT INTO pedidos_historial (pedido_id, actor, accion, nota, fecha) VALUES (?, ?, ?, ?, NOW())");
            $stmt2->bind_param("isss", $pedido_id, $actor, $nuevo_estado, $nota);
            $stmt2->execute();
            $stmt2->close();

            registrar_log($conexion, $actor, $_SESSION['rol'] ?? 'admin', "Cambio estado pedido $pedido_id -> $nuevo_estado");
        }

        header('Location: pedidos.php' . (isset($_GET['estado']) ? '?estado=' . urlencode($_GET['estado']) : ''));
        exit;
    }

    // ASIGNAR EMPLEADO
    if ($action === 'asignar') {
        $pedido_id = intval($_POST['pedido_id'] ?? 0);
        $empleado = trim($_POST['empleado'] ?? '');
        $nota = trim($_POST['nota'] ?? '');

        if ($pedido_id > 0) {
            $stmt = $conexion->prepare("UPDATE pedidos SET empleado_asignado = ? WHERE id = ?");
            $stmt->bind_param("si", $empleado, $pedido_id);
            $stmt->execute();
            $stmt->close();

            $actor = $_SESSION['identificacion'] ?? ($_SESSION['user_id'] ?? 'admin');
            $stmt2 = $conexion->prepare("INSERT INTO pedidos_historial (pedido_id, actor, accion, nota, fecha) VALUES (?, ?, 'asignado', ?, NOW())");
            $stmt2->bind_param("iss", $pedido_id, $actor, $nota);
            $stmt2->execute();
            $stmt2->close();

            registrar_log($conexion, $actor, $_SESSION['rol'] ?? 'admin', "Asignó empleado $empleado a pedido $pedido_id");
        }

        header('Location: pedidos.php');
        exit;
    }

    // AGREGAR NOTA RÁPIDA (opcional)
    if ($action === 'agregar_nota') {
        $pedido_id = intval($_POST['pedido_id'] ?? 0);
        $nota = trim($_POST['nota'] ?? '');
        if ($pedido_id > 0 && $nota !== '') {
            $actor = $_SESSION['identificacion'] ?? ($_SESSION['user_id'] ?? 'admin');
            $stmt = $conexion->prepare("INSERT INTO pedidos_historial (pedido_id, actor, accion, nota, fecha) VALUES (?, ?, 'nota', ?, NOW())");
            $stmt->bind_param("iss", $pedido_id, $actor, $nota);
            $stmt->execute();
            $stmt->close();
            registrar_log($conexion, $actor, $_SESSION['rol'] ?? 'admin', "Agregó nota a pedido $pedido_id");
        }
        header('Location: pedidos.php');
        exit;
    }
}

// ---------- ENDPOINT AJAX: devolver historial en JSON ----------
if (isset($_GET['fetch']) && $_GET['fetch'] === 'historial' && isset($_GET['pedido_id'])) {
    $pedido_id = intval($_GET['pedido_id']);
    header('Content-Type: application/json; charset=utf-8');

    $stmt = $conexion->prepare("SELECT id, actor, accion, nota, fecha FROM pedidos_historial WHERE pedido_id = ? ORDER BY fecha DESC");
    $stmt->bind_param("i", $pedido_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $hist = [];
    while ($r = $res->fetch_assoc()) $hist[] = $r;
    $stmt->close();

    echo json_encode(['ok' => true, 'historial' => $hist]);
    exit;
}

// ---------- CONSULTAS Y FILTROS ----------
$q = trim($_GET['q'] ?? '');
$filter_estado = trim($_GET['estado'] ?? '');
$filter_servicio = intval($_GET['servicio'] ?? 0);
$filter_empleado = trim($_GET['empleado'] ?? '');
$date_from = trim($_GET['date_from'] ?? '');
$date_to = trim($_GET['date_to'] ?? '');

// Paginación
$limit = 30;
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// Construir WHERE dinámico y parámetros para prepared statements
$where = [];
$params = [];
$types = '';

if ($q !== '') {
    $where[] = "(p.titulo LIKE ? OR p.descripcion LIKE ? OR p.usuario_identificacion LIKE ?)";
    $like = "%$q%";
    $params[] = $like; $params[] = $like; $params[] = $like;
    $types .= "sss";
}
if ($filter_estado !== '') {
    $where[] = "p.estado = ?";
    $params[] = $filter_estado;
    $types .= "s";
}
if ($filter_servicio > 0) {
    $where[] = "p.servicio_id = ?";
    $params[] = $filter_servicio;
    $types .= "i";
}
if ($filter_empleado !== '') {
    $where[] = "p.empleado_asignado = ?";
    $params[] = $filter_empleado;
    $types .= "s";
}
if ($date_from !== '') {
    $where[] = "p.fecha_creacion >= ?";
    $params[] = $date_from . " 00:00:00";
    $types .= "s";
}
if ($date_to !== '') {
    $where[] = "p.fecha_creacion <= ?";
    $params[] = $date_to . " 23:59:59";
    $types .= "s";
}

$where_sql = count($where) ? ("WHERE " . implode(" AND ", $where)) : "";

// total para paginación
$count_sql = "SELECT COUNT(*) AS c FROM pedidos p $where_sql";
$stmtc = $conexion->prepare($count_sql);
if ($types !== '') {
    $stmtc->bind_param($types, ...$params);
}
$stmtc->execute();
$total = $stmtc->get_result()->fetch_assoc()['c'] ?? 0;
$stmtc->close();

// Query principal: traer pedidos con servicio y plan
$sql = "
    SELECT p.*, s.nombre AS servicio_nombre, ps.nombre_plan AS plan_nombre
    FROM pedidos p
    LEFT JOIN servicios s ON s.id = p.servicio_id
    LEFT JOIN planes_servicio ps ON ps.id = p.plan_id
    $where_sql
    ORDER BY p.fecha_creacion DESC
    LIMIT ? OFFSET ?
";
$stmt = $conexion->prepare($sql);

// bind params (dinámico)
if ($types === '') {
    $stmt->bind_param("ii", $limit, $offset);
} else {
    // ajustar tipos con ii
    $bind_types = $types . "ii";
    $bind_params = array_merge($params, [$limit, $offset]);
    $stmt->bind_param($bind_types, ...$bind_params);
}
$stmt->execute();
$res = $stmt->get_result();
$stmt->close();

// Datos auxiliares para filtros y stats
$servicios_res = $conexion->query("SELECT id, nombre FROM servicios ORDER BY nombre ASC");
$empleados_res = $conexion->query("SELECT identificacion, nombre_completo FROM usuarios WHERE rol = 'empleado' ORDER BY nombre_completo ASC");

// Estadísticas rápidas
$stats = [];
$rs = $conexion->query("SELECT estado, COUNT(*) AS c FROM pedidos GROUP BY estado");
while ($r = $rs->fetch_assoc()) $stats[$r['estado']] = intval($r['c']);
$total_pedidos = array_sum($stats) ?: 0;

// render header
admin_header("Pedidos");
?>

<style>
/* estilos menores adicionales (usa admin.css global) */
.kv { color: var(--muted); }
.stats-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-bottom:16px; }
.stat-card { padding:14px; border-radius:12px; background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); border:1px solid rgba(255,255,255,0.03); text-align:center; }
.stat-card h4 { margin:0; color:var(--gold); font-size:0.95rem; }
.stat-card p { font-size:1.5rem; margin-top:8px; font-weight:800; color:var(--accent); }
.table { width:100%; border-collapse:collapse; margin-top:12px; }
.table th, .table td { padding:10px 12px; border-bottom:1px solid rgba(255,255,255,0.04); text-align:left; vertical-align:middle; }
.estado-tag { padding:6px 10px; border-radius:8px; font-weight:700; display:inline-block; text-transform:capitalize; }
.estado-pendiente { background:#facc15; color:#000; }
.estado-en_proceso { background:#38bdf8; color:#000; }
.estado-aceptado { background:#4ade80; color:#000; }
.estado-modificado { background:#a78bfa; color:#000; }
.estado-finalizado { background:#16a34a; color:#fff; }
.estado-rechazado { background:#ef4444; color:#fff; }
.estado-cancelado { background:#6b7280; color:#fff; }
.form-inline { display:inline-block; margin-right:6px; }
.small-input { padding:6px 8px; border-radius:8px; border:1px solid rgba(255,255,255,0.04); }
.chips { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.chip { padding:6px 10px; border-radius:999px; background:rgba(255,255,255,0.02); }
</style>

<div class="card" style="margin-bottom:12px;">
  <div style="display:flex; justify-content:space-between; align-items:center; gap:12px;">
    <div>
      <h3>Pedidos</h3>
      <div class="kv">Controla y gestiona todos los pedidos realizados por los usuarios.</div>
    </div>
    <div class="kv">Total pedidos: <strong><?php echo $total_pedidos; ?></strong></div>
  </div>
</div>

<!-- Estadísticas rápidas -->
<div class="stats-grid">
  <div class="stat-card">
    <h4>Total</h4>
    <p><?php echo $total_pedidos; ?></p>
  </div>
  <div class="stat-card">
    <h4>Pendientes</h4>
    <p><?php echo $stats['pendiente'] ?? 0; ?></p>
  </div>
  <div class="stat-card">
    <h4>En proceso</h4>
    <p><?php echo $stats['en_proceso'] ?? 0; ?></p>
  </div>
  <div class="stat-card">
    <h4>Aceptados</h4>
    <p><?php echo $stats['aceptado'] ?? 0; ?></p>
  </div>
  <div class="stat-card">
    <h4>Finalizados</h4>
    <p><?php echo $stats['finalizado'] ?? 0; ?></p>
  </div>
  <div class="stat-card">
    <h4>Cancelados / Rechazados</h4>
    <p><?php echo (($stats['cancelado'] ?? 0) + ($stats['rechazado'] ?? 0)); ?></p>
  </div>
</div>

<!-- FILTROS -->
<div class="card" style="margin-bottom:14px;">
  <form method="get" style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
    <input type="text" name="q" placeholder="Buscar por título, descripción o usuario" value="<?php echo htmlspecialchars($q); ?>" style="min-width:260px; padding:8px; border-radius:8px;">
    <select name="estado" class="small-input">
      <option value="">-- Estado --</option>
      <?php
      $estados = ['pendiente','en_proceso','aceptado','modificado','finalizado','rechazado','cancelado'];
      foreach ($estados as $e) {
          $sel = $filter_estado === $e ? 'selected' : '';
          echo "<option value=\"$e\" $sel>" . ucfirst(str_replace('_',' ',$e)) . "</option>";
      }
      ?>
    </select>

    <select name="servicio" class="small-input">
      <option value="0">-- Servicio --</option>
      <?php
      $servicios_res->data_seek(0);
      while ($s = $servicios_res->fetch_assoc()) {
          $sel = ($filter_servicio == $s['id']) ? 'selected' : '';
          echo "<option value=\"" . intval($s['id']) . "\" $sel>" . htmlspecialchars($s['nombre']) . "</option>";
      }
      ?>
    </select>

    <select name="empleado" class="small-input">
      <option value="">-- Empleado asignado --</option>
      <?php
      $empleados_res->data_seek(0);
      while ($em = $empleados_res->fetch_assoc()) {
          $sel = ($filter_empleado === $em['identificacion']) ? 'selected' : '';
          echo "<option value=\"" . htmlspecialchars($em['identificacion']) . "\" $sel>" . htmlspecialchars($em['nombre_completo']) . "</option>";
      }
      ?>
    </select>

    <label class="kv">Desde</label>
    <input type="date" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" class="small-input">
    <label class="kv">Hasta</label>
    <input type="date" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" class="small-input">

    <button class="btn" type="submit">Filtrar</button>
    <a class="btn ghost" href="pedidos.php">Limpiar</a>
  </form>
</div>

<!-- TABLA -->
<div class="card">
  <table class="table">
    <thead>
      <tr>
        <th>#</th>
        <th>Usuario</th>
        <th>Servicio</th>
        <th>Plan</th>
        <th>Título</th>
        <th>Estado</th>
        <th>Empleado</th>
        <th>Creado</th>
        <th style="min-width:320px;">Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php while ($p = $res->fetch_assoc()): ?>
        <tr>
          <td><?php echo $p['id']; ?></td>
          <td><?php echo htmlspecialchars($p['usuario_identificacion']); ?></td>
          <td><?php echo htmlspecialchars($p['servicio_nombre']); ?></td>
          <td><?php echo htmlspecialchars($p['plan_nombre']); ?></td>
          <td><?php echo htmlspecialchars($p['titulo']); ?></td>
          <td>
            <span class="estado-tag estado-<?php echo htmlspecialchars($p['estado']); ?>">
              <?php echo htmlspecialchars(str_replace('_',' ',$p['estado'])); ?>
            </span>
          </td>
          <td><?php echo htmlspecialchars($p['empleado_asignado']); ?></td>
          <td><?php echo htmlspecialchars($p['fecha_creacion']); ?></td>
          <td style="white-space:nowrap;">
            <a class="btn" href="detalle_pedido.php?id=<?php echo $p['id']; ?>">Ver</a>

            <!-- cambiar estado (inline) -->
            <form method="post" class="form-inline" style="display:inline-block;">
              <input type="hidden" name="action" value="cambiar_estado">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <select name="estado" class="small-input">
                <?php foreach ($estados as $e): $sel = ($p['estado']==$e)?'selected':''; ?>
                  <option value="<?php echo $e; ?>" <?php echo $sel; ?>><?php echo ucfirst(str_replace('_',' ',$e)); ?></option>
                <?php endforeach; ?>
              </select>
              <input type="text" name="nota" placeholder="Nota (opcional)" class="small-input" style="width:160px;">
              <button class="btn" type="submit">Guardar</button>
            </form>

            <!-- asignar empleado (inline) -->
            <form method="post" class="form-inline" style="display:inline-block;">
              <input type="hidden" name="action" value="asignar">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <select name="empleado" class="small-input">
                <option value="">— empleado —</option>
                <?php
                $empleados_res->data_seek(0);
                while ($e = $empleados_res->fetch_assoc()) {
                    $sel = ($p['empleado_asignado'] === $e['identificacion']) ? 'selected' : '';
                    echo '<option value="' . htmlspecialchars($e['identificacion']) . '" ' . $sel . '>' . htmlspecialchars($e['nombre_completo']) . '</option>';
                }
                ?>
              </select>
              <input type="text" name="nota" placeholder="Nota (opcional)" class="small-input" style="width:140px;">
              <button class="btn" type="submit">Asignar</button>
            </form>

            <!-- historial modal -->
            <button class="btn ghost" onclick="openHist(<?php echo $p['id']; ?>)">Historial</button>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>

  <!-- PAGINACION SIMPLE -->
  <div style="margin-top:12px; display:flex; justify-content:space-between; align-items:center;">
    <div class="kv">Mostrando <?php echo ($total>0) ? ($offset+1) : 0; ?> - <?php echo min($offset + $limit, $total); ?> de <?php echo $total; ?> pedidos</div>
    <div style="display:flex; gap:8px; align-items:center;">
      <?php
        $last_page = max(1, ceil($total / $limit));
        $base_q = $_GET;
      ?>
      <?php if ($page > 1): $base_q['page'] = $page - 1; ?>
        <a class="btn ghost" href="pedidos.php?<?php echo http_build_query($base_q); ?>">« Anterior</a>
      <?php endif; ?>

      <div class="chip">Página <?php echo $page; ?> / <?php echo $last_page; ?></div>

      <?php if ($page < $last_page): $base_q['page'] = $page + 1; ?>
        <a class="btn" href="pedidos.php?<?php echo http_build_query($base_q); ?>">Siguiente »</a>
      <?php endif; ?>
    </div>
  </div>

</div>

<!-- MODAL HISTORIAL -->
<div class="modal" id="modalHist">
  <div class="modal-card" style="position:relative;">
    <span class="modal-close" onclick="closeHist()" style="position:absolute; right:16px; top:12px; cursor:pointer;">×</span>
    <h3 style="color:var(--gold);">Historial del pedido <span id="histPedidoId"></span></h3>
    <div id="histContent" style="margin-top:12px;">
      <p class="kv">Cargando...</p>
    </div>
  </div>
</div>

<script>
async function openHist(pedidoId) {
  document.getElementById('modalHist').classList.add('show');
  document.getElementById('histPedidoId').innerText = pedidoId;
  const content = document.getElementById('histContent');
  content.innerHTML = '<p class="kv">Cargando historial...</p>';

  try {
    const res = await fetch('pedidos.php?fetch=historial&pedido_id=' + encodeURIComponent(pedidoId));
    const json = await res.json();
    if (!json.ok) {
      content.innerHTML = '<p class="kv">Error al cargar historial.</p>';
      return;
    }
    const hist = json.historial;
    if (hist.length === 0) {
      content.innerHTML = '<p class="kv">No hay historial para este pedido.</p>';
      return;
    }

    let html = '<ul style="list-style:none; padding:0; margin:0;">';
    for (const h of hist) {
      html += `<li style="padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.04);">
        <div style="display:flex; justify-content:space-between; gap:12px;">
          <div>
            <strong>${escapeHtml(h.accion)}</strong>
            <div class="kv">Actor: ${escapeHtml(h.actor)}</div>
          </div>
          <div class="kv">${escapeHtml(h.fecha)}</div>
        </div>
        <div style="margin-top:8px;">${h.nota ? escapeHtml(h.nota) : ''}</div>
      </li>`;
    }
    html += '</ul>';
    content.innerHTML = html;
  } catch (err) {
    content.innerHTML = '<p class="kv">Error al obtener datos.</p>';
    console.error(err);
  }
}

function closeHist(){
  document.getElementById('modalHist').classList.remove('show');
}

// small helper to escape HTML (for safety in modal)
function escapeHtml(unsafe) {
    if (unsafe === null || unsafe === undefined) return '';
    return String(unsafe)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
}
</script>

<?php admin_footer(); ?>