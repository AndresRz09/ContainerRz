<?php
require_once __DIR__ . '/admin_template.php';

// ===================== CONTADORES ===================== //
$c1 = $conexion->query("SELECT COUNT(*) AS c FROM usuarios")->fetch_assoc()['c'] ?? 0;
$c2 = $conexion->query("SELECT COUNT(*) AS c FROM servicios")->fetch_assoc()['c'] ?? 0;
$c3 = $conexion->query("SELECT COUNT(*) AS c FROM pedidos")->fetch_assoc()['c'] ?? 0;
$c4 = $conexion->query("SELECT COUNT(*) AS c FROM logs")->fetch_assoc()['c'] ?? 0;

// ===================== CONSULTAS EXTRA ===================== //
$last_users = $conexion->query(
    "SELECT nombre, email, creado 
     FROM usuarios 
     ORDER BY creado DESC 
     LIMIT 5"
);

$last_orders = $conexion->query(
    "SELECT p.id, p.estado, s.nombre AS servicio, p.fecha 
     FROM pedidos p 
     LEFT JOIN servicios s ON s.id = p.servicio_id 
     ORDER BY p.fecha DESC 
     LIMIT 5"
);

$lr = $conexion->query("SELECT * FROM logs ORDER BY fecha DESC LIMIT 10");

admin_header('Dashboard');
?>

<!-- ===================== TARJETAS DE ESTADÍSTICAS ===================== -->
<div class="grid-3">
    <div class="card stat-card">
        <h3>Usuarios</h3>
        <p class="stat-number"><?php echo $c1; ?></p>
    </div>

    <div class="card stat-card">
        <h3>Servicios</h3>
        <p class="stat-number"><?php echo $c2; ?></p>
    </div>

    <div class="card stat-card">
        <h3>Pedidos</h3>
        <p class="stat-number"><?php echo $c3; ?></p>
    </div>
</div>

<!-- ===================== ACCIONES RÁPIDAS ===================== -->
<div class="card" style="margin-top:20px">
    <h3>Acciones rápidas</h3>
    <div class="quick-actions">
        <a href="servicios.php" class="qa-btn">➕ Crear servicio</a>
        <a href="usuarios.php" class="qa-btn">👤 Crear usuario</a>
        <a href="pedidos.php" class="qa-btn">📦 Ver pedidos</a>
        <a href="backups.php" class="qa-btn">💾 Copia de seguridad</a>
    </div>
</div>

<!-- ===================== ÚLTIMOS PEDIDOS ===================== -->
<div class="card" style="margin-top:20px">
    <h3>Últimos pedidos</h3>

    <table class="table-modern">
        <thead>
            <tr>
                <th>ID</th>
                <th>Servicio</th>
                <th>Estado</th>
                <th>Fecha</th>
            </tr>
        </thead>

        <tbody>
        <?php while($o = $last_orders->fetch_assoc()): ?>
            <tr>
                <td>#<?php echo $o['id']; ?></td>
                <td><?php echo htmlspecialchars($o['servicio']); ?></td>
                <td>
                    <span class="status-pill status-<?php echo strtolower($o['estado']); ?>">
                        <?php echo $o['estado']; ?>
                    </span>
                </td>
                <td><?php echo $o['fecha']; ?></td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<!-- ===================== ÚLTIMOS USUARIOS ===================== -->
<div class="card" style="margin-top:20px">
    <h3>Últimos usuarios registrados</h3>
    <ul class="last-users">
        <?php while($u = $last_users->fetch_assoc()): ?>
            <li>
                <strong><?php echo htmlspecialchars($u['nombre']); ?></strong>
                — <?php echo htmlspecialchars($u['email']); ?><br>
                <small>Registrado: <?php echo $u['creado']; ?></small>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<!-- ===================== LOGS ===================== -->
<div class="card" style="margin-top:20px; margin-bottom:18px">
    <h3>Últimos 10 logs</h3>
    <ul style="margin-top:10px; list-style:none; padding-left:0">
        <?php while($l = $lr->fetch_assoc()): ?>
            <li style="padding:8px 0; border-bottom:1px solid rgba(255,255,255,0.03)">
                <?php echo htmlspecialchars("{$l['fecha']} — {$l['usuario']} — {$l['accion']}"); ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<?php admin_footer(); ?>