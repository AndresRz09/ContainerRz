<?php
include 'conexion.php';
session_start();

$usuario_nombre = $_SESSION['user_name']  ?? 'Visitante';
$usuario_rol    = $_SESSION['rol']        ?? 'cliente';
$usuario_id     = $_SESSION['user_id']    ?? 0;
$avatar         = $_SESSION['avatar']     ?? 'assets/avatar-default.png';

// ── Historial de conversaciones guardadas ──────────────────────────
$historial = [];
if ($usuario_id && isset($conexion)) {
    $qh = $conexion->prepare(
        "SELECT id, titulo, fecha, resumen
         FROM ia_conversaciones
         WHERE usuario_id = ?
         ORDER BY fecha DESC LIMIT 20"
    );
    if ($qh) {
        $qh->bind_param("i", $usuario_id);
        $qh->execute();
        $rh = $qh->get_result();
        while ($row = $rh->fetch_assoc()) $historial[] = $row;
        $qh->close();
    }
}

// ── Herramientas / Módulos de IA disponibles ──────────────────────
$herramientas = [
    ['id' => 'asistente',     'ico' => '🤖', 'titulo' => 'Asistente General',       'desc' => 'Resuelve dudas, explica conceptos y responde preguntas.',          'color' => 'green',  'prompt' => 'Eres un asistente experto en tecnología y ciberseguridad de la plataforma Team VIROX. Responde de forma clara, precisa y educativa.'],
    ['id' => 'ciberseg',      'ico' => '🛡', 'titulo' => 'Ciberseguridad',           'desc' => 'Analiza vulnerabilidades, explica amenazas y sugiere defensas.',     'color' => 'red',    'prompt' => 'Eres un experto en ciberseguridad. Analiza, explica y asesora sobre vulnerabilidades, amenazas, hacking ético, protección de sistemas y buenas prácticas de seguridad.'],
    ['id' => 'codigo',        'ico' => '💻', 'titulo' => 'Asistente de Código',      'desc' => 'Genera, revisa, depura y optimiza código en múltiples lenguajes.',  'color' => 'blue',   'prompt' => 'Eres un experto desarrollador. Genera código limpio, bien documentado y optimizado. Explica cada solución. Soportas PHP, Python, JavaScript, SQL, Bash y más.'],
    ['id' => 'aprendizaje',   'ico' => '🎓', 'titulo' => 'Tutor de Aprendizaje',     'desc' => 'Crea rutas de estudio, quizzes y explicaciones personalizadas.',    'color' => 'purple', 'prompt' => 'Eres un tutor pedagógico especializado en tecnología y ciberseguridad. Crea rutas de aprendizaje, explica conceptos paso a paso, genera ejercicios y evalúa el progreso del estudiante.'],
    ['id' => 'analisis',      'ico' => '📊', 'titulo' => 'Análisis de Datos',        'desc' => 'Interpreta datos, genera insights y sugiere visualizaciones.',      'color' => 'gold',   'prompt' => 'Eres un analista de datos experto. Interpreta conjuntos de datos, encuentra patrones, genera insights accionables y sugiere formas de visualizar la información de manera efectiva.'],
    ['id' => 'proyectos',     'ico' => '🚀', 'titulo' => 'Gestor de Proyectos IA',   'desc' => 'Planifica proyectos, KPIs, tareas y estrategias de desarrollo.',    'color' => 'teal',   'prompt' => 'Eres un experto en gestión de proyectos de software. Ayuda a planificar, definir KPIs, estructurar tareas, asignar recursos y aplicar metodologías ágiles como Scrum y Kanban.'],
    ['id' => 'redaccion',     'ico' => '✍️', 'titulo' => 'Redacción & Contenido',    'desc' => 'Crea documentación técnica, artículos, reportes y presentaciones.', 'color' => 'pink',   'prompt' => 'Eres un experto en comunicación técnica y creativa. Redacta documentación, artículos técnicos, reportes ejecutivos, presentaciones y contenido educativo con claridad profesional.'],
    ['id' => 'redes',         'ico' => '🌐', 'titulo' => 'Redes & Infraestructura',  'desc' => 'Diagnóstica redes, configura servidores y optimiza infraestructura.','color' => 'orange', 'prompt' => 'Eres un experto en redes y administración de sistemas. Ayuda con configuración de servidores, diagnóstico de redes, optimización de infraestructura, protocolos y arquitecturas cloud.'],
    ['id' => 'ia_explica',    'ico' => '🧠', 'titulo' => 'IA & Machine Learning',    'desc' => 'Explica algoritmos de IA, ML y sus aplicaciones prácticas.',        'color' => 'indigo', 'prompt' => 'Eres un experto en Inteligencia Artificial y Machine Learning. Explica algoritmos, modelos, datasets, métricas y aplica conceptos de IA a problemas reales de forma comprensible.'],
    ['id' => 'optimizador',   'ico' => '⚡', 'titulo' => 'Optimizador de Sistemas',  'desc' => 'Mejora rendimiento, detecta cuellos de botella y sugiere mejoras.',  'color' => 'yellow', 'prompt' => 'Eres un experto en optimización de rendimiento. Analiza cuellos de botella, propone mejoras de performance en código, bases de datos, servidores y arquitecturas de software.'],
];

$colores = [
    'green'  => ['rgba(40,166,128,.15)',  'rgba(40,166,128,.4)',  '#35d4a8'],
    'red'    => ['rgba(239,68,68,.12)',   'rgba(239,68,68,.35)',  '#fca5a5'],
    'blue'   => ['rgba(59,130,246,.12)',  'rgba(59,130,246,.35)', '#93c5fd'],
    'purple' => ['rgba(139,92,246,.12)', 'rgba(139,92,246,.35)', '#c4b5fd'],
    'gold'   => ['rgba(218,165,32,.14)', 'rgba(218,165,32,.4)',  '#f0c840'],
    'teal'   => ['rgba(20,184,166,.12)', 'rgba(20,184,166,.35)', '#5eead4'],
    'pink'   => ['rgba(236,72,153,.12)', 'rgba(236,72,153,.35)', '#f9a8d4'],
    'orange' => ['rgba(249,115,22,.12)', 'rgba(249,115,22,.35)', '#fdba74'],
    'indigo' => ['rgba(99,102,241,.12)', 'rgba(99,102,241,.35)', '#a5b4fc'],
    'yellow' => ['rgba(234,179,8,.12)',  'rgba(234,179,8,.35)',  '#fde047'],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>IA VIROX — Asistente Inteligente</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ══════════════════════════════════════════════════════════════
       VARIABLES — Una sola fuente: Syne
    ══════════════════════════════════════════════════════════════ */
    :root {
      --n900: #020817; --n800: #0c1526; --n700: #111827; --n600: #182035; --n500: #1e2d47; --n400: #243450;
      --gold: #DAA520; --gold-lt: #f0c840; --gold-dim: rgba(218,165,32,.14);
      --green: #28A680; --green-lt: #35d4a8; --green-dim: rgba(40,166,128,.14);
      --red: #ef4444; --red-dim: rgba(239,68,68,.12);
      --txt: #f0f4f8; --muted: #8da0b8; --dim: #526278;
      --r-sm: 8px; --r-md: 14px; --r-lg: 22px; --r-xl: 32px;
      --font: 'Syne', sans-serif;
      --hh: 68px;
      --idx-w: 280px;
      --chat-max: 860px;
    }
    *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; -webkit-font-smoothing:antialiased; }
    html { scroll-behavior:smooth; }
    body { font-family:var(--font); background:var(--n900); color:var(--txt); height:100vh; display:flex; flex-direction:column; overflow:hidden; }
    ::-webkit-scrollbar { width:4px; height:4px; }
    ::-webkit-scrollbar-track { background:var(--n800); }
    ::-webkit-scrollbar-thumb { background:var(--green); border-radius:99px; }
    a { text-decoration:none; color:inherit; }
    button { cursor:pointer; border:none; font-family:var(--font); }

    /* ══ HEADER ═══════════════════════════════════════════════════ */
    .ia-header {
      height: var(--hh); flex-shrink:0;
      background: rgba(2,8,23,.92); backdrop-filter:blur(20px);
      border-bottom: 1px solid rgba(40,166,128,.2);
      display:flex; align-items:center; justify-content:space-between;
      padding: 0 24px; z-index:200;
    }
    .ia-header-left { display:flex; align-items:center; gap:14px; }
    .ia-brand { display:flex; align-items:center; gap:8px; }
    .ia-brand-hex { font-size:1.3rem; color:var(--green); filter:drop-shadow(0 0 8px var(--green)); }
    .ia-brand-name { font-size:1.2rem; font-weight:900; color:var(--gold); letter-spacing:4px; }
    .ia-sep { width:1px; height:24px; background:rgba(255,255,255,.1); }
    .ia-title-badge {
      display:flex; align-items:center; gap:7px;
      padding:5px 14px; border-radius:99px;
      background:var(--green-dim); border:1px solid rgba(40,166,128,.35);
      font-size:.78rem; font-weight:700; color:var(--green-lt); letter-spacing:1px;
    }
    .ia-title-badge .pulse-dot {
      width:8px; height:8px; background:var(--green); border-radius:50%;
      animation:pdot 1.8s ease-in-out infinite;
    }
    @keyframes pdot { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(.7)} }

    .ia-header-right { display:flex; align-items:center; gap:10px; }
    .hdr-btn {
      display:flex; align-items:center; gap:6px;
      padding:7px 14px; border-radius:var(--r-md);
      background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.1);
      color:var(--muted); font-size:.8rem; font-weight:600;
      transition:all .2s;
    }
    .hdr-btn:hover { background:rgba(255,255,255,.1); color:var(--txt); }
    .hdr-btn.active { background:var(--green-dim); border-color:var(--green); color:var(--green-lt); }
    .hdr-av { width:32px; height:32px; border-radius:50%; object-fit:cover; border:2px solid var(--green); }
    .hdr-uname { font-size:.82rem; font-weight:600; }

    /* ══ LAYOUT PRINCIPAL ════════════════════════════════════════ */
    .ia-layout {
      display:grid;
      grid-template-columns: var(--idx-w) 1fr 280px;
      flex:1; overflow:hidden;
    }

    /* ══ PANEL IZQUIERDO — ÍNDICE DE FUNCIONES ══════════════════ */
    .ia-sidebar {
      background:var(--n800); border-right:1px solid rgba(255,255,255,.05);
      display:flex; flex-direction:column; overflow:hidden;
    }
    .isb-hd {
      padding:16px 18px 12px; border-bottom:1px solid rgba(255,255,255,.06); flex-shrink:0;
      background:linear-gradient(to right, rgba(40,166,128,.06), transparent);
    }
    .isb-hd-title { font-size:.72rem; font-weight:800; color:var(--gold); text-transform:uppercase; letter-spacing:2px; margin-bottom:10px; }
    .isb-search {
      display:flex; align-items:center; gap:8px;
      background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-md); padding:7px 11px;
    }
    .isb-search i { color:var(--muted); font-size:.78rem; flex-shrink:0; }
    .isb-search input {
      background:none; border:none; outline:none;
      color:var(--txt); font-family:var(--font); font-size:.8rem; width:100%;
    }
    .isb-search input::placeholder { color:var(--dim); }

    .isb-body { overflow-y:auto; flex:1; padding:8px 10px; }
    .isb-sec-lbl {
      font-size:.6rem; font-weight:800; color:var(--dim);
      text-transform:uppercase; letter-spacing:2px;
      padding:10px 6px 4px; display:flex; align-items:center; gap:6px;
    }
    .isb-sec-lbl::after { content:''; flex:1; height:1px; background:rgba(255,255,255,.05); }

    /* Tarjeta de herramienta en sidebar */
    .tool-item {
      display:flex; align-items:center; gap:10px;
      padding:9px 10px; border-radius:var(--r-md);
      cursor:pointer; transition:all .2s; margin-bottom:3px;
      border:1px solid transparent;
    }
    .tool-item:hover { background:rgba(255,255,255,.05); }
    .tool-item.active { background:var(--green-dim); border-color:rgba(40,166,128,.3); }
    .tool-item-ico {
      width:32px; height:32px; border-radius:var(--r-sm);
      display:flex; align-items:center; justify-content:center;
      font-size:1rem; flex-shrink:0;
      background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.08);
      transition:all .2s;
    }
    .tool-item.active .tool-item-ico { background:var(--green-dim); border-color:rgba(40,166,128,.3); }
    .tool-item-info { flex:1; min-width:0; }
    .tool-item-name { font-size:.82rem; font-weight:700; color:var(--txt); margin-bottom:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .tool-item.active .tool-item-name { color:var(--green-lt); }
    .tool-item-desc { font-size:.68rem; color:var(--muted); line-height:1.3; display:-webkit-box; -webkit-line-clamp:1; -webkit-box-orient:vertical; overflow:hidden; }

    /* Historial en sidebar */
    .hist-item {
      display:flex; align-items:center; gap:9px;
      padding:8px 10px; border-radius:var(--r-md);
      cursor:pointer; transition:all .2s; margin-bottom:2px;
    }
    .hist-item:hover { background:rgba(255,255,255,.05); }
    .hist-item i { font-size:.75rem; color:var(--dim); flex-shrink:0; width:14px; text-align:center; }
    .hist-item-txt { flex:1; min-width:0; }
    .hist-item-title { font-size:.78rem; color:var(--muted); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .hist-item-date  { font-size:.65rem; color:var(--dim); }
    .hist-del { width:20px; height:20px; border-radius:50%; background:none; color:var(--dim); font-size:.65rem; display:none; align-items:center; justify-content:center; transition:all .2s; }
    .hist-item:hover .hist-del { display:flex; }
    .hist-del:hover { background:rgba(239,68,68,.2); color:#f87171; }

    .isb-footer { padding:12px 14px; border-top:1px solid rgba(255,255,255,.05); flex-shrink:0; }
    .isb-new-chat {
      display:flex; align-items:center; justify-content:center; gap:8px;
      width:100%; padding:10px;
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      color:#fff; border-radius:var(--r-md); font-weight:700; font-size:.82rem;
      transition:all .2s; box-shadow:0 3px 12px rgba(40,166,128,.3);
    }
    .isb-new-chat:hover { transform:translateY(-2px); box-shadow:0 6px 20px rgba(40,166,128,.4); }

    /* ══ PANEL CENTRAL — CHAT ════════════════════════════════════ */
    .ia-chat-panel {
      display:flex; flex-direction:column; overflow:hidden;
      position:relative;
    }

    /* Tool header */
    .tool-header {
      padding:14px 24px; border-bottom:1px solid rgba(255,255,255,.06);
      background:rgba(12,21,38,.8); flex-shrink:0;
      display:flex; align-items:center; gap:14px;
    }
    .th-ico {
      width:40px; height:40px; border-radius:var(--r-md);
      display:flex; align-items:center; justify-content:center; font-size:1.2rem;
      background:var(--green-dim); border:1px solid rgba(40,166,128,.3); flex-shrink:0;
    }
    .th-info strong { display:block; font-size:.95rem; font-weight:700; color:var(--txt); margin-bottom:2px; }
    .th-info span { font-size:.75rem; color:var(--muted); }
    .th-actions { margin-left:auto; display:flex; gap:6px; }
    .th-btn {
      width:30px; height:30px; border-radius:50%;
      background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.1);
      color:var(--muted); font-size:.75rem; display:flex; align-items:center; justify-content:center;
      transition:all .2s;
    }
    .th-btn:hover { background:rgba(40,166,128,.15); color:var(--green-lt); border-color:var(--green); }

    /* Área de mensajes */
    .chat-messages {
      flex:1; overflow-y:auto; padding:24px;
      scroll-behavior:smooth;
      background:
        radial-gradient(ellipse 60% 40% at 50% 0%, rgba(40,166,128,.04) 0%, transparent 60%),
        var(--n900);
    }

    /* Pantalla de bienvenida */
    .chat-welcome {
      display:flex; flex-direction:column; align-items:center; justify-content:center;
      min-height:100%; text-align:center; padding:32px;
    }
    .cw-orb {
      position:relative; width:100px; height:100px;
      display:flex; align-items:center; justify-content:center; margin-bottom:24px;
    }
    .cw-ring {
      position:absolute; border-radius:50%; border:1.5px solid rgba(40,166,128,.25);
      animation:spin 10s linear infinite;
    }
    .cw-ring:nth-child(1) { inset:0; }
    .cw-ring:nth-child(2) { inset:12px; animation-duration:7s; animation-direction:reverse; }
    .cw-ring:nth-child(3) { inset:24px; animation-duration:4s; }
    @keyframes spin { to{transform:rotate(360deg)} }
    .cw-ico { font-size:2.8rem; position:relative; z-index:1; }
    .cw-title { font-size:1.4rem; font-weight:800; color:var(--txt); margin-bottom:8px; }
    .cw-sub { font-size:.88rem; color:var(--muted); line-height:1.7; max-width:480px; margin-bottom:28px; }

    /* Quick start cards */
    .cw-cards { display:grid; grid-template-columns:1fr 1fr; gap:10px; width:100%; max-width:520px; }
    .cw-card {
      background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-md); padding:14px 16px;
      text-align:left; cursor:pointer; transition:all .2s;
    }
    .cw-card:hover { background:var(--green-dim); border-color:rgba(40,166,128,.3); }
    .cw-card-ico { font-size:1.2rem; margin-bottom:6px; }
    .cw-card-txt { font-size:.8rem; color:var(--muted); line-height:1.4; }
    .cw-card:hover .cw-card-txt { color:var(--green-lt); }

    /* Burbujas de mensaje */
    .msg { display:flex; gap:10px; margin-bottom:18px; animation:msgIn .3s ease both; }
    @keyframes msgIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:none} }
    .msg.user { flex-direction:row-reverse; }

    .msg-av {
      width:32px; height:32px; border-radius:50%; flex-shrink:0;
      display:flex; align-items:center; justify-content:center;
      font-size:.85rem; overflow:hidden;
    }
    .msg-av img { width:100%; height:100%; object-fit:cover; }
    .msg-av.ai-av { background:var(--green-dim); border:1px solid rgba(40,166,128,.3); color:var(--green-lt); }
    .msg-av.user-av { background:var(--gold-dim); border:1px solid rgba(218,165,32,.3); }

    .msg-bubble {
      max-width:72%; padding:12px 16px;
      border-radius:var(--r-lg); font-size:.875rem; line-height:1.7;
      position:relative;
    }
    .msg.ai .msg-bubble {
      background:var(--n600); border:1px solid rgba(255,255,255,.07);
      border-radius:4px var(--r-lg) var(--r-lg) var(--r-lg); color:var(--txt);
    }
    .msg.user .msg-bubble {
      background:linear-gradient(135deg,var(--green),#1d8f6e);
      border-radius:var(--r-lg) 4px var(--r-lg) var(--r-lg); color:#fff;
    }
    .msg-time { font-size:.62rem; color:var(--dim); margin-top:4px; text-align:right; }
    .msg.user .msg-time { text-align:left; }

    /* Código dentro de burbuja */
    .msg-bubble pre {
      background:rgba(0,0,0,.4); border:1px solid rgba(255,255,255,.08);
      border-radius:var(--r-sm); padding:12px; margin:8px 0;
      overflow-x:auto; font-size:.78rem; line-height:1.55; font-family:monospace;
    }
    .msg-bubble code { font-family:monospace; font-size:.82rem; }
    .msg-bubble p { margin-bottom:6px; }
    .msg-bubble p:last-child { margin-bottom:0; }
    .msg-bubble ul, .msg-bubble ol { margin:6px 0 6px 18px; }
    .msg-bubble li { margin-bottom:3px; }
    .msg-bubble strong { font-weight:700; }
    .msg-bubble h3, .msg-bubble h4 { font-weight:700; margin:8px 0 4px; color:var(--green-lt); }

    /* Acciones en mensaje IA */
    .msg-actions {
      display:flex; gap:5px; margin-top:6px; opacity:0; transition:opacity .2s;
    }
    .msg:hover .msg-actions { opacity:1; }
    .msg-act {
      width:24px; height:24px; border-radius:50%;
      background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.1);
      color:var(--dim); font-size:.65rem; display:flex; align-items:center; justify-content:center;
      cursor:pointer; transition:all .2s;
    }
    .msg-act:hover { background:var(--green-dim); color:var(--green-lt); border-color:var(--green); }

    /* Typing indicator */
    .typing-indicator {
      display:none; gap:10px; align-items:center; margin-bottom:18px;
    }
    .typing-indicator.show { display:flex; }
    .typing-dots { display:flex; gap:4px; padding:10px 14px; background:var(--n600); border-radius:var(--r-lg); border:1px solid rgba(255,255,255,.07); }
    .typing-dot { width:6px; height:6px; background:var(--muted); border-radius:50%; animation:tdot .8s ease-in-out infinite; }
    .typing-dot:nth-child(2) { animation-delay:.2s; }
    .typing-dot:nth-child(3) { animation-delay:.4s; }
    @keyframes tdot { 0%,80%,100%{transform:scale(.7);opacity:.4} 40%{transform:scale(1);opacity:1} }

    /* ══ ÁREA DE SUGERENCIAS + INPUT ════════════════════════════ */
    .chat-bottom { flex-shrink:0; border-top:1px solid rgba(255,255,255,.06); }

    /* Chips de sugerencias rápidas */
    .suggestions-bar {
      display:flex; gap:7px; padding:10px 20px; overflow-x:auto; flex-wrap:nowrap;
      background:rgba(12,21,38,.5);
      border-bottom:1px solid rgba(255,255,255,.04);
    }
    .suggestions-bar::-webkit-scrollbar { height:2px; }
    .sugg-chip {
      display:flex; align-items:center; gap:6px;
      padding:5px 13px; border-radius:99px; white-space:nowrap;
      background:rgba(255,255,255,.05); border:1px solid rgba(255,255,255,.1);
      color:var(--muted); font-size:.75rem; font-weight:600; cursor:pointer;
      transition:all .2s; flex-shrink:0; font-family:var(--font);
    }
    .sugg-chip:hover { background:var(--green-dim); border-color:rgba(40,166,128,.4); color:var(--green-lt); }

    /* Input area */
    .chat-input-area { padding:14px 20px; }
    .chat-input-box {
      display:flex; align-items:flex-end; gap:10px;
      background:var(--n600); border:1px solid rgba(255,255,255,.1);
      border-radius:var(--r-lg); padding:10px 14px;
      transition:border-color .2s, box-shadow .2s;
    }
    .chat-input-box:focus-within {
      border-color:var(--green); box-shadow:0 0 0 3px rgba(40,166,128,.1);
    }

    .input-tools { display:flex; gap:5px; align-items:center; flex-shrink:0; }
    .input-tool {
      width:28px; height:28px; border-radius:var(--r-sm);
      background:none; border:none; color:var(--dim); font-size:.8rem;
      display:flex; align-items:center; justify-content:center;
      cursor:pointer; transition:all .2s;
    }
    .input-tool:hover { background:rgba(255,255,255,.08); color:var(--muted); }

    #chatInput {
      flex:1; background:none; border:none; outline:none;
      color:var(--txt); font-family:var(--font); font-size:.88rem;
      line-height:1.6; resize:none; max-height:120px; min-height:22px;
    }
    #chatInput::placeholder { color:var(--dim); }

    .input-actions { display:flex; align-items:center; gap:6px; flex-shrink:0; }
    .char-count { font-size:.65rem; color:var(--dim); }
    .send-btn {
      width:36px; height:36px; border-radius:50%;
      background:var(--green); color:#fff; font-size:.85rem;
      display:flex; align-items:center; justify-content:center;
      transition:all .2s; box-shadow:0 2px 10px rgba(40,166,128,.3);
    }
    .send-btn:hover { background:var(--green-lt); transform:scale(1.08); }
    .send-btn:disabled { background:rgba(255,255,255,.1); color:var(--dim); transform:none; box-shadow:none; cursor:not-allowed; }

    .input-hint {
      display:flex; align-items:center; justify-content:space-between;
      padding:4px 2px 0; font-size:.65rem; color:var(--dim);
    }

    /* ══ PANEL DERECHO — INFO & HERRAMIENTAS ════════════════════ */
    .ia-right-panel {
      background:var(--n800); border-left:1px solid rgba(255,255,255,.05);
      display:flex; flex-direction:column; overflow:hidden;
    }
    .rp-hd {
      padding:14px 16px 10px; border-bottom:1px solid rgba(255,255,255,.06); flex-shrink:0;
    }
    .rp-hd-title { font-size:.72rem; font-weight:800; color:var(--gold); text-transform:uppercase; letter-spacing:2px; }

    .rp-body { overflow-y:auto; flex:1; padding:12px 14px; }

    /* Tool detail card */
    .tool-detail {
      background:var(--green-dim); border:1px solid rgba(40,166,128,.3);
      border-radius:var(--r-lg); padding:16px; margin-bottom:16px;
    }
    .td-ico { font-size:2rem; margin-bottom:8px; }
    .td-title { font-size:.9rem; font-weight:800; color:var(--txt); margin-bottom:4px; }
    .td-desc { font-size:.78rem; color:var(--muted); line-height:1.55; }

    /* Capacidades */
    .cap-list { display:flex; flex-direction:column; gap:6px; margin-bottom:16px; }
    .cap-item {
      display:flex; align-items:center; gap:8px;
      padding:8px 10px; border-radius:var(--r-md);
      background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.06);
      font-size:.78rem; color:var(--muted); cursor:pointer; transition:all .2s;
    }
    .cap-item:hover { background:var(--green-dim); color:var(--green-lt); border-color:rgba(40,166,128,.3); }
    .cap-ico { width:20px; text-align:center; font-size:.85rem; }

    /* Acciones rápidas derechas */
    .quick-actions { display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:16px; }
    .qa-btn {
      display:flex; flex-direction:column; align-items:center; gap:5px;
      padding:12px 8px; border-radius:var(--r-md);
      background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.07);
      font-size:.72rem; color:var(--muted); cursor:pointer; transition:all .2s;
      font-family:var(--font);
    }
    .qa-btn:hover { background:var(--green-dim); color:var(--green-lt); border-color:rgba(40,166,128,.3); }
    .qa-btn i { font-size:1.1rem; }

    /* Modelo info */
    .model-info {
      background:rgba(255,255,255,.03); border:1px solid rgba(255,255,255,.06);
      border-radius:var(--r-md); padding:12px 14px; margin-bottom:12px;
    }
    .mi-row { display:flex; justify-content:space-between; align-items:center; margin-bottom:5px; }
    .mi-lbl { font-size:.68rem; color:var(--dim); text-transform:uppercase; letter-spacing:1px; }
    .mi-val { font-size:.75rem; color:var(--muted); font-weight:600; }
    .mi-badge {
      padding:2px 8px; border-radius:99px;
      background:var(--green-dim); border:1px solid rgba(40,166,128,.3);
      font-size:.65rem; color:var(--green-lt); font-weight:700;
    }

    /* Stats sesión */
    .session-stats { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
    .ss-card {
      background:rgba(255,255,255,.04); border-radius:var(--r-md);
      padding:10px; text-align:center;
    }
    .ss-n { font-size:1.1rem; font-weight:800; color:var(--gold); }
    .ss-l { font-size:.6rem; color:var(--dim); text-transform:uppercase; letter-spacing:.5px; margin-top:2px; }

    /* Modo oscuro toggle / config */
    .rp-section-lbl {
      font-size:.62rem; font-weight:800; color:var(--dim);
      text-transform:uppercase; letter-spacing:2px;
      padding:10px 0 6px; border-bottom:1px solid rgba(255,255,255,.05);
      margin-bottom:8px;
    }

    /* Toggle switch */
    .toggle-row { display:flex; align-items:center; justify-content:space-between; padding:5px 0; }
    .toggle-label { font-size:.78rem; color:var(--muted); }
    .toggle { position:relative; width:36px; height:20px; }
    .toggle input { display:none; }
    .toggle-sl {
      position:absolute; inset:0; background:rgba(255,255,255,.1);
      border-radius:99px; cursor:pointer; transition:.3s;
    }
    .toggle-sl::before {
      content:''; position:absolute; width:14px; height:14px;
      background:#fff; border-radius:50%; top:3px; left:3px; transition:.3s;
    }
    .toggle input:checked + .toggle-sl { background:var(--green); }
    .toggle input:checked + .toggle-sl::before { transform:translateX(16px); }

    /* ══ RESPONSIVE ═══════════════════════════════════════════════ */
    @media (max-width:1200px) {
      .ia-layout { grid-template-columns:var(--idx-w) 1fr; }
      .ia-right-panel { display:none; }
    }
    @media (max-width:820px) {
      .ia-layout { grid-template-columns:1fr; }
      .ia-sidebar { display:none; }
      .ia-layout.sidebar-open .ia-sidebar {
        display:flex; position:fixed; left:0; top:var(--hh); bottom:0; z-index:500;
        width:var(--idx-w); box-shadow:4px 0 30px rgba(0,0,0,.5);
      }
    }
    @media (max-width:480px) {
      .ia-header { padding:0 14px; }
      .ia-brand-name { display:none; }
      .cw-cards { grid-template-columns:1fr; }
    }
  </style>
</head>
<body>

<!-- ══ HEADER ═════════════════════════════════════════════════════════ -->
<header class="ia-header">
  <div class="ia-header-left">
    <a href="index.php" class="ia-brand">
      <span class="ia-brand-hex">⬡</span>
      <span class="ia-brand-name">VIROX</span>
    </a>
    <div class="ia-sep"></div>
    <div class="ia-title-badge">
      <div class="pulse-dot"></div>
      IA VIROX — Asistente Activo
    </div>
  </div>

  <div class="ia-header-right">
    <button class="hdr-btn" onclick="toggleSidebar()" id="sidebarToggleBtn" title="Índice">
      <i class="fa fa-bars"></i>
    </button>
    <button class="hdr-btn" onclick="exportChat()" title="Exportar conversación">
      <i class="fa fa-download"></i> Exportar
    </button>
    <button class="hdr-btn" onclick="clearChat()" title="Nueva conversación">
      <i class="fa fa-rotate-right"></i> Nueva
    </button>
    <a href="index.php" class="hdr-btn">
      <i class="fa fa-house"></i> Inicio
    </a>
    <img src="<?= htmlspecialchars($avatar) ?>" class="hdr-av" alt="Avatar"
         onerror="this.src='assets/avatar-default.png'">
    <span class="hdr-uname"><?= htmlspecialchars($usuario_nombre) ?></span>
  </div>
</header>


<!-- ══ LAYOUT PRINCIPAL ════════════════════════════════════════════════ -->
<div class="ia-layout" id="iaLayout">

  <!-- ─── PANEL IZQUIERDO: ÍNDICE ───────────────────────────────── -->
  <aside class="ia-sidebar" id="iaSidebar">

    <div class="isb-hd">
      <div class="isb-hd-title">🔧 Funcionalidades</div>
      <div class="isb-search">
        <i class="fa fa-search"></i>
        <input type="text" id="toolSearch" placeholder="Buscar función...">
      </div>
    </div>

    <div class="isb-body" id="toolList">
      <div class="isb-sec-lbl">Módulos IA</div>
      <?php foreach ($herramientas as $tool):
        $clr = $colores[$tool['color']] ?? $colores['green'];
      ?>
      <div class="tool-item <?= $tool['id'] === 'asistente' ? 'active' : '' ?>"
           onclick="selectTool('<?= $tool['id'] ?>', this)"
           data-id="<?= $tool['id'] ?>"
           data-prompt="<?= htmlspecialchars($tool['prompt'], ENT_QUOTES) ?>"
           data-name="<?= htmlspecialchars(strtolower($tool['titulo'])) ?>"
           id="tool-<?= $tool['id'] ?>">
        <div class="tool-item-ico" style="background:<?= $clr[0] ?>;border-color:<?= $clr[1] ?>;">
          <?= $tool['ico'] ?>
        </div>
        <div class="tool-item-info">
          <div class="tool-item-name"><?= htmlspecialchars($tool['titulo']) ?></div>
          <div class="tool-item-desc"><?= htmlspecialchars($tool['desc']) ?></div>
        </div>
      </div>
      <?php endforeach; ?>

      <!-- Historial -->
      <?php if (!empty($historial)): ?>
      <div class="isb-sec-lbl" style="margin-top:14px;">Recientes</div>
      <?php foreach ($historial as $h): ?>
      <div class="hist-item" onclick="loadHistory(<?= $h['id'] ?>)">
        <i class="fa fa-clock-rotate-left"></i>
        <div class="hist-item-txt">
          <div class="hist-item-title"><?= htmlspecialchars($h['titulo'] ?? 'Conversación') ?></div>
          <div class="hist-item-date"><?= date('d M', strtotime($h['fecha'])) ?></div>
        </div>
        <button class="hist-del" onclick="deleteHistory(event, <?= $h['id'] ?>)"><i class="fa fa-xmark"></i></button>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <div class="isb-footer">
      <button class="isb-new-chat" onclick="clearChat()">
        <i class="fa fa-plus"></i> Nueva conversación
      </button>
    </div>

  </aside>


  <!-- ─── PANEL CENTRAL: CHAT ────────────────────────────────────── -->
  <div class="ia-chat-panel">

    <!-- Encabezado de herramienta activa -->
    <div class="tool-header" id="toolHeader">
      <div class="th-ico" id="thIco">🤖</div>
      <div class="th-info">
        <strong id="thTitle">Asistente General</strong>
        <span id="thDesc">Resuelve dudas, explica conceptos y responde preguntas.</span>
      </div>
      <div class="th-actions">
        <button class="th-btn" onclick="copyLastMsg()" title="Copiar última respuesta"><i class="fa fa-copy"></i></button>
        <button class="th-btn" onclick="toggleVoice()" title="Voz" id="voiceBtn"><i class="fa fa-microphone"></i></button>
        <button class="th-btn" onclick="clearChat()" title="Limpiar chat"><i class="fa fa-trash-can"></i></button>
      </div>
    </div>

    <!-- Mensajes -->
    <div class="chat-messages" id="chatMessages">
      <!-- Pantalla de bienvenida -->
      <div class="chat-welcome" id="chatWelcome">
        <div class="cw-orb">
          <div class="cw-ring"></div>
          <div class="cw-ring"></div>
          <div class="cw-ring"></div>
          <span class="cw-ico">🤖</span>
        </div>
        <h2 class="cw-title">IA VIROX activa</h2>
        <p class="cw-sub">Soy tu asistente inteligente. Puedo ayudarte con ciberseguridad, código, aprendizaje, proyectos, análisis de datos y mucho más. ¿Por dónde empezamos?</p>
        <div class="cw-cards">
          <div class="cw-card" onclick="sendQuick('¿Qué puedes hacer exactamente?')">
            <div class="cw-card-ico">💡</div>
            <div class="cw-card-txt">¿Qué puedes hacer exactamente?</div>
          </div>
          <div class="cw-card" onclick="sendQuick('Explícame qué es el ethical hacking')">
            <div class="cw-card-ico">🛡</div>
            <div class="cw-card-txt">Explícame qué es el ethical hacking</div>
          </div>
          <div class="cw-card" onclick="sendQuick('Crea un script en Python para escanear puertos')">
            <div class="cw-card-ico">💻</div>
            <div class="cw-card-txt">Crea un script Python para escanear puertos</div>
          </div>
          <div class="cw-card" onclick="sendQuick('Dame una ruta de aprendizaje en ciberseguridad para principiantes')">
            <div class="cw-card-ico">🎓</div>
            <div class="cw-card-txt">Ruta de aprendizaje en ciberseguridad</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Typing indicator -->
    <div class="typing-indicator" id="typingIndicator">
      <div class="msg-av ai-av"><i class="fa fa-robot"></i></div>
      <div class="typing-dots">
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
        <div class="typing-dot"></div>
      </div>
    </div>

    <!-- Bottom: sugerencias + input -->
    <div class="chat-bottom">
      <div class="suggestions-bar" id="suggestionsBar">
        <!-- Generadas dinámicamente por JS según la herramienta -->
      </div>

      <div class="chat-input-area">
        <div class="chat-input-box">
          <div class="input-tools">
            <button class="input-tool" onclick="insertFile()" title="Adjuntar archivo"><i class="fa fa-paperclip"></i></button>
            <button class="input-tool" onclick="insertCode()" title="Insertar bloque de código"><i class="fa fa-code"></i></button>
          </div>
          <textarea id="chatInput"
                    placeholder="Escribe tu consulta aquí... (Shift+Enter para nueva línea)"
                    rows="1"
                    maxlength="4000"
                    onkeydown="handleKey(event)"
                    oninput="autoResize(this); updateCount()"></textarea>
          <div class="input-actions">
            <span class="char-count" id="charCount">0/4000</span>
            <button class="send-btn" id="sendBtn" onclick="sendMessage()">
              <i class="fa fa-paper-plane"></i>
            </button>
          </div>
        </div>
        <div class="input-hint">
          <span>Enter para enviar · Shift+Enter nueva línea</span>
          <span id="modelBadge" style="color:var(--green-lt);font-weight:700;">claude-sonnet-4-6 · VIROX IA</span>
        </div>
      </div>
    </div>
  </div>


  <!-- ─── PANEL DERECHO: INFO DE HERRAMIENTA ──────────────────── -->
  <div class="ia-right-panel">

    <div class="rp-hd">
      <div class="rp-hd-title">🛠 Panel de Control</div>
    </div>

    <div class="rp-body">

      <!-- Detalle herramienta activa -->
      <div class="tool-detail" id="rpToolDetail">
        <div class="td-ico">🤖</div>
        <div class="td-title">Asistente General</div>
        <div class="td-desc">Resuelve dudas, explica conceptos y responde preguntas de cualquier área tecnológica.</div>
      </div>

      <!-- Capacidades rápidas -->
      <div class="rp-section-lbl">Acciones Rápidas</div>
      <div class="cap-list" id="capList">
        <div class="cap-item" onclick="sendQuick('Explica el concepto de manera sencilla y con ejemplos')">
          <span class="cap-ico">💡</span> Explicar con ejemplos
        </div>
        <div class="cap-item" onclick="sendQuick('Dame un resumen conciso de los puntos clave')">
          <span class="cap-ico">📋</span> Resumir puntos clave
        </div>
        <div class="cap-item" onclick="sendQuick('Genera un quiz de 5 preguntas sobre este tema')">
          <span class="cap-ico">🧩</span> Generar quiz
        </div>
        <div class="cap-item" onclick="sendQuick('Crea un plan de acción paso a paso')">
          <span class="cap-ico">🗺</span> Plan de acción
        </div>
        <div class="cap-item" onclick="sendQuick('Dame fuentes y recursos para aprender más')">
          <span class="cap-ico">📚</span> Recursos de aprendizaje
        </div>
      </div>

      <!-- Botones de herramientas contextuales -->
      <div class="rp-section-lbl">Herramientas</div>
      <div class="quick-actions">
        <button class="qa-btn" onclick="sendQuick('Analiza y detecta posibles vulnerabilidades')">
          <i class="fa fa-shield-halved"></i> Analizar
        </button>
        <button class="qa-btn" onclick="sendQuick('Optimiza el siguiente código o proceso')">
          <i class="fa fa-bolt"></i> Optimizar
        </button>
        <button class="qa-btn" onclick="sendQuick('Genera documentación técnica detallada')">
          <i class="fa fa-file-lines"></i> Documentar
        </button>
        <button class="qa-btn" onclick="sendQuick('Traduce este contenido al inglés técnico')">
          <i class="fa fa-language"></i> Traducir
        </button>
      </div>

      <!-- Modelo info -->
      <div class="rp-section-lbl">Modelo Activo</div>
      <div class="model-info">
        <div class="mi-row">
          <span class="mi-lbl">Modelo</span>
          <span class="mi-badge">Sonnet 4</span>
        </div>
        <div class="mi-row">
          <span class="mi-lbl">Estado</span>
          <span class="mi-val" style="color:var(--green-lt);">● Online</span>
        </div>
        <div class="mi-row">
          <span class="mi-lbl">Tokens máx.</span>
          <span class="mi-val">1,500</span>
        </div>
        <div class="mi-row">
          <span class="mi-lbl">Contexto</span>
          <span class="mi-val" id="ctxInfo">0 msgs</span>
        </div>
      </div>

      <!-- Estadísticas de sesión -->
      <div class="rp-section-lbl">Sesión Actual</div>
      <div class="session-stats">
        <div class="ss-card">
          <div class="ss-n" id="statMsgs">0</div>
          <div class="ss-l">Mensajes</div>
        </div>
        <div class="ss-card">
          <div class="ss-n" id="statTokens">~0</div>
          <div class="ss-l">Tokens est.</div>
        </div>
      </div>

      <!-- Configuración IA -->
      <div class="rp-section-lbl" style="margin-top:14px;">Configuración</div>
      <div class="toggle-row">
        <span class="toggle-label">Modo técnico avanzado</span>
        <label class="toggle">
          <input type="checkbox" id="techMode">
          <span class="toggle-sl"></span>
        </label>
      </div>
      <div class="toggle-row">
        <span class="toggle-label">Mostrar código siempre</span>
        <label class="toggle">
          <input type="checkbox" id="codeMode" checked>
          <span class="toggle-sl"></span>
        </label>
      </div>
      <div class="toggle-row">
        <span class="toggle-label">Respuestas detalladas</span>
        <label class="toggle">
          <input type="checkbox" id="detailMode" checked>
          <span class="toggle-sl"></span>
        </label>
      </div>

    </div>
  </div>

</div><!-- /ia-layout -->


<script>
/* ══════════════════════════════════════════════════════════════════════
   CONFIGURACIÓN CENTRAL
══════════════════════════════════════════════════════════════════════ */
const CONFIG = {
  model: 'claude-sonnet-4-20250514',
  maxTokens: 1500,
  apiEndpoint: 'https://api.anthropic.com/v1/messages',
  userName: <?= json_encode($usuario_nombre) ?>,
  userAvatar: <?= json_encode($avatar) ?>,
};

/* ══════════════════════════════════════════════════════════════════════
   ESTADO GLOBAL
══════════════════════════════════════════════════════════════════════ */
let state = {
  activeTool: {
    id: 'asistente',
    ico: '🤖',
    titulo: 'Asistente General',
    desc: 'Resuelve dudas, explica conceptos y responde preguntas.',
    prompt: 'Eres un asistente experto en tecnología y ciberseguridad de la plataforma Team VIROX. Responde de forma clara, precisa y educativa en español.',
    color: 'green',
  },
  messages: [],     // { role, content }
  isLoading: false,
  msgCount: 0,
  tokenEstimate: 0,
  voiceEnabled: false,
  recognition: null,
};

/* ══════════════════════════════════════════════════════════════════════
   SUGERENCIAS POR HERRAMIENTA
══════════════════════════════════════════════════════════════════════ */
const SUGGESTIONS = {
  asistente:   ['¿Qué es OWASP?','Explica SQL Injection','Crea un esquema de base de datos','¿Cómo funciona HTTPS?','Conceptos de criptografía'],
  ciberseg:    ['Analiza esta URL sospechosa','Mejores prácticas de contraseñas','¿Qué es un ataque MITM?','Cómo hacer un pentest básico','Explica el modelo CIA'],
  codigo:      ['Crea una API REST en PHP','Script de monitoreo en Python','Consulta SQL optimizada','Función de hash segura','Parser de logs en Bash'],
  aprendizaje: ['Ruta de estudio: Hacking ético','Quiz de redes nivel básico','Explica TCP/IP paso a paso','Plan de 30 días en ciberseguridad','Recursos OSCP gratuitos'],
  analisis:    ['Analiza este CSV de logs','Visualización de datos de red','Métricas de seguridad clave','Interpreta estos resultados de Nmap','Dashboard de incidentes'],
  proyectos:   ['Sprint plan para 2 semanas','KPIs de un proyecto de seguridad','Estructura de carpetas del proyecto','Backlog para auditoría de red','Documentación técnica estándar'],
  redaccion:   ['Informe ejecutivo de incidente','Política de contraseñas corporativa','README técnico del proyecto','Propuesta de auditoría de seguridad','Procedimiento de respuesta a incidentes'],
  redes:       ['Diagnóstica este error de red','Configuración de firewall básica','¿Qué protocolo usar para VPN?','Diferencias entre TCP y UDP','Arquitectura de red segura'],
  ia_explica:  ['¿Qué es una red neuronal?','Cómo funciona Random Forest','Implementa k-means en Python','Diferencias: ML vs DL vs RL','Bias en modelos de IA'],
  optimizador: ['Optimiza esta consulta SQL','Cuellos de botella en PHP','Caché efectivo para aplicaciones','Profiling de código Python','Métricas de rendimiento web'],
};

/* ══════════════════════════════════════════════════════════════════════
   SELECCIÓN DE HERRAMIENTA
══════════════════════════════════════════════════════════════════════ */
function selectTool(id, el) {
  // Actualizar UI sidebar
  document.querySelectorAll('.tool-item').forEach(t => t.classList.remove('active'));
  el.classList.add('active');

  // Recopilar datos del elemento
  const prompt = el.dataset.prompt;
  const toolEl = el;

  // Encontrar datos de la herramienta
  const tools = <?= json_encode($herramientas) ?>;
  const tool  = tools.find(t => t.id === id);
  if (!tool) return;

  state.activeTool = { ...tool, prompt };

  // Actualizar tool header
  document.getElementById('thIco').textContent   = tool.ico;
  document.getElementById('thTitle').textContent  = tool.titulo;
  document.getElementById('thDesc').textContent   = tool.desc;

  // Actualizar panel derecho
  document.getElementById('rpToolDetail').innerHTML = `
    <div class="td-ico">${tool.ico}</div>
    <div class="td-title">${tool.titulo}</div>
    <div class="td-desc">${tool.desc}</div>
  `;

  // Actualizar sugerencias
  renderSuggestions(id);

  // Reiniciar chat para nueva herramienta
  clearChat(true);

  // Mensaje de bienvenida de la herramienta
  const welcomeMsg = `Módulo **${tool.titulo}** activado. ${tool.desc} ¿En qué te puedo ayudar?`;
  addMessage('ai', welcomeMsg);
}

/* ══════════════════════════════════════════════════════════════════════
   SUGERENCIAS
══════════════════════════════════════════════════════════════════════ */
function renderSuggestions(toolId) {
  const bar  = document.getElementById('suggestionsBar');
  const sugs = SUGGESTIONS[toolId] || SUGGESTIONS['asistente'];
  bar.innerHTML = sugs.map(s =>
    `<button class="sugg-chip" onclick="sendQuick('${s.replace(/'/g,"\\'")}')">
       <i class="fa fa-bolt fa-xs"></i> ${s}
     </button>`
  ).join('');
}

// Inicializar sugerencias
renderSuggestions('asistente');

/* ══════════════════════════════════════════════════════════════════════
   CHAT — MENSAJES
══════════════════════════════════════════════════════════════════════ */
function addMessage(role, content, animate = true) {
  const welcome = document.getElementById('chatWelcome');
  if (welcome) welcome.remove();

  const container = document.getElementById('chatMessages');
  const now = new Date().toLocaleTimeString('es', { hour:'2-digit', minute:'2-digit' });

  const msgDiv = document.createElement('div');
  msgDiv.className = `msg ${role}`;

  const avatar = role === 'ai'
    ? `<div class="msg-av ai-av"><i class="fa fa-robot"></i></div>`
    : `<div class="msg-av user-av">
         <img src="${CONFIG.userAvatar}" alt="Tú"
              onerror="this.style.display='none';this.parentElement.innerHTML='<i class=\\'fa fa-user\\'></i>'">
       </div>`;

  const rendered = role === 'ai' ? renderMarkdown(content) : escapeHtml(content).replace(/\n/g, '<br>');

  const actions = role === 'ai' ? `
    <div class="msg-actions">
      <button class="msg-act" onclick="copyText(this)" data-text="${encodeURIComponent(content)}" title="Copiar"><i class="fa fa-copy"></i></button>
      <button class="msg-act" onclick="speakText('${encodeURIComponent(content)}')" title="Escuchar"><i class="fa fa-volume-high"></i></button>
      <button class="msg-act" title="Me gusta" onclick="this.style.color='var(--green-lt)'"><i class="fa fa-thumbs-up"></i></button>
    </div>` : '';

  msgDiv.innerHTML = `
    ${avatar}
    <div>
      <div class="msg-bubble">${rendered}</div>
      <div class="msg-time">${now}</div>
      ${actions}
    </div>`;

  // Insertar antes del typing indicator
  const typing = document.getElementById('typingIndicator');
  container.insertBefore(msgDiv, typing);
  container.scrollTop = container.scrollHeight;

  // Stats
  state.msgCount++;
  state.tokenEstimate += Math.ceil(content.length / 4);
  updateStats();
}

/* ══════════════════════════════════════════════════════════════════════
   ENVIAR MENSAJE
══════════════════════════════════════════════════════════════════════ */
async function sendMessage(text) {
  const input = document.getElementById('chatInput');
  const msg   = text || input.value.trim();
  if (!msg || state.isLoading) return;

  if (!text) {
    input.value = '';
    autoResize(input);
    updateCount();
  }

  addMessage('user', msg);
  state.messages.push({ role: 'user', content: msg });

  // Mostrar typing
  setLoading(true);

  try {
    const systemPrompt = buildSystemPrompt();
    const response = await callClaudeAPI(systemPrompt, state.messages);
    const aiText = extractText(response);

    addMessage('ai', aiText);
    state.messages.push({ role: 'assistant', content: aiText });

    // Guardar en BD si hay usuario logueado
    if (<?= $usuario_id ?: 0 ?> > 0 && state.messages.length === 2) {
      saveConversation(msg, aiText);
    }

  } catch (err) {
    console.error('API Error:', err);
    addMessage('ai', `❌ **Error de conexión**: ${err.message || 'No se pudo conectar con la IA. Verifica tu conexión e inténtalo de nuevo.'}`);
  } finally {
    setLoading(false);
  }
}

function sendQuick(text) {
  sendMessage(text);
}

/* ══════════════════════════════════════════════════════════════════════
   API CLAUDE
══════════════════════════════════════════════════════════════════════ */
function buildSystemPrompt() {
  const techMode   = document.getElementById('techMode')?.checked;
  const codeMode   = document.getElementById('codeMode')?.checked;
  const detailMode = document.getElementById('detailMode')?.checked;

  let sys = state.activeTool.prompt;
  sys += `\n\nContexto del usuario: ${CONFIG.userName} en la plataforma Team VIROX.`;
  if (techMode)   sys += '\nUsa terminología técnica avanzada sin simplificaciones.';
  if (codeMode)   sys += '\nIncluye ejemplos de código siempre que sea relevante, bien comentados.';
  if (detailMode) sys += '\nProporciona respuestas detalladas y completas con ejemplos prácticos.';
  sys += '\nResponde SIEMPRE en español, con formato claro usando markdown cuando sea apropiado.';
  return sys;
}

async function callClaudeAPI(systemPrompt, messages) {
  const response = await fetch(CONFIG.apiEndpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: CONFIG.model,
      max_tokens: CONFIG.maxTokens,
      system: systemPrompt,
      messages: messages.slice(-20), // Ventana de contexto: últimos 20 mensajes
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `HTTP ${response.status}`);
  }
  return response.json();
}

function extractText(data) {
  if (!data?.content) return 'Sin respuesta del servidor.';
  return data.content
    .filter(b => b.type === 'text')
    .map(b => b.text)
    .join('\n')
    .trim() || 'Respuesta vacía.';
}

/* ══════════════════════════════════════════════════════════════════════
   GUARDAR CONVERSACIÓN (PHP via fetch)
══════════════════════════════════════════════════════════════════════ */
function saveConversation(userMsg, aiMsg) {
  const titulo = userMsg.slice(0, 60) + (userMsg.length > 60 ? '…' : '');
  fetch('api/ia_save_conv.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      titulo, tool: state.activeTool.id,
      resumen: aiMsg.slice(0, 200),
    }),
  }).catch(() => {});
}

/* ══════════════════════════════════════════════════════════════════════
   UI HELPERS
══════════════════════════════════════════════════════════════════════ */
function setLoading(v) {
  state.isLoading = v;
  document.getElementById('sendBtn').disabled = v;
  document.getElementById('typingIndicator').classList.toggle('show', v);
  if (v) document.getElementById('chatMessages').scrollTop = 9999;
}

function updateStats() {
  document.getElementById('statMsgs').textContent   = state.msgCount;
  document.getElementById('statTokens').textContent = '~' + state.tokenEstimate;
  document.getElementById('ctxInfo').textContent    = state.messages.length + ' msgs';
}

function clearChat(silent = false) {
  state.messages = [];
  state.msgCount = 0;
  state.tokenEstimate = 0;
  updateStats();

  const container = document.getElementById('chatMessages');
  // Vaciar y restaurar pantalla de bienvenida
  container.innerHTML = `
    <div class="chat-welcome" id="chatWelcome">
      <div class="cw-orb">
        <div class="cw-ring"></div><div class="cw-ring"></div><div class="cw-ring"></div>
        <span class="cw-ico">${state.activeTool.ico}</span>
      </div>
      <h2 class="cw-title">IA VIROX activa</h2>
      <p class="cw-sub">Módulo <strong>${state.activeTool.titulo}</strong> listo. ¿En qué te puedo ayudar hoy?</p>
      <div class="cw-cards">
        ${(SUGGESTIONS[state.activeTool.id] || []).slice(0,4).map(s => `
          <div class="cw-card" onclick="sendQuick('${s.replace(/'/g,"\\'")}')">
            <div class="cw-card-ico">⚡</div>
            <div class="cw-card-txt">${s}</div>
          </div>`).join('')}
      </div>
    </div>
  `;
  container.appendChild(document.getElementById('typingIndicator'));
}

/* Input auto-resize */
function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 120) + 'px';
}

function updateCount() {
  const n = document.getElementById('chatInput').value.length;
  document.getElementById('charCount').textContent = n + '/4000';
}

function handleKey(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
}

/* ══════════════════════════════════════════════════════════════════════
   MARKDOWN BÁSICO → HTML
══════════════════════════════════════════════════════════════════════ */
function renderMarkdown(text) {
  let html = escapeHtml(text);

  // Bloques de código
  html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
    `<pre><code class="lang-${lang}">${code.trim()}</code></pre>`);
  // Código inline
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  // Negrita
  html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  // Cursiva
  html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
  // Encabezados
  html = html.replace(/^### (.+)$/gm, '<h4>$1</h4>');
  html = html.replace(/^## (.+)$/gm, '<h3>$1</h3>');
  html = html.replace(/^# (.+)$/gm, '<h3>$1</h3>');
  // Listas
  html = html.replace(/^[\-\*] (.+)$/gm, '<li>$1</li>');
  html = html.replace(/(<li>.*<\/li>)/s, '<ul>$1</ul>');
  html = html.replace(/^\d+\. (.+)$/gm, '<li>$1</li>');
  // Línea horizontal
  html = html.replace(/^---$/gm, '<hr style="border-color:rgba(255,255,255,.1);margin:8px 0;">');
  // Saltos de línea
  html = html.replace(/\n\n/g, '</p><p>').replace(/\n/g, '<br>');
  if (!html.startsWith('<')) html = '<p>' + html + '</p>';

  return html;
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/* ══════════════════════════════════════════════════════════════════════
   FUNCIONES DE UTILIDAD
══════════════════════════════════════════════════════════════════════ */
function copyText(btn) {
  const text = decodeURIComponent(btn.dataset.text);
  navigator.clipboard.writeText(text).then(() => {
    btn.innerHTML = '<i class="fa fa-check"></i>';
    setTimeout(() => btn.innerHTML = '<i class="fa fa-copy"></i>', 1500);
  });
}

function copyLastMsg() {
  const msgs = document.querySelectorAll('.msg.ai .msg-bubble');
  if (msgs.length) {
    navigator.clipboard.writeText(msgs[msgs.length - 1].innerText);
    alert('✅ Último mensaje copiado.');
  }
}

function speakText(encoded) {
  const text = decodeURIComponent(encoded).slice(0, 500);
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utt = new SpeechSynthesisUtterance(text);
    utt.lang = 'es-ES'; utt.rate = 0.95;
    window.speechSynthesis.speak(utt);
  }
}

function toggleVoice() {
  const btn = document.getElementById('voiceBtn');
  if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
    alert('Tu navegador no soporta reconocimiento de voz.'); return;
  }
  if (state.voiceEnabled) {
    state.recognition?.stop();
    state.voiceEnabled = false;
    btn.style.color = '';
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  state.recognition = new SR();
  state.recognition.lang = 'es-ES';
  state.recognition.continuous = false;
  state.recognition.onresult = e => {
    document.getElementById('chatInput').value = e.results[0][0].transcript;
    updateCount();
    sendMessage();
  };
  state.recognition.onend = () => { state.voiceEnabled = false; btn.style.color = ''; };
  state.recognition.start();
  state.voiceEnabled = true;
  btn.style.color = 'var(--red)';
}

function insertCode() {
  const input = document.getElementById('chatInput');
  const val = input.value;
  input.value = val + '\n```\n// Tu código aquí\n```';
  input.focus();
  autoResize(input);
}

function insertFile() {
  alert('📎 La carga de archivos estará disponible próximamente en la versión Enterprise de VIROX IA.');
}

function exportChat() {
  const msgs = document.querySelectorAll('.msg');
  let txt = `=== VIROX IA — Conversación Exportada ===\nFecha: ${new Date().toLocaleString('es')}\nMódulo: ${state.activeTool.titulo}\n${'='.repeat(50)}\n\n`;
  msgs.forEach(m => {
    const role  = m.classList.contains('user') ? CONFIG.userName : 'VIROX IA';
    const bbl   = m.querySelector('.msg-bubble');
    if (bbl) txt += `[${role}]\n${bbl.innerText}\n\n`;
  });
  const a = document.createElement('a');
  a.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(txt);
  a.download = `virox-ia-${Date.now()}.txt`;
  a.click();
}

/* ══════════════════════════════════════════════════════════════════════
   BÚSQUEDA EN SIDEBAR
══════════════════════════════════════════════════════════════════════ */
document.getElementById('toolSearch').addEventListener('input', function () {
  const q = this.value.toLowerCase();
  document.querySelectorAll('.tool-item').forEach(t => {
    t.style.display = (!q || (t.dataset.name || '').includes(q)) ? '' : 'none';
  });
});

/* ══════════════════════════════════════════════════════════════════════
   HISTORIAL
══════════════════════════════════════════════════════════════════════ */
function loadHistory(id) {
  fetch(`api/ia_get_conv.php?id=${id}`)
    .then(r => r.json())
    .then(data => {
      if (data?.messages) {
        clearChat(true);
        data.messages.forEach(m => addMessage(m.role === 'user' ? 'user' : 'ai', m.content, false));
        state.messages = data.messages;
      }
    })
    .catch(() => alert('No se pudo cargar el historial.'));
}

function deleteHistory(e, id) {
  e.stopPropagation();
  if (!confirm('¿Eliminar esta conversación?')) return;
  fetch(`api/ia_del_conv.php?id=${id}`, { method:'POST' })
    .then(() => e.target.closest('.hist-item')?.remove())
    .catch(() => {});
}

/* ══════════════════════════════════════════════════════════════════════
   SIDEBAR TOGGLE (MÓVIL)
══════════════════════════════════════════════════════════════════════ */
function toggleSidebar() {
  document.getElementById('iaLayout').classList.toggle('sidebar-open');
  document.getElementById('sidebarToggleBtn').classList.toggle('active');
}

/* ══════════════════════════════════════════════════════════════════════
   KEYBOARD SHORTCUTS
══════════════════════════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  // Ctrl+/ → enfocar input
  if (e.ctrlKey && e.key === '/') {
    e.preventDefault();
    document.getElementById('chatInput').focus();
  }
  // Ctrl+K → nueva conversación
  if (e.ctrlKey && e.key === 'k') {
    e.preventDefault();
    clearChat();
  }
  // Ctrl+E → exportar
  if (e.ctrlKey && e.key === 'e') {
    e.preventDefault();
    exportChat();
  }
});

/* ══════════════════════════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('chatInput').focus();
});
</script>
</body>
</html>