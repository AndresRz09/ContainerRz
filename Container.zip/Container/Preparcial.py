Estudiantes = []
Calificacion = []
Comprobar = True

while Comprobar:
    Nombres = input("Ingrese el nombre del Alumno o salir\n")

    if Nombres.lower() == "salir":
        Comprobar = False
        break
    else:
        Estudiantes.append(Nombres)
        while True:
            Calificar = input(f"Ingrese la nota de: {Nombres}\n")
            try:
                numero = float(Calificar)
                if (numero <= 5.0) & (numero >= 0):
                    Calificacion.append(numero)
                    break
            except:
                print("El numero ingresado es invalido o no esta entre 0.0 y 5.0")

print("\n------------------------------------------------------------")
print("\nInforme General de los estudiantes")
print("\n------------------------------------------------------------")
NotaAlta = 0
Suma = 0
Aprobados = []
for i in range(len(Estudiantes)):
    Alumno = Estudiantes[i]
    Nota = Calificacion[i]
    print(f"Estudiante: {Alumno} | Nota: {Nota}")
    Suma += Nota
    
    if Nota >= 3.0:
        Aprobados.append(Alumno)
        

if len(Calificacion) > 0:
    promedio = Suma / len(Calificacion)
    print(f"Promedio del grupo: {promedio}")
    print(f"Estudiantes que aprobaron: {Aprobados}")
else:
    print("No se registraron datos.")
        