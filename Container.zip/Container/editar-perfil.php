<?php
include 'conexion.php';
session_start();

#if (!isset($_SESSION['user_id'])) {
    #header("Location: login.php");
    #exit();
#}

#$uid = (int)$_SESSION['user_id'];
$success = '';
$error   = '';

// ── Traer datos completos ──────────────────────────────────────────────────
$stmt = $conexion->prepare(
    "SELECT u.*, us.correo AS correo_seg, us.telefono AS tel_seg
     FROM usuarios u
     LEFT JOIN usuarios_seguridad us ON us.usuario_id = u.id
     WHERE u.id = ? LIMIT 1"
);
#$stmt->bind_param("i", $uid);
#$stmt->execute();
#$user = $stmt->get_result()->fetch_assoc();
#$stmt->close();

#if (!$user) { header("Location: login.php"); exit(); }

// ── Traer configuración MOOC/NOOC/SPOC del usuario ────────────────────────
$mooc_cfg = [];
$qm = $conexion->prepare(
    "SELECT clave, valor FROM usuario_aprendizaje WHERE usuario_id = ?"
);
if ($qm) {
    $qm->bind_param("i", $uid);
    $qm->execute();
    $rm = $qm->get_result();
    while ($row = $rm->fetch_assoc()) $mooc_cfg[$row['clave']] = $row['valor'];
    $qm->close();
}

// ── Traer datos CRM del usuario ───────────────────────────────────────────
$crm = [];
$qcrm = $conexion->prepare(
    "SELECT visitas_perfil, suscriptores, comunidad_pts, nivel_crm, etiquetas_crm
     FROM usuario_crm WHERE usuario_id = ? LIMIT 1"
);
if ($qcrm) {
    $qcrm->bind_param("i", $uid);
    $qcrm->execute();
    $rcrm = $qcrm->get_result();
    if ($rcrm->num_rows > 0) $crm = $rcrm->fetch_assoc();
    $qcrm->close();
}

// ── PROCESAR FORMULARIO ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar'])) {

    $errores = [];

    // Campos básicos
    $nombre      = htmlspecialchars(trim($_POST['nombre']     ?? ''), ENT_QUOTES);
    $apellido    = htmlspecialchars(trim($_POST['apellido']   ?? ''), ENT_QUOTES);
    $bio         = htmlspecialchars(trim($_POST['bio']        ?? ''), ENT_QUOTES);
    $ocupacion   = htmlspecialchars(trim($_POST['ocupacion']  ?? ''), ENT_QUOTES);
    $institucion = htmlspecialchars(trim($_POST['institucion']?? ''), ENT_QUOTES);
    $pais        = htmlspecialchars(trim($_POST['pais']       ?? ''), ENT_QUOTES);
    $ciudad      = htmlspecialchars(trim($_POST['ciudad']     ?? ''), ENT_QUOTES);
    $telefono    = preg_replace('/[^0-9\+\-\s]/', '', trim($_POST['telefono'] ?? ''));
    $nivel_edu   = $_POST['nivel_educativo'] ?? '';
    $genero      = $_POST['genero']          ?? '';
    $linkedin    = filter_var(trim($_POST['linkedin'] ?? ''), FILTER_SANITIZE_URL);
    $github      = filter_var(trim($_POST['github']   ?? ''), FILTER_SANITIZE_URL);
    $twitter     = filter_var(trim($_POST['twitter']  ?? ''), FILTER_SANITIZE_URL);
    $website     = filter_var(trim($_POST['website']  ?? ''), FILTER_SANITIZE_URL);
    $intereses   = $_POST['intereses'] ?? [];
    $intereses_str = implode(',', array_map('htmlspecialchars', $intereses));
    $zona_horaria  = $_POST['zona_horaria'] ?? 'America/Bogota';
    $idioma_pref   = $_POST['idioma_pref']  ?? 'es';
    $certificaciones = htmlspecialchars(trim($_POST['certificaciones'] ?? ''), ENT_QUOTES);

    // Notificaciones
    $notif_email   = isset($_POST['notif_email'])   ? 1 : 0;
    $notif_curso   = isset($_POST['notif_curso'])   ? 1 : 0;
    $notif_sistema = isset($_POST['notif_sistema']) ? 1 : 0;

    // MOOC/NOOC/SPOC
    $modo_aprendizaje = $_POST['modo_aprendizaje'] ?? 'mooc';
    $meta_semana      = (int)($_POST['meta_semana'] ?? 0);
    $meta_cursos      = (int)($_POST['meta_cursos'] ?? 0);
    $visibilidad_perfil = $_POST['visibilidad_perfil'] ?? 'publico';

    // Contraseña (opcional)
    $pw_nueva    = $_POST['pw_nueva']    ?? '';
    $pw_confirmar= $_POST['pw_confirmar']?? '';
    $pw_actual   = $_POST['pw_actual']   ?? '';

    if (!empty($pw_nueva)) {
        if (strlen($pw_nueva) < 8)              $errores[] = "Nueva contraseña debe tener al menos 8 caracteres.";
        if (!preg_match('/[A-Z]/', $pw_nueva))  $errores[] = "Debe incluir al menos una mayúscula.";
        if (!preg_match('/[0-9]/', $pw_nueva))  $errores[] = "Debe incluir al menos un número.";
        if (!preg_match('/[\W_]/', $pw_nueva))  $errores[] = "Debe incluir al menos un símbolo.";
        if ($pw_nueva !== $pw_confirmar)         $errores[] = "Las contraseñas no coinciden.";

        if (empty($errores)) {
            // Verificar contraseña actual
            $chk = $conexion->prepare("SELECT password_hash FROM usuarios_seguridad WHERE usuario_id=?");
            $chk->bind_param("i", $uid); $chk->execute();
            $chk_r = $chk->get_result()->fetch_assoc(); $chk->close();
            if (!password_verify($pw_actual, $chk_r['password_hash'] ?? ''))
                $errores[] = "La contraseña actual no es correcta.";
        }
    }

    // Avatar
    $avatar_path = $user['avatar'] ?? 'assets/avatar-default.png';
    if (!empty($_FILES['avatar']['name'])) {
        $ext = strtolower(pathinfo($_FILES['avatar']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp'])) {
            $destdir = 'uploads/avatars/';
            if (!is_dir($destdir)) mkdir($destdir, 0755, true);
            $fname = 'avatar_' . $uid . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['avatar']['tmp_name'], $destdir . $fname))
                $avatar_path = $destdir . $fname;
        } else {
            $errores[] = "Formato de imagen no válido.";
        }
    }

    if (empty($errores)) {
        // Actualizar tabla usuarios
        $upd = $conexion->prepare(
            "UPDATE usuarios SET
             nombre=?, apellido=?, bio=?, ocupacion=?, institucion=?, pais=?, ciudad=?,
             telefono=?, nivel_educativo=?, genero=?, linkedin=?, github=?, twitter=?,
             website=?, intereses=?, zona_horaria=?, idioma_preferido=?, avatar=?,
             certificaciones=?, notif_email=?, notif_curso=?, notif_sistema=?
             WHERE id=?"
        );
        $upd->bind_param(
            "sssssssssssssssssssiiiii",
            $nombre, $apellido, $bio, $ocupacion, $institucion, $pais, $ciudad,
            $telefono, $nivel_edu, $genero, $linkedin, $github, $twitter,
            $website, $intereses_str, $zona_horaria, $idioma_pref, $avatar_path,
            $certificaciones, $notif_email, $notif_curso, $notif_sistema, $uid
        );
        $upd->execute(); $upd->close();

        // Actualizar tabla seguridad (teléfono)
        $upd2 = $conexion->prepare("UPDATE usuarios_seguridad SET telefono=? WHERE usuario_id=?");
        if ($upd2) { $upd2->bind_param("si", $telefono, $uid); $upd2->execute(); $upd2->close(); }

        // Contraseña
        if (!empty($pw_nueva)) {
            $hash = password_hash($pw_nueva, PASSWORD_BCRYPT, ['cost' => 12]);
            $upd3 = $conexion->prepare("UPDATE usuarios_seguridad SET password_hash=? WHERE usuario_id=?");
            if ($upd3) { $upd3->bind_param("si", $hash, $uid); $upd3->execute(); $upd3->close(); }
        }

        // MOOC/NOOC/SPOC — upsert en usuario_aprendizaje
        $mooc_data = [
            'modo_aprendizaje'   => $modo_aprendizaje,
            'meta_semana'        => $meta_semana,
            'meta_cursos'        => $meta_cursos,
            'visibilidad_perfil' => $visibilidad_perfil,
        ];
        foreach ($mooc_data as $clave => $valor) {
            $upsert = $conexion->prepare(
                "INSERT INTO usuario_aprendizaje (usuario_id, clave, valor)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE valor=VALUES(valor)"
            );
            if ($upsert) { $upsert->bind_param("iss", $uid, $clave, $valor); $upsert->execute(); $upsert->close(); }
        }

        // Actualizar sesión
        $_SESSION['user_name'] = $nombre . ' ' . $apellido;
        $_SESSION['avatar']    = $avatar_path;

        $success = "¡Perfil actualizado exitosamente!";
        // Recargar datos
        $stmt2 = $conexion->prepare("SELECT u.*, us.correo AS correo_seg FROM usuarios u LEFT JOIN usuarios_seguridad us ON us.usuario_id=u.id WHERE u.id=? LIMIT 1");
        $stmt2->bind_param("i", $uid); $stmt2->execute();
        $user = $stmt2->get_result()->fetch_assoc(); $stmt2->close();
    } else {
        $error = implode('|', $errores);
    }
}

$intereses_arr = explode(',', $user['intereses'] ?? '');
$nombre_completo = htmlspecialchars(trim(($user['nombre']??'') . ' ' . ($user['apellido']??'')));
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Editar Perfil — Team VIROX</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    /* ── Variables ────────────────────────────────── */
    :root {
      --n900:#020817; --n800:#0c1526; --n700:#111827; --n600:#182035; --n500:#1e2d47; --n400:#243450;
      --gold:#DAA520; --gold-lt:#f0c840; --gold-dim:rgba(218,165,32,.14);
      --green:#28A680; --green-lt:#35d4a8; --green-dim:rgba(40,166,128,.14);
      --red:#ef4444; --red-dim:rgba(239,68,68,.12);
      --txt:#f0f4f8; --muted:#8da0b8; --dim:#526278;
      --r-sm:8px; --r-md:14px; --r-lg:22px; --r-xl:32px;
      --font-d:'Orbitron',monospace; --font-b:'Syne',sans-serif;
      --hh:68px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);min-height:100vh;}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);} ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;} button{cursor:pointer;border:none;font-family:inherit;}

    /* ── Header ──────────────────────────────────── */
    .site-header{position:sticky;top:0;z-index:1000;height:var(--hh);background:rgba(2,8,23,.9);backdrop-filter:blur(18px);border-bottom:1px solid rgba(40,166,128,.2);}
    .header-inner{max-width:1480px;margin:auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 28px;}
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-hex{font-size:1.5rem;color:var(--green);filter:drop-shadow(0 0 8px var(--green));}
    .brand-name{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);letter-spacing:4px;text-shadow:0 0 16px rgba(218,165,32,.4);}
    .hdr-actions{display:flex;align-items:center;gap:12px;}
    .hdr-back{display:flex;align-items:center;gap:7px;padding:8px 16px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--muted);font-size:.85rem;font-weight:600;transition:all .2s;}
    .hdr-back:hover{background:rgba(255,255,255,.1);color:var(--txt);}
    .hdr-user{display:flex;align-items:center;gap:8px;}
    .hdr-av{width:34px;height:34px;border-radius:50%;object-fit:cover;border:2px solid var(--green);}
    .hdr-uname{font-size:.85rem;font-weight:600;color:var(--txt);}

    /* ── Layout ──────────────────────────────────── */
    .ep-layout{display:grid;grid-template-columns:300px 1fr;max-width:1280px;margin:0 auto;padding:36px 28px;gap:32px;align-items:start;}

    /* ── Panel izquierdo (avatar + nav) ──────────── */
    .ep-aside{position:sticky;top:calc(var(--hh) + 20px);}

    /* Avatar card */
    .avatar-card{background:var(--n800);border:1px solid rgba(40,166,128,.2);border-radius:var(--r-xl);padding:28px 24px;text-align:center;margin-bottom:16px;}
    .av-wrap{position:relative;width:110px;height:110px;margin:0 auto 16px;cursor:pointer;}
    .av-img{width:110px;height:110px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 28px rgba(40,166,128,.4);transition:filter .2s;}
    .av-wrap:hover .av-img{filter:brightness(.6);}
    .av-ring{position:absolute;inset:-6px;border-radius:50%;border:1px dashed rgba(40,166,128,.4);animation:spin 10s linear infinite;pointer-events:none;}
    @keyframes spin{to{transform:rotate(360deg)}}
    .av-overlay{position:absolute;inset:0;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;opacity:0;transition:opacity .2s;pointer-events:none;}
    .av-wrap:hover .av-overlay{opacity:1;}
    .av-overlay i{font-size:1.4rem;color:#fff;}
    .av-overlay span{font-size:.65rem;color:#fff;letter-spacing:1px;text-transform:uppercase;}
    .av-input{display:none;}
    .av-name{font-family:var(--font-d);font-size:.95rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .av-role{font-size:.72rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;margin-bottom:12px;}
    .av-username{font-size:.78rem;color:var(--dim);margin-bottom:18px;}

    /* CRM mini badge */
    .crm-mini{display:flex;align-items:center;justify-content:center;gap:16px;padding:12px 16px;background:rgba(255,255,255,.04);border-radius:var(--r-md);}
    .crm-stat{text-align:center;}
    .crm-stat-n{font-family:var(--font-d);font-size:1.1rem;font-weight:900;color:var(--gold);}
    .crm-stat-l{font-size:.62rem;color:var(--dim);text-transform:uppercase;letter-spacing:.8px;}
    .crm-div{width:1px;height:28px;background:rgba(255,255,255,.08);}

    /* Nivel barra */
    .nivel-wrap{margin-top:14px;text-align:left;}
    .nivel-hd{display:flex;justify-content:space-between;font-size:.72rem;color:var(--muted);margin-bottom:6px;}
    .nivel-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;}
    .nivel-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}

    /* Nav lateral */
    .ep-nav{background:var(--n800);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-xl);padding:20px 16px;}
    .ep-nav-title{font-size:.68rem;color:var(--dim);text-transform:uppercase;letter-spacing:2px;margin-bottom:12px;padding:0 6px;}
    .ep-nav-lnk{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:var(--r-md);color:var(--muted);font-size:.88rem;font-weight:500;cursor:pointer;transition:all .2s;margin-bottom:2px;}
    .ep-nav-lnk:hover,.ep-nav-lnk.on{background:var(--green-dim);color:var(--green-lt);}
    .ep-nav-lnk.on{border-left:3px solid var(--green);}
    .ep-nav-lnk i{width:18px;text-align:center;}
    .ep-nav-sep{height:1px;background:rgba(255,255,255,.06);margin:10px 0;}

    /* ── Contenido principal ─────────────────────── */
    .ep-main{min-width:0;}

    /* Tabs contenido */
    .ep-section{display:none;animation:secIn .35s ease both;}
    .ep-section.on{display:block;}
    @keyframes secIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}

    /* Cabecera de sección */
    .sec-hd{display:flex;align-items:center;gap:14px;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid rgba(255,255,255,.06);}
    .sec-ico{width:42px;height:42px;border-radius:var(--r-md);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
    .ico-green{background:var(--green-dim);border:1px solid rgba(40,166,128,.3);}
    .ico-gold {background:var(--gold-dim); border:1px solid rgba(218,165,32,.3);}
    .ico-blue {background:rgba(59,130,246,.12);border:1px solid rgba(59,130,246,.3);}
    .ico-purple{background:rgba(139,92,246,.12);border:1px solid rgba(139,92,246,.3);}
    .sec-hd-text strong{display:block;font-family:var(--font-d);font-size:.9rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:3px;}
    .sec-hd-text span{font-size:.78rem;color:var(--muted);}

    /* Inputs */
    .frow{display:grid;gap:14px;margin-bottom:14px;}
    .frow-2{grid-template-columns:1fr 1fr;}
    .frow-3{grid-template-columns:1fr 1fr 1fr;}
    .fgroup{display:flex;flex-direction:column;gap:5px;}
    .fgroup label{font-size:.72rem;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:1px;display:flex;align-items:center;gap:5px;}
    .finput{padding:11px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);color:var(--txt);font-family:var(--font-b);font-size:.9rem;transition:all .2s;width:100%;}
    .finput:focus{outline:none;border-color:var(--green);background:rgba(40,166,128,.06);box-shadow:0 0 0 3px rgba(40,166,128,.1);}
    select.finput option{background:var(--n700);}
    textarea.finput{resize:vertical;min-height:90px;line-height:1.6;}

    /* Password strength */
    .pw-bars{display:flex;gap:4px;margin-top:6px;}
    .pw-bar{flex:1;height:3px;border-radius:99px;background:rgba(255,255,255,.08);transition:background .3s;}
    .pw-bar.w{background:#ef4444;} .pw-bar.m{background:var(--gold);} .pw-bar.s{background:var(--green);}
    .pw-hint{font-size:.7rem;color:var(--muted);margin-top:4px;}

    /* Toggle switch */
    .toggle-row{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-md);margin-bottom:10px;}
    .toggle-info strong{display:block;font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:2px;}
    .toggle-info span{font-size:.75rem;color:var(--muted);}
    .toggle{position:relative;width:44px;height:24px;flex-shrink:0;}
    .toggle input{display:none;}
    .toggle-slider{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:99px;cursor:pointer;transition:background .3s;}
    .toggle-slider::before{content:'';position:absolute;width:18px;height:18px;border-radius:50%;background:#fff;top:3px;left:3px;transition:transform .3s;box-shadow:0 1px 4px rgba(0,0,0,.4);}
    .toggle input:checked + .toggle-slider{background:var(--green);}
    .toggle input:checked + .toggle-slider::before{transform:translateX(20px);}

    /* Checkboxes intereses */
    .int-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;}
    .int-item input{display:none;}
    .int-item label{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--r-md);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);font-size:.8rem;cursor:pointer;transition:all .2s;}
    .int-item input:checked + label{background:var(--green-dim);border-color:var(--green);color:var(--green-lt);}

    /* MOOC modo cards */
    .modo-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px;}
    .modo-item input{display:none;}
    .modo-item label{display:flex;flex-direction:column;align-items:center;gap:8px;padding:18px 12px;border-radius:var(--r-lg);background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.08);cursor:pointer;transition:all .25s;text-align:center;}
    .modo-item label .mo-ico{font-size:2rem;}
    .modo-item label .mo-nm{font-family:var(--font-d);font-size:.7rem;font-weight:700;color:var(--txt);letter-spacing:1px;}
    .modo-item label .mo-desc{font-size:.72rem;color:var(--muted);line-height:1.4;}
    .modo-item input:checked + label{border-color:var(--gold);background:var(--gold-dim);}
    .modo-item input:checked + label .mo-nm{color:var(--gold-lt);}

    /* Meta sliders */
    .meta-slider{width:100%;accent-color:var(--green);height:4px;}
    .meta-val{font-family:var(--font-d);font-size:1.2rem;font-weight:700;color:var(--gold);text-align:center;margin-bottom:4px;}

    /* CRM panel */
    .crm-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:14px;margin-bottom:24px;}
    .crm-card{background:var(--n600);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);padding:20px 16px;text-align:center;}
    .crm-card-ico{font-size:1.8rem;margin-bottom:8px;}
    .crm-card-num{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);line-height:1;}
    .crm-card-lbl{font-size:.68rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;}
    .crm-tags{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px;}
    .crm-tag{padding:4px 12px;background:var(--green-dim);border:1px solid var(--green);border-radius:99px;font-size:.72rem;color:var(--green-lt);font-weight:600;}

    /* Visibilidad perfil */
    .vis-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;}
    .vis-item input{display:none;}
    .vis-item label{display:flex;align-items:center;justify-content:center;gap:8px;padding:12px 10px;border-radius:var(--r-md);background:rgba(255,255,255,.04);border:1.5px solid rgba(255,255,255,.08);font-size:.8rem;cursor:pointer;transition:all .2s;text-align:center;}
    .vis-item input:checked + label{border-color:var(--green);background:var(--green-dim);color:var(--green-lt);}

    /* Peligro zone */
    .danger-zone{background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.2);border-radius:var(--r-lg);padding:24px;}
    .danger-zone h4{font-family:var(--font-d);font-size:.85rem;font-weight:700;color:#f87171;letter-spacing:1px;margin-bottom:16px;}
    .danger-btn{padding:10px 20px;background:transparent;border:1.5px solid rgba(239,68,68,.4);color:#f87171;border-radius:var(--r-md);font-size:.85rem;font-weight:700;transition:all .2s;font-family:var(--font-b);}
    .danger-btn:hover{background:var(--red-dim);border-color:#ef4444;}

    /* Mensajes */
    .msg-ok{background:rgba(40,166,128,.1);border:1px solid rgba(40,166,128,.3);border-radius:var(--r-md);padding:14px 18px;margin-bottom:20px;display:flex;align-items:center;gap:10px;font-size:.88rem;color:var(--green-lt);animation:msgIn .4s ease both;}
    .msg-err{background:var(--red-dim);border:1px solid rgba(239,68,68,.3);border-radius:var(--r-md);padding:14px 18px;margin-bottom:20px;animation:msgIn .4s ease both;}
    .msg-err ul{list-style:none;display:flex;flex-direction:column;gap:4px;}
    .msg-err li{font-size:.82rem;color:#fca5a5;display:flex;gap:6px;}
    .msg-err li::before{content:'✕';color:#ef4444;flex-shrink:0;}
    @keyframes msgIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:none}}

    /* Botón guardar sticky */
    .save-bar{position:sticky;bottom:0;z-index:100;padding:16px 0;background:linear-gradient(to top,var(--n900) 60%,transparent);display:flex;gap:12px;justify-content:flex-end;}
    .btn-save{display:inline-flex;align-items:center;gap:8px;padding:13px 32px;background:linear-gradient(135deg,var(--green),#1d8f6e);color:#fff;border-radius:var(--r-md);font-weight:800;font-size:.95rem;letter-spacing:.5px;transition:all .2s;box-shadow:0 4px 20px rgba(40,166,128,.35);}
    .btn-save:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(40,166,128,.45);}
    .btn-cancel{display:inline-flex;align-items:center;gap:8px;padding:13px 24px;border:1.5px solid rgba(255,255,255,.15);color:var(--muted);border-radius:var(--r-md);font-weight:600;font-size:.9rem;transition:all .2s;}
    .btn-cancel:hover{border-color:rgba(255,255,255,.3);color:var(--txt);}

    /* Preview avatar */
    #av-preview-img{display:none;width:110px;height:110px;border-radius:50%;object-fit:cover;border:3px solid var(--gold);box-shadow:0 0 20px rgba(218,165,32,.4);margin:12px auto 0;}

    /* Responsive */
    @media(max-width:960px){
      .ep-layout{grid-template-columns:1fr;}
      .ep-aside{position:static;}
      .frow-3{grid-template-columns:1fr 1fr;}
      .int-grid{grid-template-columns:repeat(2,1fr);}
      .modo-grid{grid-template-columns:1fr 1fr;}
    }
    @media(max-width:600px){
      .ep-layout{padding:20px 16px;}
      .frow-2,.frow-3{grid-template-columns:1fr;}
      .modo-grid,.vis-grid{grid-template-columns:1fr;}
      .int-grid{grid-template-columns:1fr 1fr;}
      .crm-cards{grid-template-columns:1fr 1fr;}
    }
  </style>
</head>
<body>

<!-- ══ HEADER ══════════════════════════════════════════════════════════ -->
<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <div class="hdr-actions">
      <a href="perfil.php" class="hdr-back"><i class="fa fa-arrow-left"></i> Volver al perfil</a>
      <div class="hdr-user">
        <img src="<?= htmlspecialchars($user['avatar'] ?? 'assets/avatar-default.png') ?>" class="hdr-av" alt="Avatar">
        <span class="hdr-uname"><?= htmlspecialchars($user['nombre'] ?? '') ?></span>
      </div>
    </div>
  </div>
</header>

<!-- ══ LAYOUT ══════════════════════════════════════════════════════════ -->
<div class="ep-layout">

  <!-- ─── ASIDE ──────────────────────────────────────────────────────── -->
  <aside class="ep-aside">

    <!-- Avatar card -->
    <div class="avatar-card">
      <div class="av-wrap" onclick="document.getElementById('avatarFile').click()">
        <img src="<?= htmlspecialchars($user['avatar'] ?? 'assets/avatar-default.png') ?>" class="av-img" id="avMain" alt="Avatar">
        <div class="av-ring"></div>
        <div class="av-overlay">
          <i class="fa fa-camera"></i>
          <span>Cambiar foto</span>
        </div>
      </div>
      <img id="av-preview-img" src="" alt="Preview">
      <div class="av-name"><?= $nombre_completo ?></div>
      <div class="av-role"><?= htmlspecialchars(ucfirst($user['rol'] ?? '')) ?></div>
      <div class="av-username">@<?= htmlspecialchars($user['username'] ?? '') ?></div>

      <!-- CRM mini stats -->
      <div class="crm-mini">
        <div class="crm-stat">
          <div class="crm-stat-n"><?= number_format($crm['visitas_perfil'] ?? 0) ?></div>
          <div class="crm-stat-l">Visitas</div>
        </div>
        <div class="crm-div"></div>
        <div class="crm-stat">
          <div class="crm-stat-n"><?= number_format($crm['suscriptores'] ?? 0) ?></div>
          <div class="crm-stat-l">Seguidores</div>
        </div>
        <div class="crm-div"></div>
        <div class="crm-stat">
          <div class="crm-stat-n"><?= $crm['nivel_crm'] ?? 0 ?></div>
          <div class="crm-stat-l">Nivel CRM</div>
        </div>
      </div>

      <!-- Nivel -->
      <?php $nivel = min(100, (int)(($crm['nivel_crm'] ?? 0) * 10)); ?>
      <div class="nivel-wrap">
        <div class="nivel-hd">
          <span>Nivel de influencia</span>
          <span><?= $nivel ?>/100</span>
        </div>
        <div class="nivel-bar">
          <div class="nivel-fill" style="width:<?= $nivel ?>%"></div>
        </div>
      </div>
    </div>

    <!-- Nav lateral -->
    <div class="ep-nav">
      <div class="ep-nav-title">Configuración</div>
      <div class="ep-nav-lnk on" onclick="showSec('personal',this)"><i class="fa fa-user"></i> Información Personal</div>
      <div class="ep-nav-lnk" onclick="showSec('profesional',this)"><i class="fa fa-briefcase"></i> Info. Profesional</div>
      <div class="ep-nav-lnk" onclick="showSec('aprendizaje',this)"><i class="fa fa-graduation-cap"></i> Modo de Aprendizaje</div>
      <div class="ep-nav-lnk" onclick="showSec('crm',this)"><i class="fa fa-chart-line"></i> CRM & Comunidad</div>
      <div class="ep-nav-lnk" onclick="showSec('redes',this)"><i class="fa fa-share-nodes"></i> Redes & Contacto</div>
      <div class="ep-nav-sep"></div>
      <div class="ep-nav-lnk" onclick="showSec('seguridad',this)"><i class="fa fa-shield-halved"></i> Seguridad</div>
      <div class="ep-nav-lnk" onclick="showSec('notificaciones',this)"><i class="fa fa-bell"></i> Notificaciones</div>
      <div class="ep-nav-lnk" onclick="showSec('privacidad',this)"><i class="fa fa-eye-slash"></i> Privacidad</div>
      <div class="ep-nav-sep"></div>
      <div class="ep-nav-lnk" onclick="showSec('peligro',this)" style="color:#f87171;"><i class="fa fa-triangle-exclamation"></i> Zona Peligrosa</div>
    </div>

  </aside>

  <!-- ─── CONTENIDO PRINCIPAL ─────────────────────────────────────────── -->
  <main class="ep-main">

    <?php if ($success): ?>
    <div class="msg-ok"><i class="fa fa-circle-check" style="font-size:1.1rem;"></i> <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="msg-err">
      <ul><?php foreach (explode('|', $error) as $e): ?>
        <li><?= htmlspecialchars($e) ?></li>
      <?php endforeach; ?></ul>
    </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" id="epForm">
      <input type="file" name="avatar" id="avatarFile" accept=".jpg,.jpeg,.png,.gif,.webp" style="display:none">

      <!-- ══ 1. INFORMACIÓN PERSONAL ══════════════════════════════════ -->
      <div class="ep-section on" id="sec-personal">
        <div class="sec-hd">
          <div class="sec-ico ico-green"><i class="fa fa-user"></i></div>
          <div class="sec-hd-text">
            <strong>Información Personal</strong>
            <span>Datos de identificación y presentación pública</span>
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa fa-user fa-xs"></i> Nombre(s)</label>
            <input class="finput" type="text" name="nombre" value="<?= htmlspecialchars($user['nombre'] ?? '') ?>" required>
          </div>
          <div class="fgroup">
            <label><i class="fa fa-user fa-xs"></i> Apellido(s)</label>
            <input class="finput" type="text" name="apellido" value="<?= htmlspecialchars($user['apellido'] ?? '') ?>" required>
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label><i class="fa fa-pen fa-xs"></i> Bio / Descripción pública</label>
            <textarea class="finput" name="bio" rows="4" placeholder="Cuéntale a la comunidad sobre ti y tus objetivos..."><?= htmlspecialchars($user['bio'] ?? '') ?></textarea>
          </div>
        </div>

        <div class="frow frow-3">
          <div class="fgroup">
            <label><i class="fa fa-venus-mars fa-xs"></i> Género</label>
            <select class="finput" name="genero">
              <option value="">Prefiero no decir</option>
              <?php foreach (['M'=>'Masculino','F'=>'Femenino','NB'=>'No binario','O'=>'Otro'] as $v=>$l): ?>
              <option value="<?=$v?>" <?= ($user['genero']??'')===$v?'selected':'' ?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="fgroup">
            <label><i class="fa fa-globe fa-xs"></i> País</label>
            <input class="finput" type="text" name="pais" value="<?= htmlspecialchars($user['pais'] ?? '') ?>">
          </div>
          <div class="fgroup">
            <label><i class="fa fa-city fa-xs"></i> Ciudad</label>
            <input class="finput" type="text" name="ciudad" value="<?= htmlspecialchars($user['ciudad'] ?? '') ?>">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa fa-phone fa-xs"></i> Teléfono / WhatsApp</label>
            <input class="finput" type="tel" name="telefono" value="<?= htmlspecialchars($user['telefono'] ?? '') ?>" placeholder="+57 300 000 0000">
          </div>
          <div class="fgroup">
            <label><i class="fa fa-clock fa-xs"></i> Zona Horaria</label>
            <select class="finput" name="zona_horaria">
              <?php foreach ([
                'America/Bogota'       => 'Colombia (UTC-5)',
                'America/Mexico_City'  => 'México (UTC-6)',
                'America/Guayaquil'    => 'Ecuador (UTC-5)',
                'America/Lima'         => 'Perú (UTC-5)',
                'America/Buenos_Aires' => 'Argentina (UTC-3)',
                'Europe/Madrid'        => 'España (UTC+1/2)',
              ] as $v=>$l): ?>
              <option value="<?=$v?>" <?= ($user['zona_horaria']??'')===$v?'selected':'' ?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label><i class="fa fa-language fa-xs"></i> Idioma preferido</label>
            <select class="finput" name="idioma_pref">
              <option value="es" <?=($user['idioma_preferido']??'es')==='es'?'selected':''?>>🇪🇸 Español</option>
              <option value="en" <?=($user['idioma_preferido']??'')==='en'?'selected':''?>>🇺🇸 English</option>
              <option value="pt" <?=($user['idioma_preferido']??'')==='pt'?'selected':''?>>🇧🇷 Português</option>
            </select>
          </div>
        </div>
      </div>

      <!-- ══ 2. INFORMACIÓN PROFESIONAL ═══════════════════════════════ -->
      <div class="ep-section" id="sec-profesional">
        <div class="sec-hd">
          <div class="sec-ico ico-gold"><i class="fa fa-briefcase"></i></div>
          <div class="sec-hd-text">
            <strong>Información Profesional</strong>
            <span>Ocupación, institución y área de experticia</span>
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Ocupación / Cargo</label>
            <input class="finput" type="text" name="ocupacion" value="<?= htmlspecialchars($user['ocupacion'] ?? '') ?>" placeholder="Ej: Ingeniero de Sistemas">
          </div>
          <div class="fgroup">
            <label>Institución / Empresa</label>
            <input class="finput" type="text" name="institucion" value="<?= htmlspecialchars($user['institucion'] ?? '') ?>" placeholder="Ej: UNIMINUTO">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label>Nivel Educativo</label>
            <select class="finput" name="nivel_educativo">
              <?php foreach ([
                ''               => 'Seleccionar...',
                'primaria'       => 'Primaria',
                'bachillerato'   => 'Bachillerato',
                'tecnico'        => 'Técnico / Tecnólogo',
                'universitario'  => 'Universitario (en curso)',
                'pregrado'       => 'Pregrado completo',
                'especializacion'=> 'Especialización',
                'maestria'       => 'Maestría',
                'doctorado'      => 'Doctorado',
              ] as $v=>$l): ?>
              <option value="<?=$v?>" <?=($user['nivel_educativo']??'')===$v?'selected':''?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="fgroup">
            <label>Experiencia en Ciberseguridad</label>
            <select class="finput" name="experiencia_cyber">
              <?php foreach ([
                'ninguna'    => 'Principiante — sin experiencia',
                'basica'     => 'Básica — conceptos generales',
                'intermedia' => 'Intermedia — experiencia laboral',
                'avanzada'   => 'Avanzada — profesional',
              ] as $v=>$l): ?>
              <option value="<?=$v?>" <?=($user['experiencia_cyber']??'')===$v?'selected':''?>><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="frow">
          <div class="fgroup">
            <label>Certificaciones actuales</label>
            <input class="finput" type="text" name="certificaciones" value="<?= htmlspecialchars($user['certificaciones'] ?? '') ?>" placeholder="Ej: CompTIA Security+, CEH, OSCP...">
          </div>
        </div>

        <!-- Intereses / Áreas MOOC -->
        <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;margin-top:8px;font-weight:700;">Áreas de interés</p>
        <div class="int-grid">
          <?php
            $areas = [
              ['hacking',      '🔴', 'Ethical Hacking'],
              ['redes',        '🌐', 'Redes y Protocolos'],
              ['criptografia', '🔐', 'Criptografía'],
              ['ia_security',  '🤖', 'IA en Seguridad'],
              ['forense',      '🔍', 'Análisis Forense'],
              ['malware',      '🦠', 'Malware & Virus'],
              ['cloud',        '☁️', 'Cloud Security'],
              ['web_security', '🌍', 'Seguridad Web'],
              ['programacion', '💻', 'Programación'],
            ];
            foreach ($areas as [$v,$ico,$lbl]):
              $ch = in_array($v, $intereses_arr) ? 'checked' : '';
          ?>
          <div class="int-item">
            <input type="checkbox" name="intereses[]" value="<?=$v?>" id="int_<?=$v?>" <?=$ch?>>
            <label for="int_<?=$v?>"><?=$ico?> <?=$lbl?></label>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- ══ 3. MODO DE APRENDIZAJE (MOOC/NOOC/SPOC) ═════════════════ -->
      <div class="ep-section" id="sec-aprendizaje">
        <div class="sec-hd">
          <div class="sec-ico ico-green"><i class="fa fa-graduation-cap"></i></div>
          <div class="sec-hd-text">
            <strong>Modo de Aprendizaje</strong>
            <span>Configura tu experiencia educativa MOOC, NOOC o SPOC</span>
          </div>
        </div>

        <!-- Selector de modo -->
        <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:14px;font-weight:700;">Tipo de curso preferido</p>
        <div class="modo-grid">
          <?php
            $modos = [
              ['mooc',  '🌍', 'MOOC', 'Massive Open Online Course — Acceso masivo y abierto para cualquier usuario del mundo'],
              ['nooc',  '⚡', 'NOOC', 'Nano Open Online Course — Micro-lecciones cortas, habilidades específicas en poco tiempo'],
              ['spoc',  '🔒', 'SPOC', 'Small Private Online Course — Acceso restringido, grupo reducido y seguimiento personalizado'],
            ];
            $modo_actual = $mooc_cfg['modo_aprendizaje'] ?? 'mooc';
            foreach ($modos as [$v,$ico,$nm,$desc]):
          ?>
          <div class="modo-item">
            <input type="radio" name="modo_aprendizaje" value="<?=$v?>" id="modo_<?=$v?>" <?=$modo_actual===$v?'checked':''?>>
            <label for="modo_<?=$v?>">
              <span class="mo-ico"><?=$ico?></span>
              <span class="mo-nm"><?=$nm?></span>
              <span class="mo-desc"><?=$desc?></span>
            </label>
          </div>
          <?php endforeach; ?>
        </div>

        <!-- Metas de aprendizaje -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;margin-bottom:20px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:20px;font-weight:700;">🎯 Metas de Aprendizaje</p>

          <div class="frow frow-2">
            <div class="fgroup">
              <label>Horas de estudio por semana</label>
              <div class="meta-val" id="metaSemanaVal"><?= $mooc_cfg['meta_semana'] ?? 5 ?>h</div>
              <input type="range" class="meta-slider" name="meta_semana" min="1" max="40" value="<?= $mooc_cfg['meta_semana'] ?? 5 ?>"
                     oninput="document.getElementById('metaSemanaVal').textContent=this.value+'h'">
              <small style="font-size:.7rem;color:var(--dim);text-align:center;display:block;margin-top:4px;">1h — 40h por semana</small>
            </div>
            <div class="fgroup">
              <label>Cursos a completar este año</label>
              <div class="meta-val" id="metaCursosVal"><?= $mooc_cfg['meta_cursos'] ?? 3 ?></div>
              <input type="range" class="meta-slider" name="meta_cursos" min="1" max="20" value="<?= $mooc_cfg['meta_cursos'] ?? 3 ?>"
                     oninput="document.getElementById('metaCursosVal').textContent=this.value">
              <small style="font-size:.7rem;color:var(--dim);text-align:center;display:block;margin-top:4px;">1 — 20 cursos anuales</small>
            </div>
          </div>
        </div>

        <!-- Preferencias de contenido -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:16px;font-weight:700;">⚙️ Preferencias de Contenido</p>
          <div class="frow frow-2">
            <div class="fgroup">
              <label>Formato preferido de lección</label>
              <select class="finput" name="formato_leccion">
                <?php foreach (['video'=>'🎥 Video','lectura'=>'📖 Lectura','interactivo'=>'🧩 Interactivo','mixto'=>'🔀 Mixto'] as $v=>$l): ?>
                <option value="<?=$v?>" <?=($mooc_cfg['formato_leccion']??'mixto')===$v?'selected':''?>><?=$l?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="fgroup">
              <label>Nivel de dificultad preferido</label>
              <select class="finput" name="dificultad_pref">
                <?php foreach (['basico'=>'🟢 Básico','intermedio'=>'🟡 Intermedio','avanzado'=>'🔴 Avanzado','experto'=>'⚫ Experto'] as $v=>$l): ?>
                <option value="<?=$v?>" <?=($mooc_cfg['dificultad_pref']??'intermedio')===$v?'selected':''?>><?=$l?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="frow" style="margin-top:4px;">
            <div class="fgroup">
              <label>Recordatorio de estudio diario</label>
              <select class="finput" name="recordatorio_hora">
                <option value="">Sin recordatorio</option>
                <?php for($h=6;$h<=22;$h++):
                  $t = str_pad($h,2,'0',STR_PAD_LEFT).':00';
                  $sel = ($mooc_cfg['recordatorio_hora']??'')===$t?'selected':'';
                ?>
                <option value="<?=$t?>" <?=$sel?>>⏰ <?=$t?></option>
                <?php endfor; ?>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- ══ 4. CRM & COMUNIDAD ═══════════════════════════════════════ -->
      <div class="ep-section" id="sec-crm">
        <div class="sec-hd">
          <div class="sec-ico ico-blue"><i class="fa fa-chart-line"></i></div>
          <div class="sec-hd-text">
            <strong>CRM & Comunidad</strong>
            <span>Gestión de relaciones, audiencia e influencia dentro de VIROX</span>
          </div>
        </div>

        <!-- Stats CRM -->
        <div class="crm-cards">
          <div class="crm-card">
            <div class="crm-card-ico">👁</div>
            <div class="crm-card-num"><?= number_format($crm['visitas_perfil'] ?? 0) ?></div>
            <div class="crm-card-lbl">Visitas al perfil</div>
          </div>
          <div class="crm-card">
            <div class="crm-card-ico">🔔</div>
            <div class="crm-card-num"><?= number_format($crm['suscriptores'] ?? 0) ?></div>
            <div class="crm-card-lbl">Seguidores</div>
          </div>
          <div class="crm-card">
            <div class="crm-card-ico">💬</div>
            <div class="crm-card-num"><?= number_format($crm['comunidad_pts'] ?? 0) ?></div>
            <div class="crm-card-lbl">Puntos comunidad</div>
          </div>
          <div class="crm-card">
            <div class="crm-card-ico">⭐</div>
            <div class="crm-card-num"><?= $crm['nivel_crm'] ?? 0 ?></div>
            <div class="crm-card-lbl">Nivel CRM</div>
          </div>
        </div>

        <!-- Etiquetas CRM -->
        <?php if (!empty($crm['etiquetas_crm'])): ?>
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:20px;margin-bottom:18px;">
          <p style="font-size:.75rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;font-weight:700;">🏷 Etiquetas de segmento CRM</p>
          <div class="crm-tags">
            <?php foreach (explode(',', $crm['etiquetas_crm']) as $tag): if(empty(trim($tag))) continue; ?>
            <span class="crm-tag"><?= htmlspecialchars(trim($tag)) ?></span>
            <?php endforeach; ?>
          </div>
        </div>
        <?php endif; ?>

        <!-- Configuración CRM -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:16px;font-weight:700;">⚙️ Configuración de Perfil Público</p>

          <div class="frow">
            <div class="fgroup">
              <label>Rol visible en la comunidad</label>
              <select class="finput" name="rol_comunidad">
                <?php foreach ([
                  'cliente'  => '🎓 Estudiante / Aprendiz',
                  'empresa'  => '🏢 Empresa / Organización',
                  'creador'  => '✍️ Creador de Contenido',
                  'consultor'=> '🔍 Consultor / Freelancer',
                ] as $v=>$l): ?>
                <option value="<?=$v?>" <?=($user['tipo_usuario']??'cliente')===$v?'selected':''?>><?=$l?></option>
                <?php endforeach; ?>
              </select>
            </div>
          </div>

          <div class="frow frow-2" style="margin-top:4px;">
            <div class="fgroup">
              <label>Permitir ser contactado por</label>
              <select class="finput" name="contacto_por">
                <option value="todos">🌐 Todos los usuarios</option>
                <option value="verificados">✅ Solo verificados</option>
                <option value="nadie">🚫 Nadie (privado)</option>
              </select>
            </div>
            <div class="fgroup">
              <label>Mostrar estadísticas en perfil</label>
              <select class="finput" name="mostrar_stats">
                <option value="1">✅ Sí, mostrar</option>
                <option value="0">🚫 No mostrar</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <!-- ══ 5. REDES & CONTACTO ══════════════════════════════════════ -->
      <div class="ep-section" id="sec-redes">
        <div class="sec-hd">
          <div class="sec-ico ico-green"><i class="fa fa-share-nodes"></i></div>
          <div class="sec-hd-text">
            <strong>Redes & Contacto</strong>
            <span>Conecta tu perfil con tus redes sociales y sitio web</span>
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa-brands fa-linkedin" style="color:#0A66C2"></i> LinkedIn</label>
            <input class="finput" type="url" name="linkedin" value="<?= htmlspecialchars($user['linkedin'] ?? '') ?>" placeholder="https://linkedin.com/in/...">
          </div>
          <div class="fgroup">
            <label><i class="fa-brands fa-github" style="color:#ccc"></i> GitHub</label>
            <input class="finput" type="url" name="github" value="<?= htmlspecialchars($user['github'] ?? '') ?>" placeholder="https://github.com/...">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa-brands fa-twitter" style="color:#1DA1F2"></i> Twitter / X</label>
            <input class="finput" type="url" name="twitter" value="<?= htmlspecialchars($user['twitter'] ?? '') ?>" placeholder="https://twitter.com/...">
          </div>
          <div class="fgroup">
            <label><i class="fa-solid fa-globe" style="color:var(--green)"></i> Sitio Web</label>
            <input class="finput" type="url" name="website" value="<?= htmlspecialchars($user['website'] ?? '') ?>" placeholder="https://mipagina.com">
          </div>
        </div>

        <div class="frow frow-2">
          <div class="fgroup">
            <label><i class="fa-brands fa-discord" style="color:#7289da"></i> Discord</label>
            <input class="finput" type="text" name="discord" value="<?= htmlspecialchars($user['discord'] ?? '') ?>" placeholder="usuario#0000">
          </div>
          <div class="fgroup">
            <label><i class="fa-brands fa-telegram" style="color:#0088cc"></i> Telegram</label>
            <input class="finput" type="text" name="telegram" value="<?= htmlspecialchars($user['telegram'] ?? '') ?>" placeholder="@usuario">
          </div>
        </div>
      </div>

      <!-- ══ 6. SEGURIDAD ══════════════════════════════════════════════ -->
      <div class="ep-section" id="sec-seguridad">
        <div class="sec-hd">
          <div class="sec-ico ico-gold"><i class="fa fa-shield-halved"></i></div>
          <div class="sec-hd-text">
            <strong>Seguridad de la Cuenta</strong>
            <span>Cambia tu contraseña o gestiona el acceso</span>
          </div>
        </div>

        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;margin-bottom:16px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:18px;font-weight:700;">🔑 Cambiar Contraseña</p>

          <div class="frow">
            <div class="fgroup">
              <label>Contraseña actual</label>
              <input class="finput" type="password" name="pw_actual" placeholder="••••••••" autocomplete="current-password">
            </div>
          </div>
          <div class="frow frow-2">
            <div class="fgroup">
              <label>Nueva contraseña</label>
              <input class="finput" type="password" name="pw_nueva" id="pwNew" placeholder="Mínimo 8 caracteres" autocomplete="new-password">
              <div class="pw-bars"><div class="pw-bar" id="pb1"></div><div class="pw-bar" id="pb2"></div><div class="pw-bar" id="pb3"></div><div class="pw-bar" id="pb4"></div></div>
              <div class="pw-hint" id="pwHint">Escribe tu nueva contraseña</div>
            </div>
            <div class="fgroup">
              <label>Confirmar nueva contraseña</label>
              <input class="finput" type="password" name="pw_confirmar" id="pwConf" placeholder="Repite la contraseña" autocomplete="new-password">
              <div class="pw-hint" id="matchHint"></div>
            </div>
          </div>
          <p style="font-size:.75rem;color:var(--dim);margin-top:4px;">⚠️ Deja en blanco si no deseas cambiar tu contraseña.</p>
        </div>

        <!-- Sesiones activas placeholder -->
        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:20px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:12px;font-weight:700;">🖥 Sesiones Activas</p>
          <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 0;">
            <div style="display:flex;align-items:center;gap:12px;">
              <i class="fa fa-display" style="color:var(--green);font-size:1.2rem;"></i>
              <div>
                <p style="font-size:.85rem;font-weight:600;color:var(--txt);">Sesión actual</p>
                <span style="font-size:.72rem;color:var(--dim);">PHP Session · <?= date('d M Y, H:i') ?></span>
              </div>
            </div>
            <span style="font-size:.72rem;padding:3px 10px;background:var(--green-dim);color:var(--green-lt);border-radius:99px;border:1px solid var(--green);">Activa</span>
          </div>
        </div>
      </div>

      <!-- ══ 7. NOTIFICACIONES ═════════════════════════════════════════ -->
      <div class="ep-section" id="sec-notificaciones">
        <div class="sec-hd">
          <div class="sec-ico ico-green"><i class="fa fa-bell"></i></div>
          <div class="sec-hd-text">
            <strong>Notificaciones</strong>
            <span>Controla cómo y cuándo te notifica la plataforma</span>
          </div>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>📧 Notificaciones por correo</strong>
            <span>Recibe actualizaciones importantes en tu email</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="notif_email" <?= ($user['notif_email'] ?? 1) ? 'checked' : '' ?>>
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>🎓 Avisos de cursos y progreso</strong>
            <span>Recordatorios de lecciones y logros de aprendizaje</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="notif_curso" <?= ($user['notif_curso'] ?? 1) ? 'checked' : '' ?>>
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>🔔 Notificaciones del sistema</strong>
            <span>Alertas de seguridad, actualizaciones y mantenimiento</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="notif_sistema" <?= ($user['notif_sistema'] ?? 1) ? 'checked' : '' ?>>
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>👥 Actividad de la comunidad</strong>
            <span>Menciones, respuestas y actividad en foros</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="notif_comunidad">
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>🏆 Logros y certificaciones</strong>
            <span>Avisa cuando obtienes un nuevo certificado o nivel</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="notif_logros" checked>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>

      <!-- ══ 8. PRIVACIDAD ═════════════════════════════════════════════ -->
      <div class="ep-section" id="sec-privacidad">
        <div class="sec-hd">
          <div class="sec-ico ico-purple"><i class="fa fa-eye-slash"></i></div>
          <div class="sec-hd-text">
            <strong>Privacidad del Perfil</strong>
            <span>Controla quién ve tu información y actividad</span>
          </div>
        </div>

        <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.07);border-radius:var(--r-lg);padding:24px;margin-bottom:16px;">
          <p style="font-size:.78rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:16px;font-weight:700;">👁 Visibilidad del Perfil</p>
          <div class="vis-grid">
            <?php
              $vops = [
                'publico'     => ['🌐', 'Público', 'Todos pueden ver tu perfil'],
                'comunidad'   => ['👥', 'Comunidad', 'Solo usuarios de VIROX'],
                'privado'     => ['🔒', 'Privado',  'Solo tú puedes verlo'],
              ];
              $vact = $mooc_cfg['visibilidad_perfil'] ?? 'publico';
              foreach ($vops as $v=>[$ico,$nm,$desc]):
            ?>
            <div class="vis-item">
              <input type="radio" name="visibilidad_perfil" value="<?=$v?>" id="vis_<?=$v?>" <?=$vact===$v?'checked':''?>>
              <label for="vis_<?=$v?>"><?=$ico?> <?=$nm?></label>
            </div>
            <?php endforeach; ?>
          </div>
          <p style="font-size:.72rem;color:var(--dim);margin-top:10px;">La visibilidad afecta tu aparición en búsquedas dentro de la plataforma.</p>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>📊 Mostrar estadísticas públicas</strong>
            <span>Cursos completados, certificados y nivel visibles</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="pub_stats" checked>
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>🕐 Mostrar última conexión</strong>
            <span>Otros usuarios pueden ver cuándo estuviste activo</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="pub_conexion">
            <span class="toggle-slider"></span>
          </label>
        </div>

        <div class="toggle-row">
          <div class="toggle-info">
            <strong>🔍 Aparecer en búsquedas</strong>
            <span>Tu perfil puede aparecer al buscar usuarios</span>
          </div>
          <label class="toggle">
            <input type="checkbox" name="pub_busqueda" checked>
            <span class="toggle-slider"></span>
          </label>
        </div>
      </div>

      <!-- ══ 9. ZONA PELIGROSA ═════════════════════════════════════════ -->
      <div class="ep-section" id="sec-peligro">
        <div class="sec-hd">
          <div class="sec-ico" style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);"><i class="fa fa-triangle-exclamation" style="color:#f87171;"></i></div>
          <div class="sec-hd-text">
            <strong style="color:#f87171;">Zona Peligrosa</strong>
            <span>Acciones irreversibles sobre tu cuenta</span>
          </div>
        </div>

        <div class="danger-zone">
          <h4><i class="fa fa-triangle-exclamation"></i> Acciones Irreversibles</h4>

          <div style="display:flex;flex-direction:column;gap:14px;">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
              <div>
                <p style="font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:4px;">🗑 Eliminar historial de actividad</p>
                <p style="font-size:.78rem;color:var(--dim);">Borra todo el registro de actividad de tu cuenta.</p>
              </div>
              <button type="button" class="danger-btn" onclick="confirmAction('¿Eliminar tu historial de actividad? Esta acción no se puede deshacer.','borrar_historial')">Eliminar historial</button>
            </div>

            <div style="height:1px;background:rgba(239,68,68,.15);"></div>

            <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
              <div>
                <p style="font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:4px;">⏸ Desactivar cuenta temporalmente</p>
                <p style="font-size:.78rem;color:var(--dim);">Tu perfil se oculta pero puedes reactivarla iniciando sesión.</p>
              </div>
              <button type="button" class="danger-btn" onclick="confirmAction('¿Desactivar tu cuenta? Podrás reactivarla después.','desactivar_cuenta')">Desactivar cuenta</button>
            </div>

            <div style="height:1px;background:rgba(239,68,68,.15);"></div>

            <div style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;">
              <div>
                <p style="font-size:.9rem;font-weight:700;color:#f87171;margin-bottom:4px;">💀 Eliminar cuenta permanentemente</p>
                <p style="font-size:.78rem;color:var(--dim);">Todos tus datos, cursos y certificados serán eliminados. Irreversible.</p>
              </div>
              <button type="button" class="danger-btn" style="border-color:#ef4444;color:#ef4444;" onclick="confirmAction('ATENCIÓN: Esta acción eliminará tu cuenta permanentemente y no se puede deshacer. ¿Estás seguro?','eliminar_cuenta')">Eliminar cuenta</button>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Botón guardar sticky ──────────────────────────────────── -->
      <div class="save-bar" id="saveBar" style="display:none;">
        <a href="perfil.php" class="btn-cancel"><i class="fa fa-xmark"></i> Cancelar</a>
        <button type="submit" name="guardar" class="btn-save">
          <i class="fa fa-floppy-disk"></i> Guardar cambios
        </button>
      </div>

    </form><!-- /epForm -->
  </main>
</div>

<!-- ── FOOTER ──────────────────────────────────────────────────────────── -->
<footer style="border-top:1px solid rgba(40,166,128,.1);padding:24px 28px;background:#050d1a;margin-top:40px;">
  <div style="max-width:1280px;margin:auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
    <span style="font-family:var(--font-d);font-size:.9rem;color:var(--gold);letter-spacing:3px;">⬡ VIROX</span>
    <span style="font-size:.78rem;color:var(--dim);">Editar Perfil · Team VIROX © 2025</span>
    <a href="perfil.php" style="font-size:.8rem;color:var(--green);font-weight:600;">← Volver al perfil</a>
  </div>
</footer>

<script>
/* ── Nav lateral ──────────────────────────────── */
function showSec(id, el) {
  document.querySelectorAll('.ep-section').forEach(s => s.classList.remove('on'));
  document.querySelectorAll('.ep-nav-lnk').forEach(l => l.classList.remove('on'));
  document.getElementById('sec-' + id).classList.add('on');
  el.classList.add('on');
  // Mostrar save bar (ocultar en zona peligrosa)
  document.getElementById('saveBar').style.display = id === 'peligro' ? 'none' : 'flex';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Mostrar save bar inicialmente
document.getElementById('saveBar').style.display = 'flex';

/* ── Avatar preview ──────────────────────────── */
document.getElementById('avatarFile').addEventListener('change', function () {
  const file = this.files[0];
  if (!file) return;
  const r = new FileReader();
  r.onload = e => {
    const prev = document.getElementById('av-preview-img');
    prev.src = e.target.result;
    prev.style.display = 'block';
    document.getElementById('avMain').src = e.target.result;
  };
  r.readAsDataURL(file);
});

/* ── Password strength ───────────────────────── */
document.getElementById('pwNew')?.addEventListener('input', function () {
  const v = this.value;
  let s = 0;
  if (v.length >= 8) s++;
  if (/[A-Z]/.test(v)) s++;
  if (/[0-9]/.test(v)) s++;
  if (/[\W_]/.test(v)) s++;
  const cls = ['', 'w', 'w', 'm', 's'];
  const lbl = ['', 'Muy débil', 'Débil', 'Moderada', 'Fuerte'];
  ['pb1','pb2','pb3','pb4'].forEach((id, i) => {
    const el = document.getElementById(id);
    el.className = 'pw-bar';
    if (i < s) el.classList.add(cls[s]);
  });
  document.getElementById('pwHint').textContent = v.length ? lbl[s] : 'Escribe tu nueva contraseña';
  document.getElementById('pwHint').style.color = s >= 3 ? 'var(--green)' : s >= 2 ? 'var(--gold)' : 'var(--red)';
});

document.getElementById('pwConf')?.addEventListener('input', function () {
  const pw = document.getElementById('pwNew').value;
  const h  = document.getElementById('matchHint');
  if (!this.value) { h.textContent = ''; return; }
  if (this.value === pw) { h.style.color = 'var(--green)'; h.textContent = '✓ Contraseñas coinciden'; }
  else                   { h.style.color = 'var(--red)';   h.textContent = '✕ No coinciden'; }
});

/* ── Zona peligrosa ──────────────────────────── */
function confirmAction(msg, action) {
  if (confirm(msg)) {
    const f = document.createElement('form');
    f.method = 'POST';
    const i = document.createElement('input');
    i.type = 'hidden'; i.name = action; i.value = '1';
    f.appendChild(i); document.body.appendChild(f); f.submit();
  }
}

/* ── Detectar cambios en el formulario ─────────── */
let changed = false;
document.getElementById('epForm').addEventListener('input', () => { changed = true; });
window.addEventListener('beforeunload', e => {
  if (changed) { e.preventDefault(); e.returnValue = ''; }
});
document.getElementById('epForm').addEventListener('submit', () => { changed = false; });
document.querySelector('.btn-cancel')?.addEventListener('click', () => { changed = false; });
</script>
</body>
</html>