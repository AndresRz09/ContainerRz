<?php
include 'conexion.php';
session_start();

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$uid = (int)$_SESSION['user_id'];

// ── Traer datos completos del usuario ──
$stmt = $conexion->prepare(
    "SELECT u.*, 
            COALESCE(u.avatar,'assets/avatar-default.png') AS avatar_url
     FROM usuarios u
     WHERE u.id = ? LIMIT 1"
);
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$user){ header("Location: login.php"); exit(); }

// ── Estadísticas del usuario ──
// Cursos inscritos
$q1 = $conexion->prepare("SELECT COUNT(*) as total FROM inscripciones WHERE usuario_id=?");
$q1->bind_param("i",$uid); $q1->execute();
$cursos_total = $q1->get_result()->fetch_assoc()['total'] ?? 0; $q1->close();

// Cursos completados
$q2 = $conexion->prepare("SELECT COUNT(*) as total FROM inscripciones WHERE usuario_id=? AND completado=1");
$q2->bind_param("i",$uid); $q2->execute();
$cursos_comp = $q2->get_result()->fetch_assoc()['total'] ?? 0; $q2->close();

// Certificados
$q3 = $conexion->prepare("SELECT COUNT(*) as total FROM certificados WHERE usuario_id=?");
$q3->bind_param("i",$uid); $q3->execute();
$certs = $q3->get_result()->fetch_assoc()['total'] ?? 0; $q3->close();

// Publicaciones
$q4 = $conexion->prepare("SELECT COUNT(*) as total FROM publicaciones WHERE autor_id=?");
$q4->bind_param("i",$uid); $q4->execute();
$pubs = $q4->get_result()->fetch_assoc()['total'] ?? 0; $q4->close();

// Nivel (0-100 basado en actividad)
$nivel = min(100, (int)(($cursos_comp * 15) + ($certs * 20) + ($pubs * 10)));

// ── Actividad reciente ──
$actividad = [];
$qa = $conexion->prepare("SELECT tipo, descripcion, fecha FROM actividad_usuario WHERE usuario_id=? ORDER BY fecha DESC LIMIT 8");
if($qa){ $qa->bind_param("i",$uid); $qa->execute(); $ra=$qa->get_result(); while($a=$ra->fetch_assoc()) $actividad[]=$a; $qa->close(); }

// ── Cursos recientes ──
$cursos_rec = [];
$qcr = $conexion->prepare("SELECT c.titulo, c.imagen, i.progreso, i.completado FROM inscripciones i JOIN cursos c ON i.curso_id=c.id WHERE i.usuario_id=? ORDER BY i.fecha_inscripcion DESC LIMIT 4");
if($qcr){ $qcr->bind_param("i",$uid); $qcr->execute(); $rcr=$qcr->get_result(); while($cr=$rcr->fetch_assoc()) $cursos_rec[]=$cr; $qcr->close(); }

// ── Certificados ──
$certs_lista = [];
$qcl = $conexion->prepare("SELECT cert.nombre, cert.fecha_emision, cert.url FROM certificados cert WHERE cert.usuario_id=? ORDER BY cert.fecha_emision DESC LIMIT 6");
if($qcl){ $qcl->bind_param("i",$uid); $qcl->execute(); $rcl=$qcl->get_result(); while($c=$rcl->fetch_assoc()) $certs_lista[]=$c; $qcl->close(); }

$intereses = explode(',', $user['intereses'] ?? '');
$nombre_completo = htmlspecialchars(trim(($user['nombre']??'') . ' ' . ($user['apellido']??'')));
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title><?= $nombre_completo ?> — Perfil VIROX</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
    :root{
      --n900:#020817;--n800:#0c1526;--n700:#111827;--n600:#182035;--n500:#1e2d47;
      --gold:#DAA520;--gold-lt:#f0c840;--gold-dim:rgba(218,165,32,.14);
      --green:#28A680;--green-lt:#35d4a8;--green-dim:rgba(40,166,128,.14);
      --txt:#f0f4f8;--muted:#8da0b8;--dim:#526278;
      --r-md:14px;--r-lg:22px;--font-d:'Orbitron',monospace;--font-b:'Syne',sans-serif;
      --hh:68px;
    }
    *,*::before,*::after{margin:0;padding:0;box-sizing:border-box;-webkit-font-smoothing:antialiased;}
    html{scroll-behavior:smooth;}
    body{font-family:var(--font-b);background:var(--n900);color:var(--txt);}
    ::-webkit-scrollbar{width:5px;} ::-webkit-scrollbar-track{background:var(--n800);} ::-webkit-scrollbar-thumb{background:var(--green);border-radius:99px;}
    a{text-decoration:none;color:inherit;} button{cursor:pointer;border:none;font-family:inherit;}

    /* ── Header reutilizado del sistema ── */
    .site-header{position:sticky;top:0;z-index:1000;height:var(--hh);background:rgba(2,8,23,.9);backdrop-filter:blur(16px);border-bottom:1px solid rgba(40,166,128,.2);}
    .header-inner{max-width:1480px;margin:auto;height:100%;display:flex;align-items:center;justify-content:space-between;padding:0 28px;}
    .brand{display:flex;align-items:center;gap:10px;}
    .brand-hex{font-size:1.5rem;color:var(--green);}
    .brand-name{font-family:var(--font-d);font-size:1.4rem;font-weight:900;color:var(--gold);letter-spacing:4px;}
    .hdr-nav{display:flex;align-items:center;gap:8px;}
    .hdr-nav a{padding:8px 15px;border-radius:var(--r-md);font-size:.88rem;color:var(--muted);font-weight:600;transition:all .2s;}
    .hdr-nav a:hover{color:var(--txt);background:rgba(255,255,255,.06);}
    .hdr-user{display:flex;align-items:center;gap:10px;padding:6px 14px;background:var(--green-dim);border:1px solid rgba(40,166,128,.3);border-radius:99px;}
    .hdr-user img{width:28px;height:28px;border-radius:50%;object-fit:cover;border:2px solid var(--green);}
    .hdr-user span{font-size:.85rem;font-weight:600;color:var(--txt);}

    /* ── Layout YouTube Studio ── */
    .prof-layout{display:grid;grid-template-columns:260px 1fr;min-height:calc(100vh - var(--hh));}

    /* ── Sidebar perfil ── */
    .prof-sidebar{
      background:var(--n800);border-right:1px solid rgba(255,255,255,.05);
      padding:28px 20px;position:sticky;top:var(--hh);height:calc(100vh - var(--hh));overflow-y:auto;
    }

    /* Avatar grande */
    .psb-avatar-wrap{position:relative;width:90px;height:90px;margin:0 auto 14px;}
    .psb-avatar{width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--green);box-shadow:0 0 24px rgba(40,166,128,.4);}
    .psb-ring{position:absolute;inset:-5px;border-radius:50%;border:1px dashed rgba(40,166,128,.4);animation:pspin 10s linear infinite;}
    @keyframes pspin{to{transform:rotate(360deg)}}
    .psb-online{position:absolute;bottom:4px;right:4px;width:12px;height:12px;background:#22c55e;border-radius:50%;border:2px solid var(--n800);}

    .psb-name{text-align:center;font-family:var(--font-d);font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .psb-role{text-align:center;font-size:.72rem;color:var(--green-lt);letter-spacing:2px;text-transform:uppercase;margin-bottom:6px;}
    .psb-username{text-align:center;font-size:.78rem;color:var(--dim);margin-bottom:16px;}

    /* Nivel */
    .psb-level{background:rgba(255,255,255,.04);border-radius:var(--r-md);padding:14px;margin-bottom:20px;text-align:center;}
    .psb-level-label{font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;}
    .psb-level-num{font-family:var(--font-d);font-size:1.8rem;font-weight:900;color:var(--gold);}
    .psb-level-bar{height:4px;background:rgba(255,255,255,.08);border-radius:99px;margin-top:8px;overflow:hidden;}
    .psb-level-fill{height:100%;background:linear-gradient(to right,var(--green),var(--gold));border-radius:99px;transition:width 1s ease;}

    .psb-rule{height:1px;background:rgba(255,255,255,.06);margin:16px 0;}

    /* Nav sidebar */
    .psb-nav{display:flex;flex-direction:column;gap:2px;}
    .psb-lnk{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:var(--r-md);color:var(--muted);font-size:.88rem;font-weight:500;cursor:pointer;transition:all .2s;}
    .psb-lnk:hover,.psb-lnk.on{color:var(--txt);background:var(--green-dim);}
    .psb-lnk.on{color:var(--green-lt);border-left:3px solid var(--green);}
    .psb-lnk i{width:18px;text-align:center;font-size:.9rem;}

    .psb-edit-btn{
      display:flex;align-items:center;justify-content:center;gap:8px;
      padding:11px;background:var(--green);color:#fff;
      border-radius:var(--r-md);font-weight:700;font-size:.85rem;
      margin-top:20px;transition:all .2s;
    }
    .psb-edit-btn:hover{background:var(--green-lt);transform:translateY(-2px);}

    /* ── Contenido principal ── */
    .prof-main{padding:32px 36px;min-width:0;}

    /* Tabs */
    .prof-tabs{display:flex;gap:4px;border-bottom:1px solid rgba(255,255,255,.07);margin-bottom:28px;}
    .ptab{
      padding:10px 20px;font-size:.88rem;font-weight:600;color:var(--muted);
      border-bottom:2px solid transparent;cursor:pointer;transition:all .2s;background:none;
    }
    .ptab:hover{color:var(--txt);}
    .ptab.on{color:var(--green-lt);border-bottom-color:var(--green);}

    .ptab-content{display:none;animation:tabIn .35s ease both;}
    .ptab-content.on{display:block;}
    @keyframes tabIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

    /* ── Stats cards ── */
    .stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:16px;margin-bottom:28px;}
    .stat-card{
      background:var(--n600);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);
      padding:22px 18px;text-align:center;transition:transform .2s,border-color .2s;
    }
    .stat-card:hover{transform:translateY(-4px);border-color:rgba(40,166,128,.3);}
    .sc-ico{font-size:1.8rem;margin-bottom:8px;}
    .sc-num{font-family:var(--font-d);font-size:2rem;font-weight:900;color:var(--gold);line-height:1;}
    .sc-lbl{font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-top:4px;}

    /* ── Gráfico de actividad ── */
    .activity-chart{background:var(--n600);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);padding:24px;margin-bottom:24px;}
    .ac-title{font-size:.9rem;font-weight:700;color:var(--txt);margin-bottom:16px;}
    .ac-bars{display:flex;align-items:flex-end;gap:6px;height:80px;}
    .ac-bar{flex:1;border-radius:4px 4px 0 0;background:linear-gradient(to top,var(--green),rgba(40,166,128,.3));transition:height .8s ease;min-height:4px;}
    .ac-labels{display:flex;gap:6px;margin-top:6px;}
    .ac-lbl{flex:1;text-align:center;font-size:.65rem;color:var(--dim);}

    /* ── Cursos ── */
    .section-title{font-family:var(--font-d);font-size:.92rem;font-weight:700;color:var(--txt);letter-spacing:1px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;}
    .section-title a{font-family:var(--font-b);font-size:.78rem;color:var(--green);font-weight:600;}
    .courses-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin-bottom:28px;}
    .course-card{background:var(--n600);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-lg);overflow:hidden;transition:transform .2s,border-color .2s;}
    .course-card:hover{transform:translateY(-4px);border-color:rgba(40,166,128,.3);}
    .course-img{width:100%;aspect-ratio:16/9;object-fit:cover;background:var(--n500);}
    .course-body{padding:12px;}
    .course-title{font-size:.82rem;font-weight:700;color:var(--txt);margin-bottom:8px;line-height:1.3;}
    .course-prog{height:3px;background:rgba(255,255,255,.08);border-radius:99px;margin-bottom:4px;}
    .course-prog-fill{height:100%;background:var(--green);border-radius:99px;}
    .course-pct{font-size:.7rem;color:var(--muted);}

    /* ── Certificados ── */
    .certs-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:28px;}
    .cert-card{background:linear-gradient(135deg,var(--n600),var(--n500));border:1px solid rgba(218,165,32,.2);border-radius:var(--r-lg);padding:20px;display:flex;align-items:center;gap:14px;transition:transform .2s;}
    .cert-card:hover{transform:translateY(-3px);}
    .cert-ico{font-size:2rem;flex-shrink:0;}
    .cert-name{font-size:.88rem;font-weight:700;color:var(--txt);margin-bottom:4px;}
    .cert-date{font-size:.72rem;color:var(--muted);}
    .cert-link{font-size:.72rem;color:var(--gold);font-weight:600;display:flex;align-items:center;gap:4px;margin-top:6px;}

    /* ── Actividad reciente ── */
    .activity-list{display:flex;flex-direction:column;gap:8px;}
    .act-item{display:flex;align-items:center;gap:14px;padding:12px 16px;background:var(--n600);border:1px solid rgba(255,255,255,.05);border-radius:var(--r-md);}
    .act-ico{width:36px;height:36px;border-radius:50%;background:var(--green-dim);display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;}
    .act-desc{font-size:.85rem;color:var(--txt);flex:1;}
    .act-date{font-size:.72rem;color:var(--dim);}

    /* ── Info personal tab ── */
    .info-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
    .info-item{background:var(--n600);border:1px solid rgba(255,255,255,.06);border-radius:var(--r-md);padding:16px;}
    .info-lbl{font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;}
    .info-val{font-size:.92rem;color:var(--txt);font-weight:600;}

    /* Intereses tags */
    .tags{display:flex;flex-wrap:wrap;gap:8px;margin-top:16px;}
    .tag{padding:4px 14px;background:var(--green-dim);border:1px solid var(--green);border-radius:99px;font-size:.75rem;color:var(--green-lt);font-weight:600;}

    /* Redes sociales */
    .social-row{display:flex;gap:10px;margin-top:16px;flex-wrap:wrap;}
    .soc-btn{display:flex;align-items:center;gap:8px;padding:8px 14px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:var(--r-md);font-size:.8rem;color:var(--muted);transition:all .2s;}
    .soc-btn:hover{background:rgba(255,255,255,.1);color:var(--txt);}

    @media(max-width:960px){
      .prof-layout{grid-template-columns:1fr;}
      .prof-sidebar{position:static;height:auto;}
      .prof-main{padding:20px;}
      .info-grid{grid-template-columns:1fr;}
    }
  </style>
</head>
<body>

<!-- Header -->
<header class="site-header">
  <div class="header-inner">
    <a href="index.php" class="brand">
      <span class="brand-hex">⬡</span>
      <span class="brand-name">VIROX</span>
    </a>
    <nav class="hdr-nav">
      <a href="index.php"><i class="fa fa-home"></i> Inicio</a>
      <a href="cursos.php"><i class="fa fa-book"></i> Cursos</a>
      <a href="servicios.php"><i class="fa fa-tools"></i> Servicios</a>
    </nav>
    <div class="hdr-user">
      <img src="<?= htmlspecialchars($user['avatar_url']) ?>" alt="Avatar">
      <span><?= htmlspecialchars($user['nombre'] ?? '') ?></span>
    </div>
  </div>
</header>

<div class="prof-layout">

  <!-- ══ SIDEBAR ══ -->
  <aside class="prof-sidebar">
    <div class="psb-avatar-wrap">
      <img src="<?= htmlspecialchars($user['avatar_url']) ?>" class="psb-avatar" alt="Avatar">
      <div class="psb-ring"></div>
      <div class="psb-online"></div>
    </div>
    <div class="psb-name"><?= $nombre_completo ?></div>
    <div class="psb-role"><?= htmlspecialchars(ucfirst($user['rol'] ?? 'Usuario')) ?></div>
    <div class="psb-username">@<?= htmlspecialchars($user['username'] ?? '') ?></div>

    <!-- Nivel -->
    <div class="psb-level">
      <div class="psb-level-label">Nivel de Progreso</div>
      <div class="psb-level-num"><?= $nivel ?><span style="font-size:1rem;color:var(--muted)">/100</span></div>
      <div class="psb-level-bar">
        <div class="psb-level-fill" style="width:<?= $nivel ?>%"></div>
      </div>
    </div>

    <div class="psb-rule"></div>

    <nav class="psb-nav">
      <div class="psb-lnk on" onclick="showTab('overview',this)"><i class="fa fa-chart-line"></i> Vista general</div>
      <div class="psb-lnk" onclick="showTab('cursos',this)"><i class="fa fa-graduation-cap"></i> Mis cursos</div>
      <div class="psb-lnk" onclick="showTab('certificados',this)"><i class="fa fa-certificate"></i> Certificados</div>
      <div class="psb-lnk" onclick="showTab('actividad',this)"><i class="fa fa-clock-rotate-left"></i> Actividad</div>
      <div class="psb-lnk" onclick="showTab('info',this)"><i class="fa fa-id-card"></i> Información</div>
      <div class="psb-lnk" onclick="showTab('comunidad',this)"><i class="fa fa-users"></i> Comunidad</div>
    </nav>

    <a href="editar-perfil.php" class="psb-edit-btn">
      <i class="fa fa-pen"></i> Editar perfil
    </a>
    <a href="logout.php" style="display:flex;align-items:center;justify-content:center;gap:8px;padding:10px;margin-top:8px;border-radius:var(--r-md);font-size:.82rem;color:var(--dim);transition:all .2s;">
      <i class="fa fa-sign-out-alt"></i> Cerrar sesión
    </a>
  </aside>

  <!-- ══ CONTENIDO ══ -->
  <main class="prof-main">

    <!-- Tab: Vista general -->
    <div class="ptab-content on" id="tab-overview">
      <div class="stats-row">
        <div class="stat-card"><div class="sc-ico">🎓</div><div class="sc-num"><?= $cursos_total ?></div><div class="sc-lbl">Cursos inscritos</div></div>
        <div class="stat-card"><div class="sc-ico">✅</div><div class="sc-num"><?= $cursos_comp ?></div><div class="sc-lbl">Completados</div></div>
        <div class="stat-card"><div class="sc-ico">🏆</div><div class="sc-num"><?= $certs ?></div><div class="sc-lbl">Certificados</div></div>
        <div class="stat-card"><div class="sc-ico">📄</div><div class="sc-num"><?= $pubs ?></div><div class="sc-lbl">Publicaciones</div></div>
        <div class="stat-card"><div class="sc-ico">⭐</div><div class="sc-num"><?= $nivel ?></div><div class="sc-lbl">Nivel</div></div>
      </div>

      <!-- Gráfico de actividad simulado -->
      <div class="activity-chart">
        <div class="ac-title">📊 Actividad últimos 7 días</div>
        <div class="ac-bars" id="acBars">
          <?php
            $dias = ['Lun','Mar','Mié','Jue','Vie','Sáb','Dom'];
            $vals = [30,65,45,80,55,90,40]; // Reemplazar con datos reales
            foreach($vals as $v)
              echo "<div class='ac-bar' style='height:{$v}%' data-h='{$v}'></div>";
          ?>
        </div>
        <div class="ac-labels">
          <?php foreach($dias as $d) echo "<div class='ac-lbl'>{$d}</div>"; ?>
        </div>
      </div>

      <!-- Cursos recientes -->
      <?php if(!empty($cursos_rec)): ?>
      <div class="section-title">Cursos Recientes <a href="cursos.php">Ver todos ›</a></div>
      <div class="courses-grid">
        <?php foreach($cursos_rec as $cr):
          $prog = (int)($cr['progreso'] ?? 0);
        ?>
        <div class="course-card">
          <div class="course-img" style="background:var(--n500);display:flex;align-items:center;justify-content:center;font-size:2rem;">📚</div>
          <div class="course-body">
            <div class="course-title"><?= htmlspecialchars($cr['titulo']) ?></div>
            <div class="course-prog"><div class="course-prog-fill" style="width:<?= $prog ?>%"></div></div>
            <div class="course-pct"><?= $prog ?>% completado <?= $cr['completado'] ? '✅' : '' ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <!-- Tasas CRM -->
      <div class="section-title">📈 Tasas de Visitas / Suscripciones</div>
      <div class="stats-row">
        <div class="stat-card" style="background:linear-gradient(135deg,var(--n600),var(--n500));">
          <div class="sc-ico">👁</div>
          <div class="sc-num" id="visitasCount">–</div>
          <div class="sc-lbl">Visitas al perfil</div>
        </div>
        <div class="stat-card" style="background:linear-gradient(135deg,var(--n600),var(--n500));">
          <div class="sc-ico">🔔</div>
          <div class="sc-num" id="subsCount">–</div>
          <div class="sc-lbl">Suscriptores</div>
        </div>
        <div class="stat-card" style="background:linear-gradient(135deg,var(--n600),var(--n500));">
          <div class="sc-ico">💬</div>
          <div class="sc-num" id="comCount">–</div>
          <div class="sc-lbl">Comunidad</div>
        </div>
      </div>
    </div>

    <!-- Tab: Cursos -->
    <div class="ptab-content" id="tab-cursos">
      <div class="section-title">Mis Cursos (MOOC / NOOC / SPOC)</div>
      <?php if(empty($cursos_rec)): ?>
        <div style="text-align:center;padding:48px;color:var(--muted);">
          <div style="font-size:3rem;margin-bottom:12px;">📚</div>
          <p>Aún no estás inscrito en ningún curso.</p>
          <a href="cursos.php" style="color:var(--gold);font-weight:700;">Explorar cursos ›</a>
        </div>
      <?php else: ?>
        <div class="courses-grid">
          <?php foreach($cursos_rec as $cr):
            $prog = (int)($cr['progreso'] ?? 0);
          ?>
          <div class="course-card">
            <div class="course-img" style="background:var(--n500);display:flex;align-items:center;justify-content:center;font-size:2.5rem;">📖</div>
            <div class="course-body">
              <div class="course-title"><?= htmlspecialchars($cr['titulo']) ?></div>
              <div class="course-prog"><div class="course-prog-fill" style="width:<?= $prog ?>%"></div></div>
              <div class="course-pct"><?= $prog ?>% <?= $cr['completado'] ? '— Completado ✅' : 'en progreso' ?></div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Certificados -->
    <div class="ptab-content" id="tab-certificados">
      <div class="section-title">Certificados Obtenidos</div>
      <?php if(empty($certs_lista)): ?>
        <div style="text-align:center;padding:48px;color:var(--muted);">
          <div style="font-size:3rem;margin-bottom:12px;">🏆</div>
          <p>Aún no tienes certificados. ¡Completa tu primer curso!</p>
        </div>
      <?php else: ?>
        <div class="certs-grid">
          <?php foreach($certs_lista as $c): ?>
          <div class="cert-card">
            <span class="cert-ico">🏆</span>
            <div>
              <div class="cert-name"><?= htmlspecialchars($c['nombre']) ?></div>
              <div class="cert-date"><?= date('d M Y', strtotime($c['fecha_emision'])) ?></div>
              <?php if(!empty($c['url'])): ?>
              <a href="<?= htmlspecialchars($c['url']) ?>" target="_blank" class="cert-link"><i class="fa fa-external-link"></i> Ver certificado</a>
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Actividad -->
    <div class="ptab-content" id="tab-actividad">
      <div class="section-title">Actividad Reciente</div>
      <?php if(empty($actividad)): ?>
        <div style="text-align:center;padding:48px;color:var(--muted);">
          <div style="font-size:3rem;margin-bottom:12px;">🕐</div>
          <p>Sin actividad registrada aún.</p>
        </div>
      <?php else: ?>
        <div class="activity-list">
          <?php foreach($actividad as $a): ?>
          <div class="act-item">
            <div class="act-ico">📌</div>
            <div class="act-desc"><?= htmlspecialchars($a['descripcion']) ?></div>
            <div class="act-date"><?= date('d M', strtotime($a['fecha'])) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Información personal -->
    <div class="ptab-content" id="tab-info">
      <div class="section-title">Información del Usuario</div>
      <div class="info-grid">
        <?php
          $fields = [
            ['Nombre completo', $nombre_completo],
            ['Usuario', '@'.($user['username']??'–')],
            ['Correo', $user['correo']??'–'],
            ['Teléfono', $user['telefono']??'–'],
            ['Tipo documento', $user['tipo_documento']??'–'],
            ['Identificación', $user['identificacion']??'–'],
            ['País', $user['pais']??'–'],
            ['Ciudad', $user['ciudad']??'–'],
            ['Ocupación', $user['ocupacion']??'–'],
            ['Institución', $user['institucion']??'–'],
            ['Nivel educativo', ucfirst($user['nivel_educativo']??'–')],
            ['Rol en VIROX', ucfirst($user['rol']??'–')],
            ['Miembro desde', !empty($user['fecha_registro'])?date('d M Y',strtotime($user['fecha_registro'])):'–'],
            ['Último acceso', !empty($user['ultimo_acceso'])?date('d M Y H:i',strtotime($user['ultimo_acceso'])):'–'],
          ];
          foreach($fields as [$lbl,$val]):
        ?>
        <div class="info-item">
          <div class="info-lbl"><?= $lbl ?></div>
          <div class="info-val"><?= htmlspecialchars($val) ?></div>
        </div>
        <?php endforeach; ?>
      </div>

      <?php if(!empty(array_filter($intereses))): ?>
      <div style="margin-top:20px;">
        <div class="section-title">Áreas de Interés</div>
        <div class="tags">
          <?php foreach($intereses as $int): if(empty(trim($int))) continue; ?>
          <span class="tag"><?= htmlspecialchars(trim($int)) ?></span>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>

      <?php if(!empty($user['bio'])): ?>
      <div style="margin-top:20px;background:var(--n600);border-radius:var(--r-lg);padding:20px;border:1px solid rgba(255,255,255,.06);">
        <div class="section-title" style="margin-bottom:10px;">Bio</div>
        <p style="font-size:.9rem;color:var(--muted);line-height:1.7;"><?= htmlspecialchars($user['bio']) ?></p>
      </div>
      <?php endif; ?>

      <!-- Redes sociales -->
      <?php
        $redes = ['linkedin'=>['fa-brands fa-linkedin','LinkedIn','#0A66C2'],
                  'github'  =>['fa-brands fa-github','GitHub','#fff'],
                  'twitter' =>['fa-brands fa-twitter','Twitter','#1DA1F2'],
                  'website' =>['fa-solid fa-globe','Website','var(--green)']];
        $hayRedes = false;
        foreach($redes as $k=>[$ico,$lbl,$clr]) if(!empty($user[$k])) $hayRedes=true;
      ?>
      <?php if($hayRedes): ?>
      <div style="margin-top:20px;">
        <div class="section-title">Redes y Contacto</div>
        <div class="social-row">
          <?php foreach($redes as $k=>[$ico,$lbl,$clr]): if(empty($user[$k])) continue; ?>
          <a href="<?= htmlspecialchars($user[$k]) ?>" target="_blank" class="soc-btn">
            <i class="<?= $ico ?>" style="color:<?= $clr ?>"></i> <?= $lbl ?>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>

    <!-- Tab: Comunidad -->
    <div class="ptab-content" id="tab-comunidad">
      <div class="section-title">Comunidad VIROX</div>
      <div style="text-align:center;padding:60px 24px;background:var(--n600);border-radius:var(--r-lg);border:1px dashed rgba(255,255,255,.1);">
        <div style="font-size:3rem;margin-bottom:14px;">👥</div>
        <h3 style="font-family:var(--font-d);font-size:1rem;color:var(--txt);margin-bottom:8px;">Próximamente</h3>
        <p style="font-size:.85rem;color:var(--muted);">El módulo de comunidad estará disponible pronto.</p>
      </div>
    </div>

  </main>
</div>

<script>
function showTab(id, el){
  document.querySelectorAll('.ptab-content').forEach(t=>t.classList.remove('on'));
  document.querySelectorAll('.psb-lnk').forEach(l=>l.classList.remove('on'));
  document.getElementById('tab-'+id).classList.add('on');
  el.classList.add('on');
}

// Cargar stats CRM desde AJAX (simplificado)
fetch('api/perfil_stats.php?uid=<?= $uid ?>')
  .then(r=>r.json())
  .then(d=>{
    if(d.visitas !== undefined) document.getElementById('visitasCount').textContent = d.visitas;
    if(d.subs    !== undefined) document.getElementById('subsCount').textContent    = d.subs;
    if(d.comunidad!==undefined) document.getElementById('comCount').textContent     = d.comunidad;
  }).catch(()=>{
    document.getElementById('visitasCount').textContent = '—';
    document.getElementById('subsCount').textContent    = '—';
    document.getElementById('comCount').textContent     = '—';
  });
</script>
</body>
</html>