package com.containerrz.util

import android.content.Context
import android.content.SharedPreferences
import com.containerrz.data.model.User

/**
 * SessionManager — wraps SharedPreferences for user authentication state.
 * Mirrors the PHP session logic from login.php.
 */
class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    fun saveSession(user: User) {
        prefs.edit().apply {
            putBoolean(KEY_LOGGED_IN, true)
            putInt(KEY_USER_ID, user.id)
            putString(KEY_USER_NAME, user.nombreCompleto)
            putString(KEY_USER_EMAIL, user.correo)
            putString(KEY_USER_ROL, user.rol)
            putString(KEY_USER_AVATAR, user.avatarUrl)
            putString(KEY_TOKEN, user.token)
            apply()
        }
    }

    fun isLoggedIn(): Boolean = prefs.getBoolean(KEY_LOGGED_IN, false)

    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "Usuario") ?: "Usuario"

    fun getUserEmail(): String = prefs.getString(KEY_USER_EMAIL, "") ?: ""

    fun getUserRol(): String = prefs.getString(KEY_USER_ROL, "") ?: ""

    fun getUserAvatar(): String = prefs.getString(KEY_USER_AVATAR, "") ?: ""

    fun getToken(): String = prefs.getString(KEY_TOKEN, "") ?: ""

    fun isAdmin(): Boolean = getUserRol() in listOf("admin", "superadmin")

    fun logout() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val PREF_NAME   = "containerrz_session"
        private const val KEY_LOGGED_IN = "logged_in"
        private const val KEY_USER_ID   = "user_id"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_ROL  = "user_rol"
        private const val KEY_USER_AVATAR = "user_avatar"
        private const val KEY_TOKEN     = "token"
    }
}