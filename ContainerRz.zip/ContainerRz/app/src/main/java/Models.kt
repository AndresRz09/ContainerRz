package com.containerrz.data.model

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

// ─── Service / Servicio ──────────────────────────────────────────────────────

@Parcelize
data class Servicio(
    val id: String,
    val ico: String,
    val categoria: String,       // Desarrollo, Ciberseguridad, Redes, IA…
    val titulo: String,
    val subtitulo: String,
    val color: String,           // "green" | "blue" | "gold" | "purple"
    val nivel: String,
    val duracion: String,
    val precioBase: Long,
    val definicion: String,
    val importancia: String,
    val conceptos: List<Concepto>,
    val parametros: List<String>,
    val fotoUrl: String,
    val videoUrl: String,
    val links: List<Link>,
    val planes: List<Plan>
) : Parcelable

@Parcelize
data class Concepto(
    val icon: String,
    val titulo: String,
    val descripcion: String
) : Parcelable

@Parcelize
data class Link(
    val icon: String,
    val label: String,
    val url: String
) : Parcelable

@Parcelize
data class Plan(
    val nombre: String,
    val precio: Long,
    val features: List<String>
) : Parcelable

// ─── Team Member / Miembro ───────────────────────────────────────────────────

@Parcelize
data class Miembro(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val username: String,
    val avatarUrl: String,
    val rol: String,             // admin | superadmin | empleado | creador
    val bio: String,
    val ocupacion: String,
    val intereses: List<String>,
    val areaTecnologica: String,
    val tipoEquipo: String,
    val cargoEquipo: String,
    val disponible: Boolean,
    val calificacion: Float,
    val numProyectos: Int,
    val habilidades: List<String>,
    val descripcionEquipo: String,
    val orden: Int
) : Parcelable {
    val nombreCompleto get() = "$nombre $apellido"
}

// ─── Project / Proyecto ──────────────────────────────────────────────────────

@Parcelize
data class Proyecto(
    val id: Int,
    val titulo: String,
    val descripcion: String,
    val estado: String,          // "activo" | "completado" | "pausado"
    val progreso: Int,           // 0-100
    val tecnologias: List<String>,
    val imageUrl: String,
    val fechaInicio: String
) : Parcelable

// ─── Chat Message (IA) ───────────────────────────────────────────────────────

data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isLoading: Boolean = false
)

// ─── Hero Slide ──────────────────────────────────────────────────────────────

data class HeroSlide(
    val tag: String,
    val tagColor: SlideColor,
    val title: String,
    val accentTitle: String?,
    val body: String,
    val ctaText: String?,
    val ctaDestination: String?
)

enum class SlideColor { GREEN, GOLD, BLUE }

// ─── User Session ────────────────────────────────────────────────────────────

data class User(
    val id: Int,
    val nombre: String,
    val apellido: String,
    val correo: String,
    val rol: String,
    val avatarUrl: String,
    val token: String
) {
    val nombreCompleto get() = "$nombre $apellido"
}

// ─── Login / Auth ────────────────────────────────────────────────────────────

data class LoginRequest(
    val input: String,
    val password: String
)

data class LoginResponse(
    val success: Boolean,
    val user: User?,
    val message: String
)

data class RegisterRequest(
    val nombre: String,
    val apellido: String,
    val correo: String,
    val password: String,
    val telefono: String,
    val identificacion: String
)

// ─── Static data helpers ─────────────────────────────────────────────────────

object ServiciosData {
    /**
     * Local static copy of the services catalogue, matching PHP servicios.php.
     * In a real build this would come from the backend API.
     */
    val servicios: List<Servicio> = listOf(
        Servicio(
            id = "programacion",
            ico = "💻",
            categoria = "Desarrollo",
            titulo = "Programación",
            subtitulo = "Fundamentos y desarrollo de software",
            color = "green",
            nivel = "Básico → Avanzado",
            duracion = "20 – 120 h",
            precioBase = 150_000,
            definicion = "La programación es el proceso de diseñar, codificar, depurar y mantener el código fuente de programas computacionales para resolver problemas o realizar tareas.",
            importancia = "En un mundo completamente digitalizado, la programación es el motor que impulsa la economía, la medicina, la ingeniería y la educación.",
            conceptos = listOf(
                Concepto("🧮", "Algoritmos", "Secuencia lógica de pasos para resolver un problema."),
                Concepto("📝", "Lenguajes de Programación", "Python, JavaScript, Java, C++, C#, Go, Rust, entre otros."),
                Concepto("🔄", "Tipos de Programación", "Imperativa, OOP, funcional, lógica y reactiva."),
                Concepto("🐛", "Depuración", "Identificar, analizar y corregir errores en el código."),
                Concepto("📦", "Librerías y Frameworks", "Código reutilizable que acelera el desarrollo."),
                Concepto("🔧", "Control de Versiones", "Git para rastrear cambios y colaborar.")
            ),
            parametros = listOf(
                "Programación desde cero (lógica y pseudocódigo)",
                "Python, JavaScript, C++",
                "Variables, tipos de datos y operadores",
                "Estructuras de control: condicionales y ciclos",
                "Funciones, módulos y reutilización",
                "POO completa",
                "Patrones de diseño GoF",
                "Testing unitario y TDD",
                "APIs REST",
                "Clean Code"
            ),
            fotoUrl = "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&q=80",
            videoUrl = "https://www.youtube.com/embed/nLRL_NcnK-4",
            links = listOf(
                Link("🐍", "Python Official Docs", "https://docs.python.org"),
                Link("📘", "MDN JavaScript", "https://developer.mozilla.org/es/docs/Web/JavaScript"),
                Link("📚", "freeCodeCamp", "https://www.freecodecamp.org")
            ),
            planes = listOf(
                Plan("Básico", 59_000, listOf("Lógica y pseudocódigo", "1 lenguaje", "10 ejercicios", "Soporte por chat")),
                Plan("Estándar", 129_000, listOf("Todo lo Básico", "3 lenguajes", "Proyecto integrador", "POO completo")),
                Plan("Premium", 250_000, listOf("Todo lo Estándar", "Patrones de diseño", "Testing y CI/CD", "Mentoría 1:1", "Certificado VIROX"))
            )
        ),
        Servicio(
            id = "prog_web",
            ico = "🌐",
            categoria = "Desarrollo",
            titulo = "Programación Web",
            subtitulo = "Frontend, Backend y Full-Stack",
            color = "blue",
            nivel = "Básico → Full-Stack",
            duracion = "30 – 150 h",
            precioBase = 180_000,
            definicion = "La programación web permite crear sitios, aplicaciones y plataformas accesibles desde navegadores usando HTML, CSS, JavaScript, PHP, Node.js, React, entre otras.",
            importancia = "Más del 60% de las empresas del mundo dependen de presencia digital activa.",
            conceptos = listOf(
                Concepto("🖼", "HTML5", "Estructura del contenido de páginas web."),
                Concepto("🎨", "CSS3", "Diseño, colores, animaciones y responsive."),
                Concepto("⚡", "JavaScript", "Interactividad frontend y backend con Node.js."),
                Concepto("⚙️", "PHP / Node", "Procesamiento server-side y bases de datos."),
                Concepto("🔗", "APIs REST", "Comunicación frontend-backend via HTTP/JSON."),
                Concepto("📱", "Responsive", "Adaptación a móviles, tablets y escritorios.")
            ),
            parametros = listOf(
                "HTML5 semántico y accesibilidad",
                "CSS3: Flexbox, Grid, animaciones",
                "JavaScript ES6+: async/await, fetch",
                "React, Vue.js, Svelte",
                "Backend PHP 8 / Node.js / Express",
                "MySQL, PostgreSQL, MongoDB",
                "JWT, OAuth2, sesiones",
                "Despliegue: Netlify, Vercel, AWS"
            ),
            fotoUrl = "https://images.unsplash.com/photo-1547658719-da2b51169166?w=800&q=80",
            videoUrl = "https://www.youtube.com/embed/ysEN5RaKOlA",
            links = listOf(
                Link("🌐", "W3Schools", "https://www.w3schools.com"),
                Link("📘", "MDN Web Docs", "https://developer.mozilla.org")
            ),
            planes = listOf(
                Plan("Básico", 79_000, listOf("HTML + CSS", "JS básico", "Proyecto portafolio")),
                Plan("Estándar", 159_000, listOf("Todo lo Básico", "React / Vue", "Backend básico")),
                Plan("Premium", 299_000, listOf("Full-Stack completo", "DevOps básico", "Certificado VIROX"))
            )
        ),
        Servicio(
            id = "ciberseguridad",
            ico = "🔐",
            categoria = "Ciberseguridad",
            titulo = "Ciberseguridad",
            subtitulo = "Defensa, ética y hacking",
            color = "gold",
            nivel = "Intermedio → Avanzado",
            duracion = "40 – 200 h",
            precioBase = 200_000,
            definicion = "La ciberseguridad es la práctica de proteger sistemas, redes y programas de ataques digitales mediante técnicas de defensa, análisis forense y ethical hacking.",
            importancia = "Con el crecimiento exponencial de amenazas digitales, los profesionales en seguridad son de los más demandados y mejor pagados del mercado tecnológico.",
            conceptos = listOf(
                Concepto("🛡", "Defensa", "Firewalls, IDS/IPS, hardening de sistemas y redes."),
                Concepto("⚔️", "Ethical Hacking", "Pentesting autorizado para encontrar vulnerabilidades."),
                Concepto("🔍", "Forense Digital", "Análisis de evidencia digital tras incidentes."),
                Concepto("🦠", "Malware Analysis", "Estudio y reversión de software malicioso."),
                Concepto("🔐", "Criptografía", "Protección de datos mediante algoritmos matemáticos."),
                Concepto("📋", "Cumplimiento", "ISO 27001, NIST, GDPR y marcos regulatorios.")
            ),
            parametros = listOf(
                "Fundamentos de redes y protocolos",
                "Linux para seguridad (Kali, Parrot)",
                "Pentesting con Metasploit",
                "Análisis de vulnerabilidades OWASP",
                "Criptografía simétrica y asimétrica",
                "Forense digital básico",
                "OSINT y reconocimiento pasivo",
                "Hardening de sistemas",
                "CTF Challenges"
            ),
            fotoUrl = "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80",
            videoUrl = "https://www.youtube.com/embed/3Kq1MIfTWCE",
            links = listOf(
                Link("🔐", "OWASP", "https://owasp.org"),
                Link("🖥", "TryHackMe", "https://tryhackme.com"),
                Link("⚡", "HackTheBox", "https://hackthebox.com")
            ),
            planes = listOf(
                Plan("Básico", 89_000, listOf("Redes y protocolos", "Linux básico", "OWASP Top 10")),
                Plan("Estándar", 189_000, listOf("Pentesting completo", "Metasploit", "Forense básico")),
                Plan("Premium", 350_000, listOf("Red Team / Blue Team", "CTF avanzado", "Certificado VIROX"))
            )
        ),
        Servicio(
            id = "redes",
            ico = "🌐",
            categoria = "Redes",
            titulo = "Redes y Telecomunicaciones",
            subtitulo = "Infraestructura y conectividad",
            color = "green",
            nivel = "Básico → CCNA",
            duracion = "25 – 100 h",
            precioBase = 160_000,
            definicion = "Las redes de computadoras son sistemas que permiten la comunicación e intercambio de datos entre dispositivos. Abarcan desde redes locales hasta la internet global.",
            importancia = "Toda organización moderna requiere redes estables, seguras y eficientes. Los administradores de red son esenciales en cualquier empresa tecnológica.",
            conceptos = listOf(
                Concepto("📡", "Modelo OSI", "7 capas que definen cómo se comunican los sistemas."),
                Concepto("🔀", "Routing", "Algoritmos para dirigir paquetes entre redes."),
                Concepto("🏠", "LAN / WAN", "Redes de área local, amplia y metropolitana."),
                Concepto("☁️", "Cloud Networking", "Redes en AWS, Azure, GCP."),
                Concepto("🔒", "VPN / Tunneling", "Conexiones seguras y cifradas."),
                Concepto("📊", "Monitoreo", "Herramientas como Zabbix, Nagios, Wireshark.")
            ),
            parametros = listOf(
                "Modelo OSI y TCP/IP",
                "Subnetting y VLSM",
                "Routing dinámico OSPF, BGP",
                "Switching: VLANs, STP",
                "Wi-Fi y seguridad inalámbrica",
                "Cisco IOS básico",
                "Firewalls y ACLs",
                "VPN IPSec y SSL"
            ),
            fotoUrl = "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&q=80",
            videoUrl = "https://www.youtube.com/embed/qiQR5rTSshw",
            links = listOf(
                Link("🎓", "Cisco NetAcad", "https://www.netacad.com"),
                Link("📘", "Packet Tracer", "https://www.netacad.com/courses/packet-tracer")
            ),
            planes = listOf(
                Plan("Básico", 69_000, listOf("OSI / TCP-IP", "Subnetting", "Wi-Fi básico")),
                Plan("Estándar", 139_000, listOf("Routing dinámico", "Switching avanzado", "Cisco IOS")),
                Plan("Premium", 269_000, listOf("CCNA prep completa", "Laboratorios reales", "Certificado VIROX"))
            )
        ),
        Servicio(
            id = "ia",
            ico = "🤖",
            categoria = "IA",
            titulo = "Inteligencia Artificial",
            subtitulo = "Machine Learning y Deep Learning",
            color = "purple",
            nivel = "Intermedio → Avanzado",
            duracion = "50 – 200 h",
            precioBase = 250_000,
            definicion = "La inteligencia artificial comprende algoritmos y sistemas que simulan procesos cognitivos humanos: aprendizaje, razonamiento, percepción y toma de decisiones.",
            importancia = "La IA está transformando todos los sectores. Desde diagnóstico médico hasta autos autónomos, los ingenieros de IA lideran la cuarta revolución industrial.",
            conceptos = listOf(
                Concepto("📊", "Machine Learning", "Algoritmos que aprenden de datos sin ser programados explícitamente."),
                Concepto("🧠", "Deep Learning", "Redes neuronales profundas para visión, lenguaje y más."),
                Concepto("💬", "NLP", "Procesamiento de lenguaje natural para chatbots y análisis de texto."),
                Concepto("👁", "Computer Vision", "Reconocimiento de imágenes y video."),
                Concepto("🎮", "Reinforcement Learning", "Agentes que aprenden por recompensas."),
                Concepto("🔧", "MLOps", "Despliegue y mantenimiento de modelos en producción.")
            ),
            parametros = listOf(
                "Python para IA (NumPy, Pandas, Matplotlib)",
                "Regresión, clasificación, clustering",
                "Redes neuronales con TensorFlow / PyTorch",
                "CNN para visión artificial",
                "RNN / LSTM para secuencias",
                "Transformers y LLMs",
                "Fine-tuning de modelos",
                "Despliegue con FastAPI / Docker"
            ),
            fotoUrl = "https://images.unsplash.com/photo-1677442135703-1787eea5ce01?w=800&q=80",
            videoUrl = "https://www.youtube.com/embed/ukzFI9rgwfU",
            links = listOf(
                Link("🤗", "Hugging Face", "https://huggingface.co"),
                Link("🔥", "PyTorch Docs", "https://pytorch.org/docs"),
                Link("📊", "Kaggle", "https://kaggle.com")
            ),
            planes = listOf(
                Plan("Básico", 99_000, listOf("Python para datos", "ML supervisado", "Proyecto de clasificación")),
                Plan("Estándar", 199_000, listOf("Deep Learning", "CNN + NLP", "Proyecto completo")),
                Plan("Premium", 399_000, listOf("LLMs y Transformers", "MLOps", "Mentoría 1:1", "Certificado VIROX"))
            )
        )
    )
}