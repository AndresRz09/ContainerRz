package com.containerrz

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.containerrz.databinding.ActivityMainBinding
import com.containerrz.util.SessionManager

/**
 * MainActivity — single-activity host for ContainerRz.
 * Uses Navigation Component + BottomNavigationView.
 * Design: dark navy (#020817) with gold (#DAA520) + green (#28A680) accents.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private lateinit var session: SessionManager

    // Fragments where the bottom nav should be hidden
    private val hideNavDestinations = setOf(
        R.id.loginFragment,
        R.id.registerFragment,
        R.id.serviceDetailFragment,
        R.id.memberDetailFragment
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        session = SessionManager(this)
        setupNavigation()
        observeNavDestination()
    }

    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Wire bottom nav to Navigation Component
        binding.bottomNav.setupWithNavController(navController)

        // Override perfil nav item: go to login if not authenticated
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_perfil -> {
                    if (session.isLoggedIn()) {
                        navController.navigate(R.id.perfilFragment)
                    } else {
                        navController.navigate(R.id.loginFragment)
                    }
                    true
                }
                else -> {
                    navController.navigate(item.itemId)
                    true
                }
            }
        }
    }

    private fun observeNavDestination() {
        navController.addOnDestinationChangedListener { _, destination, _ ->
            val shouldHide = destination.id in hideNavDestinations
            binding.bottomNav.visibility = if (shouldHide) View.GONE else View.VISIBLE
            binding.navDivider.visibility = if (shouldHide) View.GONE else View.VISIBLE
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}