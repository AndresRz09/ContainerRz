package com.containerrz.util

import android.content.Context
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.containerrz.R
import java.text.NumberFormat
import java.util.Locale

// ─── View extensions ────────────────────────────────────────────────────────

fun View.show() { visibility = View.VISIBLE }
fun View.hide() { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun View.fadeIn(duration: Long = 300) {
    alpha = 0f
    show()
    animate().alpha(1f).setDuration(duration).start()
}

fun View.slideInFromBottom(context: Context) {
    val anim = AnimationUtils.loadAnimation(context, android.R.anim.slide_in_left)
    startAnimation(anim)
}

// ─── ImageView extensions ────────────────────────────────────────────────────

fun ImageView.loadUrl(url: String, placeholder: Int = R.drawable.ic_logo_hex) {
    Glide.with(this)
        .load(url)
        .placeholder(placeholder)
        .error(placeholder)
        .transition(DrawableTransitionOptions.withCrossFade(300))
        .centerCrop()
        .into(this)
}

fun ImageView.loadAvatar(url: String) {
    Glide.with(this)
        .load(url.ifBlank { null })
        .placeholder(R.drawable.ic_nav_perfil)
        .error(R.drawable.ic_nav_perfil)
        .transition(DrawableTransitionOptions.withCrossFade(200))
        .circleCrop()
        .into(this)
}

// ─── Number formatting ──────────────────────────────────────────────────────

fun Long.toCOP(): String {
    val fmt = NumberFormat.getNumberInstance(Locale("es", "CO"))
    return "$ ${fmt.format(this)}"
}

// ─── Color helpers ───────────────────────────────────────────────────────────

fun Context.colorFromServiceColor(colorKey: String): Int {
    return when (colorKey) {
        "green"  -> ContextCompat.getColor(this, R.color.green_accent)
        "gold"   -> ContextCompat.getColor(this, R.color.gold)
        "blue"   -> ContextCompat.getColor(this, R.color.tag_blue)
        "purple" -> ContextCompat.getColor(this, R.color.tag_purple)
        else     -> ContextCompat.getColor(this, R.color.green_accent)
    }
}

// ─── String helpers ──────────────────────────────────────────────────────────

fun String.capitalizeFirst(): String =
    if (isEmpty()) this else this[0].uppercase() + substring(1)

fun List<String>.toChipText(): String = joinToString(" · ")

// ─── Countdown animator ─────────────────────────────────────────────────────

/**
 * Animates a TextView's text from 0 to [target] over [durationMs].
 * Mirrors the JavaScript counter animation in index.php.
 */
fun TextView.animateCounter(target: Int, durationMs: Long = 1200) {
    val steps = 40
    val delay = durationMs / steps
    var current = 0
    val increment = (target / steps).coerceAtLeast(1)

    val runnable = object : Runnable {
        override fun run() {
            current += increment
            if (current >= target) {
                text = target.toString()
                return
            }
            text = current.toString()
            postDelayed(this, delay)
        }
    }
    post(runnable)
}